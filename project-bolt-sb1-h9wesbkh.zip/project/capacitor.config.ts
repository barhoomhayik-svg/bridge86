import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.dentallink.app',
  appName: 'Bridge',
  webDir: 'dist',
  server: {
    // Remove this block for production builds. For live dev/testing
    // over the network, set androidScheme to 'https' and optionally
    // point url to your local dev server IP:
    // url: 'http://192.168.x.x:5173',
    androidScheme: 'https',
  },
  ios: {
    contentInset: 'automatic',
    backgroundColor: '#ffffff',
  },
  android: {
    backgroundColor: '#ffffff',
  },
  plugins: {
    SplashScreen: {
      launchShowDuration: 1500,
      backgroundColor: '#2563eb',
      androidSplashResourceName: 'splash',
      showSpinner: false,
    },
    StatusBar: {
      style: 'DEFAULT',
      backgroundColor: '#2563eb',
    },
  },
};

export default config;
