import React, { useState } from 'react';
import { supabase } from '../lib/supabase';
import { Building2, Stethoscope, FlaskConical, Eye, EyeOff, CheckCircle2, ArrowLeft, Mail, Loader2, MailCheck, Send, Sparkles } from 'lucide-react';
import BridgeLogo from '../components/BridgeLogo';

type Mode = 'login' | 'register';
type Role = 'center' | 'doctor' | 'lab';

const roles = [
  { value: 'center' as Role, label: 'Dental Center', desc: 'A clinic or dental center placing orders', icon: Building2 },
  { value: 'doctor' as Role, label: 'Dentist / Doctor', desc: 'An individual dental practitioner', icon: Stethoscope },
  { value: 'lab' as Role, label: 'Dental Laboratory', desc: 'A lab receiving and fulfilling orders', icon: FlaskConical },
];

const countryDialCodes: Record<string, string> = {
  'Saudi Arabia': '+966', 'United Arab Emirates': '+971', 'Egypt': '+20', 'Qatar': '+974',
  'Kuwait': '+965', 'Bahrain': '+973', 'Oman': '+968', 'Jordan': '+962', 'Lebanon': '+961',
  'Syria': '+963', 'Iraq': '+964', 'Yemen': '+967', 'Palestine': '+970', 'Israel': '+972',
  'Turkey': '+90', 'Iran': '+98',
  'Afghanistan': '+93', 'Albania': '+355', 'Algeria': '+213', 'Andorra': '+376', 'Angola': '+244',
  'Antigua and Barbuda': '+1', 'Argentina': '+54', 'Armenia': '+374', 'Australia': '+61',
  'Austria': '+43', 'Azerbaijan': '+994', 'Bahamas': '+1', 'Bangladesh': '+880', 'Barbados': '+1',
  'Belarus': '+375', 'Belgium': '+32', 'Belize': '+501', 'Benin': '+229', 'Bhutan': '+975',
  'Bolivia': '+591', 'Bosnia and Herzegovina': '+387', 'Botswana': '+267', 'Brazil': '+55',
  'Brunei': '+673', 'Bulgaria': '+359', 'Burkina Faso': '+226', 'Burundi': '+257', 'Cabo Verde': '+238',
  'Cambodia': '+855', 'Cameroon': '+237', 'Canada': '+1', 'Central African Republic': '+236',
  'Chad': '+235', 'Chile': '+56', 'China': '+86', 'Colombia': '+57', 'Comoros': '+269',
  'Congo (Brazzaville)': '+242', 'Congo (Kinshasa)': '+243', 'Costa Rica': '+506', 'Croatia': '+385',
  'Cuba': '+53', 'Cyprus': '+357', 'Czechia': '+420', "Côte d'Ivoire": '+225', 'Denmark': '+45',
  'Djibouti': '+253', 'Dominica': '+1', 'Dominican Republic': '+1', 'Ecuador': '+593',
  'El Salvador': '+503', 'Equatorial Guinea': '+240', 'Eritrea': '+291', 'Estonia': '+372',
  'Eswatini': '+268', 'Ethiopia': '+251', 'Fiji': '+679', 'Finland': '+358', 'France': '+33',
  'Gabon': '+241', 'Gambia': '+220', 'Georgia': '+995', 'Germany': '+49', 'Ghana': '+233',
  'Greece': '+30', 'Grenada': '+1', 'Guatemala': '+502', 'Guinea': '+224', 'Guinea-Bissau': '+245',
  'Guyana': '+592', 'Haiti': '+509', 'Honduras': '+504', 'Hungary': '+36', 'Iceland': '+354',
  'India': '+91', 'Indonesia': '+62', 'Ireland': '+353', 'Italy': '+39', 'Jamaica': '+1',
  'Japan': '+81', 'Kazakhstan': '+7', 'Kenya': '+254', 'Kiribati': '+686', 'Kosovo': '+383',
  'Kyrgyzstan': '+996', 'Laos': '+856', 'Latvia': '+371', 'Lesotho': '+266', 'Liberia': '+231',
  'Libya': '+218', 'Liechtenstein': '+423', 'Lithuania': '+370', 'Luxembourg': '+352',
  'Madagascar': '+261', 'Malawi': '+265', 'Malaysia': '+60', 'Maldives': '+960', 'Mali': '+223',
  'Malta': '+356', 'Marshall Islands': '+692', 'Mauritania': '+222', 'Mauritius': '+230',
  'Mexico': '+52', 'Micronesia': '+691', 'Moldova': '+373', 'Monaco': '+377', 'Mongolia': '+976',
  'Montenegro': '+382', 'Morocco': '+212', 'Mozambique': '+258', 'Myanmar': '+95', 'Namibia': '+264',
  'Nauru': '+674', 'Nepal': '+977', 'Netherlands': '+31', 'New Zealand': '+64', 'Nicaragua': '+505',
  'Niger': '+227', 'Nigeria': '+234', 'North Korea': '+850', 'North Macedonia': '+389',
  'Norway': '+47', 'Pakistan': '+92', 'Palau': '+680', 'Panama': '+507', 'Papua New Guinea': '+675',
  'Paraguay': '+595', 'Peru': '+51', 'Philippines': '+63', 'Poland': '+48', 'Portugal': '+351',
  'Romania': '+40', 'Russia': '+7', 'Rwanda': '+250', 'Saint Kitts and Nevis': '+1',
  'Saint Lucia': '+1', 'Saint Vincent and the Grenadines': '+1', 'Samoa': '+685', 'San Marino': '+378',
  'Sao Tome and Principe': '+239', 'Senegal': '+221', 'Serbia': '+381', 'Seychelles': '+248',
  'Sierra Leone': '+232', 'Singapore': '+65', 'Slovakia': '+421', 'Slovenia': '+386',
  'Solomon Islands': '+677', 'Somalia': '+252', 'South Africa': '+27', 'South Korea': '+82',
  'South Sudan': '+211', 'Spain': '+34', 'Sri Lanka': '+94', 'Sudan': '+249', 'Suriname': '+597',
  'Sweden': '+46', 'Switzerland': '+41', 'Taiwan': '+886', 'Tajikistan': '+992', 'Tanzania': '+255',
  'Thailand': '+66', 'Timor-Leste': '+670', 'Togo': '+228', 'Tonga': '+676', 'Trinidad and Tobago': '+1',
  'Tunisia': '+216', 'Turkmenistan': '+993', 'Tuvalu': '+688', 'Uganda': '+256', 'Ukraine': '+380',
  'United Kingdom': '+44', 'United States': '+1', 'Uruguay': '+598', 'Uzbekistan': '+998',
  'Vanuatu': '+678', 'Vatican City': '+39', 'Venezuela': '+58', 'Vietnam': '+84', 'Zambia': '+260',
  'Zimbabwe': '+263',
};

const middleEastCountries = [
  'Saudi Arabia', 'United Arab Emirates', 'Egypt', 'Qatar', 'Kuwait', 'Bahrain', 'Oman',
  'Jordan', 'Lebanon', 'Syria', 'Iraq', 'Yemen', 'Palestine', 'Israel', 'Turkey', 'Iran',
];

const otherCountries = Object.keys(countryDialCodes)
  .filter(c => !middleEastCountries.includes(c))
  .sort((a, b) => a.localeCompare(b));

export default function AuthPage({ onBack }: { onBack?: () => void }) {
  const [mode, setMode] = useState<Mode>('login');
  const [role, setRole] = useState<Role>('center');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [country, setCountry] = useState('');
  const [phone, setPhone] = useState('');
  const [showPass, setShowPass] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState(false);
  const [needsEmailVerification, setNeedsEmailVerification] = useState(false);
  const [slideDir, setSlideDir] = useState<1 | -1>(1);
  const [forgot, setForgot] = useState(false);
  const [forgotEmail, setForgotEmail] = useState('');
  const [forgotLoading, setForgotLoading] = useState(false);
  const [forgotSent, setForgotSent] = useState(false);
  const [forgotError, setForgotError] = useState('');
  const [resending, setResending] = useState(false);
  const [resendSent, setResendSent] = useState(false);
  const [pendingEmail, setPendingEmail] = useState('');
  const [magicLink, setMagicLink] = useState(false);
  const [magicEmail, setMagicEmail] = useState('');
  const [magicLoading, setMagicLoading] = useState(false);
  const [magicSent, setMagicSent] = useState(false);
  const [magicError, setMagicError] = useState('');


  const handleForgot = async (e: React.FormEvent) => {
    e.preventDefault();
    setForgotError('');
    setForgotLoading(true);
    try {
      const { error } = await supabase.auth.resetPasswordForEmail(forgotEmail, {
        redirectTo: window.location.origin,
      });
      if (error) throw error;
      setForgotSent(true);
    } catch (err: unknown) {
      setForgotError('Could not send the reset email right now. Please try again in a moment.');
    } finally {
      setForgotLoading(false);
    }
  };

  const closeForgot = () => {
    setForgot(false);
    setForgotSent(false);
    setForgotEmail('');
    setForgotError('');
  };

  const switchMode = (m: Mode, dir: 1 | -1) => {
    setSlideDir(dir);
    setMode(m);
    setError('');
    setSuccess(false);
    setNeedsEmailVerification(false);
    setResendSent(false);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    if (mode === 'register' && !/(?=.*[a-z])(?=.*[A-Z])(?=.*[^A-Za-z0-9]).{6,}/.test(password)) {
      setError('Password must be at least 6 characters and include a lowercase letter, an uppercase letter, and a symbol.');
      return;
    }
    setLoading(true);
    try {
      if (mode === 'login') {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) {
          // One message for every failure, so the form never reveals whether an
          // account exists or whether its email is still unconfirmed.
          setPendingEmail(email);
          throw new Error(
            'We could not sign you in. Check your email and password, and if you just registered, confirm your email using the link we sent you.',
          );
        }
      } else {
        const { data, error } = await supabase.auth.signUp({
          email,
          password,
          options: {
            emailRedirectTo: window.location.origin,
            data: {
              role,
              name,
              full_name: name,
              phone: phone ? `${countryDialCodes[country] ?? ''}${phone}` : null,
              country: country || null,
            },
          },
        });
        if (error) {
          // Generic message: a distinct "already registered" error would let
          // anyone test which email addresses have accounts.
          throw new Error('Could not create your account. If you already have one, sign in or reset your password instead.');
        }
        // Never let a new account into the app before the email is verified.
        // If Supabase returns an active session (email confirmation disabled),
        // sign back out so the user must confirm the link first.
        if (data.session) {
          await supabase.auth.signOut();
        }
        setNeedsEmailVerification(true);
        setPendingEmail(email);
        setSuccess(true);
        setPassword('');
      }
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Something went wrong');
    } finally {
      setLoading(false);
    }
  };

  const handleResendVerification = async () => {
    if (!pendingEmail) return;
    setResending(true);
    setResendSent(false);
    try {
      const { error } = await supabase.auth.resend({
        type: 'signup',
        email: pendingEmail,
        options: { emailRedirectTo: window.location.origin },
      });
      if (error) throw error;
      setResendSent(true);
    } catch (err: unknown) {
      setError('Could not resend the confirmation email right now. Please try again in a moment.');
    } finally {
      setResending(false);
    }
  };

  const handleMagicLink = async (e: React.FormEvent) => {
    e.preventDefault();
    setMagicError('');
    setMagicLoading(true);
    try {
      const { error } = await supabase.auth.signInWithOtp({
        email: magicEmail,
        options: { emailRedirectTo: window.location.origin },
      });
      if (error) throw error;
      setMagicSent(true);
    } catch (err: unknown) {
      setMagicError('Could not send the magic link. Please try again in a moment.');
    } finally {
      setMagicLoading(false);
    }
  };

  const closeMagicLink = () => {
    setMagicLink(false);
    setMagicSent(false);
    setMagicEmail('');
    setMagicError('');
  };

  const [oauthRolePicker, setOauthRolePicker] = useState<'google' | 'apple' | null>(null);
  const [oauthRole, setOauthRole] = useState<Role>('center');

  const startOAuth = (provider: 'google' | 'apple') => {
    setOauthRolePicker(provider);
  };

  const confirmOAuthRole = async () => {
    if (!oauthRolePicker) return;
    setError('');
    setLoading(true);
    localStorage.setItem('pending_oauth_role', oauthRole);
    try {
      const { error } = await supabase.auth.signInWithOAuth({
        provider: oauthRolePicker,
        options: {
          redirectTo: window.location.origin,
        },
      });
      if (error) throw error;
    } catch (err: unknown) {
      console.error('oauth sign-in failed', err);
      localStorage.removeItem('pending_oauth_role');
      setError('Could not start sign-in. Please try again.');
      setLoading(false);
    }
  };

  if (oauthRolePicker) {
    return (
      <div className="relative min-h-dvh bg-white flex items-center justify-center p-4 py-safe px-safe overflow-hidden">
        <div className="relative w-full max-w-md">
          <button
            onClick={() => { setOauthRolePicker(null); setLoading(false); }}
            className="absolute top-4 left-4 flex items-center gap-1.5 text-sm text-neutral-500 hover:text-neutral-900 transition-colors z-10"
          >
            <ArrowLeft className="w-4 h-4" />
            Back
          </button>

          <div className="flex items-center justify-center gap-3 mb-8 pt-safe-sm">
            <img src="/logo_%20copy%202.png" alt="Bridge" className="w-10 h-10 rounded-xl object-contain" />
            <div>
              <h1 className="text-neutral-900 font-bold text-fluid-xl leading-none">Bridge</h1>
              <p className="text-neutral-500 text-fluid-xs">Lab Ordering Platform</p>
            </div>
          </div>

          <div className="bg-white rounded-2xl border border-neutral-200 shadow-sm p-6">
            <h2 className="text-lg font-bold text-neutral-900 text-center mb-1">Choose your account type</h2>
            <p className="text-sm text-neutral-500 text-center mb-6">
              Select what best describes you before signing in with {oauthRolePicker === 'google' ? 'Google' : 'Apple'}
            </p>

            <div className="space-y-2 mb-6">
              {roles.map(r => {
                const Icon = r.icon;
                return (
                  <label
                    key={r.value}
                    className={`flex items-center gap-3 p-3.5 rounded-xl border-2 cursor-pointer transition-all ${
                      oauthRole === r.value ? 'border-primary-500 bg-primary-50' : 'border-neutral-200 hover:border-neutral-300'
                    }`}
                  >
                    <input type="radio" name="oauth-role" value={r.value} checked={oauthRole === r.value} onChange={() => setOauthRole(r.value)} className="sr-only" />
                    <div className={`w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0 ${oauthRole === r.value ? 'bg-primary-500' : 'bg-neutral-100'}`}>
                      <Icon className={`w-5 h-5 ${oauthRole === r.value ? 'text-white' : 'text-neutral-500'}`} />
                    </div>
                    <div className="min-w-0">
                      <p className="text-sm font-semibold text-neutral-800">{r.label}</p>
                      <p className="text-xs text-neutral-500">{r.desc}</p>
                    </div>
                  </label>
                );
              })}
            </div>

            <button
              onClick={confirmOAuthRole}
              disabled={loading}
              className="w-full py-3 bg-primary-600 hover:bg-primary-700 disabled:bg-primary-400 text-white font-semibold rounded-lg text-sm transition-colors flex items-center justify-center gap-2"
            >
              {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : null}
              {loading ? 'Connecting...' : `Continue with ${oauthRolePicker === 'google' ? 'Google' : 'Apple'}`}
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="relative min-h-dvh bg-white flex items-center justify-center p-4 py-safe px-safe overflow-hidden">
      <div className="relative w-full max-w-md">
        {/* Logo */}
        <div className="flex items-center justify-center gap-3 mb-8 pt-safe-sm">
          <img
            src="/logo_%20copy%202.png"
            alt="Bridge"
            className="w-10 h-10 rounded-xl object-contain"
          />
          <div>
            <h1 className="text-neutral-900 font-bold text-fluid-xl leading-none">Bridge</h1>
            <p className="text-neutral-500 text-fluid-xs">Lab Ordering Platform</p>
          </div>
        </div>
        {onBack && (
          <button onClick={onBack}
            className="absolute top-4 left-4 flex items-center gap-1.5 text-sm text-neutral-500 hover:text-neutral-900 transition-colors z-10">
            <ArrowLeft className="w-4 h-4" />
            Back
          </button>
        )}

        <div className="bg-white rounded-2xl shadow-modal overflow-hidden border border-neutral-200">
          {/* Tab switcher */}
          <div className="flex border-b border-neutral-200">
            {(['login', 'register'] as Mode[]).map((m, i) => (
              <button
                key={m}
                onClick={() => switchMode(m, m === 'login' ? -1 : 1)}
                className={`flex-1 py-4 text-sm font-semibold transition-colors ${
                  mode === m ? 'text-primary-600 border-b-2 border-primary-600' : 'text-neutral-500 hover:text-neutral-700'
                }`}
              >
                {m === 'login' ? 'Sign In' : 'Create Account'}
              </button>
            ))}
          </div>

          <div className="overflow-hidden">
          {magicLink ? (
            <div
              key="magic"
              style={{ animation: 'slideIn-left 0.42s cubic-bezier(0.22, 1, 0.36, 1)' }}
            >
              <div className="p-6">
                <button
                  onClick={closeMagicLink}
                  className="flex items-center gap-1.5 text-sm text-neutral-500 hover:text-neutral-700 mb-4 transition-colors"
                >
                  <ArrowLeft className="w-4 h-4" />
                  Back to sign in
                </button>

                {magicSent ? (
                  <div className="text-center py-6" style={{ animation: 'fadeInDown 0.4s ease' }}>
                    <div className="w-14 h-14 bg-primary-50 rounded-full flex items-center justify-center mx-auto mb-4">
                      <Mail className="w-7 h-7 text-primary-500" />
                    </div>
                    <h3 className="text-lg font-bold text-neutral-800 mb-2">Check your email</h3>
                    <p className="text-sm text-neutral-500 mb-2">
                      We sent a magic link to
                    </p>
                    <p className="text-sm font-semibold text-neutral-800 mb-5 break-all">{magicEmail}</p>
                    <p className="text-sm text-neutral-500 mb-6">
                      Click the link in the email to sign in instantly -- no password needed.
                    </p>
                    <button
                      onClick={closeMagicLink}
                      className="w-full py-2.5 bg-primary-600 hover:bg-primary-700 text-white font-semibold rounded-lg text-sm transition-colors"
                    >
                      Back to sign in
                    </button>
                  </div>
                ) : (
                  <>
                    <div className="flex items-center gap-2 mb-1.5">
                      <Sparkles className="w-5 h-5 text-primary-500" />
                      <h3 className="text-lg font-bold text-neutral-800">Magic Link</h3>
                    </div>
                    <p className="text-sm text-neutral-500 mb-5">
                      Enter your email and we'll send you a link to sign in instantly without a password.
                    </p>
                    <form onSubmit={handleMagicLink} className="space-y-4">
                      <div>
                        <label className="block text-xs font-semibold text-neutral-600 mb-1.5 uppercase tracking-wide">Email</label>
                        <input
                          type="email" required value={magicEmail} onChange={e => setMagicEmail(e.target.value)}
                          placeholder="you@example.com"
                          className="w-full px-3.5 py-2.5 rounded-lg border border-neutral-300 text-sm focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                        />
                      </div>
                      {magicError && (
                        <div className="bg-red-50 border border-red-200 text-red-700 text-sm rounded-lg px-3.5 py-2.5">{magicError}</div>
                      )}
                      <button
                        type="submit" disabled={magicLoading}
                        className="w-full py-2.5 bg-primary-600 hover:bg-primary-700 disabled:bg-primary-400 text-white font-semibold rounded-lg text-sm transition-colors flex items-center justify-center gap-2"
                      >
                        {magicLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Mail className="w-4 h-4" />}
                        {magicLoading ? 'Sending...' : 'Send Magic Link'}
                      </button>
                    </form>
                  </>
                )}
              </div>
            </div>
          ) : forgot ? (
            <div
              key="forgot"
              style={{ animation: 'slideIn-left 0.42s cubic-bezier(0.22, 1, 0.36, 1)' }}
            >
              <div className="p-6">
                <button
                  onClick={closeForgot}
                  className="flex items-center gap-1.5 text-sm text-neutral-500 hover:text-neutral-700 mb-4 transition-colors"
                >
                  <ArrowLeft className="w-4 h-4" />
                  Back to sign in
                </button>

                {forgotSent ? (
                  <div className="text-center py-6" style={{ animation: 'fadeInDown 0.4s ease' }}>
                    <div className="w-14 h-14 bg-primary-50 rounded-full flex items-center justify-center mx-auto mb-4">
                      <Mail className="w-7 h-7 text-primary-500" />
                    </div>
                    <h3 className="text-lg font-bold text-neutral-800 mb-2">Check your email</h3>
                    <p className="text-sm text-neutral-500 mb-6">
                      We sent a password reset link to <span className="font-semibold text-neutral-700">{forgotEmail}</span>. Click the link in the email to reset your password.
                    </p>
                    <button
                      onClick={closeForgot}
                      className="w-full py-2.5 bg-primary-600 hover:bg-primary-700 text-white font-semibold rounded-lg text-sm transition-colors"
                    >
                      Back to sign in
                    </button>
                  </div>
                ) : (
                  <>
                    <h3 className="text-lg font-bold text-neutral-800 mb-1.5">Forgot password?</h3>
                    <p className="text-sm text-neutral-500 mb-5">
                      Enter your email and we'll send you a link to reset your password.
                    </p>
                    <form onSubmit={handleForgot} className="space-y-4">
                      <div>
                        <label className="block text-xs font-semibold text-neutral-600 mb-1.5 uppercase tracking-wide">Email</label>
                        <input
                          type="email" required value={forgotEmail} onChange={e => setForgotEmail(e.target.value)}
                          placeholder="you@example.com"
                          className="w-full px-3.5 py-2.5 rounded-lg border border-neutral-300 text-sm focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                        />
                      </div>
                      {forgotError && (
                        <div className="bg-red-50 border border-red-200 text-red-700 text-sm rounded-lg px-3.5 py-2.5">{forgotError}</div>
                      )}
                      <button
                        type="submit" disabled={forgotLoading}
                        className="w-full py-2.5 bg-primary-600 hover:bg-primary-700 disabled:bg-primary-400 text-white font-semibold rounded-lg text-sm transition-colors"
                      >
                        {forgotLoading ? 'Sending...' : 'Send reset link'}
                      </button>
                    </form>
                  </>
                )}
              </div>
            </div>
          ) : (
          <div
            key={mode}
            style={{ animation: `slideIn-${slideDir === 1 ? 'right' : 'left'} 0.42s cubic-bezier(0.22, 1, 0.36, 1)` }}
          >
          {success && needsEmailVerification ? (
            <div className="p-6 text-center" style={{ animation: 'fadeInDown 0.4s ease' }}>
              <div className="w-16 h-16 bg-primary-50 rounded-full flex items-center justify-center mx-auto mb-4">
                <MailCheck className="w-8 h-8 text-primary-500" />
              </div>
              <h3 className="text-lg font-bold text-neutral-800 mb-2">Verify your email</h3>
              <p className="text-sm text-neutral-500 mb-1">
                We sent a confirmation link to
              </p>
              <p className="text-sm font-semibold text-neutral-800 mb-5 break-all">{pendingEmail || email}</p>
              <p className="text-sm text-neutral-500 mb-6">
                Click the link in the email to activate your account, then return here to sign in.
              </p>
              {resendSent ? (
                <div className="flex items-center justify-center gap-2 text-sm text-primary-600 mb-4">
                  <CheckCircle2 className="w-4 h-4" /> Verification email sent again
                </div>
              ) : (
                <button
                  type="button"
                  onClick={handleResendVerification}
                  disabled={resending}
                  className="w-full py-2.5 border border-primary-300 text-primary-600 hover:bg-primary-50 disabled:opacity-50 font-semibold rounded-lg text-sm transition-colors flex items-center justify-center gap-2 mb-4"
                >
                  {resending ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
                  Resend verification email
                </button>
              )}
              <button
                type="button"
                onClick={() => { setSuccess(false); setNeedsEmailVerification(false); setMode('login'); setSlideDir(-1); }}
                className="w-full py-2.5 bg-primary-600 hover:bg-primary-700 text-white font-semibold rounded-lg text-sm transition-colors"
              >
                Back to sign in
              </button>
            </div>
          ) : (
          <>
          {success && (
            <div className="mx-6 mt-4 flex items-center gap-2.5 bg-primary-50 border border-primary-200 text-primary-700 text-sm rounded-lg px-3.5 py-2.5"
              style={{ animation: 'fadeInDown 0.4s ease' }}
            >
              <CheckCircle2 className="w-5 h-5 text-primary-500 flex-shrink-0" />
              <span>Account created! Please sign in to continue.</span>
            </div>
          )}
          <form onSubmit={handleSubmit} className="p-6 space-y-4">
            {mode === 'register' && (
              <>
                <div>
                  <label className="block text-xs font-semibold text-neutral-600 mb-2 uppercase tracking-wide">Account Type</label>
                  <div className="grid grid-cols-1 gap-2">
                    {roles.map(r => {
                      const Icon = r.icon;
                      return (
                        <label
                          key={r.value}
                          className={`flex items-center gap-3 p-3 rounded-xl border-2 cursor-pointer transition-all ${
                            role === r.value ? 'border-primary-500 bg-primary-50' : 'border-neutral-200 hover:border-neutral-300'
                          }`}
                        >
                          <input type="radio" name="role" value={r.value} checked={role === r.value} onChange={() => setRole(r.value)} className="sr-only" />
                          <div className={`w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0 ${role === r.value ? 'bg-primary-500' : 'bg-neutral-100'}`}>
                            <Icon className={`w-4 h-4 ${role === r.value ? 'text-white' : 'text-neutral-500'}`} />
                          </div>
                          <div className="min-w-0">
                            <p className="text-sm font-semibold text-neutral-800">{r.label}</p>
                            <p className="text-xs text-neutral-500">{r.desc}</p>
                          </div>
                        </label>
                      );
                    })}
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-neutral-600 mb-1.5 uppercase tracking-wide">
                    {role === 'lab' ? 'Lab Name' : role === 'center' ? 'Center Name' : 'Doctor Name'}
                  </label>
                  <input
                    type="text" required value={name} onChange={e => setName(e.target.value)}
                    placeholder="Full name"
                    className="w-full px-3.5 py-2.5 rounded-lg border border-neutral-300 text-sm focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-semibold text-neutral-600 mb-1.5 uppercase tracking-wide">Country</label>
                    <select
                      required value={country} onChange={e => setCountry(e.target.value)}
                      className="w-full px-3.5 py-2.5 rounded-lg border border-neutral-300 bg-white text-sm focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                    >
                      <option value="">Select country</option>
                      <optgroup label="Middle East">
                        {middleEastCountries.map(option => <option key={option} value={option}>{option}</option>)}
                      </optgroup>
                      <optgroup label="All countries">
                        {otherCountries.map(option => <option key={option} value={option}>{option}</option>)}
                      </optgroup>
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-neutral-600 mb-1.5 uppercase tracking-wide">Phone</label>
                    <div className="relative">
                      <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-sm text-neutral-500 pointer-events-none select-none">
                        {country ? countryDialCodes[country] ?? '+' : '+'}
                      </span>
                      <input
                        type="tel" inputMode="numeric" value={phone}
                        onChange={e => setPhone(e.target.value.replace(/[^0-9]/g, ''))}
                        placeholder="1234567890"
                        className="w-full pl-14 pr-3.5 py-2.5 rounded-lg border border-neutral-300 text-sm focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                      />
                    </div>
                  </div>
                </div>
              </>
            )}

            <div>
              <label className="block text-xs font-semibold text-neutral-600 mb-1.5 uppercase tracking-wide">Email</label>
              <input
                type="email" required value={email} onChange={e => setEmail(e.target.value)}
                placeholder="you@example.com"
                className="w-full px-3.5 py-2.5 rounded-lg border border-neutral-300 text-sm focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-transparent"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-neutral-600 mb-1.5 uppercase tracking-wide">Password</label>
              <div className="relative">
                <input
                  type={showPass ? 'text' : 'password'} required value={password} onChange={e => setPassword(e.target.value)}
                  minLength={mode === 'register' ? 6 : undefined}
                  pattern={mode === 'register' ? '(?=.*[a-z])(?=.*[A-Z])(?=.*[^A-Za-z0-9]).{6,}' : undefined}
                  title={mode === 'register' ? 'Use at least 6 characters with a lowercase letter, an uppercase letter, and a symbol.' : undefined}
                  placeholder={mode === 'register' ? '6+ chars: Aa and a symbol' : 'Enter your password'}
                  className="w-full px-3.5 py-2.5 pr-10 rounded-lg border border-neutral-300 text-sm focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                />
                <button type="button" onClick={() => setShowPass(!showPass)} className="absolute right-3 top-1/2 -translate-y-1/2 text-neutral-400 hover:text-neutral-600">
                  {showPass ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
              {mode === 'login' && (
                <button
                  type="button"
                  onClick={() => { setForgot(true); setForgotSent(false); setForgotError(''); }}
                  className="mt-2 text-xs font-medium text-primary-600 hover:text-primary-700 transition-colors"
                >
                  Forgot password?
                </button>
              )}
            </div>

            {error && (
              <div className="bg-red-50 border border-red-200 text-red-700 text-sm rounded-lg px-3.5 py-2.5 space-y-2">
                <p>{error}</p>
                {mode === 'login' && pendingEmail && (
                  resendSent ? (
                    <p className="text-red-600/80 text-xs">If that address needs confirming, a new link is on its way.</p>
                  ) : (
                    <button
                      type="button"
                      onClick={handleResendVerification}
                      disabled={resending}
                      className="text-xs font-semibold text-red-700 underline underline-offset-2 disabled:opacity-60"
                    >
                      {resending ? 'Sending...' : 'Resend confirmation email'}
                    </button>
                  )
                )}
              </div>
            )}

            <button
              type="submit" disabled={loading}
              className="w-full py-2.5 bg-primary-600 hover:bg-primary-700 disabled:bg-primary-400 text-white font-semibold rounded-lg text-sm transition-colors"
            >
              {loading ? 'Please wait...' : mode === 'login' ? 'Sign In' : 'Create Account'}
            </button>

            <div className="relative py-1">
              <div className="absolute inset-0 flex items-center"><div className="w-full border-t border-neutral-200" /></div>
              <div className="relative flex justify-center"><span className="bg-white px-3 text-xs text-neutral-400">or continue with</span></div>
            </div>



            <div className="grid grid-cols-2 gap-3">
              <button
                type="button"
                onClick={() => startOAuth('google')}
                disabled={loading}
                className="flex items-center justify-center gap-2 py-2.5 border border-neutral-300 rounded-lg text-sm font-semibold text-neutral-700 hover:bg-neutral-50 disabled:opacity-50 transition-colors"
              >
                {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : (
                  <svg className="w-4 h-4" viewBox="0 0 24 24">
                    <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                    <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                    <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/>
                    <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
                  </svg>
                )}
                Google
              </button>
              <button
                type="button"
                onClick={() => startOAuth('apple')}
                disabled={loading}
                className="flex items-center justify-center gap-2 py-2.5 border border-neutral-300 rounded-lg text-sm font-semibold text-neutral-700 hover:bg-neutral-50 disabled:opacity-50 transition-colors"
              >
                {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : (
                  <svg className="w-4 h-4" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M17.05 20.28c-.98.95-2.05.88-3.08.4-1.09-.5-2.08-.48-3.24 0-1.44.62-2.2.44-3.06-.4C2.79 15.25 3.51 7.59 9.05 7.31c1.35.07 2.29.74 3.08.8 1.18-.24 2.31-.93 3.57-.84 1.51.12 2.65.72 3.4 1.8-3.12 1.87-2.38 5.98.48 7.13-.57 1.5-1.31 2.99-2.54 4.09zM12.03 7.25c-.15-2.23 1.66-4.07 3.74-4.25.29 2.58-2.34 4.5-3.74 4.25z"/>
                  </svg>
                )}
                Apple
              </button>
            </div>
          </form>
          {mode === 'login' && !success && (
            <div className="px-6 pb-4 -mt-2">
              <p className="text-center text-xs text-neutral-400">
                Drivers: sign in with the credentials your lab provided.
              </p>
            </div>
          )}
          </>
          )}
          </div>
          )}
        </div>

        <div className="text-center mt-6 pb-safe-sm space-y-2">
          <div className="flex items-center justify-center gap-3 text-xs text-neutral-400">
            <a href="/privacy-policy" className="hover:text-neutral-700 transition-colors">Privacy Policy</a>
            <span>&middot;</span>
            <a href="/terms-of-service" className="hover:text-neutral-700 transition-colors">Terms of Service</a>
          </div>
          <p className="text-neutral-400 text-fluid-xs">&copy; 2026 Bridge 86. All rights reserved.</p>
        </div>
      </div>
    </div>
    </div>
  );
}
