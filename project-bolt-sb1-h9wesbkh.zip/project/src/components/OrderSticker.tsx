import React, { useEffect, useMemo, useRef, useState } from 'react';
import QRCode from 'qrcode';
import { Order } from '../lib/supabase';
import { X, Printer } from 'lucide-react';

interface Props {
  order: Order;
  onClose: () => void;
}

interface Row {
  label: string;
  value: string;
}

export default function OrderSticker({ order, onClose }: Props) {
  const [qrDataUrl, setQrDataUrl] = useState('');
  const [logoDataUrl, setLogoDataUrl] = useState('');
  const iframeRef = useRef<HTMLIFrameElement | null>(null);

  useEffect(() => {
    const base = import.meta.env.VITE_SUPABASE_URL as string;
    const payload = `${base}/functions/v1/order-view?id=${order.id}`;
    QRCode.toDataURL(payload, { margin: 0, width: 512, errorCorrectionLevel: 'M' })
      .then(setQrDataUrl)
      .catch(() => setQrDataUrl(''));
  }, [order.id]);

  useEffect(() => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => {
      const c = document.createElement('canvas');
      c.width = img.naturalWidth;
      c.height = img.naturalHeight;
      const cx = c.getContext('2d');
      if (cx) {
        cx.drawImage(img, 0, 0);
        setLogoDataUrl(c.toDataURL('image/png'));
      }
    };
    img.src = '/logo_ copy 7.png';
  }, []);

  const rows: Row[] = useMemo(() => {
    const dash = '—';
    return [
      { label: 'Dr', value: (order.dr_name || '').trim() || dash },
      { label: 'Pt', value: (order.patient_name || '').trim() || dash },
      { label: 'File', value: (order.file_number || '').trim() || dash },
    ];
  }, [order]);

  const buildStickerHtml = () => `<!doctype html><html><head><meta charset="utf-8" /><title>Sticker ${escapeHtml(order.order_number)}</title>
<style>
  @page { size: 80mm 50mm; margin: 0; }
  * { box-sizing: border-box; }
  html, body { margin: 0; padding: 0; font-family: -apple-system, "Segoe UI", Roboto, sans-serif; -webkit-print-color-adjust: exact; print-color-adjust: exact; }
  .card { width: 80mm; height: 50mm; padding: 3mm; display: flex; gap: 3mm; align-items: stretch; background: #ffffff; }
  .qr { width: 26mm; height: 26mm; flex-shrink: 0; align-self: center; }
  .qr img { width: 100%; height: 100%; display: block; }
  .info { flex: 1; min-width: 0; display: flex; flex-direction: column; justify-content: center; gap: 0.4mm; color: #0f172a; }
  .info .num { font-weight: 800; font-size: 11pt; letter-spacing: -0.02em; color: #0f172a; line-height: 1.05; margin-bottom: 0.6mm; }
  .info .row { font-size: 7pt; line-height: 1.2; color: #0f172a; word-wrap: break-word; overflow-wrap: anywhere; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
  .info .row .lbl { color: #64748b; font-size: 5.5pt; font-weight: 700; text-transform: uppercase; letter-spacing: 0.04em; margin-right: 1mm; }
  .info .row .val { font-weight: 600; }
  .brand { margin-top: 0.6mm; display: flex; align-items: center; }
  .brand img { height: 5mm; width: auto; display: block; }
</style></head><body>
<div class="card">
  <div class="qr"><img src="${qrDataUrl}" alt="QR" /></div>
  <div class="info">
    <div class="num">#${escapeHtml(order.order_number)}</div>
    ${rows.map(r => `<div class="row"><span class="lbl">${escapeHtml(r.label)}</span><span class="val">${escapeHtml(r.value)}</span></div>`).join('')}
    <div class="brand"><img src="${logoDataUrl}" alt="Bridge" /></div>
  </div>
</div>
</body></html>`;

  const handlePrint = () => {
    if (!qrDataUrl) return;
    const iframe = iframeRef.current;
    if (!iframe) return;
    const doc = iframe.contentDocument;
    const win = iframe.contentWindow;
    if (!doc || !win) return;

    doc.open();
    doc.write(buildStickerHtml());
    doc.close();

    const runPrint = () => {
      try {
        win.focus();
        win.print();
      } catch {
        // ignore
      }
    };

    const img = doc.querySelector('.qr img') as HTMLImageElement | null;
    if (img && !(img.complete && img.naturalWidth > 0)) {
      img.addEventListener('load', () => setTimeout(runPrint, 60));
      img.addEventListener('error', () => setTimeout(runPrint, 60));
    } else {
      setTimeout(runPrint, 120);
    }
  };

  const handleDownloadPng = async () => {
    if (!qrDataUrl) return;
    const scale = 12;
    const mm = scale;
    const pt = 0.3528 * scale;
    const W = 80 * mm;
    const H = 50 * mm;

    const canvas = document.createElement('canvas');
    canvas.width = W;
    canvas.height = H;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, W, H);

    const qrImg = new Image();
    qrImg.src = qrDataUrl;
    await new Promise<void>(resolve => {
      qrImg.onload = () => resolve();
      qrImg.onerror = () => resolve();
    });

    const pad = 3 * mm;
    const qrSize = 26 * mm;
    ctx.drawImage(qrImg, pad, (H - qrSize) / 2, qrSize, qrSize);

    const textX = pad + qrSize + 3 * mm;
    const textRight = W - pad;
    const maxTextWidth = textRight - textX;

    ctx.textBaseline = 'top';

    const numFontSize = 11 * pt;
    const rowLabelFont = `700 ${5.5 * pt}px -apple-system, "Segoe UI", Roboto, sans-serif`;
    const rowValueFont = `600 ${7 * pt}px -apple-system, "Segoe UI", Roboto, sans-serif`;
    const brandFontSize = 6 * pt;

    const numLineHeight = numFontSize * 1.15;
    const rowLineHeight = 7 * pt * 1.3;
    const brandLineHeight = brandFontSize * 1.2;
    const brandGap = 0.6 * mm;

    const totalHeight =
      numLineHeight + rows.length * rowLineHeight + brandGap + brandLineHeight;
    let y = Math.max(pad, (H - totalHeight) / 2);

    ctx.fillStyle = '#0f172a';
    ctx.font = `800 ${numFontSize}px -apple-system, "Segoe UI", Roboto, sans-serif`;
    ctx.fillText(`#${order.order_number}`, textX, y);
    y += numLineHeight;

    for (const r of rows) {
      ctx.font = rowLabelFont;
      ctx.fillStyle = '#64748b';
      const labelText = r.label.toUpperCase();
      const labelY = y + (7 * pt - 5.5 * pt) * 0.6;
      ctx.fillText(labelText, textX, labelY);
      const lblWidth = ctx.measureText(labelText).width + 1 * mm;

      ctx.font = rowValueFont;
      ctx.fillStyle = '#0f172a';
      const availW = maxTextWidth - lblWidth;
      const truncated = truncateToWidth(ctx, r.value, availW);
      ctx.fillText(truncated, textX + lblWidth, y);
      y += rowLineHeight;
    }

    y += brandGap;
    const logoImg = new Image();
    logoImg.src = logoDataUrl;
    await new Promise<void>(resolve => {
      logoImg.onload = () => resolve();
      logoImg.onerror = () => resolve();
    });
    if (logoImg.naturalWidth > 0) {
      const logoH = 5 * mm;
      const ratio = logoImg.naturalWidth / logoImg.naturalHeight;
      const logoW = logoH * ratio;
      ctx.drawImage(logoImg, textX, y, logoW, logoH);
    }

    const url = canvas.toDataURL('image/png');
    const a = document.createElement('a');
    a.href = url;
    a.download = `sticker-${order.order_number}.png`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-[70] p-4 animate-modal-in">
      <div className="bg-white rounded-2xl shadow-modal w-full max-w-md overflow-hidden">
        <div className="flex items-center justify-between p-4 border-b border-neutral-200">
          <div>
            <h2 className="font-bold text-neutral-900">Order Sticker</h2>
            <p className="text-xs text-neutral-500">Scan to open the order</p>
          </div>
          <button onClick={onClose} className="w-8 h-8 flex items-center justify-center rounded-lg hover:bg-neutral-100">
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="p-6 flex justify-center bg-neutral-50">
          <div
            className="bg-white rounded-xl border border-neutral-200 shadow-sm p-3 flex items-center gap-3 w-full max-w-sm"
            style={{ aspectRatio: '80 / 50' }}
          >
            <div className="w-24 h-24 flex-shrink-0 flex items-center justify-center bg-white rounded-md border border-neutral-100">
              {qrDataUrl
                ? <img src={qrDataUrl} alt="Order QR" className="w-full h-full" />
                : <div className="w-full h-full animate-pulse bg-neutral-100" />
              }
            </div>
            <div className="flex-1 min-w-0 text-[10px] leading-tight text-neutral-800 space-y-[1px]">
              <p className="font-extrabold text-sm text-neutral-900 truncate mb-0.5">#{order.order_number}</p>
              {rows.map(r => (
                <p key={r.label} className="truncate">
                  <span className="text-neutral-500 text-[8px] font-bold uppercase tracking-wider mr-1">
                    {r.label}
                  </span>
                  <span className="font-semibold">{r.value}</span>
                </p>
              ))}
              {logoDataUrl && <img src={logoDataUrl} alt="Bridge" className="h-3 w-auto object-contain mt-1" />}
            </div>
          </div>
        </div>

        <div className="p-4 border-t border-neutral-200 grid grid-cols-3 gap-2">
          <button onClick={onClose} className="py-2.5 border border-neutral-300 text-neutral-700 font-semibold rounded-xl text-sm hover:bg-neutral-50 transition-colors">
            Close
          </button>
          <button onClick={handleDownloadPng} disabled={!qrDataUrl}
            className="py-2.5 border border-teal-300 text-teal-700 font-semibold rounded-xl text-sm hover:bg-teal-50 disabled:opacity-50 transition-colors">
            Save PNG
          </button>
          <button onClick={handlePrint} disabled={!qrDataUrl}
            className="flex items-center justify-center gap-1.5 py-2.5 bg-primary-600 hover:bg-primary-700 disabled:bg-primary-400 text-white font-semibold rounded-xl text-sm transition-colors">
            <Printer className="w-4 h-4" /> Print
          </button>
        </div>
      </div>

      <iframe
        ref={iframeRef}
        title="sticker-print-frame"
        style={{ position: 'fixed', right: 0, bottom: 0, width: 0, height: 0, border: 0, opacity: 0, pointerEvents: 'none' }}
      />
    </div>
  );
}

function escapeHtml(s: string | null | undefined): string {
  return (s ?? '').replace(/[&<>"']/g, ch => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[ch] as string));
}

function truncateToWidth(ctx: CanvasRenderingContext2D, text: string, maxWidth: number): string {
  if (!text) return '';
  if (ctx.measureText(text).width <= maxWidth) return text;
  const ell = '…';
  let lo = 0;
  let hi = text.length;
  while (lo < hi) {
    const mid = Math.ceil((lo + hi) / 2);
    if (ctx.measureText(text.slice(0, mid) + ell).width <= maxWidth) lo = mid;
    else hi = mid - 1;
  }
  return text.slice(0, lo) + ell;
}

