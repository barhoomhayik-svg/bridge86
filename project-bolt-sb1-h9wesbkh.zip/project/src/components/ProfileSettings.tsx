import React, { useState, useCallback } from 'react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { X, Upload, MapPin, Phone, Building2, Save, Navigation, Loader2, Copy, Check, Lock, ChevronDown, ChevronUp, Image as ImageIcon, Trash2 } from 'lucide-react';

interface Props {
  onClose: () => void;
}

interface GeoResult {
  display_name: string;
  address?: {
    city?: string;
    town?: string;
    village?: string;
    road?: string;
    house_number?: string;
    country?: string;
  };
}

export default function ProfileSettings({ onClose }: Props) {
  const { profile, refreshProfile } = useAuth();

  const [name, setName] = useState(profile?.name ?? '');
  const [phone, setPhone] = useState(profile?.phone ?? '');
  const [address, setAddress] = useState(profile?.address ?? '');
  const [city, setCity] = useState(profile?.city ?? '');
  const [lat, setLat] = useState<string>(profile?.latitude?.toString() ?? '');
  const [lng, setLng] = useState<string>(profile?.longitude?.toString() ?? '');
  const [logoFile, setLogoFile] = useState<File | null>(null);
  const [logoPreview, setLogoPreview] = useState<string>(profile?.logo_url ?? '');
  const [coverFile, setCoverFile] = useState<File | null>(null);
  const [coverPreview, setCoverPreview] = useState<string>(profile?.cover_url ?? '');
  const [coverRemoved, setCoverRemoved] = useState(false);
  const [locating, setLocating] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState(false);
  const [copied, setCopied] = useState(false);
  const [showPassSection, setShowPassSection] = useState(false);
  const [newPass, setNewPass] = useState('');
  const [confirmPass, setConfirmPass] = useState('');
  const [passLoading, setPassLoading] = useState(false);
  const [passError, setPassError] = useState('');
  const [passSuccess, setPassSuccess] = useState(false);

  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setPassError('');
    setPassSuccess(false);
    if (newPass.length < 6) {
      setPassError('Password must be at least 6 characters');
      return;
    }
    if (newPass !== confirmPass) {
      setPassError('Passwords do not match');
      return;
    }
    setPassLoading(true);
    try {
      const { error } = await supabase.auth.updateUser({ password: newPass });
      if (error) throw error;
      setPassSuccess(true);
      setNewPass('');
      setConfirmPass('');
      setTimeout(() => setPassSuccess(false), 3000);
    } catch (err: unknown) {
      // Keep provider detail out of the interface.
      console.error('password update failed', err);
      setPassError('Could not update your password. Please try again.');
    } finally {
      setPassLoading(false);
    }
  };

  const copyCode = () => {
    if (!profile?.profile_code) return;
    navigator.clipboard.writeText(profile.profile_code).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  };

  const handleLogoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setLogoFile(file);
    setLogoPreview(URL.createObjectURL(file));
  };

  const handleCoverChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setCoverFile(file);
    setCoverPreview(URL.createObjectURL(file));
    setCoverRemoved(false);
  };

  const handleRemoveCover = () => {
    setCoverFile(null);
    setCoverPreview('');
    setCoverRemoved(true);
  };

  const detectLocation = useCallback(async () => {
    setLocating(true);
    setError('');
    try {
      const pos = await new Promise<GeolocationPosition>((resolve, reject) =>
        navigator.geolocation.getCurrentPosition(resolve, reject, { timeout: 10000 })
      );
      const { latitude, longitude } = pos.coords;
      setLat(latitude.toFixed(6));
      setLng(longitude.toFixed(6));

      const res = await fetch(
        `https://nominatim.openstreetmap.org/reverse?format=json&lat=${latitude}&lon=${longitude}&addressdetails=1`,
        { headers: { 'Accept-Language': 'en', 'User-Agent': 'Bridge/1.0' } }
      );
      if (res.ok) {
        const data: GeoResult = await res.json();
        const a = data.address ?? {};
        const detectedCity = a.city ?? a.town ?? a.village ?? '';
        const street = [a.house_number, a.road].filter(Boolean).join(' ');
        if (detectedCity) setCity(detectedCity);
        if (street) setAddress(street);
      }
    } catch {
      setError('Could not detect location. Please allow location access.');
    } finally {
      setLocating(false);
    }
  }, []);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!profile) return;
    setSaving(true);
    setError('');
    try {
      let logoUrl = profile.logo_url;
      if (logoFile) {
        const ext = logoFile.name.split('.').pop();
        const path = `logos/${profile.id}.${ext}`;
        const { error: upErr } = await supabase.storage.from('avatars').upload(path, logoFile, { upsert: true });
        if (upErr) throw upErr;
        const { data: { publicUrl } } = supabase.storage.from('avatars').getPublicUrl(path);
        logoUrl = publicUrl;
      }
      let coverUrl: string | null = profile.cover_url;
      if (coverFile) {
        const ext = coverFile.name.split('.').pop();
        const path = `covers/${profile.id}-${Date.now()}.${ext}`;
        const { error: upErr } = await supabase.storage.from('avatars').upload(path, coverFile, { upsert: true });
        if (upErr) throw upErr;
        const { data: { publicUrl } } = supabase.storage.from('avatars').getPublicUrl(path);
        coverUrl = publicUrl;
      } else if (coverRemoved) {
        coverUrl = null;
      }
      const { error: updateErr } = await supabase.from('profiles').update({
        name,
        phone: phone || null,
        address: address || null,
        city: city || null,
        latitude: lat ? parseFloat(lat) : null,
        longitude: lng ? parseFloat(lng) : null,
        logo_url: logoUrl,
        cover_url: coverUrl,
        updated_at: new Date().toISOString(),
      }).eq('id', profile.id);
      if (updateErr) throw updateErr;
      await refreshProfile();
      setSuccess(true);
      setTimeout(onClose, 1000);
    } catch (err: unknown) {
      setError('Could not save your profile. Please try again.');
    } finally {
      setSaving(false);
    }
  };

  const mapUrl = lat && lng
    ? `https://www.openstreetmap.org/export/embed.html?bbox=${parseFloat(lng)-0.01},${parseFloat(lat)-0.01},${parseFloat(lng)+0.01},${parseFloat(lat)+0.01}&layer=mapnik&marker=${lat},${lng}`
    : null;

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4 py-safe px-safe">
      <div className="bg-white rounded-2xl shadow-modal w-full max-w-xl max-h-[90vh] overflow-hidden flex flex-col animate-modal-in">
        <div className="flex items-center justify-between p-5 border-b border-neutral-200">
          <h2 className="font-bold text-neutral-900">Profile Settings</h2>
          <button onClick={onClose} className="w-8 h-8 flex items-center justify-center rounded-lg hover:bg-neutral-100">
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleSave} className="overflow-y-auto flex-1 p-5 space-y-5">
          {/* Profile Code */}
          {profile?.profile_code && (
            <div className="bg-neutral-50 border border-neutral-200 rounded-xl p-4">
              <label className="block text-xs font-semibold text-neutral-600 mb-2 uppercase tracking-wide">Your Account ID</label>
              <div className="flex items-center gap-3">
                <div className="flex-1 flex items-center gap-3 bg-white border border-neutral-300 rounded-lg px-3 py-2.5">
                  <span className="font-mono text-lg font-bold tracking-widest text-primary-700 select-all">
                    {profile.profile_code}
                  </span>
                </div>
                <button
                  type="button"
                  onClick={copyCode}
                  className={`flex items-center gap-1.5 px-3 py-2.5 text-sm font-semibold rounded-lg border transition-all flex-shrink-0 ${
                    copied
                      ? 'bg-teal-50 border-teal-200 text-teal-700'
                      : 'bg-white border-neutral-300 text-neutral-600 hover:bg-neutral-50 hover:border-neutral-400'
                  }`}
                >
                  {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                  {copied ? 'Copied!' : 'Copy'}
                </button>
              </div>
              <p className="text-xs text-neutral-400 mt-2">Share this ID so centers or teams can find and add you</p>
            </div>
          )}

          {/* Cover photo — labs only */}
          {profile?.role === 'lab' && (
            <div>
              <label className="block text-xs font-semibold text-neutral-600 mb-2 uppercase tracking-wide">Cover Photo</label>
              <div className="relative w-full aspect-[16/6] rounded-2xl overflow-hidden border border-neutral-200 bg-gradient-to-br from-primary-600 via-primary-500 to-teal-500">
                {coverPreview ? (
                  <img src={coverPreview} alt="cover" className="w-full h-full object-cover" />
                ) : (
                  <div className="absolute inset-0 flex items-center justify-center text-white/80 text-xs font-semibold">
                    <ImageIcon className="w-4 h-4 mr-1.5" /> No cover photo yet
                  </div>
                )}
                <div className="absolute bottom-3 right-3 flex gap-2">
                  {coverPreview && (
                    <button
                      type="button"
                      onClick={handleRemoveCover}
                      className="flex items-center gap-1.5 px-3 py-1.5 bg-white/95 hover:bg-white text-red-600 text-xs font-semibold rounded-lg shadow-sm"
                    >
                      <Trash2 className="w-3.5 h-3.5" /> Remove
                    </button>
                  )}
                  <label className="cursor-pointer flex items-center gap-1.5 px-3 py-1.5 bg-white/95 hover:bg-white text-neutral-800 text-xs font-semibold rounded-lg shadow-sm">
                    <Upload className="w-3.5 h-3.5" /> {coverPreview ? 'Change' : 'Upload'}
                    <input type="file" accept="image/*" className="sr-only" onChange={handleCoverChange} />
                  </label>
                </div>
              </div>
              <p className="text-xs text-neutral-400 mt-1.5">Shown as the banner on your lab page. PNG or JPG up to 5MB. Recommended 1600×600.</p>
            </div>
          )}

          {/* Logo upload */}
          <div>
            <label className="block text-xs font-semibold text-neutral-600 mb-2 uppercase tracking-wide">Logo / Photo</label>
            <div className="flex items-center gap-4">
              <div className="w-20 h-20 rounded-2xl bg-neutral-100 border-2 border-dashed border-neutral-300 overflow-hidden flex items-center justify-center flex-shrink-0">
                {logoPreview ? (
                  <img src={logoPreview} alt="logo" className="w-full h-full object-cover" />
                ) : (
                  <Building2 className="w-8 h-8 text-neutral-300" />
                )}
              </div>
              <div>
                <label className="cursor-pointer flex items-center gap-2 px-4 py-2 bg-primary-50 hover:bg-primary-100 text-primary-700 text-sm font-semibold rounded-xl transition-colors border border-primary-200">
                  <Upload className="w-4 h-4" /> Upload Logo
                  <input type="file" accept="image/*" className="sr-only" onChange={handleLogoChange} />
                </label>
                <p className="text-xs text-neutral-400 mt-1.5">PNG, JPG up to 5MB</p>
              </div>
            </div>
          </div>

          {/* Basic info */}
          <div className="grid grid-cols-1 gap-3">
            <Field label="Display Name *">
              <input type="text" required value={name} onChange={e => setName(e.target.value)}
                className={inputCls} placeholder="Your name" />
            </Field>
            <Field label="Phone">
              <div className="relative">
                <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-neutral-400" />
                <input type="tel" value={phone} onChange={e => setPhone(e.target.value)}
                  className={inputCls + ' pl-9'} placeholder="+1 234 567 8900" />
              </div>
            </Field>
          </div>

          {/* Change Password */}
          <div className="border border-neutral-200 rounded-xl overflow-hidden">
            <button
              type="button"
              onClick={() => setShowPassSection(!showPassSection)}
              className="w-full flex items-center justify-between p-4 hover:bg-neutral-50 transition-colors"
            >
              <span className="flex items-center gap-2.5 text-sm font-semibold text-neutral-700">
                <Lock className="w-4 h-4 text-neutral-500" />
                Change Password
              </span>
              {showPassSection ? <ChevronUp className="w-4 h-4 text-neutral-400" /> : <ChevronDown className="w-4 h-4 text-neutral-400" />}
            </button>
            {showPassSection && (
              <div className="p-4 pt-0 space-y-3" style={{ animation: 'fadeInDown 0.3s ease' }}>
                <Field label="New Password">
                  <input
                    type="password" value={newPass} onChange={e => setNewPass(e.target.value)}
                    className={inputCls} placeholder="Min. 6 characters"
                  />
                </Field>
                <Field label="Confirm New Password">
                  <input
                    type="password" value={confirmPass} onChange={e => setConfirmPass(e.target.value)}
                    className={inputCls} placeholder="Re-enter new password"
                  />
                </Field>
                {passError && <p className="text-sm text-red-600 bg-red-50 px-3 py-2 rounded-lg border border-red-200">{passError}</p>}
                {passSuccess && <p className="text-sm text-teal-700 bg-teal-50 px-3 py-2 rounded-lg border border-teal-200">Password updated successfully!</p>}
                <button
                  type="button" onClick={handleChangePassword} disabled={passLoading}
                  className="w-full py-2.5 bg-neutral-800 hover:bg-neutral-900 disabled:bg-neutral-400 text-white font-semibold rounded-lg text-sm transition-colors flex items-center justify-center gap-2"
                >
                  {passLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Lock className="w-4 h-4" />}
                  {passLoading ? 'Updating...' : 'Update Password'}
                </button>
              </div>
            )}
          </div>

          {/* Address & Location */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="text-xs font-semibold text-neutral-600 uppercase tracking-wide">Location</label>
              <button type="button" onClick={detectLocation} disabled={locating}
                className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-teal-700 bg-teal-50 hover:bg-teal-100 rounded-lg border border-teal-200 transition-colors disabled:opacity-60"
              >
                {locating ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Navigation className="w-3.5 h-3.5" />}
                {locating ? 'Detecting...' : 'Use My Location'}
              </button>
            </div>
            <div className="grid grid-cols-2 gap-3 mb-3">
              <Field label="City">
                <input type="text" value={city} onChange={e => setCity(e.target.value)}
                  className={inputCls} placeholder="City" />
              </Field>
              <Field label="Address">
                <input type="text" value={address} onChange={e => setAddress(e.target.value)}
                  className={inputCls} placeholder="Street address" />
              </Field>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <Field label="Latitude">
                <input type="number" step="0.000001" value={lat} onChange={e => setLat(e.target.value)}
                  className={inputCls} placeholder="0.000000" />
              </Field>
              <Field label="Longitude">
                <input type="number" step="0.000001" value={lng} onChange={e => setLng(e.target.value)}
                  className={inputCls} placeholder="0.000000" />
              </Field>
            </div>
            {mapUrl && (
              <div className="mt-3 rounded-xl overflow-hidden border border-neutral-200 h-40">
                <iframe
                  src={mapUrl}
                  className="w-full h-full border-0"
                  title="Location map"
                  loading="lazy"
                />
              </div>
            )}
            {!mapUrl && (
              <div className="mt-3 h-32 rounded-xl bg-neutral-50 border-2 border-dashed border-neutral-200 flex flex-col items-center justify-center text-neutral-400">
                <MapPin className="w-6 h-6 mb-1" />
                <p className="text-xs">Use "My Location" or enter coordinates to see map</p>
              </div>
            )}
          </div>

          {error && <p className="text-sm text-red-600 bg-red-50 px-3 py-2 rounded-lg border border-red-200">{error}</p>}
          {success && <p className="text-sm text-teal-700 bg-teal-50 px-3 py-2 rounded-lg border border-teal-200">Saved successfully!</p>}
        </form>

        <div className="p-5 border-t border-neutral-200 flex gap-3">
          <button type="button" onClick={onClose} className="flex-1 py-2.5 border border-neutral-300 text-neutral-700 font-semibold rounded-xl text-sm hover:bg-neutral-50 transition-colors">
            Cancel
          </button>
          <button
            onClick={handleSave}
            disabled={saving}
            className="flex-1 py-2.5 bg-primary-600 hover:bg-primary-700 disabled:bg-primary-400 text-white font-semibold rounded-xl text-sm transition-colors flex items-center justify-center gap-2"
          >
            {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
            {saving ? 'Saving...' : 'Save Changes'}
          </button>
        </div>
      </div>
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <label className="block text-xs font-semibold text-neutral-600 mb-1.5 uppercase tracking-wide">{label}</label>
      {children}
    </div>
  );
}

const inputCls = 'w-full px-3 py-2.5 rounded-lg border border-neutral-300 text-sm focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-transparent';
