import React, { useState, useEffect, useCallback, useRef } from 'react';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import AuthPage from './pages/AuthPage';
import LandingPage from './pages/LandingPage';
import PrivacyPolicy from './pages/PrivacyPolicy';
import TermsOfService from './pages/TermsOfService';
import LabDiscovery from './pages/LabDiscovery';
import LabDashboard from './pages/LabDashboard';
import LabOverview from './pages/LabOverview';
import LabClients from './pages/LabClients';
import CenterDashboard from './pages/CenterDashboard';
import DoctorDashboard from './pages/DoctorDashboard';
import CenterTeam from './pages/CenterTeam';
import CenterReports from './pages/CenterReports';
import DriverDashboard from './pages/DriverDashboard';
import OrdersView from './components/OrdersView';
import QuotationsView from './components/QuotationsView';
import NewOrderModal from './components/NewOrderModal';
import QuotationModal from './components/QuotationModal';
import NotificationBell from './components/NotificationBell';
import BridgeLogo from './components/BridgeLogo';
import ProfileSettings from './components/ProfileSettings';
import OrderDetailModal from './components/OrderDetailModal';
import { useNotifications } from './lib/useNotifications';
import { supabase, Profile, Service, Order, Notification } from './lib/supabase';
import {
  Search, ClipboardList, MessageSquare, LayoutDashboard,
  LogOut, Users, Settings, Menu, X, Building2, Stethoscope, Microscope, UserCog,
  MessageCircle, Briefcase, BarChart3, Truck, Package, CheckCircle,
  XCircle, RefreshCw, Paperclip, FileText, CheckCheck,
} from 'lucide-react';

type Tab = 'discover' | 'orders' | 'quotations' | 'lab-dashboard' | 'lab-overview' | 'lab-clients' | 'team' | 'center-dashboard' | 'doctor-dashboard' | 'center-reports' | 'driver-dashboard';

interface LiveToast {
  id: string;
  notification: Notification;
}

const QUOTATION_NOTIF_TYPES = new Set([
  'new_quotation',
  'quotation_update',
  'quotation_accepted',
  'quotation_declined',
]);

function Shell() {
  const { profile, loading, signOut } = useAuth();
  const [tab, setTab] = useState<Tab>('discover');
  const [orderTarget, setOrderTarget] = useState<Profile | null>(null);
  const [quotationTarget, setQuotationTarget] = useState<Profile | null>(null);
  const [orderServices, setOrderServices] = useState<Service[]>([]);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [quickOrder, setQuickOrder] = useState<Order | null>(null);
  const [toasts, setToasts] = useState<LiveToast[]>([]);
  const toastTimers = useRef<Map<string, ReturnType<typeof setTimeout>>>(new Map());

  const dismissToast = useCallback((id: string) => {
    setToasts(prev => prev.filter(t => t.id !== id));
    const timer = toastTimers.current.get(id);
    if (timer) { clearTimeout(timer); toastTimers.current.delete(id); }
  }, []);

  const handleIncomingNotification = useCallback((n: Notification) => {
    const toast: LiveToast = { id: n.id, notification: n };
    setToasts(prev => [toast, ...prev].slice(0, 4));
    const timer = setTimeout(() => dismissToast(n.id), 6000);
    toastTimers.current.set(n.id, timer);
  }, [dismissToast]);

  const { notifications, unreadCount, markAllRead, markRead, refetch } = useNotifications({
    onIncoming: handleIncomingNotification,
  });

  // Show existing unread notifications as toasts on first load
  const hasShownInitial = useRef(false);
  useEffect(() => {
    if (hasShownInitial.current || !notifications.length) return;
    const unread = notifications.filter(n => !n.read).slice(0, 3);
    if (!unread.length) { hasShownInitial.current = true; return; }
    hasShownInitial.current = true;
    unread.forEach((n, i) => {
      setTimeout(() => {
        const toast: LiveToast = { id: `init-${n.id}`, notification: n };
        setToasts(prev => [toast, ...prev].slice(0, 4));
        const timer = setTimeout(() => dismissToast(`init-${n.id}`), 7000);
        toastTimers.current.set(`init-${n.id}`, timer);
      }, i * 400);
    });
  }, [notifications, dismissToast]);

  const handleOpenOrder = useCallback(async (orderId: string) => {
    const { data } = await supabase
      .from('orders')
      .select('*, from_profile:profiles!orders_from_id_fkey(*), lab_profile:profiles!orders_lab_id_fkey(*), service:services(*), attachments:order_attachments(*), order_services(*, service:services(*))')
      .eq('id', orderId)
      .maybeSingle();
    if (data) setQuickOrder(data as Order);
  }, []);

    useEffect(() => {
    if (profile) {
      if (profile.role === 'lab') setTab('lab-overview');
      else if (profile.role === 'center') setTab('center-dashboard');
      else if (profile.role === 'doctor') setTab('doctor-dashboard');
      else if (profile.role === 'driver') setTab('driver-dashboard');
      else setTab('discover');
    }
  }, [profile?.id]);

  useEffect(() => {
    const timers = toastTimers.current;
    return () => { timers.forEach(clearTimeout); };
  }, []);

  if (loading) {
    return (
      <div className="min-h-dvh bg-neutral-50 flex items-center justify-center pt-safe pb-safe">
        <div className="flex flex-col items-center gap-3">
          <div className="w-10 h-10 bg-primary-600 rounded-xl flex items-center justify-center animate-pulse">
            <BridgeLogo className="w-5 h-5 text-white" iconClassName="w-2.5 h-2.5" compact />
          </div>
          <p className="text-fluid-sm text-neutral-400">Loading...</p>
        </div>
      </div>
    );
  }

  if (!profile) return <LandingPage />;

  const isLab = profile.role === 'lab';
  const isCenter = profile.role === 'center';
  const isDoctor = profile.role === 'doctor';
  const isDriver = profile.role === 'driver';

  const handleSelectLab = async (lab: Profile) => {
    const { data: services } = await supabase.from('services').select('*').eq('lab_id', lab.id);
    setOrderServices(services ?? []);
    setOrderTarget(lab);
  };

  const navItems: {
    id: Tab; label: string; icon: React.ReactNode;
    labOnly?: boolean; clientOnly?: boolean; labHidden?: boolean; clientHidden?: boolean;
    centerOnly?: boolean; doctorOnly?: boolean; driverOnly?: boolean;
  }[] = [
    { id: 'driver-dashboard', label: 'Deliveries', icon: <Truck className="w-5 h-5" />, driverOnly: true },
    { id: 'doctor-dashboard',  label: 'Home',        icon: <LayoutDashboard className="w-5 h-5" />, doctorOnly: true },
    { id: 'center-dashboard',  label: 'Home',        icon: <LayoutDashboard className="w-5 h-5" />, centerOnly: true },
    { id: 'lab-overview',      label: 'Home',        icon: <LayoutDashboard className="w-5 h-5" />, labOnly: true },
    { id: 'discover',          label: 'Find Labs',   icon: <Search className="w-5 h-5" />,          clientOnly: true, clientHidden: isDriver || isCenter },
    { id: 'orders',            label: 'Orders',      icon: <ClipboardList className="w-5 h-5" />, clientHidden: isDriver },
    { id: 'quotations',        label: 'Quotes',      icon: <MessageSquare className="w-5 h-5" />, clientHidden: isDriver },
    { id: 'center-reports',   label: 'Reports',     icon: <BarChart3 className="w-5 h-5" />,       centerOnly: true },
    { id: 'team',              label: 'Team',        icon: <Users className="w-5 h-5" />,            labHidden: true, clientHidden: isDriver },
    { id: 'lab-clients',       label: 'Clients',      icon: <Briefcase className="w-5 h-5" />,        labOnly: true },
    { id: 'lab-dashboard',     label: 'Profile',     icon: <UserCog className="w-5 h-5" />,          labOnly: true },
  ];

  const visibleNav = navItems.filter(n => {
    if (n.labOnly && !isLab) return false;
    if (n.clientOnly && isLab) return false;
    if (n.labHidden && isLab) return false;
    if (n.centerOnly && !isCenter) return false;
    if (n.doctorOnly && !isDoctor) return false;
    if (n.driverOnly && !isDriver) return false;
    if (n.clientHidden && isDriver) return false;
    return true;
  });

  // Bottom nav: max 4 items + settings
  const bottomNavItems = visibleNav.slice(0, 4);

  // Unread notification counts grouped by the section they belong to
  const unreadByTab = notifications.reduce((acc, n) => {
    if (n.read) return acc;
    const target: Tab = QUOTATION_NOTIF_TYPES.has(n.type) ? 'quotations' : 'orders';
    acc[target] = (acc[target] ?? 0) + 1;
    return acc;
  }, {} as Partial<Record<Tab, number>>);

  const RoleIcon = isLab ? Microscope : isCenter ? Building2 : isDriver ? Truck : Stethoscope;
  const roleLabel = isCenter ? 'Dental Center' : isDoctor ? 'Doctor' : isDriver ? 'Driver' : 'Dental Lab';

  const navigate = (t: Tab) => { setTab(t); setMobileMenuOpen(false); };

  return (
    <div className="min-h-dvh bg-neutral-50 flex flex-col">
      {/* ── Top header ── */}
      <header className="bg-white/80 backdrop-blur-lg border-b border-neutral-200 sticky top-0 z-30 pt-safe">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 h-14 flex items-center justify-between">
          <div className="flex items-center gap-6">
            <div className="flex items-center gap-2.5">
              <img
                src="/logo_%20copy.png"
                alt="Bridge"
                className="w-8 h-8 rounded-lg object-contain"
              />
              <span className="font-bold text-fluid-lg text-neutral-900">Bridge</span>
            </div>

            {/* Desktop nav */}
            <nav className="hidden md:flex items-center gap-1">
              {visibleNav.map(item => {
                const badge = unreadByTab[item.id] ?? 0;
                return (
                  <button
                    key={item.id}
                    onClick={() => setTab(item.id)}
                    className={`relative flex items-center gap-2 px-3 py-1.5 rounded-lg text-sm font-medium transition-colors ${
                      tab === item.id ? 'bg-primary-50 text-primary-700' : 'text-neutral-600 hover:bg-neutral-100 hover:text-neutral-900'
                    }`}
                  >
                    {item.icon}
                    <span className="text-sm">{item.label}</span>
                    {badge > 0 && (
                      <span className="ml-0.5 min-w-[18px] h-[18px] px-1 bg-red-500 text-white text-[10px] font-bold rounded-full flex items-center justify-center leading-none">
                        {badge > 9 ? '9+' : badge}
                      </span>
                    )}
                  </button>
                );
              })}
            </nav>
          </div>

          <div className="flex items-center gap-1.5">
            <NotificationBell
              notifications={notifications}
              unreadCount={unreadCount}
              onMarkAllRead={markAllRead}
              onMarkRead={markRead}
              onNavigate={(t) => setTab(t as Tab)}
              onOpenOrder={handleOpenOrder}
            />

            <div className="hidden sm:flex items-center gap-2 px-3 py-1.5 bg-neutral-50 rounded-xl border border-neutral-200 ml-1">
              {profile.logo_url ? (
                <img src={profile.logo_url} alt={profile.name} className="w-6 h-6 rounded-full object-cover" />
              ) : (
                <div className="w-6 h-6 bg-primary-100 rounded-full flex items-center justify-center">
                  <RoleIcon className="w-3.5 h-3.5 text-primary-600" />
                </div>
              )}
              <div className="text-xs">
                <p className="font-semibold text-neutral-900 leading-none">{profile.name}</p>
                <p className="text-neutral-400 mt-0.5">{roleLabel}</p>
              </div>
            </div>

            <button
              onClick={() => setShowSettings(true)}
              className="hidden md:flex p-2 rounded-lg text-neutral-400 hover:text-neutral-700 hover:bg-neutral-100 transition-colors"
              title="Settings"
            >
              <Settings className="w-[18px] h-[18px]" />
            </button>

            <button
              onClick={() => signOut()}
              className="hidden md:flex p-2 rounded-lg text-neutral-400 hover:text-red-500 hover:bg-red-50 transition-colors"
              title="Sign out"
            >
              <LogOut className="w-4 h-4" />
            </button>

            {/* Mobile hamburger (shows more options beyond bottom nav) */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="md:hidden p-2 rounded-lg text-neutral-500 hover:bg-neutral-100"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>

        {/* Mobile overflow menu */}
        {mobileMenuOpen && (
          <div className="md:hidden border-t border-neutral-100 px-4 py-2 flex flex-col gap-1 bg-white shadow-lg">
            {visibleNav.map(item => {
              const badge = unreadByTab[item.id] ?? 0;
              return (
                <button
                  key={item.id}
                  onClick={() => navigate(item.id)}
                  className={`flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-sm font-medium transition-colors ${
                    tab === item.id ? 'bg-primary-50 text-primary-700' : 'text-neutral-700 hover:bg-neutral-100'
                  }`}
                >
                  {item.icon}{item.label}
                  {badge > 0 && (
                    <span className="ml-auto min-w-[18px] h-[18px] px-1 bg-red-500 text-white text-[10px] font-bold rounded-full flex items-center justify-center leading-none">
                      {badge > 9 ? '9+' : badge}
                    </span>
                  )}
                </button>
              );
            })}
            <div className="border-t border-neutral-100 mt-1 pt-1">
              <button
                onClick={() => { setShowSettings(true); setMobileMenuOpen(false); }}
                className="w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-sm font-medium text-neutral-700 hover:bg-neutral-100"
              >
                <Settings className="w-5 h-5" /> Settings
              </button>
              <button
                onClick={() => signOut()}
                className="w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-sm font-medium text-red-600 hover:bg-red-50"
              >
                <LogOut className="w-5 h-5" /> Sign out
              </button>
            </div>
          </div>
        )}
      </header>

      {/* ── Page content ── */}
      <main className="flex-1 pb-[calc(64px+env(safe-area-inset-bottom))] md:pb-0 scroll-touch">
        {tab === 'center-dashboard' && isCenter && <CenterDashboard />}
        {tab === 'doctor-dashboard' && isDoctor && (
          <DoctorDashboard onNavigateDiscover={() => setTab('discover')} />
        )}
        {tab === 'lab-overview' && isLab && (
          <LabOverview onNavigateOrders={() => setTab('orders')} />
        )}
        {tab === 'discover' && !isLab && (
          <LabDiscovery
            onSelectLab={handleSelectLab}
            onRequestQuotation={(lab) => setQuotationTarget(lab)}
          />
        )}
        {tab === 'orders' && <OrdersView viewAs={isLab ? 'lab' : 'sender'} />}
        {tab === 'quotations' && <QuotationsView isLab={isLab} />}
        {tab === 'team' && !isLab && <CenterTeam />}
        {tab === 'center-reports' && isCenter && <CenterReports />}
        {tab === 'lab-dashboard' && isLab && <LabDashboard />}
        {tab === 'lab-clients' && isLab && <LabClients />}
        {tab === 'driver-dashboard' && isDriver && <DriverDashboard />}
      </main>

      {/* ── Mobile bottom navigation ── */}
      <nav
        className="fixed bottom-0 left-0 right-0 md:hidden bg-white/90 backdrop-blur-lg border-t border-neutral-200 z-30 flex items-stretch pb-safe"
      >
        {bottomNavItems.map(item => {
          const isActive = tab === item.id;
          const badge = unreadByTab[item.id] ?? 0;
          const showBadge = badge > 0;
          return (
            <button
              key={item.id}
              onClick={() => setTab(item.id)}
              className={`flex-1 flex flex-col items-center justify-center gap-1 pt-2 pb-1 min-h-[56px] relative transition-colors ${
                isActive ? 'text-primary-600' : 'text-neutral-400 active:bg-neutral-50'
              }`}
            >
              <div className="relative">
                {item.icon}
                {showBadge && (
                  <span className="absolute -top-1 -right-1.5 w-4 h-4 bg-red-500 text-white text-[8px] font-bold rounded-full flex items-center justify-center">
                    {badge > 9 ? '9+' : badge}
                  </span>
                )}
              </div>
              <span className={`text-[10px] font-semibold leading-none ${isActive ? 'text-primary-600' : 'text-neutral-400'}`}>
                {item.label}
              </span>
              {isActive && (
                <span className="absolute top-0 left-1/2 -translate-x-1/2 w-8 h-0.5 bg-primary-600 rounded-full" />
              )}
            </button>
          );
        })}
        {/* Settings slot */}
        <button
          onClick={() => setShowSettings(true)}
          className="flex-1 flex flex-col items-center justify-center gap-1 pt-2 pb-1 min-h-[56px] text-neutral-400 active:bg-neutral-50 transition-colors"
        >
          <Settings className="w-5 h-5" />
          <span className="text-[10px] font-semibold leading-none">More</span>
        </button>
      </nav>

      {/* ── Modals ── */}
      {orderTarget && (
        <NewOrderModal
          lab={orderTarget}
          services={orderServices}
          onClose={() => setOrderTarget(null)}
          onSuccess={() => { setOrderTarget(null); setTab('orders'); }}
        />
      )}
      {quotationTarget && (
        <QuotationModal
          lab={quotationTarget}
          onClose={() => setQuotationTarget(null)}
          onSuccess={() => { setQuotationTarget(null); setTab('quotations'); }}
        />
      )}
      {showSettings && <ProfileSettings onClose={() => setShowSettings(false)} />}

      {quickOrder && (
        <OrderDetailModal
          order={quickOrder}
          isLab={isLab}
          onClose={() => setQuickOrder(null)}
          onStatusChange={() => setQuickOrder(null)}
          onRead={(id) => { /* no-op for driver toast navigation */ void id; }}
        />
      )}

      {/* ── Live notification toasts (top-right on all screens) ── */}
      <div className="fixed top-[calc(56px+env(safe-area-inset-top))] md:top-16 right-3 md:right-5 z-50 flex flex-col gap-2.5 items-end pointer-events-none no-scrollbar">
        {toasts.map(toast => (
          <NotificationToast
            key={toast.id}
            toast={toast}
            onOpen={() => {
              dismissToast(toast.id);
              if (QUOTATION_NOTIF_TYPES.has(toast.notification.type)) {
                setTab('quotations');
              } else if (toast.notification.related_id) {
                handleOpenOrder(toast.notification.related_id);
              }
            }}
            onDismiss={() => dismissToast(toast.id)}
          />
        ))}
      </div>
    </div>
  );
}

const TOAST_CONFIG: Record<string, { icon: React.ReactNode; accent: string; bg: string; text: string }> = {
  new_order:          { icon: <Package className="w-[18px] h-[18px]" />,      accent: 'bg-primary-500', bg: 'bg-primary-50',  text: 'text-primary-700' },
  order_update:       { icon: <RefreshCw className="w-[18px] h-[18px]" />,    accent: 'bg-teal-500',    bg: 'bg-teal-50',    text: 'text-teal-700' },
  new_quotation:      { icon: <MessageSquare className="w-[18px] h-[18px]" />, accent: 'bg-amber-500',   bg: 'bg-amber-50',   text: 'text-amber-700' },
  quotation_update:   { icon: <MessageSquare className="w-[18px] h-[18px]" />, accent: 'bg-blue-500',    bg: 'bg-blue-50',    text: 'text-blue-700' },
  quotation_accepted: { icon: <CheckCircle className="w-[18px] h-[18px]" />,   accent: 'bg-green-500',   bg: 'bg-green-50',   text: 'text-green-700' },
  quotation_declined: { icon: <XCircle className="w-[18px] h-[18px]" />,      accent: 'bg-red-500',     bg: 'bg-red-50',     text: 'text-red-700' },
  new_comment:        { icon: <MessageCircle className="w-[18px] h-[18px]" />, accent: 'bg-blue-500',    bg: 'bg-blue-50',    text: 'text-blue-700' },
  order_delivered:    { icon: <Truck className="w-[18px] h-[18px]" />,          accent: 'bg-teal-500',    bg: 'bg-teal-50',    text: 'text-teal-700' },
  order_accepted:     { icon: <CheckCircle className="w-[18px] h-[18px]" />,   accent: 'bg-green-500',   bg: 'bg-green-50',   text: 'text-green-700' },
  order_rejected:     { icon: <XCircle className="w-[18px] h-[18px]" />,      accent: 'bg-red-500',     bg: 'bg-red-50',     text: 'text-red-700' },
  order_completed:    { icon: <CheckCheck className="w-[18px] h-[18px]" />,    accent: 'bg-teal-500',    bg: 'bg-teal-50',    text: 'text-teal-700' },
  order_delivering:   { icon: <Truck className="w-[18px] h-[18px]" />,          accent: 'bg-teal-500',    bg: 'bg-teal-50',    text: 'text-teal-700' },
  order_cancelled:    { icon: <X className="w-[18px] h-[18px]" />,            accent: 'bg-red-500',     bg: 'bg-red-50',     text: 'text-red-700' },
  order_redo:         { icon: <RefreshCw className="w-[18px] h-[18px]" />,    accent: 'bg-orange-500',  bg: 'bg-orange-50',  text: 'text-orange-700' },
  order_assigned:     { icon: <FileText className="w-[18px] h-[18px]" />,      accent: 'bg-primary-500', bg: 'bg-primary-50', text: 'text-primary-700' },
  new_attachment:     { icon: <Paperclip className="w-[18px] h-[18px]" />,      accent: 'bg-blue-500',    bg: 'bg-blue-50',    text: 'text-blue-700' },
};

function NotificationToast({
  toast, onOpen, onDismiss,
}: {
  toast: LiveToast;
  onOpen: () => void;
  onDismiss: () => void;
}) {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const t = setTimeout(() => setVisible(true), 10);
    return () => clearTimeout(t);
  }, []);

  const n = toast.notification;
  const config = TOAST_CONFIG[n.type] ?? TOAST_CONFIG['order_update'];

  return (
    <div
      className={`pointer-events-auto w-72 md:w-80 bg-white/95 backdrop-blur-md rounded-2xl shadow-lg shadow-neutral-900/10 border border-neutral-200/80 overflow-hidden transition-all duration-300 ease-out ${
        visible ? 'opacity-100 translate-x-0 scale-100' : 'opacity-0 translate-x-8 scale-95'
      }`}
    >
      <div className={`h-1 ${config.accent}`} />
      <div className="px-3.5 py-3 flex items-start gap-3">
        <div className={`w-9 h-9 rounded-xl ${config.bg} flex items-center justify-center flex-shrink-0 mt-0.5 ${config.text}`}>
          {config.icon}
        </div>
        <div className="flex-1 min-w-0">
          <p className="text-sm font-semibold text-neutral-900 leading-tight">{n.title}</p>
          {n.body && (
            <p className="text-xs text-neutral-500 mt-0.5 line-clamp-2 leading-relaxed">{n.body}</p>
          )}
          <div className="flex items-center gap-2 mt-2">
            {n.related_id && (
              <button
                onClick={onOpen}
                className={`text-xs font-semibold ${config.text} hover:opacity-80 ${config.bg} px-2.5 py-1 rounded-lg transition-opacity`}
              >
                Open
              </button>
            )}
            <button onClick={onDismiss} className="text-xs text-neutral-400 hover:text-neutral-600 transition-colors">
              Dismiss
            </button>
          </div>
        </div>
        <button onClick={onDismiss} className="text-neutral-300 hover:text-neutral-500 transition-colors flex-shrink-0 mt-0.5">
          <X className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
}

export default function App() {
  const [path, setPath] = useState(window.location.pathname);

  useEffect(() => {
    const onPop = () => setPath(window.location.pathname);
    window.addEventListener('popstate', onPop);
    return () => window.removeEventListener('popstate', onPop);
  }, []);

  if (path === '/privacy-policy') return <PrivacyPolicy />;
  if (path === '/terms-of-service') return <TermsOfService />;

  return (
    <AuthProvider>
      <Shell />
    </AuthProvider>
  );
}
