import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL as string;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY as string;

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

/**
 * Case attachments live in a private bucket: only the people involved in an
 * order may read them. Stored links keep the historical `.../object/public/...`
 * shape, so the object path is extracted and exchanged for a short-lived
 * signed link at the moment it is opened.
 */
export async function signedAttachmentUrl(url: string | null | undefined): Promise<string | null> {
  if (!url) return null;
  const marker = '/order-attachments/';
  const at = url.indexOf(marker);
  if (at === -1) return url;
  const path = decodeURIComponent(url.slice(at + marker.length).split('?')[0]);
  const { data } = await supabase.storage.from('order-attachments').createSignedUrl(path, 60 * 60);
  return data?.signedUrl ?? null;
}

export type Role = 'center' | 'doctor' | 'lab' | 'driver';
export type OrderStatus = 'pending' | 'accepted' | 'in_progress' | 'completed' | 'try_in' | 'delivering' | 'delivered' | 'rejected' | 'cancelled' | 'redo';
export type QuotationStatus = 'pending' | 'responded' | 'accepted' | 'declined';
export type NotificationType =
  | 'new_order' | 'order_update' | 'new_quotation' | 'quotation_update'
  | 'new_comment' | 'order_delivered' | 'order_assigned' | 'order_accepted'
  | 'order_rejected' | 'order_completed' | 'order_try_in' | 'order_delivering' | 'order_cancelled'
  | 'order_redo' | 'new_attachment' | 'quotation_accepted' | 'quotation_declined';

export interface Profile {
  id: string;
  role: Role;
  name: string;
  phone: string | null;
  address: string | null;
  city: string | null;
  latitude: number | null;
  longitude: number | null;
  avatar_url: string | null;
  logo_url: string | null;
  cover_url: string | null;
  profile_code: string | null;
  created_at: string;
  updated_at: string;
}

export interface Service {
  id: string;
  lab_id: string;
  name: string;
  description: string | null;
  price_from: number | null;
  price_to: number | null;
  turnaround_days: number | null;
  created_at: string;
}

export interface CasePhoto {
  id: string;
  lab_id: string;
  title: string;
  description: string | null;
  photo_url: string;
  created_at: string;
}

export interface Order {
  id: string;
  order_number: string;
  from_id: string;
  lab_id: string;
  file_number: string;
  patient_name: string;
  dr_name: string;
  shade: string | null;
  teeth_numbers: string | null;
  service_id: string | null;
  notes: string | null;
  status: OrderStatus;
  due_date: string | null;
  parent_order_id: string | null;
  bill_to: 'doctor' | 'center';
  try_in: boolean;
  is_final: boolean;
  delivered_at: string | null;
  delivered_by: string | null;
  created_at: string;
  updated_at: string;
  from_profile?: Profile;
  lab_profile?: Profile;
  service?: Service;
  attachments?: OrderAttachment[];
  order_services?: OrderService[];
  delivered_by_profile?: Profile;
}

export interface OrderService {
  id: string;
  order_id: string;
  service_id: string | null;
  service_name: string;
  notes: string | null;
  teeth_numbers: string | null;
  is_bridge: boolean;
  created_at: string;
  service?: Service;
}

export interface OrderAttachment {
  id: string;
  order_id: string;
  uploader_id: string;
  file_name: string;
  file_url: string;
  file_size: number | null;
  mime_type: string | null;
  created_at: string;
}

export interface OrderComment {
  id: string;
  order_id: string;
  author_id: string;
  body: string;
  created_at: string;
  author?: Pick<Profile, 'id' | 'name' | 'role'>;
  attachment_url?: string | null;
  attachment_name?: string | null;
  attachment_size?: number | null;
  attachment_mime?: string | null;
}

export interface QuotationService {
  id: string;
  quotation_id: string;
  service_id: string | null;
  service_name: string;
  notes: string | null;
  teeth_numbers: string | null;
  quoted_price: number | null;
  created_at: string;
  service?: Service;
}

export interface Quotation {
  id: string;
  from_id: string;
  lab_id: string;
  description: string | null;
  teeth_numbers: string | null;
  status: QuotationStatus;
  response_notes: string | null;
  created_at: string;
  updated_at: string;
  from_profile?: Profile;
  lab_profile?: Profile;
  quotation_services?: QuotationService[];
}

export interface Notification {
  id: string;
  user_id: string;
  type: NotificationType;
  title: string;
  body: string | null;
  related_id: string | null;
  read: boolean;
  created_at: string;
}

export interface LabReview {
  id: string;
  order_id: string;
  lab_id: string;
  reviewer_id: string;
  rating: number;
  comment: string | null;
  created_at: string;
  updated_at: string;
}

export interface FavouriteLab {
  id: string;
  user_id: string;
  lab_id: string;
  created_at: string;
}

export interface CenterMember {
  id: string;
  center_id: string;
  doctor_id: string;
  created_at: string;
  doctor_profile?: Profile;
}

export interface LabDriver {
  id: string;
  lab_id: string;
  driver_id: string;
  created_at: string;
  driver_profile?: Profile;
}
