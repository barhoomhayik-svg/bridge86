import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "npm:@supabase/supabase-js@2";
import { jsPDF } from "npm:jspdf@2.5.2";
import { LOGO_B64, LOGO_FORMAT } from "./logo.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

function fmtDate(d: string | null | undefined): string {
  if (!d) return "—";
  const dt = new Date(d);
  if (isNaN(dt.getTime())) return String(d);
  return dt.toLocaleDateString("en-US", { year: "numeric", month: "short", day: "numeric" });
}

function safe(s: unknown): string {
  return s == null ? "—" : String(s);
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const url = new URL(req.url);
    const id = url.searchParams.get("id");
    if (!id) {
      return new Response("Missing order id", {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "text/plain" },
      });
    }

    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
    );

    // The QR sticker on a case has to be scannable by lab staff who are not
    // signed in, so the document stays reachable without a session — but nothing
    // that identifies the patient, the doctor or the clinic is included unless the
    // caller is proved to be a party to this case. Anyone else gets a minimal
    // routing slip: order number, status, dates, lab and service list.
    let callerId: string | null = null;
    const authHeader = req.headers.get("Authorization") ?? "";
    const token = authHeader.toLowerCase().startsWith("bearer ")
      ? authHeader.slice(7).trim()
      : "";
    if (token && token !== Deno.env.get("SUPABASE_ANON_KEY")) {
      const { data: userData } = await supabase.auth.getUser(token);
      callerId = userData?.user?.id ?? null;
    }

    const { data: order, error: orderErr } = await supabase
      .from("orders")
      .select("*, from_profile:profiles!orders_from_id_fkey(name, address, city, phone), lab_profile:profiles!orders_lab_id_fkey(name, address, city, phone)")
      .eq("id", id)
      .maybeSingle();

    if (orderErr || !order) {
      return new Response("Order not found", {
        status: 404,
        headers: { ...corsHeaders, "Content-Type": "text/plain" },
      });
    }

    let isParty = false;
    if (callerId) {
      if (
        order.from_id === callerId ||
        order.lab_id === callerId ||
        order.doctor_id === callerId
      ) {
        isParty = true;
      } else {
        const [{ data: driverRow }, { data: memberRow }] = await Promise.all([
          supabase.from("lab_drivers").select("id")
            .eq("driver_id", callerId).eq("lab_id", order.lab_id).maybeSingle(),
          supabase.from("center_members").select("id")
            .eq("doctor_id", callerId).eq("center_id", order.from_id).maybeSingle(),
        ]);
        isParty = !!driverRow || !!memberRow;
      }
    }

    const { data: services } = await supabase
      .from("order_services")
      .select("*")
      .eq("order_id", id);

    const doc = new jsPDF({ unit: "pt", format: "a4" });
    const pageW = doc.internal.pageSize.getWidth();
    const pageH = doc.internal.pageSize.getHeight();
    const margin = 40;
    let y = margin;

    // Header brand bar
    doc.setFillColor(255, 255, 255);
    doc.rect(0, 0, pageW, 72, "F");
    try {
      doc.addImage(`data:image/jpeg;base64,${LOGO_B64}`, LOGO_FORMAT, margin, 14, 44, 44);
    } catch {
      // ignore image failure, keep text branding
    }
    doc.setTextColor(15, 23, 42);
    doc.setFont("helvetica", "bold");
    doc.setFontSize(22);
    doc.text("Bridge", margin + 54, 40);
    doc.setFont("helvetica", "normal");
    doc.setFontSize(10);
    doc.setTextColor(100, 116, 139);
    doc.text("Dental lab work order", margin + 54, 54);
    doc.setDrawColor(226, 232, 240);
    doc.line(margin, 72, pageW - margin, 72);

    doc.setFontSize(16);
    doc.setFont("helvetica", "bold");
    doc.setTextColor(15, 23, 42);
    const numText = `#${safe(order.order_number)}`;
    const numWidth = doc.getTextWidth(numText);
    doc.text(numText, pageW - margin - numWidth, 40);
    doc.setFontSize(9);
    doc.setFont("helvetica", "normal");
    doc.setTextColor(100, 116, 139);
    const statusText = String(order.status ?? "").toUpperCase();
    const statusWidth = doc.getTextWidth(statusText);
    doc.text(statusText, pageW - margin - statusWidth, 56);

    y = 100;
    doc.setTextColor(15, 23, 42);

    // Key fields. Patient, doctor and file number identify a person, so they are
    // withheld from a caller who cannot be proved party to this case.
    const restricted = "Restricted";
    const keyFields: Array<[string, string]> = [
      ["Order #", safe(order.order_number)],
      ["Doctor", isParty ? safe(order.dr_name) : restricted],
      ["Patient", isParty ? safe(order.patient_name) : restricted],
      ["File #", isParty ? safe(order.file_number) : restricted],
    ];

    doc.setFont("helvetica", "bold");
    doc.setFontSize(11);
    doc.text("Order Details", margin, y);
    y += 14;

    const colW = (pageW - margin * 2) / 2;
    keyFields.forEach((f, i) => {
      const col = i % 2;
      const row = Math.floor(i / 2);
      const x = margin + col * colW;
      const cy = y + row * 44;
      doc.setDrawColor(226, 232, 240);
      doc.setFillColor(248, 250, 252);
      doc.roundedRect(x, cy, colW - 8, 36, 6, 6, "FD");
      doc.setFont("helvetica", "bold");
      doc.setFontSize(8);
      doc.setTextColor(100, 116, 139);
      doc.text(f[0].toUpperCase(), x + 10, cy + 14);
      doc.setFont("helvetica", "bold");
      doc.setFontSize(12);
      doc.setTextColor(15, 23, 42);
      doc.text(f[1], x + 10, cy + 28);
    });
    y += Math.ceil(keyFields.length / 2) * 44 + 12;

    // Meta fields
    const metaFields: Array<[string, string]> = [
      ["Shade", safe(order.shade)],
      ["Due Date", fmtDate(order.due_date)],
      ["Created", fmtDate(order.created_at)],
      ["From", isParty ? safe(order.from_profile?.name) : restricted],
      ["Lab", safe(order.lab_profile?.name)],
    ];
    if (isParty) {
      metaFields.push(["From Phone", safe(order.from_profile?.phone)]);
      metaFields.push(["Lab Phone", safe(order.lab_profile?.phone)]);
      metaFields.push([
        "From Address",
        safe([order.from_profile?.address, order.from_profile?.city].filter(Boolean).join(", ") || null),
      ]);
    }
    metaFields.forEach((f, i) => {
      const col = i % 2;
      const row = Math.floor(i / 2);
      const x = margin + col * colW;
      const cy = y + row * 40;
      doc.setDrawColor(226, 232, 240);
      doc.setFillColor(255, 255, 255);
      doc.roundedRect(x, cy, colW - 8, 32, 6, 6, "FD");
      doc.setFont("helvetica", "bold");
      doc.setFontSize(7.5);
      doc.setTextColor(148, 163, 184);
      doc.text(f[0].toUpperCase(), x + 10, cy + 12);
      doc.setFont("helvetica", "normal");
      doc.setFontSize(10);
      doc.setTextColor(30, 41, 59);
      doc.text(f[1], x + 10, cy + 25);
    });
    y += Math.ceil(metaFields.length / 2) * 40 + 16;

    // Services
    doc.setFont("helvetica", "bold");
    doc.setFontSize(11);
    doc.setTextColor(15, 23, 42);
    doc.text("Services", margin, y);
    y += 12;

    if (!services || services.length === 0) {
      doc.setFont("helvetica", "italic");
      doc.setFontSize(10);
      doc.setTextColor(148, 163, 184);
      doc.text("No services listed.", margin, y + 10);
      y += 24;
    } else {
      doc.setDrawColor(226, 232, 240);
      doc.setFillColor(241, 245, 249);
      doc.rect(margin, y, pageW - margin * 2, 20, "F");
      doc.setFont("helvetica", "bold");
      doc.setFontSize(8);
      doc.setTextColor(100, 116, 139);
      doc.text("SERVICE", margin + 8, y + 13);
      doc.text("TEETH", margin + 260, y + 13);
      doc.text("NOTES", margin + 360, y + 13);
      y += 22;

      doc.setFont("helvetica", "normal");
      doc.setFontSize(10);
      doc.setTextColor(30, 41, 59);
      for (const s of services) {
        if (y > pageH - 80) {
          doc.addPage();
          y = margin;
        }
        const name = safe(s.service_name) + (s.is_bridge ? "  [Bridge]" : "");
        const teeth = safe(s.teeth_numbers);
        const notes = isParty ? safe(s.notes) : "—";
        const notesLines = doc.splitTextToSize(notes, pageW - margin - 360 - 8);
        const rowH = Math.max(16, 12 + notesLines.length * 12);
        doc.text(name, margin + 8, y + 10);
        doc.text(teeth, margin + 260, y + 10);
        doc.text(notesLines, margin + 360, y + 10);
        doc.setDrawColor(241, 245, 249);
        doc.line(margin, y + rowH, pageW - margin, y + rowH);
        y += rowH + 2;
      }
      y += 6;
    }

    // Order notes. Free text can name the patient, so parties only.
    if (order.notes && isParty) {
      if (y > pageH - 100) {
        doc.addPage();
        y = margin;
      }
      doc.setFont("helvetica", "bold");
      doc.setFontSize(11);
      doc.setTextColor(15, 23, 42);
      doc.text("Order Notes", margin, y);
      y += 12;
      doc.setDrawColor(253, 230, 138);
      doc.setFillColor(254, 252, 232);
      const notesLines = doc.splitTextToSize(String(order.notes), pageW - margin * 2 - 16);
      const boxH = notesLines.length * 12 + 16;
      doc.roundedRect(margin, y, pageW - margin * 2, boxH, 6, 6, "FD");
      doc.setFont("helvetica", "normal");
      doc.setFontSize(10);
      doc.setTextColor(113, 63, 18);
      doc.text(notesLines, margin + 8, y + 14);
      y += boxH + 10;
    }

    // Footer
    doc.setFont("helvetica", "normal");
    doc.setFontSize(9);
    doc.setTextColor(148, 163, 184);
    doc.text(
      `Generated by Bridge  |  ${fmtDate(new Date().toISOString())}`,
      margin,
      pageH - 24,
    );
    if (!isParty) {
      doc.text(
        "Sign in to Bridge with an account linked to this case to see the full work order.",
        margin,
        pageH - 38,
      );
    }

    const pdfBytes = doc.output("arraybuffer");
    const filename = `order-${safe(order.order_number).replace(/[^A-Za-z0-9._-]/g, "")}.pdf`;

    return new Response(pdfBytes, {
      status: 200,
      headers: {
        ...corsHeaders,
        "Content-Type": "application/pdf",
        "Content-Disposition": `inline; filename="${filename}"`,
        "Cache-Control": "no-store",
      },
    });
  } catch (err) {
    console.error("order-view failed", err);
    return new Response("Could not generate this document. Please try again.", {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "text/plain" },
    });
  }
});
