---
name: interface-and-motion
description: Conventions for elevating the interface and adding motion in this app — spacing, hierarchy, hover/press feedback, transitions, entrance animations, and loading/skeleton states. Use whenever the user asks to enhance, polish, refine, "make it nicer", improve the look and feel, or add animation/motion to any screen, component, modal, or view, even if they don't name this skill.
---

# Interface and Motion

Raise the visual quality and responsiveness of screens in this React + Tailwind + lucide-react app. Apply this when polishing existing UI or building new UI that should feel finished, not just when the word "animation" appears.

## Guiding principle

Motion exists to explain change, not to decorate. Every animation should answer "what just happened / what can I do here?" — an element appearing, a state changing, an action being acknowledged. If a motion doesn't clarify something, leave it out. Keep it fast (150–300ms) and use ease-out for things entering so they feel responsive rather than sluggish.

## Interface polish

- Respect the 8px spacing rhythm already used in the app (`p-2`, `p-4`, `gap-6`, etc.) so new elements line up with existing ones. Consistent spacing reads as "designed" more than any single flourish.
- Establish hierarchy with size, weight, and color — not more boxes. One clear primary action per screen; secondary actions should be visibly quieter (ghost or outline styling).
- Keep contrast readable in every state. When a surface changes color on hover, scroll, or open, re-check the text on it still passes as legible — this is the most common regression when adding transitions.
- Reuse the app's existing color tokens and Tailwind classes rather than introducing new palettes. Never introduce purple/indigo unless the app already uses it.

## Motion patterns to reach for

- **Hover and press feedback** on anything interactive: `transition-colors`/`transition-transform`, a subtle `hover:` color shift, and `active:scale-[0.98]` on buttons so taps feel physical. This is the highest-value, lowest-risk motion — add it liberally.
- **Entrance animations** for content that appears (modals, dropdowns, toasts, newly loaded lists): fade + a small translate or scale, e.g. opacity 0→100 with `translate-y-1`→0 over ~200ms. Stagger list items slightly so a list feels like it assembles rather than snapping in.
- **State transitions**: when a value or status changes (order status, badge, count), transition it instead of hard-swapping so the user notices the change happened.
- **Loading and empty states**: prefer skeleton placeholders that match the final layout over spinners, and give empty states a calm icon + one line of guidance. A screen should never flash blank or jump as data arrives.

## Guardrails

- Prefer Tailwind's built-in `transition`, `duration`, `ease-*`, and `animate-*` utilities and small CSS keyframes over pulling in an animation library. Don't add a dependency for motion unless the user asks.
- Don't animate layout-critical properties (width/height/top/left) when a transform will do — transforms are smoother and won't cause reflow jank.
- Respect `prefers-reduced-motion`: wrap non-essential motion so users who opt out get instant, static UI.
- Enhance in place. Polishing a screen shouldn't change what it does or rearrange its information architecture unless the user asked for that.

## Example

Before: a button that instantly changes color and a modal that pops in.

After:
- Button: `transition-colors duration-200 hover:bg-blue-700 active:scale-[0.98]` — the press is now acknowledged.
- Modal: backdrop fades in, panel animates from `opacity-0 translate-y-2 scale-95` to `opacity-100 translate-y-0 scale-100` over 200ms ease-out — the user's eye follows where it came from instead of being startled.
