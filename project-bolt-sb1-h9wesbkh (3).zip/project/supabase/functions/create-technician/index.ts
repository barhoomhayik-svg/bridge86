import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "npm:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
      { auth: { autoRefreshToken: false, persistSession: false } }
    );

    const authHeader = req.headers.get("Authorization") ?? "";
    const token = authHeader.replace("Bearer ", "");
    if (!token) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const { data: { user }, error: userErr } = await supabase.auth.getUser(token);
    if (userErr || !user) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const { data: labProfile } = await supabase
      .from("profiles")
      .select("id, role")
      .eq("id", user.id)
      .maybeSingle();

    if (!labProfile || labProfile.role !== "lab") {
      return new Response(JSON.stringify({ error: "Only labs can create technicians" }), {
        status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const body = await req.json().catch(() => null);
    const name = typeof body?.name === "string" ? body.name.trim() : "";
    const email = typeof body?.email === "string" ? body.email.trim().toLowerCase() : "";
    const password = typeof body?.password === "string" ? body.password : "";
    const phone = typeof body?.phone === "string" ? body.phone.trim() : "";

    const emailShape = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
    const invalid =
      name.length < 2 || name.length > 120 ||
      email.length > 254 || !emailShape.test(email) ||
      password.length < 8 || password.length > 72 ||
      phone.length > 40;

    if (invalid) {
      return new Response(
        JSON.stringify({
          error:
            "Please provide a name, a valid email address, and a password of at least 8 characters.",
        }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } },
      );
    }

    const { data: authData, error: authErr } = await supabase.auth.admin.createUser({
      email,
      password,
      email_confirm: true,
    });

    if (authErr || !authData.user) {
      console.error("create-technician: account creation failed", authErr);
      return new Response(JSON.stringify({ error: "Could not create this technician account." }), {
        status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const techId = authData.user.id;

    const { error: profileErr } = await supabase.from("profiles").upsert({
      id: techId,
      role: "technician",
      name,
      phone: phone || null,
    }, { onConflict: "id" });

    if (profileErr) {
      await supabase.auth.admin.deleteUser(techId);
      console.error("create-technician: profile insert failed", profileErr);
      return new Response(JSON.stringify({ error: "Could not create this technician account." }), {
        status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const { error: linkErr } = await supabase.from("lab_technicians").insert({
      lab_id: labProfile.id,
      technician_id: techId,
    });

    if (linkErr) {
      await supabase.from("profiles").delete().eq("id", techId);
      await supabase.auth.admin.deleteUser(techId);
      console.error("create-technician: link failed", linkErr);
      return new Response(JSON.stringify({ error: "Could not create this technician account." }), {
        status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    return new Response(JSON.stringify({ id: techId, name, email }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (err) {
    console.error("create-technician failed", err);
    return new Response(
      JSON.stringify({ error: "Could not create this technician account. Please try again." }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
