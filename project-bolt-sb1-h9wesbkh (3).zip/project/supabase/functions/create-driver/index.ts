import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "npm:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
      { auth: { autoRefreshToken: false, persistSession: false } }
    );

    // Verify the caller is an authenticated lab
    const authHeader = req.headers.get("Authorization") ?? "";
    const token = authHeader.replace("Bearer ", "");
    if (!token) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const { data: { user }, error: userErr } = await supabase.auth.getUser(token);
    if (userErr || !user) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const { data: labProfile } = await supabase
      .from("profiles")
      .select("id, role")
      .eq("id", user.id)
      .maybeSingle();

    if (!labProfile || labProfile.role !== "lab") {
      return new Response(JSON.stringify({ error: "Only labs can create drivers" }), {
        status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const body = await req.json().catch(() => null);
    const name = typeof body?.name === "string" ? body.name.trim() : "";
    const email = typeof body?.email === "string" ? body.email.trim().toLowerCase() : "";
    const password = typeof body?.password === "string" ? body.password : "";
    const phone = typeof body?.phone === "string" ? body.phone.trim() : "";

    // The browser is untrusted, so every field is validated here as well.
    const emailShape = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
    const invalid =
      name.length < 2 || name.length > 120 ||
      email.length > 254 || !emailShape.test(email) ||
      password.length < 8 || password.length > 72 ||
      phone.length > 40;

    if (invalid) {
      return new Response(
        JSON.stringify({
          error:
            "Please provide a name, a valid email address, and a password of at least 8 characters.",
        }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } },
      );
    }

    // Create auth account
    const { data: authData, error: authErr } = await supabase.auth.admin.createUser({
      email,
      password,
      email_confirm: true,
    });

    if (authErr || !authData.user) {
      // The provider's message says whether the address is already registered, so
      // it is logged rather than returned.
      console.error("create-driver: account creation failed", authErr);
      return new Response(JSON.stringify({ error: "Could not create this driver account." }), {
        status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const driverId = authData.user.id;

    // Create/overwrite profile row (a trigger on auth.users may have already
    // inserted one with a default role — upsert so we set role = 'driver').
    const { error: profileErr } = await supabase.from("profiles").upsert({
      id: driverId,
      role: "driver",
      name,
      phone: phone || null,
    }, { onConflict: "id" });

    if (profileErr) {
      await supabase.auth.admin.deleteUser(driverId);
      console.error("create-driver: profile insert failed", profileErr);
      return new Response(JSON.stringify({ error: "Could not create this driver account." }), {
        status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Link driver to lab
    const { error: linkErr } = await supabase.from("lab_drivers").insert({
      lab_id: labProfile.id,
      driver_id: driverId,
    });

    if (linkErr) {
      await supabase.from("profiles").delete().eq("id", driverId);
      await supabase.auth.admin.deleteUser(driverId);
      console.error("create-driver: driver link failed", linkErr);
      return new Response(JSON.stringify({ error: "Could not create this driver account." }), {
        status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    return new Response(JSON.stringify({ id: driverId, name, email }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (err) {
    console.error("create-driver failed", err);
    return new Response(
      JSON.stringify({ error: "Could not create this driver account. Please try again." }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
