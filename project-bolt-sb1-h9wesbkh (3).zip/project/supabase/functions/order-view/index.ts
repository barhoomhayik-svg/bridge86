import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "npm:@supabase/supabase-js@2";
import { jsPDF } from "npm:jspdf@2.5.2";
import { LOGO_B64, LOGO_FORMAT } from "./logo.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

function fmtDate(d: string | null | undefined): string {
  if (!d) return "\u2014";
  const dt = new Date(d);
  if (isNaN(dt.getTime())) return String(d);
  return dt.toLocaleDateString("en-US", { year: "numeric", month: "short", day: "numeric" });
}

function fmtDateTime(d: string | null | undefined): string {
  if (!d) return "\u2014";
  const dt = new Date(d);
  if (isNaN(dt.getTime())) return String(d);
  return dt.toLocaleDateString("en-US", { year: "numeric", month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" });
}

function safe(s: unknown): string {
  return s == null ? "\u2014" : String(s);
}

function statusLabel(s: string | null): string {
  if (!s) return "\u2014";
  return s.replace(/_/g, " ").replace(/\b\w/g, c => c.toUpperCase());
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const url = new URL(req.url);
    const id = url.searchParams.get("id");
    if (!id) {
      return new Response("Missing order id", {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "text/plain" },
      });
    }

    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
    );

    let callerId: string | null = null;
    const authHeader = req.headers.get("Authorization") ?? "";
    const token = authHeader.toLowerCase().startsWith("bearer ")
      ? authHeader.slice(7).trim()
      : "";
    if (token && token !== Deno.env.get("SUPABASE_ANON_KEY")) {
      const { data: userData } = await supabase.auth.getUser(token);
      callerId = userData?.user?.id ?? null;
    }

    const { data: order, error: orderErr } = await supabase
      .from("orders")
      .select("*, from_profile:profiles!orders_from_id_fkey(name, address, city, phone), lab_profile:profiles!orders_lab_id_fkey(name, address, city, phone)")
      .eq("id", id)
      .maybeSingle();

    if (orderErr || !order) {
      return new Response("Order not found", {
        status: 404,
        headers: { ...corsHeaders, "Content-Type": "text/plain" },
      });
    }

    let isParty = false;
    if (callerId) {
      if (
        order.from_id === callerId ||
        order.lab_id === callerId ||
        order.doctor_id === callerId
      ) {
        isParty = true;
      } else {
        const [{ data: driverRow }, { data: memberRow }] = await Promise.all([
          supabase.from("lab_drivers").select("id")
            .eq("driver_id", callerId).eq("lab_id", order.lab_id).maybeSingle(),
          supabase.from("center_members").select("id")
            .eq("doctor_id", callerId).eq("center_id", order.from_id).maybeSingle(),
        ]);
        isParty = !!driverRow || !!memberRow;
      }
    }

    const { data: services } = await supabase
      .from("order_services")
      .select("*")
      .eq("order_id", id);

    // --- PDF Generation ---
    const doc = new jsPDF({ unit: "pt", format: "a4" });
    const pageW = doc.internal.pageSize.getWidth();
    const pageH = doc.internal.pageSize.getHeight();
    const margin = 40;
    const contentW = pageW - margin * 2;
    let y = margin;

    // Colors
    const slate900 = [15, 23, 42] as const;
    const slate600 = [71, 85, 105] as const;
    const slate400 = [148, 163, 184] as const;
    const teal600 = [13, 148, 136] as const;
    const teal50 = [240, 253, 250] as const;
    const slate50 = [248, 250, 252] as const;
    const slate200 = [226, 232, 240] as const;
    const white = [255, 255, 255] as const;
    const amber50 = [254, 252, 232] as const;
    const amber300 = [253, 230, 138] as const;
    const amber900 = [113, 63, 18] as const;

    // Helper: check if we need a new page
    const ensureSpace = (needed: number) => {
      if (y + needed > pageH - 50) {
        doc.addPage();
        y = margin;
      }
    };

    // ========== HEADER ==========
    // Logo
    y = 24;
    try {
      doc.addImage(`data:image/png;base64,${LOGO_B64}`, LOGO_FORMAT, margin, y, 40, 40);
    } catch { /* ignore */ }

    // Brand text
    doc.setTextColor(...slate900);
    doc.setFont("helvetica", "bold");
    doc.setFontSize(20);
    doc.text("Bridge", margin + 50, y + 18);
    doc.setFont("helvetica", "normal");
    doc.setFontSize(9);
    doc.setTextColor(...slate400);
    doc.text("Dental Lab Work Order", margin + 50, y + 32);

    // Order number and status (top-right)
    doc.setFont("helvetica", "bold");
    doc.setFontSize(18);
    doc.setTextColor(...slate900);
    const numText = `#${safe(order.order_number)}`;
    const numW = doc.getTextWidth(numText);
    doc.text(numText, pageW - margin - numW, y + 16);

    // Status badge
    const status = statusLabel(order.status);
    doc.setFontSize(9);
    doc.setFont("helvetica", "bold");
    const statusW = doc.getTextWidth(status) + 16;
    const statusX = pageW - margin - statusW;
    doc.setFillColor(...teal50);
    doc.setDrawColor(...teal600);
    doc.roundedRect(statusX, y + 22, statusW, 16, 8, 8, "FD");
    doc.setTextColor(...teal600);
    doc.text(status, statusX + 8, y + 33);

    // Divider
    y = 80;
    doc.setDrawColor(...slate200);
    doc.line(margin, y, pageW - margin, y);
    y += 20;

    // ========== ORDER DETAILS SECTION ==========
    doc.setFont("helvetica", "bold");
    doc.setFontSize(12);
    doc.setTextColor(...slate900);
    doc.text("Order Information", margin, y);
    y += 16;

    const restricted = "Restricted";
    const detailFields: Array<[string, string]> = [
      ["Order #", safe(order.order_number)],
      ["Status", statusLabel(order.status)],
      ["Doctor", isParty ? safe(order.dr_name) : restricted],
      ["Patient", isParty ? safe(order.patient_name) : restricted],
      ["File #", isParty ? safe(order.file_number) : restricted],
      ["Shade", safe(order.shade)],
      ["Due Date", fmtDate(order.due_date)],
      ["Created", fmtDateTime(order.created_at)],
      ["Try-In", order.try_in ? "Yes" : "No"],
      ["Final Delivery", order.is_final ? "Yes" : "No"],
      ["Bill To", safe(order.bill_to)],
      ["Delivered At", order.delivered_at ? fmtDateTime(order.delivered_at) : "\u2014"],
    ];

    // Draw detail fields in a 2-column card grid
    const cardW = (contentW - 12) / 2;
    const cardH = 38;
    const cardGap = 8;

    for (let i = 0; i < detailFields.length; i++) {
      const col = i % 2;
      const row = Math.floor(i / 2);
      if (col === 0) ensureSpace(cardH + cardGap);
      const x = margin + col * (cardW + 12);
      const cy = y + row * (cardH + cardGap);

      doc.setDrawColor(...slate200);
      doc.setFillColor(...slate50);
      doc.roundedRect(x, cy, cardW, cardH, 4, 4, "FD");

      doc.setFont("helvetica", "bold");
      doc.setFontSize(7.5);
      doc.setTextColor(...slate400);
      doc.text(detailFields[i][0].toUpperCase(), x + 10, cy + 14);

      doc.setFont("helvetica", "normal");
      doc.setFontSize(11);
      doc.setTextColor(...slate900);
      const val = detailFields[i][1];
      const maxValW = cardW - 20;
      const trimmed = doc.getTextWidth(val) > maxValW
        ? val.substring(0, Math.floor(val.length * (maxValW / doc.getTextWidth(val)))) + "\u2026"
        : val;
      doc.text(trimmed, x + 10, cy + 30);
    }
    y += Math.ceil(detailFields.length / 2) * (cardH + cardGap) + 16;

    // ========== FROM / LAB SECTION ==========
    ensureSpace(100);
    doc.setFont("helvetica", "bold");
    doc.setFontSize(12);
    doc.setTextColor(...slate900);
    doc.text("Parties", margin, y);
    y += 16;

    const partyW = (contentW - 12) / 2;
    const parties = [
      {
        title: "FROM (Clinic/Center)",
        name: isParty ? safe(order.from_profile?.name) : restricted,
        phone: isParty ? safe(order.from_profile?.phone) : "\u2014",
        address: isParty ? safe([order.from_profile?.address, order.from_profile?.city].filter(Boolean).join(", ") || null) : "\u2014",
      },
      {
        title: "LAB",
        name: safe(order.lab_profile?.name),
        phone: safe(order.lab_profile?.phone),
        address: safe([order.lab_profile?.address, order.lab_profile?.city].filter(Boolean).join(", ") || null),
      },
    ];

    const partyH = 72;
    parties.forEach((p, i) => {
      const x = margin + i * (partyW + 12);
      doc.setFillColor(...white);
      doc.setDrawColor(...slate200);
      doc.roundedRect(x, y, partyW, partyH, 6, 6, "FD");

      // Teal top accent inside card
      doc.setFillColor(...teal600);
      doc.rect(x, y, partyW, 3, "F");
      // Re-round top corners
      doc.setFillColor(...white);

      doc.setFont("helvetica", "bold");
      doc.setFontSize(7.5);
      doc.setTextColor(...teal600);
      doc.text(p.title, x + 10, y + 16);

      doc.setFont("helvetica", "bold");
      doc.setFontSize(11);
      doc.setTextColor(...slate900);
      doc.text(p.name, x + 10, y + 32);

      doc.setFont("helvetica", "normal");
      doc.setFontSize(9);
      doc.setTextColor(...slate600);
      doc.text(p.phone, x + 10, y + 46);
      const addrLines = doc.splitTextToSize(p.address, partyW - 20);
      doc.text(addrLines.slice(0, 2), x + 10, y + 58);
    });
    y += partyH + 20;

    // ========== SERVICES TABLE ==========
    ensureSpace(60);
    doc.setFont("helvetica", "bold");
    doc.setFontSize(12);
    doc.setTextColor(...slate900);
    doc.text("Services", margin, y);
    y += 14;

    if (!services || services.length === 0) {
      doc.setFont("helvetica", "italic");
      doc.setFontSize(10);
      doc.setTextColor(...slate400);
      doc.text("No services listed.", margin + 8, y + 10);
      y += 28;
    } else {
      // Table header
      doc.setFillColor(241, 245, 249);
      doc.setDrawColor(...slate200);
      doc.roundedRect(margin, y, contentW, 22, 4, 4, "FD");
      doc.setFont("helvetica", "bold");
      doc.setFontSize(8);
      doc.setTextColor(...slate600);
      doc.text("SERVICE", margin + 10, y + 14);
      doc.text("TEETH", margin + 220, y + 14);
      doc.text("BRIDGE", margin + 320, y + 14);
      doc.text("NOTES", margin + 380, y + 14);
      y += 26;

      doc.setFont("helvetica", "normal");
      doc.setFontSize(9.5);
      for (let i = 0; i < services.length; i++) {
        const s = services[i];
        ensureSpace(30);

        // Alternate row shading
        if (i % 2 === 0) {
          doc.setFillColor(...slate50);
          doc.rect(margin, y - 2, contentW, 22, "F");
        }

        doc.setTextColor(...slate900);
        doc.setFont("helvetica", "normal");
        doc.setFontSize(9.5);
        doc.text(safe(s.service_name), margin + 10, y + 10);

        doc.setTextColor(...slate600);
        doc.text(safe(s.teeth_numbers), margin + 220, y + 10);

        doc.setTextColor(...teal600);
        doc.setFont("helvetica", "bold");
        doc.text(s.is_bridge ? "Yes" : "\u2014", margin + 320, y + 10);

        doc.setFont("helvetica", "normal");
        doc.setFontSize(9);
        doc.setTextColor(...slate600);
        const notes = isParty ? safe(s.notes) : "\u2014";
        const notesLines = doc.splitTextToSize(notes, contentW - 390);
        doc.text(notesLines.slice(0, 2), margin + 380, y + 10);

        const rowH = Math.max(22, 12 + notesLines.length * 11);
        y += rowH;

        // Bottom border
        doc.setDrawColor(241, 245, 249);
        doc.line(margin, y - 2, pageW - margin, y - 2);
      }
      y += 12;
    }

    // ========== NOTES ==========
    if (order.notes && isParty) {
      ensureSpace(80);
      doc.setFont("helvetica", "bold");
      doc.setFontSize(12);
      doc.setTextColor(...slate900);
      doc.text("Order Notes", margin, y);
      y += 14;

      doc.setDrawColor(...amber300);
      doc.setFillColor(...amber50);
      const notesLines = doc.splitTextToSize(String(order.notes), contentW - 20);
      const boxH = Math.max(32, notesLines.length * 13 + 20);
      doc.roundedRect(margin, y, contentW, boxH, 6, 6, "FD");
      doc.setFont("helvetica", "normal");
      doc.setFontSize(10);
      doc.setTextColor(...amber900);
      doc.text(notesLines, margin + 10, y + 14);
      y += boxH + 14;
    }

    // ========== REDO INFO ==========
    if (order.parent_order_id) {
      ensureSpace(40);
      doc.setFont("helvetica", "bold");
      doc.setFontSize(10);
      doc.setTextColor(...slate600);
      doc.text("This is a REDO of a previous order.", margin, y + 10);
      y += 24;
    }

    // ========== FOOTER ==========
    const totalPages = doc.internal.pages.length - 1;
    for (let p = 1; p <= totalPages; p++) {
      doc.setPage(p);
      // Bottom teal accent
      doc.setFillColor(...teal600);
      doc.rect(0, pageH - 4, pageW, 4, "F");

      doc.setFont("helvetica", "normal");
      doc.setFontSize(8);
      doc.setTextColor(...slate400);
      doc.text(
        `Generated by Bridge  \u00B7  ${fmtDate(new Date().toISOString())}`,
        margin,
        pageH - 16,
      );
      doc.text(`Page ${p} of ${totalPages}`, pageW - margin - 40, pageH - 16);

      if (!isParty) {
        doc.setFontSize(8);
        doc.setTextColor(...slate600);
        doc.text(
          "Sign in to Bridge with an account linked to this case to see the full work order.",
          margin,
          pageH - 28,
        );
      }
    }

    const pdfBytes = doc.output("arraybuffer");
    const filename = `order-${safe(order.order_number).replace(/[^A-Za-z0-9._-]/g, "")}.pdf`;

    return new Response(pdfBytes, {
      status: 200,
      headers: {
        ...corsHeaders,
        "Content-Type": "application/pdf",
        "Content-Disposition": `inline; filename="${filename}"`,
        "Cache-Control": "no-store",
      },
    });
  } catch (err) {
    console.error("order-view failed", err);
    return new Response("Could not generate this document. Please try again.", {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "text/plain" },
    });
  }
});
