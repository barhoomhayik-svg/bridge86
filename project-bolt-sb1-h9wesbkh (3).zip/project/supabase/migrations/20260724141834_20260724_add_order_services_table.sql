/*
# Add order_services table for multi-service orders

1. New Tables
- `order_services`
  - `id` (uuid, primary key)
  - `order_id` (uuid, FK to orders.id, ON DELETE CASCADE)
  - `service_id` (uuid, FK to services.id, nullable for custom cases)
  - `service_name` (text, not null — denormalized name for display)
  - `notes` (text, nullable — per-service notes like shade/material)
  - `teeth_numbers` (text, nullable — comma-separated tooth numbers)
  - `created_at` (timestamptz, default now())

2. Purpose
- Allows a single order to contain multiple services, each with its own teeth selection and notes.
- Mirrors the existing `quotation_services` table pattern.
- The `orders.service_id` and `orders.teeth_numbers` columns are kept for backward compatibility with existing single-service orders.

3. Security
- Enable RLS on `order_services`.
- SELECT: any authenticated user who can already see the parent order.
- INSERT/UPDATE/DELETE: only the order's creator (from_id) or the lab (lab_id).
- Uses the same ownership pattern as the orders table.
*/

CREATE TABLE IF NOT EXISTS order_services (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id uuid NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  service_id uuid REFERENCES services(id) ON DELETE SET NULL,
  service_name text NOT NULL,
  notes text,
  teeth_numbers text,
  created_at timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_order_services_order_id ON order_services(order_id);

ALTER TABLE order_services ENABLE ROW LEVEL SECURITY;

-- SELECT: anyone who can see the parent order can see its service lines
DROP POLICY IF EXISTS "select_order_services" ON order_services;
CREATE POLICY "select_order_services" ON order_services FOR SELECT
  TO authenticated USING (
    EXISTS (
      SELECT 1 FROM orders o
      WHERE o.id = order_services.order_id
      AND (
        o.from_id = auth.uid()
        OR o.lab_id = auth.uid()
        OR o.doctor_id = auth.uid()
        OR EXISTS (
          SELECT 1 FROM center_members cm
          WHERE cm.center_id = o.from_id AND cm.doctor_id = auth.uid()
        )
      )
    )
  );

-- INSERT: only the order creator or lab
DROP POLICY IF EXISTS "insert_order_services" ON order_services;
CREATE POLICY "insert_order_services" ON order_services FOR INSERT
  TO authenticated WITH CHECK (
    EXISTS (
      SELECT 1 FROM orders o
      WHERE o.id = order_services.order_id
      AND (o.from_id = auth.uid() OR o.lab_id = auth.uid())
    )
  );

-- UPDATE: only the order creator or lab
DROP POLICY IF EXISTS "update_order_services" ON order_services;
CREATE POLICY "update_order_services" ON order_services FOR UPDATE
  TO authenticated USING (
    EXISTS (
      SELECT 1 FROM orders o
      WHERE o.id = order_services.order_id
      AND (o.from_id = auth.uid() OR o.lab_id = auth.uid())
    )
  ) WITH CHECK (
    EXISTS (
      SELECT 1 FROM orders o
      WHERE o.id = order_services.order_id
      AND (o.from_id = auth.uid() OR o.lab_id = auth.uid())
    )
  );

-- DELETE: only the order creator or lab
DROP POLICY IF EXISTS "delete_order_services" ON order_services;
CREATE POLICY "delete_order_services" ON order_services FOR DELETE
  TO authenticated USING (
    EXISTS (
      SELECT 1 FROM orders o
      WHERE o.id = order_services.order_id
      AND (o.from_id = auth.uid() OR o.lab_id = auth.uid())
    )
  );
