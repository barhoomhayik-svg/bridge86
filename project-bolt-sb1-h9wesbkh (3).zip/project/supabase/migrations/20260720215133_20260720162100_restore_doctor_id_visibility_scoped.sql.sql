/*
# Restore doctor_id visibility in orders_select (with membership-time scoping)

## Problem
The previous scoping migration (20260720162000) rebuilt `orders_select` using
the pre-20260715 shape and accidentally dropped the `auth.uid() = doctor_id`
condition that lets an assigned doctor see an order a center placed on their
behalf. Assigned doctors lost visibility of their own orders.

## Fix
Rebuild `orders_select` and `order_attachments_select` to include ALL four
visibility paths:
  1. Sender (`from_id`)
  2. Receiving lab (`lab_id`)
  3. Assigned doctor (`doctor_id`)
  4. Center team membership — scoped so the center only sees orders created
     on/after the doctor joined (`center_members.created_at <= orders.created_at`)

No schema changes. No new tables/columns. Policies only.
*/

DROP POLICY IF EXISTS "orders_select" ON orders;
CREATE POLICY "orders_select" ON orders FOR SELECT TO authenticated
  USING (
    auth.uid() = from_id
    OR auth.uid() = lab_id
    OR auth.uid() = doctor_id
    OR EXISTS (
      SELECT 1 FROM center_members
      WHERE center_members.center_id = auth.uid()
        AND center_members.doctor_id = orders.from_id
        AND center_members.created_at <= orders.created_at
    )
  );

DROP POLICY IF EXISTS "order_attachments_select" ON order_attachments;
CREATE POLICY "order_attachments_select" ON order_attachments FOR SELECT TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM orders
      WHERE orders.id = order_attachments.order_id
        AND (
          orders.from_id = auth.uid()
          OR orders.lab_id = auth.uid()
          OR orders.doctor_id = auth.uid()
          OR EXISTS (
            SELECT 1 FROM center_members
            WHERE center_members.center_id = auth.uid()
              AND center_members.doctor_id = orders.from_id
              AND center_members.created_at <= orders.created_at
          )
        )
    )
  );
