-- Revoke anon and public EXECUTE on internal helper functions
-- These should only be callable by authenticated (for RLS policy evaluation)
REVOKE EXECUTE ON FUNCTION internal.can_access_order_object(text, uuid) FROM public, anon;
REVOKE EXECUTE ON FUNCTION internal.can_view_profile(uuid) FROM public, anon;
