/*
  # Harden database function definitions

  1. Security
    - The notification and numbering trigger functions ran with a mutable
      search_path; several are SECURITY DEFINER, so a schema a caller controls
      could shadow the objects they reference.
    - Supabase's default privileges also left every one of them executable by the
      anon and authenticated roles even though they are only ever meant to run as
      triggers. EXECUTE is now revoked from both roles for those functions.
    - Helper functions the app calls directly keep EXECUTE for authenticated only.
*/

DO $$
DECLARE
  fn text;
BEGIN
  FOREACH fn IN ARRAY ARRAY[
    'public.fn_notify_attachment()',
    'public.fn_notify_delivery()',
    'public.fn_notify_doctor_order()',
    'public.fn_notify_new_comment()',
    'public.fn_notify_new_order()',
    'public.fn_notify_new_quotation()',
    'public.fn_notify_order_status()',
    'public.fn_notify_quotation_update()',
    'public.generate_order_number()',
    'public.generate_profile_code()',
    'public.enforce_redo_window()',
    'public.enforce_order_update_guards()',
    'public.handle_new_user()'
  ] LOOP
    EXECUTE format('ALTER FUNCTION %s SET search_path = public, pg_temp', fn);
    EXECUTE format('REVOKE ALL ON FUNCTION %s FROM PUBLIC', fn);
    EXECUTE format('REVOKE ALL ON FUNCTION %s FROM anon', fn);
    EXECUTE format('REVOKE ALL ON FUNCTION %s FROM authenticated', fn);
  END LOOP;
END $$;

REVOKE ALL ON FUNCTION public.can_view_profile(uuid) FROM anon;
REVOKE ALL ON FUNCTION public.search_doctor_profiles(text) FROM anon;
REVOKE ALL ON FUNCTION public.can_access_order_object(text, uuid) FROM anon;
REVOKE ALL ON FUNCTION public.can_access_order_object(text, uuid) FROM authenticated;

GRANT EXECUTE ON FUNCTION public.can_view_profile(uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.search_doctor_profiles(text) TO authenticated;
