/*
# Create center_labs table for formal center-lab relationships

1. New Tables
- `center_labs`
  - `id` (uuid, primary key)
  - `center_id` (uuid, not null) — FK → profiles(id), the center
  - `lab_id` (uuid, not null) — FK → profiles(id), the lab
  - `quotation_id` (uuid, nullable) — FK → quotations(id), the quotation that established this relationship
  - `created_at` (timestamptz, default now())
  - UNIQUE(center_id, lab_id) — one relationship per center-lab pair

2. Security
- Enable RLS on `center_labs`.
- SELECT: center owner OR lab owner can read (both parties need visibility).
- INSERT: center owner only (centers establish formal labs by accepting quotations).
- DELETE: center owner only.

3. Notes
- When a center accepts a quotation, the frontend inserts a row here linking
  the center to that lab. This creates a "formal lab" relationship.
- When a doctor belonging to a center creates an order "for" that center,
  the lab picker is restricted to the center's formal labs (rows in this table).
- If a center has no formal labs yet, the doctor can still browse all labs
  (fallback so they are never stuck).
*/

CREATE TABLE IF NOT EXISTS center_labs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  center_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  lab_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  quotation_id uuid REFERENCES quotations(id) ON DELETE SET NULL,
  created_at timestamptz DEFAULT now(),
  UNIQUE (center_id, lab_id)
);

ALTER TABLE center_labs ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_center_labs" ON center_labs;
CREATE POLICY "select_center_labs"
ON center_labs FOR SELECT
TO authenticated
USING (auth.uid() = center_id OR auth.uid() = lab_id);

DROP POLICY IF EXISTS "insert_center_labs" ON center_labs;
CREATE POLICY "insert_center_labs"
ON center_labs FOR INSERT
TO authenticated
WITH CHECK (auth.uid() = center_id);

DROP POLICY IF EXISTS "delete_center_labs" ON center_labs;
CREATE POLICY "delete_center_labs"
ON center_labs FOR DELETE
TO authenticated
USING (auth.uid() = center_id);
