-- ============================================================
-- Enhanced real-time notification triggers
-- Adds specific notification types for order lifecycle events
-- and attachment uploads
-- ============================================================

-- 1. Replace the generic order_status trigger with specific types
CREATE OR REPLACE FUNCTION fn_notify_order_status()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER AS $$
BEGIN
  IF OLD.status IS DISTINCT FROM NEW.status THEN
    -- Specific notification types for key status transitions
    IF NEW.status = 'accepted' THEN
      INSERT INTO notifications (user_id, type, title, body, related_id)
      VALUES (NEW.from_id, 'order_accepted', 'Order Accepted – ' || NEW.order_number,
        'Your order has been accepted by the lab.', NEW.id);
    ELSIF NEW.status = 'rejected' THEN
      INSERT INTO notifications (user_id, type, title, body, related_id)
      VALUES (NEW.from_id, 'order_rejected', 'Order Rejected – ' || NEW.order_number,
        'Your order has been rejected by the lab.', NEW.id);
    ELSIF NEW.status = 'in_progress' THEN
      INSERT INTO notifications (user_id, type, title, body, related_id)
      VALUES (NEW.from_id, 'order_update', 'Order In Progress – ' || NEW.order_number,
        'The lab has started working on your order.', NEW.id);
    ELSIF NEW.status = 'completed' THEN
      INSERT INTO notifications (user_id, type, title, body, related_id)
      VALUES (NEW.from_id, 'order_completed', 'Order Completed – ' || NEW.order_number,
        'Your order is ready for delivery.', NEW.id);
    ELSIF NEW.status = 'delivering' THEN
      INSERT INTO notifications (user_id, type, title, body, related_id)
      VALUES (NEW.from_id, 'order_delivering', 'Out for Delivery – ' || NEW.order_number,
        'Your case is on its way to you.', NEW.id);
    ELSIF NEW.status = 'cancelled' THEN
      INSERT INTO notifications (user_id, type, title, body, related_id)
      VALUES (NEW.from_id, 'order_cancelled', 'Order Cancelled – ' || NEW.order_number,
        'This order has been cancelled.', NEW.id);
    ELSIF NEW.status = 'redo' THEN
      INSERT INTO notifications (user_id, type, title, body, related_id)
      VALUES (NEW.from_id, 'order_redo', 'Redo Requested – ' || NEW.order_number,
        'A redo has been requested for this order.', NEW.id);
    ELSE
      INSERT INTO notifications (user_id, type, title, body, related_id)
      VALUES (NEW.from_id, 'order_update', 'Order Status Changed',
        'Order ' || NEW.order_number || ' is now ' || REPLACE(NEW.status, '_', ' '), NEW.id);
    END IF;
  END IF;
  RETURN NEW;
END;
$$;

-- 2. Notify the other party when an attachment is uploaded
CREATE OR REPLACE FUNCTION fn_notify_attachment()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER AS $$
DECLARE
  order_row orders%ROWTYPE;
  uploader_name text;
  notify_user uuid;
BEGIN
  SELECT * INTO order_row FROM orders WHERE id = NEW.order_id;
  IF NOT FOUND THEN RETURN NEW; END IF;

  SELECT name INTO uploader_name FROM profiles WHERE id = NEW.uploader_id;

  -- Notify the OTHER party
  IF NEW.uploader_id = order_row.from_id THEN
    notify_user := order_row.lab_id;
  ELSE
    notify_user := order_row.from_id;
  END IF;

  INSERT INTO notifications (user_id, type, title, body, related_id)
  VALUES (notify_user, 'new_attachment', 'New File – ' || order_row.order_number,
    COALESCE(uploader_name, 'Someone') || ' uploaded ' || NEW.file_name, NEW.order_id);

  RETURN NEW;
END;
$$;

-- Trigger for attachment uploads
DROP TRIGGER IF EXISTS trg_notify_attachment ON order_attachments;
CREATE TRIGGER trg_notify_attachment AFTER INSERT ON order_attachments
FOR EACH ROW EXECUTE FUNCTION fn_notify_attachment();

-- 3. Notify the lab when a quotation is accepted or declined by the requester
CREATE OR REPLACE FUNCTION fn_notify_quotation_update()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER AS $$
BEGIN
  IF OLD.status IS DISTINCT FROM NEW.status THEN
    IF NEW.status = 'accepted' THEN
      INSERT INTO notifications (user_id, type, title, body, related_id)
      VALUES (NEW.lab_id, 'quotation_accepted', 'Quotation Accepted',
        'Your quotation has been accepted by the client.', NEW.id);
    ELSIF NEW.status = 'declined' THEN
      INSERT INTO notifications (user_id, type, title, body, related_id)
      VALUES (NEW.lab_id, 'quotation_declined', 'Quotation Declined',
        'Your quotation has been declined by the client.', NEW.id);
    ELSIF NEW.status = 'responded' THEN
      INSERT INTO notifications (user_id, type, title, body, related_id)
      VALUES (NEW.from_id, 'quotation_update', 'Quotation Response Received',
        'The lab has responded to your quotation request.', NEW.id);
    ELSE
      INSERT INTO notifications (user_id, type, title, body, related_id)
      VALUES (NEW.from_id, 'quotation_update', 'Quotation Updated',
        'Your quotation request status: ' || NEW.status, NEW.id);
    END IF;
  END IF;
  RETURN NEW;
END;
$$;
