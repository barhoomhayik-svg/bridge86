/*
# Add delivering and delivered order statuses

## Overview
Extends the order status pipeline to include delivery stages so that
labs, doctors, and centers can see when a case is out for delivery and
when it has been delivered — same as they see pending/accepted/in_progress/completed.

## Pipeline
pending → accepted → in_progress → completed → delivering → delivered

## Changes
1. orders.status CHECK constraint updated to include 'delivering' and 'delivered'
2. No new columns — delivered_at/delivered_by already exist from the
   previous migration; the status column now tracks the delivery stage
   in addition to those timestamps.

## Notes
- Existing orders with delivered_at set will be updated to status='delivered'
  so they show correctly in the new pipeline.
- Idempotent: constraint is dropped and re-added safely.
*/

-- Update status constraint to include delivering + delivered
ALTER TABLE orders DROP CONSTRAINT IF EXISTS orders_status_check;
ALTER TABLE orders ADD CONSTRAINT orders_status_check
  CHECK (status IN ('pending', 'accepted', 'in_progress', 'completed', 'delivering', 'delivered', 'rejected', 'cancelled', 'redo'));

-- Backfill: any order that has delivered_at set but status is still 'completed'
-- should be moved to 'delivered' so it appears correctly in the new pipeline
UPDATE orders SET status = 'delivered' WHERE delivered_at IS NOT NULL AND status = 'completed';
