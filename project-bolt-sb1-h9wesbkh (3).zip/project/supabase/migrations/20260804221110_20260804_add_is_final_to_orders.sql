/*
# Add is_final flag to orders

1. Purpose
   When a doctor approves a try-in case, the order returns to "in_progress"
   with a "Final Case" tag so the lab knows this is the final version.
   The lab then completes and delivers normally.

2. Changes
   - Add `is_final` boolean column to `orders`, default false.
   - Existing rows are unaffected (default false).

3. Security
   - No RLS policy changes. The new column is writable by the same
     roles that can already update orders (lab/doctor/center via existing
     UPDATE policies). No new policy needed.
*/

ALTER TABLE orders
  ADD COLUMN IF NOT EXISTS is_final boolean NOT NULL DEFAULT false;
