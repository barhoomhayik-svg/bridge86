/*
  # Keep the quotation guard trigger off the public API

  1. Why
     - New functions get EXECUTE for PUBLIC, so the trigger function added for the
       quotation guards was reachable as an RPC endpoint. Trigger functions should
       never be callable directly; the existing order and profile guard functions
       are already revoked this way.

  2. Change
     - Revoke EXECUTE from PUBLIC, `anon` and `authenticated`.

  3. Security
     - The trigger itself keeps working: it runs as the table owner, not as the
       caller's role.
*/

REVOKE ALL ON FUNCTION public.enforce_quotation_update_guards() FROM PUBLIC;
REVOKE ALL ON FUNCTION public.enforce_quotation_update_guards() FROM anon;
REVOKE ALL ON FUNCTION public.enforce_quotation_update_guards() FROM authenticated;
