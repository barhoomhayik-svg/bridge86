/*
# Add monthly target units to lab_technicians

## Overview
Allows lab managers to set a custom monthly production target (in teeth/units)
for each technician. When set, the analytics page uses this value as the
technician's goal. When NULL, the app calculates an automatic target from
the rolling 3-month average of completed units.

## Changes

### 1. New column on lab_technicians
- `monthly_target_units` (integer, nullable) — manual target override.

### 2. New UPDATE policy on lab_technicians
- Lab owner (`auth.uid() = lab_id`) can update their technician rows.

## Security
- Only the lab owner can update the target; technicians cannot modify it.
*/

-- 1. Add the column
DO $$ BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema = 'public'
      AND table_name = 'lab_technicians'
      AND column_name = 'monthly_target_units'
  ) THEN
    ALTER TABLE lab_technicians ADD COLUMN monthly_target_units integer;
  END IF;
END $$;

-- 2. UPDATE policy so the lab owner can set the target
DROP POLICY IF EXISTS "lab_technicians_update" ON lab_technicians;
CREATE POLICY "lab_technicians_update" ON lab_technicians FOR UPDATE
  TO authenticated
  USING (auth.uid() = lab_id)
  WITH CHECK (auth.uid() = lab_id);
