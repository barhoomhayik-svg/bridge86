/*
  # Enforce upload size and type limits server-side

  1. Security
    - The buckets had no file_size_limit and no allowed_mime_types, so the accept
      attributes in the UI were the only restriction and a direct storage call
      could upload an arbitrary file of arbitrary size.
    - Avatar and case-photo buckets now accept images only, up to 10 MB.
    - Case attachments accept images, PDFs, archives and the CAD/scan types the
      app advertises (including generic binary, which is what browsers report for
      stl, ply and dcm files), up to 50 MB.
*/

UPDATE storage.buckets
SET file_size_limit = 10485760,
    allowed_mime_types = ARRAY['image/png','image/jpeg','image/jpg','image/webp','image/gif','image/heic','image/heif']
WHERE id IN ('avatars', 'case-photos');

UPDATE storage.buckets
SET file_size_limit = 52428800,
    allowed_mime_types = ARRAY[
      'image/png','image/jpeg','image/jpg','image/webp','image/gif','image/heic','image/heif',
      'application/pdf','application/zip','application/x-zip-compressed',
      'application/dicom','model/stl','model/obj','application/sla',
      'application/octet-stream','text/plain'
    ]
WHERE id = 'order-attachments';
