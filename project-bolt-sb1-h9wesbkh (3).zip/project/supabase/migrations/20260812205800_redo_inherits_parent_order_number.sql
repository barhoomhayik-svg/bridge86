/*
  # Redo orders inherit parent order_number

  When a new order is inserted with a non-null parent_order_id, copy the
  parent's order_number onto the child instead of generating a new one.
*/

CREATE OR REPLACE FUNCTION generate_order_number()
RETURNS TRIGGER AS $$
DECLARE
  prefix text;
  next_num integer;
  parent_number text;
BEGIN
  IF NEW.parent_order_id IS NOT NULL THEN
    SELECT order_number INTO parent_number FROM orders WHERE id = NEW.parent_order_id;
    IF parent_number IS NOT NULL THEN
      NEW.order_number := parent_number;
      RETURN NEW;
    END IF;
  END IF;

  prefix := 'ORD-' || upper(substr(coalesce(NEW.dr_name, 'X'), 1, 1));
  SELECT COALESCE(MAX(num), 0) + 1 INTO next_num
  FROM (
    SELECT CASE
      WHEN order_number ~ '^ORD-[A-Z][0-9]+$'
        THEN regexp_replace(order_number, '^ORD-[A-Z]', '')::integer
      ELSE 0
    END AS num
    FROM orders
    WHERE order_number LIKE prefix || '%'
  ) sub;
  NEW.order_number := prefix || lpad(next_num::text, 3, '0');
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;
