/*
# Restore batch 2: Storage buckets, features (favourites, center_members, notifications, triggers), quotation_services, profile_code, comments, doctor assignment, redo, bill_to
*/

-- Storage bucket for order-attachments
INSERT INTO storage.buckets (id, name, public) VALUES ('order-attachments', 'order-attachments', true) ON CONFLICT (id) DO NOTHING;

DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE schemaname = 'storage' AND tablename = 'objects' AND policyname = 'order_attachments_select') THEN
    EXECUTE $p$ CREATE POLICY order_attachments_select ON storage.objects FOR SELECT TO public USING (bucket_id = 'order-attachments') $p$;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE schemaname = 'storage' AND tablename = 'objects' AND policyname = 'order_attachments_insert') THEN
    EXECUTE $p$ CREATE POLICY order_attachments_insert ON storage.objects FOR INSERT TO authenticated WITH CHECK (bucket_id = 'order-attachments') $p$;
  END IF;
END $$;

-- Features: logo_url, favourite_labs, center_members, notifications
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS logo_url text;

CREATE TABLE IF NOT EXISTS favourite_labs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES profiles(id) ON DELETE CASCADE,
  lab_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  created_at timestamptz DEFAULT now(),
  UNIQUE(user_id, lab_id)
);
ALTER TABLE favourite_labs ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "fl_select" ON favourite_labs;
CREATE POLICY "fl_select" ON favourite_labs FOR SELECT TO authenticated USING (auth.uid() = user_id);
DROP POLICY IF EXISTS "fl_insert" ON favourite_labs;
CREATE POLICY "fl_insert" ON favourite_labs FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
DROP POLICY IF EXISTS "fl_delete" ON favourite_labs;
CREATE POLICY "fl_delete" ON favourite_labs FOR DELETE TO authenticated USING (auth.uid() = user_id);

CREATE TABLE IF NOT EXISTS center_members (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  center_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  doctor_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  created_at timestamptz DEFAULT now(),
  UNIQUE(center_id, doctor_id)
);
ALTER TABLE center_members ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "cm_select" ON center_members;
CREATE POLICY "cm_select" ON center_members FOR SELECT TO authenticated USING (auth.uid() = center_id OR auth.uid() = doctor_id);
DROP POLICY IF EXISTS "cm_insert" ON center_members;
CREATE POLICY "cm_insert" ON center_members FOR INSERT TO authenticated WITH CHECK (auth.uid() = center_id AND EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'center'));
DROP POLICY IF EXISTS "cm_delete" ON center_members;
CREATE POLICY "cm_delete" ON center_members FOR DELETE TO authenticated USING (auth.uid() = center_id);

CREATE TABLE IF NOT EXISTS notifications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  type text NOT NULL,
  title text NOT NULL,
  body text,
  related_id uuid,
  read boolean NOT NULL DEFAULT false,
  created_at timestamptz DEFAULT now()
);
ALTER TABLE notifications ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "notif_select" ON notifications;
CREATE POLICY "notif_select" ON notifications FOR SELECT TO authenticated USING (auth.uid() = user_id);
DROP POLICY IF EXISTS "notif_insert" ON notifications;
CREATE POLICY "notif_insert" ON notifications FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
DROP POLICY IF EXISTS "notif_update" ON notifications;
CREATE POLICY "notif_update" ON notifications FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
DROP POLICY IF EXISTS "notif_delete" ON notifications;
CREATE POLICY "notif_delete" ON notifications FOR DELETE TO authenticated USING (auth.uid() = user_id);

CREATE INDEX IF NOT EXISTS idx_notifications_user_id ON notifications(user_id);
CREATE INDEX IF NOT EXISTS idx_notifications_read ON notifications(user_id, read);
CREATE INDEX IF NOT EXISTS idx_favourite_labs_user ON favourite_labs(user_id);
CREATE INDEX IF NOT EXISTS idx_center_members_center ON center_members(center_id);

-- Notification triggers
CREATE OR REPLACE FUNCTION fn_notify_new_order() RETURNS TRIGGER LANGUAGE plpgsql SECURITY DEFINER AS $$
DECLARE sender_name text;
BEGIN
  SELECT name INTO sender_name FROM profiles WHERE id = NEW.from_id;
  INSERT INTO notifications (user_id, type, title, body, related_id)
  VALUES (NEW.lab_id, 'new_order', 'New Order Received', 'Order ' || NEW.order_number || ' from ' || COALESCE(sender_name, 'a client'), NEW.id);
  RETURN NEW;
END; $$;
DROP TRIGGER IF EXISTS trg_notify_new_order ON orders;
CREATE TRIGGER trg_notify_new_order AFTER INSERT ON orders FOR EACH ROW EXECUTE FUNCTION fn_notify_new_order();

CREATE OR REPLACE FUNCTION fn_notify_order_status() RETURNS TRIGGER LANGUAGE plpgsql SECURITY DEFINER AS $$
BEGIN
  IF OLD.status IS DISTINCT FROM NEW.status THEN
    INSERT INTO notifications (user_id, type, title, body, related_id)
    VALUES (NEW.from_id, 'order_update', 'Order Status Changed', 'Order ' || NEW.order_number || ' is now ' || REPLACE(NEW.status, '_', ' '), NEW.id);
  END IF;
  RETURN NEW;
END; $$;
DROP TRIGGER IF EXISTS trg_notify_order_status ON orders;
CREATE TRIGGER trg_notify_order_status AFTER UPDATE ON orders FOR EACH ROW EXECUTE FUNCTION fn_notify_order_status();

CREATE OR REPLACE FUNCTION fn_notify_new_quotation() RETURNS TRIGGER LANGUAGE plpgsql SECURITY DEFINER AS $$
DECLARE sender_name text;
BEGIN
  SELECT name INTO sender_name FROM profiles WHERE id = NEW.from_id;
  INSERT INTO notifications (user_id, type, title, body, related_id)
  VALUES (NEW.lab_id, 'new_quotation', 'New Quotation Request', 'Quotation request from ' || COALESCE(sender_name, 'a client'), NEW.id);
  RETURN NEW;
END; $$;
DROP TRIGGER IF EXISTS trg_notify_new_quotation ON quotations;
CREATE TRIGGER trg_notify_new_quotation AFTER INSERT ON quotations FOR EACH ROW EXECUTE FUNCTION fn_notify_new_quotation();

CREATE OR REPLACE FUNCTION fn_notify_quotation_update() RETURNS TRIGGER LANGUAGE plpgsql SECURITY DEFINER AS $$
BEGIN
  IF OLD.status IS DISTINCT FROM NEW.status THEN
    INSERT INTO notifications (user_id, type, title, body, related_id)
    VALUES (NEW.from_id, 'quotation_update', 'Quotation Updated', 'Your quotation request status: ' || NEW.status, NEW.id);
  END IF;
  RETURN NEW;
END; $$;
DROP TRIGGER IF EXISTS trg_notify_quotation_update ON quotations;
CREATE TRIGGER trg_notify_quotation_update AFTER UPDATE ON quotations FOR EACH ROW EXECUTE FUNCTION fn_notify_quotation_update();

-- Avatars bucket
INSERT INTO storage.buckets (id, name, public) VALUES ('avatars', 'avatars', true) ON CONFLICT (id) DO NOTHING;
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE schemaname='storage' AND tablename='objects' AND policyname='avatars_select') THEN
    EXECUTE $p$ CREATE POLICY avatars_select ON storage.objects FOR SELECT TO public USING (bucket_id='avatars') $p$;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE schemaname='storage' AND tablename='objects' AND policyname='avatars_insert') THEN
    EXECUTE $p$ CREATE POLICY avatars_insert ON storage.objects FOR INSERT TO authenticated WITH CHECK (bucket_id='avatars') $p$;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE schemaname='storage' AND tablename='objects' AND policyname='avatars_update') THEN
    EXECUTE $p$ CREATE POLICY avatars_update ON storage.objects FOR UPDATE TO authenticated USING (bucket_id='avatars') WITH CHECK (bucket_id='avatars') $p$;
  END IF;
END $$;

-- Quotation multi-service
ALTER TABLE quotations ADD COLUMN IF NOT EXISTS service_id uuid REFERENCES services(id) ON DELETE SET NULL;

CREATE TABLE IF NOT EXISTS quotation_services (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  quotation_id uuid NOT NULL REFERENCES quotations(id) ON DELETE CASCADE,
  service_id uuid REFERENCES services(id) ON DELETE SET NULL,
  service_name text NOT NULL,
  notes text,
  quoted_price numeric,
  created_at timestamptz DEFAULT now()
);
ALTER TABLE quotation_services ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_quotation_services" ON quotation_services;
CREATE POLICY "select_quotation_services" ON quotation_services FOR SELECT TO authenticated
  USING (EXISTS (SELECT 1 FROM quotations q WHERE q.id = quotation_id AND (q.from_id = auth.uid() OR q.lab_id = auth.uid())));
DROP POLICY IF EXISTS "insert_quotation_services" ON quotation_services;
CREATE POLICY "insert_quotation_services" ON quotation_services FOR INSERT TO authenticated
  WITH CHECK (EXISTS (SELECT 1 FROM quotations q WHERE q.id = quotation_id AND q.from_id = auth.uid()));
DROP POLICY IF EXISTS "update_quotation_services" ON quotation_services;
CREATE POLICY "update_quotation_services" ON quotation_services FOR UPDATE TO authenticated
  USING (EXISTS (SELECT 1 FROM quotations q WHERE q.id = quotation_id AND q.lab_id = auth.uid()))
  WITH CHECK (EXISTS (SELECT 1 FROM quotations q WHERE q.id = quotation_id AND q.lab_id = auth.uid()));
DROP POLICY IF EXISTS "delete_quotation_services" ON quotation_services;
CREATE POLICY "delete_quotation_services" ON quotation_services FOR DELETE TO authenticated
  USING (EXISTS (SELECT 1 FROM quotations q WHERE q.id = quotation_id AND q.from_id = auth.uid()));

ALTER TABLE quotations DROP COLUMN IF EXISTS service_id;
ALTER TABLE quotations DROP COLUMN IF EXISTS response_price;
ALTER TABLE quotation_services ADD COLUMN IF NOT EXISTS teeth_numbers text;

-- Profile code
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS profile_code text;
DO $$
DECLARE r RECORD; new_code text;
BEGIN
  FOR r IN SELECT id FROM profiles WHERE profile_code IS NULL LOOP
    LOOP
      new_code := upper(substr(replace(gen_random_uuid()::text, '-', ''), 1, 6));
      EXIT WHEN NOT EXISTS (SELECT 1 FROM profiles WHERE profile_code = new_code);
    END LOOP;
    UPDATE profiles SET profile_code = new_code WHERE id = r.id;
  END LOOP;
END $$;
DO $$ BEGIN
  ALTER TABLE profiles ALTER COLUMN profile_code SET NOT NULL;
EXCEPTION WHEN others THEN NULL;
END $$;
DO $$ BEGIN
  ALTER TABLE profiles ADD CONSTRAINT profiles_profile_code_unique UNIQUE (profile_code);
EXCEPTION WHEN duplicate_table THEN NULL;
END $$;

CREATE OR REPLACE FUNCTION generate_profile_code() RETURNS TRIGGER LANGUAGE plpgsql AS $$
DECLARE new_code text;
BEGIN
  IF NEW.profile_code IS NULL OR NEW.profile_code = '' THEN
    LOOP
      new_code := upper(substr(replace(gen_random_uuid()::text, '-', ''), 1, 6));
      EXIT WHEN NOT EXISTS (SELECT 1 FROM profiles WHERE profile_code = new_code);
    END LOOP;
    NEW.profile_code := new_code;
  END IF;
  RETURN NEW;
END $$;
DROP TRIGGER IF EXISTS trg_profile_code ON profiles;
CREATE TRIGGER trg_profile_code BEFORE INSERT ON profiles FOR EACH ROW EXECUTE FUNCTION generate_profile_code();
CREATE INDEX IF NOT EXISTS idx_profiles_profile_code ON profiles(profile_code);

-- Case photos storage bucket
INSERT INTO storage.buckets (id, name, public) VALUES ('case-photos', 'case-photos', true) ON CONFLICT (id) DO NOTHING;
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE schemaname='storage' AND tablename='objects' AND policyname='case_photos_select') THEN
    EXECUTE $p$ CREATE POLICY case_photos_select ON storage.objects FOR SELECT TO public USING (bucket_id = 'case-photos') $p$;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE schemaname='storage' AND tablename='objects' AND policyname='case_photos_insert') THEN
    EXECUTE $p$ CREATE POLICY case_photos_insert ON storage.objects FOR INSERT TO authenticated WITH CHECK (bucket_id = 'case-photos' AND (storage.foldername(name))[1] = auth.uid()::text) $p$;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE schemaname='storage' AND tablename='objects' AND policyname='case_photos_update') THEN
    EXECUTE $p$ CREATE POLICY case_photos_update ON storage.objects FOR UPDATE TO authenticated USING (bucket_id = 'case-photos' AND (storage.foldername(name))[1] = auth.uid()::text) WITH CHECK (bucket_id = 'case-photos' AND (storage.foldername(name))[1] = auth.uid()::text) $p$;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE schemaname='storage' AND tablename='objects' AND policyname='case_photos_delete') THEN
    EXECUTE $p$ CREATE POLICY case_photos_delete ON storage.objects FOR DELETE TO authenticated USING (bucket_id = 'case-photos' AND (storage.foldername(name))[1] = auth.uid()::text) $p$;
  END IF;
END $$;
