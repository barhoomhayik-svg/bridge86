/*
# Restore batch 3: Comments, doctor assignment, redo, bill_to, center team visibility, drivers, delivering/delivered statuses
*/

-- Order comments
CREATE TABLE IF NOT EXISTS order_comments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id uuid NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  author_id uuid NOT NULL DEFAULT auth.uid() REFERENCES profiles(id) ON DELETE CASCADE,
  body text NOT NULL CHECK (char_length(trim(body)) > 0),
  created_at timestamptz DEFAULT now()
);
ALTER TABLE order_comments ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "order_comments_select" ON order_comments;
CREATE POLICY "order_comments_select" ON order_comments FOR SELECT TO authenticated
  USING (EXISTS (SELECT 1 FROM orders WHERE orders.id = order_id AND (orders.from_id = auth.uid() OR orders.lab_id = auth.uid())));
DROP POLICY IF EXISTS "order_comments_insert" ON order_comments;
CREATE POLICY "order_comments_insert" ON order_comments FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = author_id AND EXISTS (SELECT 1 FROM orders WHERE orders.id = order_id AND (orders.from_id = auth.uid() OR orders.lab_id = auth.uid())));
DROP POLICY IF EXISTS "order_comments_delete" ON order_comments;
CREATE POLICY "order_comments_delete" ON order_comments FOR DELETE TO authenticated USING (auth.uid() = author_id);
CREATE INDEX IF NOT EXISTS idx_order_comments_order_id ON order_comments(order_id);
CREATE INDEX IF NOT EXISTS idx_order_comments_author_id ON order_comments(author_id);

-- Order comment reads
CREATE TABLE IF NOT EXISTS order_comment_reads (
  user_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  order_id uuid NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  last_read_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (user_id, order_id)
);
ALTER TABLE order_comment_reads ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "select_own_reads" ON order_comment_reads;
CREATE POLICY "select_own_reads" ON order_comment_reads FOR SELECT TO authenticated USING (auth.uid() = user_id);
DROP POLICY IF EXISTS "insert_own_reads" ON order_comment_reads;
CREATE POLICY "insert_own_reads" ON order_comment_reads FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
DROP POLICY IF EXISTS "update_own_reads" ON order_comment_reads;
CREATE POLICY "update_own_reads" ON order_comment_reads FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
DROP POLICY IF EXISTS "delete_own_reads" ON order_comment_reads;
CREATE POLICY "delete_own_reads" ON order_comment_reads FOR DELETE TO authenticated USING (auth.uid() = user_id);

-- Comment notification trigger
CREATE OR REPLACE FUNCTION fn_notify_new_comment() RETURNS TRIGGER LANGUAGE plpgsql SECURITY DEFINER AS $$
DECLARE order_row orders%ROWTYPE; author_name text; notify_user uuid;
BEGIN
  SELECT * INTO order_row FROM orders WHERE id = NEW.order_id;
  IF NOT FOUND THEN RETURN NEW; END IF;
  SELECT name INTO author_name FROM profiles WHERE id = NEW.author_id;
  IF NEW.author_id = order_row.from_id THEN notify_user := order_row.lab_id;
  ELSE notify_user := order_row.from_id; END IF;
  INSERT INTO notifications (user_id, type, title, body, related_id)
  VALUES (notify_user, 'new_comment', 'New Message – ' || order_row.order_number, LEFT(NEW.body, 120), NEW.order_id);
  RETURN NEW;
END; $$;
DROP TRIGGER IF EXISTS trg_notify_new_comment ON order_comments;
CREATE TRIGGER trg_notify_new_comment AFTER INSERT ON order_comments FOR EACH ROW EXECUTE FUNCTION fn_notify_new_comment();

-- Doctor assignment
ALTER TABLE orders ADD COLUMN IF NOT EXISTS doctor_id uuid REFERENCES profiles(id) ON DELETE SET NULL;

-- Doctor order notification
CREATE OR REPLACE FUNCTION fn_notify_doctor_order() RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER AS $$
DECLARE v_center_name text;
BEGIN
  IF NEW.doctor_id IS NULL THEN RETURN NEW; END IF;
  SELECT name INTO v_center_name FROM profiles WHERE id = NEW.from_id;
  INSERT INTO notifications (user_id, type, title, body, related_id)
  VALUES (NEW.doctor_id, 'order_assigned', 'New Order from ' || COALESCE(v_center_name, 'your center'),
    'Order ' || NEW.order_number || ' for patient ' || NEW.patient_name || ' has been placed on your behalf.', NEW.id);
  RETURN NEW;
END; $$;
DROP TRIGGER IF EXISTS trg_notify_doctor_order ON orders;
CREATE TRIGGER trg_notify_doctor_order AFTER INSERT ON orders FOR EACH ROW EXECUTE FUNCTION fn_notify_doctor_order();

-- Redo status + parent_order_id
ALTER TABLE orders DROP CONSTRAINT IF EXISTS orders_status_check;
ALTER TABLE orders ADD CONSTRAINT orders_status_check CHECK (status IN ('pending','accepted','in_progress','completed','rejected','cancelled','redo'));
ALTER TABLE orders ADD COLUMN IF NOT EXISTS parent_order_id uuid REFERENCES orders(id) ON DELETE SET NULL;
CREATE INDEX IF NOT EXISTS idx_orders_parent_order_id ON orders(parent_order_id);

-- Bill to
ALTER TABLE orders ADD COLUMN IF NOT EXISTS bill_to text NOT NULL DEFAULT 'doctor';
ALTER TABLE orders DROP CONSTRAINT IF EXISTS orders_bill_to_check;
ALTER TABLE orders ADD CONSTRAINT orders_bill_to_check CHECK (bill_to IN ('doctor', 'center'));

-- Center team order visibility (scoped)
DROP POLICY IF EXISTS "orders_select" ON orders;
CREATE POLICY "orders_select" ON orders FOR SELECT TO authenticated
  USING (auth.uid() = from_id OR auth.uid() = lab_id OR auth.uid() = doctor_id
    OR EXISTS (SELECT 1 FROM center_members WHERE center_members.center_id = auth.uid() AND center_members.doctor_id = orders.from_id));

DROP POLICY IF EXISTS "order_attachments_select" ON order_attachments;
CREATE POLICY "order_attachments_select" ON order_attachments FOR SELECT TO authenticated
  USING (EXISTS (SELECT 1 FROM orders WHERE orders.id = order_attachments.order_id
    AND (orders.from_id = auth.uid() OR orders.lab_id = auth.uid() OR orders.doctor_id = auth.uid()
      OR EXISTS (SELECT 1 FROM center_members WHERE center_members.center_id = auth.uid() AND center_members.doctor_id = orders.from_id))));

-- Driver subaccounts
CREATE TABLE IF NOT EXISTS lab_drivers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  lab_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  driver_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  created_at timestamptz DEFAULT now(),
  UNIQUE(lab_id, driver_id)
);
ALTER TABLE lab_drivers ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "ld_select" ON lab_drivers;
CREATE POLICY "ld_select" ON lab_drivers FOR SELECT TO authenticated USING (auth.uid() = lab_id OR auth.uid() = driver_id);
DROP POLICY IF EXISTS "ld_insert" ON lab_drivers;
CREATE POLICY "ld_insert" ON lab_drivers FOR INSERT TO authenticated WITH CHECK (auth.uid() = lab_id);
DROP POLICY IF EXISTS "ld_delete" ON lab_drivers;
CREATE POLICY "ld_delete" ON lab_drivers FOR DELETE TO authenticated USING (auth.uid() = lab_id);
CREATE INDEX IF NOT EXISTS idx_lab_drivers_lab ON lab_drivers(lab_id);
CREATE INDEX IF NOT EXISTS idx_lab_drivers_driver ON lab_drivers(driver_id);

-- Extend orders SELECT for drivers
DROP POLICY IF EXISTS "orders_select" ON orders;
CREATE POLICY "orders_select" ON orders FOR SELECT TO authenticated
  USING (auth.uid() = from_id OR auth.uid() = lab_id OR auth.uid() = doctor_id
    OR EXISTS (SELECT 1 FROM center_members WHERE center_members.center_id = auth.uid() AND center_members.doctor_id = orders.from_id)
    OR EXISTS (SELECT 1 FROM lab_drivers WHERE lab_drivers.driver_id = auth.uid() AND lab_drivers.lab_id = orders.lab_id));

-- Delivering/delivered statuses
ALTER TABLE orders DROP CONSTRAINT IF EXISTS orders_status_check;
ALTER TABLE orders ADD CONSTRAINT orders_status_check CHECK (status IN ('pending','accepted','in_progress','completed','rejected','cancelled','redo','delivering','delivered'));
