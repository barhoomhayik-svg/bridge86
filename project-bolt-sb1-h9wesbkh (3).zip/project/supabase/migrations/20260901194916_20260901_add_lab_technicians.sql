/*
# Add lab technicians feature

## Overview
Labs can now employ technicians who are assigned to specific orders.
Each technician gets their own login (auth account with role='technician')
linked to a lab via the `lab_technicians` table. Technicians see only the
orders explicitly assigned to them and can update status and conversation.

## Changes

### 1. Profiles role constraint extended
- Now accepts 'technician' in addition to center/doctor/lab/driver.

### 2. New table: lab_technicians
- id (uuid, primary key)
- lab_id (uuid FK -> profiles, the lab that employs the technician)
- technician_id (uuid FK -> profiles, the technician's profile)
- created_at (timestamptz)
- UNIQUE(lab_id, technician_id)

### 3. New column on orders: assigned_technician_id
- uuid, nullable, FK -> profiles
- Stores which technician is responsible for this order

### 4. RLS on lab_technicians
- Lab owner can SELECT, INSERT, DELETE their own technician links.
- Technician can SELECT their own link.

### 5. Updated orders SELECT policy
- Technician can see orders where assigned_technician_id = auth.uid().

### 6. Updated orders UPDATE policy
- Technician can update orders assigned to them (guard trigger limits columns).

### 7. Updated order_comments policies
- Technician can read/write comments on their assigned orders.

### 8. Updated order_attachments SELECT policy
- Technician can view attachments on assigned orders.

### 9. Updated storage access helper
- Technician can access storage objects for their assigned orders.

### 10. Updated profile visibility
- Technician can see profiles related to their assigned orders.
- Lab can see its technicians' profiles.

### 11. Updated order update guard trigger
- Technician can update status and assigned_technician_id-related fields
  but not clinical/scheduling/ownership fields (same restriction pattern as driver).

### 12. Realtime publication
- lab_technicians added to realtime publication.
*/

-- 1. Extend profiles role constraint to include 'technician'
ALTER TABLE profiles DROP CONSTRAINT IF EXISTS profiles_role_check;
ALTER TABLE profiles ADD CONSTRAINT profiles_role_check
  CHECK (role IN ('center', 'doctor', 'lab', 'driver', 'technician'));

-- 2. lab_technicians table
CREATE TABLE IF NOT EXISTS lab_technicians (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  lab_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  technician_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  created_at timestamptz DEFAULT now(),
  UNIQUE(lab_id, technician_id)
);
ALTER TABLE lab_technicians ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "lab_technicians_select" ON lab_technicians;
CREATE POLICY "lab_technicians_select" ON lab_technicians FOR SELECT TO authenticated
  USING (auth.uid() = lab_id OR auth.uid() = technician_id);

DROP POLICY IF EXISTS "lab_technicians_insert" ON lab_technicians;
CREATE POLICY "lab_technicians_insert" ON lab_technicians FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = lab_id);

DROP POLICY IF EXISTS "lab_technicians_delete" ON lab_technicians;
CREATE POLICY "lab_technicians_delete" ON lab_technicians FOR DELETE TO authenticated
  USING (auth.uid() = lab_id);

CREATE INDEX IF NOT EXISTS idx_lab_technicians_lab ON lab_technicians(lab_id);
CREATE INDEX IF NOT EXISTS idx_lab_technicians_technician ON lab_technicians(technician_id);

-- 3. Add assigned_technician_id to orders
DO $$ BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema = 'public' AND table_name = 'orders' AND column_name = 'assigned_technician_id'
  ) THEN
    ALTER TABLE orders ADD COLUMN assigned_technician_id uuid REFERENCES profiles(id) ON DELETE SET NULL;
  END IF;
END $$;

CREATE INDEX IF NOT EXISTS idx_orders_assigned_technician ON orders(assigned_technician_id);

-- 4. Update orders SELECT policy to include technicians (assigned orders only)
DROP POLICY IF EXISTS "orders_select" ON orders;
CREATE POLICY "orders_select" ON orders FOR SELECT TO authenticated
  USING (
    auth.uid() = from_id
    OR auth.uid() = lab_id
    OR auth.uid() = doctor_id
    OR auth.uid() = assigned_technician_id
    OR EXISTS (
      SELECT 1 FROM lab_drivers
      WHERE lab_drivers.driver_id = auth.uid()
        AND lab_drivers.lab_id = orders.lab_id
    )
    OR EXISTS (
      SELECT 1 FROM center_members
      WHERE center_members.center_id = orders.from_id
        AND center_members.doctor_id = auth.uid()
    )
  );

-- 5. Update orders UPDATE policy to include technicians
DROP POLICY IF EXISTS "orders_update" ON orders;
CREATE POLICY "orders_update" ON orders FOR UPDATE TO authenticated
  USING (
    auth.uid() = from_id
    OR auth.uid() = lab_id
    OR auth.uid() = doctor_id
    OR auth.uid() = assigned_technician_id
    OR EXISTS (
      SELECT 1 FROM lab_drivers
      WHERE lab_drivers.driver_id = auth.uid()
        AND lab_drivers.lab_id = orders.lab_id
    )
  )
  WITH CHECK (
    auth.uid() = from_id
    OR auth.uid() = lab_id
    OR auth.uid() = doctor_id
    OR auth.uid() = assigned_technician_id
    OR EXISTS (
      SELECT 1 FROM lab_drivers
      WHERE lab_drivers.driver_id = auth.uid()
        AND lab_drivers.lab_id = orders.lab_id
    )
  );

-- 6. Update order_comments policies to include technicians
DROP POLICY IF EXISTS "order_comments_insert" ON order_comments;
CREATE POLICY "order_comments_insert" ON order_comments FOR INSERT
TO authenticated
WITH CHECK (
  auth.uid() = author_id
  AND EXISTS (
    SELECT 1 FROM orders o
    WHERE o.id = order_comments.order_id
    AND (
      o.from_id = auth.uid()
      OR o.lab_id = auth.uid()
      OR o.doctor_id = auth.uid()
      OR o.assigned_technician_id = auth.uid()
      OR EXISTS (SELECT 1 FROM center_members cm WHERE cm.center_id = o.from_id AND cm.doctor_id = auth.uid())
      OR EXISTS (SELECT 1 FROM lab_drivers ld WHERE ld.lab_id = o.lab_id AND ld.driver_id = auth.uid())
    )
  )
);

DROP POLICY IF EXISTS "order_comments_select" ON order_comments;
CREATE POLICY "order_comments_select" ON order_comments FOR SELECT
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM orders o
    WHERE o.id = order_comments.order_id
    AND (
      o.from_id = auth.uid()
      OR o.lab_id = auth.uid()
      OR o.doctor_id = auth.uid()
      OR o.assigned_technician_id = auth.uid()
      OR EXISTS (SELECT 1 FROM center_members cm WHERE cm.center_id = o.from_id AND cm.doctor_id = auth.uid())
      OR EXISTS (SELECT 1 FROM lab_drivers ld WHERE ld.lab_id = o.lab_id AND ld.driver_id = auth.uid())
    )
  )
);

-- 7. Update order_attachments SELECT policy
DROP POLICY IF EXISTS "order_attachments_select" ON order_attachments;
CREATE POLICY "order_attachments_select" ON order_attachments FOR SELECT TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM orders
      WHERE orders.id = order_id
        AND (
          orders.from_id = auth.uid()
          OR orders.lab_id = auth.uid()
          OR orders.doctor_id = auth.uid()
          OR orders.assigned_technician_id = auth.uid()
          OR EXISTS (
            SELECT 1 FROM lab_drivers
            WHERE lab_drivers.driver_id = auth.uid()
              AND lab_drivers.lab_id = orders.lab_id
          )
          OR EXISTS (
            SELECT 1 FROM center_members
            WHERE center_members.center_id = orders.from_id
              AND center_members.doctor_id = auth.uid()
          )
        )
    )
  );

-- 8. Update storage access helper to include technicians
CREATE OR REPLACE FUNCTION public.can_access_order_object(object_name text, uid uuid)
RETURNS boolean
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = public, storage, pg_temp
AS $$
DECLARE
  seg text;
  ord_id uuid;
BEGIN
  IF uid IS NULL OR object_name IS NULL THEN
    RETURN false;
  END IF;

  FOREACH seg IN ARRAY storage.foldername(object_name)
  LOOP
    BEGIN
      ord_id := seg::uuid;
    EXCEPTION WHEN others THEN
      CONTINUE;
    END;

    IF EXISTS (
      SELECT 1 FROM public.orders o
      WHERE o.id = ord_id
        AND (
          o.from_id = uid
          OR o.lab_id = uid
          OR o.doctor_id = uid
          OR o.assigned_technician_id = uid
          OR EXISTS (
            SELECT 1 FROM public.lab_drivers d
            WHERE d.driver_id = uid AND d.lab_id = o.lab_id
          )
          OR EXISTS (
            SELECT 1 FROM public.center_members cm
            WHERE cm.center_id = o.from_id AND cm.doctor_id = uid
          )
        )
    ) THEN
      RETURN true;
    END IF;
  END LOOP;

  RETURN false;
END;
$$;

REVOKE ALL ON FUNCTION public.can_access_order_object(text, uuid) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.can_access_order_object(text, uuid) TO authenticated;

-- 9. Update profile visibility to include technicians
CREATE OR REPLACE FUNCTION public.can_view_profile(target uuid)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
  SELECT
    auth.uid() IS NOT NULL
    AND (
      target = auth.uid()
      OR EXISTS (SELECT 1 FROM public.profiles p WHERE p.id = target AND p.role = 'lab')
      OR EXISTS (
        SELECT 1 FROM public.orders o
        WHERE (o.from_id = target OR o.lab_id = target OR o.doctor_id = target OR o.assigned_technician_id = target)
          AND (
            o.from_id = auth.uid() OR o.lab_id = auth.uid() OR o.doctor_id = auth.uid()
            OR o.assigned_technician_id = auth.uid()
            OR EXISTS (SELECT 1 FROM public.lab_drivers d WHERE d.driver_id = auth.uid() AND d.lab_id = o.lab_id)
            OR EXISTS (SELECT 1 FROM public.center_members cm WHERE cm.center_id = o.from_id AND cm.doctor_id = auth.uid())
          )
      )
      OR EXISTS (
        SELECT 1 FROM public.center_members cm
        WHERE (cm.center_id = auth.uid() AND cm.doctor_id = target)
           OR (cm.doctor_id = auth.uid() AND cm.center_id = target)
      )
      OR EXISTS (
        SELECT 1 FROM public.lab_drivers d
        WHERE (d.lab_id = auth.uid() AND d.driver_id = target)
           OR (d.driver_id = auth.uid() AND d.lab_id = target)
      )
      OR EXISTS (
        SELECT 1 FROM public.lab_technicians t
        WHERE (t.lab_id = auth.uid() AND t.technician_id = target)
           OR (t.technician_id = auth.uid() AND t.lab_id = target)
      )
    );
$$;

REVOKE ALL ON FUNCTION public.can_view_profile(uuid) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.can_view_profile(uuid) TO authenticated;

-- 10. Update order update guard trigger to handle technicians
CREATE OR REPLACE FUNCTION public.enforce_order_update_guards()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public', 'pg_temp'
AS $function$
DECLARE
  uid uuid := auth.uid();
  is_lab_side boolean;
  is_driver_only boolean;
  is_technician_only boolean;
BEGIN
  -- Redo window
  IF NEW.status = 'redo'
    AND OLD.status = 'delivered'
    AND OLD.delivered_at IS NOT NULL
    AND (now() - OLD.delivered_at) > INTERVAL '30 days' THEN
    RAISE EXCEPTION 'Redo not allowed: the 30-day window since delivery has passed'
      USING ERRCODE = 'check_violation';
  END IF;

  IF uid IS NULL THEN
    RETURN NEW;
  END IF;

  -- A caller who is only a driver may confirm deliveries and nothing else.
  is_driver_only := uid IS DISTINCT FROM OLD.lab_id
    AND uid IS DISTINCT FROM OLD.from_id
    AND (OLD.doctor_id IS NULL OR uid IS DISTINCT FROM OLD.doctor_id)
    AND (OLD.assigned_technician_id IS NULL OR uid IS DISTINCT FROM OLD.assigned_technician_id)
    AND NOT EXISTS (
      SELECT 1 FROM public.center_members cm
      WHERE cm.center_id = OLD.from_id AND cm.doctor_id = uid
    )
    AND EXISTS (
      SELECT 1 FROM public.lab_drivers d
      WHERE d.driver_id = uid AND d.lab_id = OLD.lab_id
    );

  IF is_driver_only THEN
    IF NEW.id IS DISTINCT FROM OLD.id
      OR NEW.order_number IS DISTINCT FROM OLD.order_number
      OR NEW.from_id IS DISTINCT FROM OLD.from_id
      OR NEW.lab_id IS DISTINCT FROM OLD.lab_id
      OR NEW.doctor_id IS DISTINCT FROM OLD.doctor_id
      OR NEW.file_number IS DISTINCT FROM OLD.file_number
      OR NEW.patient_name IS DISTINCT FROM OLD.patient_name
      OR NEW.dr_name IS DISTINCT FROM OLD.dr_name
      OR NEW.shade IS DISTINCT FROM OLD.shade
      OR NEW.teeth_numbers IS DISTINCT FROM OLD.teeth_numbers
      OR NEW.service_id IS DISTINCT FROM OLD.service_id
      OR NEW.notes IS DISTINCT FROM OLD.notes
      OR NEW.due_date IS DISTINCT FROM OLD.due_date
      OR NEW.created_at IS DISTINCT FROM OLD.created_at
      OR NEW.parent_order_id IS DISTINCT FROM OLD.parent_order_id
      OR NEW.bill_to IS DISTINCT FROM OLD.bill_to
      OR NEW.try_in IS DISTINCT FROM OLD.try_in
      OR NEW.is_final IS DISTINCT FROM OLD.is_final
      OR NEW.assigned_technician_id IS DISTINCT FROM OLD.assigned_technician_id THEN
      RAISE EXCEPTION 'A driver can only confirm delivery on an order'
        USING ERRCODE = 'check_violation';
    END IF;
  END IF;

  -- A caller who is only the assigned technician may update status and updated_at only.
  is_technician_only := uid IS DISTINCT FROM OLD.lab_id
    AND uid IS DISTINCT FROM OLD.from_id
    AND (OLD.doctor_id IS NULL OR uid IS DISTINCT FROM OLD.doctor_id)
    AND OLD.assigned_technician_id IS NOT NULL
    AND uid = OLD.assigned_technician_id
    AND NOT EXISTS (
      SELECT 1 FROM public.center_members cm
      WHERE cm.center_id = OLD.from_id AND cm.doctor_id = uid
    )
    AND NOT EXISTS (
      SELECT 1 FROM public.lab_drivers d
      WHERE d.driver_id = uid AND d.lab_id = OLD.lab_id
    );

  IF is_technician_only THEN
    IF NEW.id IS DISTINCT FROM OLD.id
      OR NEW.order_number IS DISTINCT FROM OLD.order_number
      OR NEW.from_id IS DISTINCT FROM OLD.from_id
      OR NEW.lab_id IS DISTINCT FROM OLD.lab_id
      OR NEW.doctor_id IS DISTINCT FROM OLD.doctor_id
      OR NEW.file_number IS DISTINCT FROM OLD.file_number
      OR NEW.patient_name IS DISTINCT FROM OLD.patient_name
      OR NEW.dr_name IS DISTINCT FROM OLD.dr_name
      OR NEW.shade IS DISTINCT FROM OLD.shade
      OR NEW.teeth_numbers IS DISTINCT FROM OLD.teeth_numbers
      OR NEW.service_id IS DISTINCT FROM OLD.service_id
      OR NEW.notes IS DISTINCT FROM OLD.notes
      OR NEW.due_date IS DISTINCT FROM OLD.due_date
      OR NEW.created_at IS DISTINCT FROM OLD.created_at
      OR NEW.parent_order_id IS DISTINCT FROM OLD.parent_order_id
      OR NEW.bill_to IS DISTINCT FROM OLD.bill_to
      OR NEW.try_in IS DISTINCT FROM OLD.try_in
      OR NEW.is_final IS DISTINCT FROM OLD.is_final
      OR NEW.delivered_at IS DISTINCT FROM OLD.delivered_at
      OR NEW.delivered_by IS DISTINCT FROM OLD.delivered_by
      OR NEW.assigned_technician_id IS DISTINCT FROM OLD.assigned_technician_id THEN
      RAISE EXCEPTION 'A technician can only update the status of an assigned order'
        USING ERRCODE = 'check_violation';
    END IF;
  END IF;

  -- The lab that owns the case can never be reassigned by a client.
  IF NEW.lab_id IS DISTINCT FROM OLD.lab_id THEN
    RAISE EXCEPTION 'The laboratory on an order cannot be changed'
      USING ERRCODE = 'check_violation';
  END IF;

  -- The ordering account may only change in the try-in hand-over.
  IF NEW.from_id IS DISTINCT FROM OLD.from_id THEN
    IF NOT (OLD.status = 'try_in' AND OLD.doctor_id = uid AND NEW.from_id = uid) THEN
      RAISE EXCEPTION 'The ordering account on an order cannot be changed'
        USING ERRCODE = 'check_violation';
    END IF;
  END IF;

  IF NEW.doctor_id IS DISTINCT FROM OLD.doctor_id THEN
    IF NOT (
      (OLD.doctor_id = uid AND NEW.doctor_id IS NULL)
      OR OLD.from_id = uid
    ) THEN
      RAISE EXCEPTION 'The assigned doctor on an order cannot be changed'
        USING ERRCODE = 'check_violation';
    END IF;
  END IF;

  -- Delivery stamps: write-once, set by the lab or one of its drivers, and
  -- always timed by the server.
  IF NEW.delivered_at IS DISTINCT FROM OLD.delivered_at
    OR NEW.delivered_by IS DISTINCT FROM OLD.delivered_by THEN

    IF OLD.delivered_at IS NOT NULL THEN
      NEW.delivered_at := OLD.delivered_at;
      NEW.delivered_by := OLD.delivered_by;
    ELSE
      is_lab_side := (OLD.lab_id = uid)
        OR EXISTS (SELECT 1 FROM public.lab_drivers d WHERE d.driver_id = uid AND d.lab_id = OLD.lab_id);

      IF NOT is_lab_side THEN
        RAISE EXCEPTION 'Only the laboratory or its driver can mark an order delivered'
          USING ERRCODE = 'check_violation';
      END IF;

      IF NEW.delivered_at IS NOT NULL THEN
        NEW.delivered_at := now();
        NEW.delivered_by := uid;
      END IF;
    END IF;
  END IF;

  RETURN NEW;
END;
$function$;

REVOKE ALL ON FUNCTION public.enforce_order_update_guards() FROM PUBLIC;

-- 11. Add lab_technicians to realtime publication
DO $$ BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_publication_tables
    WHERE pubname = 'supabase_realtime' AND tablename = 'lab_technicians'
  ) THEN
    ALTER PUBLICATION supabase_realtime ADD TABLE lab_technicians;
  END IF;
END $$;

-- Revoke anon privileges on new table (consistent with security hardening)
REVOKE ALL ON lab_technicians FROM anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON lab_technicians TO authenticated;
