/*
  # Stop anyone from bulk-closing delivered orders

  close_stale_orders() is SECURITY DEFINER and was executable by anon and
  authenticated, so any caller holding the public anon key could flip every
  delivered order older than 30 days to 'closed' across every laboratory.
  It is a maintenance routine and belongs to the service role / scheduler only.
*/

REVOKE ALL ON FUNCTION public.close_stale_orders() FROM PUBLIC;
REVOKE ALL ON FUNCTION public.close_stale_orders() FROM anon;
REVOKE ALL ON FUNCTION public.close_stale_orders() FROM authenticated;
