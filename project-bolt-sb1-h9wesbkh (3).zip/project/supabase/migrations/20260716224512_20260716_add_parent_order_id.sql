-- Add parent_order_id to link a redo order back to its original
ALTER TABLE orders ADD COLUMN IF NOT EXISTS parent_order_id uuid REFERENCES orders(id) ON DELETE SET NULL;
CREATE INDEX IF NOT EXISTS idx_orders_parent_order_id ON orders(parent_order_id);
