/*
# Add driver sub-accounts for labs

## Overview
Labs can employ drivers to deliver completed cases to the doctor/center.
Each driver gets their own login (auth account with role='driver') linked
to a lab via the `lab_drivers` table. Drivers see only their lab's orders,
can mark an order as "delivered" (sets delivered_at + delivered_by), and
the ordering doctor/center receives a notification that the case arrived.

## 1. New role
- `profiles.role` now accepts 'driver' in addition to center/doctor/lab.
  Drivers are created by the lab via an edge function (which uses the
  service-role key to create the auth account + profile row).

## 2. New table: lab_drivers
- id (uuid PK)
- lab_id (uuid FK -> profiles, the lab that employs the driver)
- driver_id (uuid FK -> profiles, the driver's profile)
- created_at (timestamptz)
- UNIQUE(lab_id, driver_id)

## 3. Orders changes
- delivered_at (timestamptz, nullable) — when the driver confirmed delivery
- delivered_by (uuid FK -> profiles, nullable) — which driver delivered

## 4. Security
- RLS on lab_drivers: lab owner can CRUD their driver links; drivers can
  read their own link row.
- Orders SELECT policy updated so a driver can see orders belonging to
  their lab (via EXISTS check on lab_drivers).
- Orders UPDATE policy updated so a driver can update delivered_at /
  delivered_by on their lab's orders.
- New notification type 'order_delivered' inserted via trigger when
  delivered_at transitions from NULL to a value.

## 5. Trigger: notify on delivery
- fn_notify_delivery — AFTER UPDATE on orders, when delivered_at goes
  from NULL to NOT NULL, insert a notification for the order sender
  (from_id) with type 'order_delivered', title "Case Delivered – #XXXX".
*/

-- 1. Extend profiles role constraint to include 'driver'
ALTER TABLE profiles DROP CONSTRAINT IF EXISTS profiles_role_check;
DO $$ BEGIN
  SELECT pg_get_constraintdef(oid) FROM pg_constraint WHERE conrelid = 'profiles'::regclass AND conname = 'profiles_role_check';
EXCEPTION WHEN OTHERS THEN NULL; END $$;
ALTER TABLE profiles ADD CONSTRAINT profiles_role_check
  CHECK (role IN ('center', 'doctor', 'lab', 'driver'));

-- 2. lab_drivers table
CREATE TABLE IF NOT EXISTS lab_drivers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  lab_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  driver_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  created_at timestamptz DEFAULT now(),
  UNIQUE(lab_id, driver_id)
);
ALTER TABLE lab_drivers ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "lab_drivers_select" ON lab_drivers;
CREATE POLICY "lab_drivers_select" ON lab_drivers FOR SELECT TO authenticated
  USING (auth.uid() = lab_id OR auth.uid() = driver_id);

DROP POLICY IF EXISTS "lab_drivers_insert" ON lab_drivers;
CREATE POLICY "lab_drivers_insert" ON lab_drivers FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = lab_id AND EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'lab'));

DROP POLICY IF EXISTS "lab_drivers_delete" ON lab_drivers;
CREATE POLICY "lab_drivers_delete" ON lab_drivers FOR DELETE TO authenticated
  USING (auth.uid() = lab_id);

CREATE INDEX IF NOT EXISTS idx_lab_drivers_lab ON lab_drivers(lab_id);
CREATE INDEX IF NOT EXISTS idx_lab_drivers_driver ON lab_drivers(driver_id);

-- 3. Orders: delivery columns
ALTER TABLE orders ADD COLUMN IF NOT EXISTS delivered_at timestamptz;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS delivered_by uuid REFERENCES profiles(id) ON DELETE SET NULL;

-- 4. Orders RLS: allow drivers to see + update delivery on their lab's orders
-- Replace existing SELECT policy to include drivers via lab_drivers
DROP POLICY IF EXISTS "orders_select" ON orders;
CREATE POLICY "orders_select" ON orders FOR SELECT TO authenticated
  USING (
    auth.uid() = from_id
    OR auth.uid() = lab_id
    OR EXISTS (SELECT 1 FROM lab_drivers WHERE lab_drivers.driver_id = auth.uid() AND lab_drivers.lab_id = orders.lab_id)
  );

-- Replace existing UPDATE policy to include drivers (they can only set delivery fields)
DROP POLICY IF EXISTS "orders_update" ON orders;
CREATE POLICY "orders_update" ON orders FOR UPDATE TO authenticated
  USING (
    auth.uid() = from_id
    OR auth.uid() = lab_id
    OR EXISTS (SELECT 1 FROM lab_drivers WHERE lab_drivers.driver_id = auth.uid() AND lab_drivers.lab_id = orders.lab_id)
  )
  WITH CHECK (
    auth.uid() = from_id
    OR auth.uid() = lab_id
    OR EXISTS (SELECT 1 FROM lab_drivers WHERE lab_drivers.driver_id = auth.uid() AND lab_drivers.lab_id = orders.lab_id)
  );

CREATE INDEX IF NOT EXISTS idx_orders_delivered_by ON orders(delivered_by);

-- 5. Trigger: notify order sender when case is delivered
CREATE OR REPLACE FUNCTION fn_notify_delivery()
RETURNS TRIGGER LANGUAGE plpgsql SECURITY DEFINER AS $$
BEGIN
  IF OLD.delivered_at IS NULL AND NEW.delivered_at IS NOT NULL THEN
    INSERT INTO notifications (user_id, type, title, body, related_id)
    VALUES (
      NEW.from_id,
      'order_delivered',
      'Case Delivered – ' || NEW.order_number,
      'Your case has been delivered to the location.',
      NEW.id
    );
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_notify_delivery ON orders;
CREATE TRIGGER trg_notify_delivery
  AFTER UPDATE ON orders FOR EACH ROW EXECUTE FUNCTION fn_notify_delivery();
