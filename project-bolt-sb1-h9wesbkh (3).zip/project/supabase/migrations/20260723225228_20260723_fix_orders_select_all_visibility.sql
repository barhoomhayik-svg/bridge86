/*
# Fix orders SELECT policy — restore all visibility paths

## Problem
The current `orders_select` policy is missing:
  1. `auth.uid() = doctor_id` — lets an assigned doctor see the order
  2. Center-member visibility — lets a doctor who is a member of a center
     see orders where `from_id` = that center
  3. A doctor who created an order on behalf of a center has `from_id` =
     center, so they cannot read back the order they just inserted,
     causing the `.select().single()` after insert to fail silently.

## Fix
Rebuild `orders_select` with all four visibility paths:
  1. Sender: `from_id = auth.uid()`
  2. Lab: `lab_id = auth.uid()`
  3. Assigned doctor: `doctor_id = auth.uid()`
  4. Doctor is a member of the center that sent the order:
     `center_members.center_id = from_id AND center_members.doctor_id = auth.uid()`
  5. Lab drivers (preserved from previous migration)

Also rebuild `order_attachments_select` to match.
*/

DROP POLICY IF EXISTS "orders_select" ON orders;
CREATE POLICY "orders_select" ON orders FOR SELECT TO authenticated
  USING (
    auth.uid() = from_id
    OR auth.uid() = lab_id
    OR auth.uid() = doctor_id
    OR EXISTS (
      SELECT 1 FROM lab_drivers
      WHERE lab_drivers.driver_id = auth.uid()
        AND lab_drivers.lab_id = orders.lab_id
    )
    OR EXISTS (
      SELECT 1 FROM center_members
      WHERE center_members.center_id = orders.from_id
        AND center_members.doctor_id = auth.uid()
    )
  );

DROP POLICY IF EXISTS "order_attachments_select" ON order_attachments;
CREATE POLICY "order_attachments_select" ON order_attachments FOR SELECT TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM orders
      WHERE orders.id = order_id
        AND (
          orders.from_id = auth.uid()
          OR orders.lab_id = auth.uid()
          OR orders.doctor_id = auth.uid()
          OR EXISTS (
            SELECT 1 FROM lab_drivers
            WHERE lab_drivers.driver_id = auth.uid()
              AND lab_drivers.lab_id = orders.lab_id
          )
          OR EXISTS (
            SELECT 1 FROM center_members
            WHERE center_members.center_id = orders.from_id
              AND center_members.doctor_id = auth.uid()
          )
        )
    )
  );