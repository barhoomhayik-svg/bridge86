-- Drop the old random default
ALTER TABLE orders ALTER COLUMN order_number DROP DEFAULT;

-- Create a trigger function that generates order_number as ORD-<first letter of dr_name><sequential number>
CREATE OR REPLACE FUNCTION generate_order_number()
RETURNS TRIGGER AS $$
DECLARE
  prefix text;
  next_num integer;
BEGIN
  prefix := 'ORD-' || upper(substr(coalesce(NEW.dr_name, 'X'), 1, 1));
  SELECT COALESCE(MAX(num), 0) + 1 INTO next_num
  FROM (
    SELECT CASE
      WHEN order_number ~ '^ORD-[A-Z][0-9]+$'
        THEN regexp_replace(order_number, '^ORD-[A-Z]', '')::integer
      ELSE 0
    END AS num
    FROM orders
    WHERE order_number LIKE prefix || '%'
  ) sub;
  NEW.order_number := prefix || lpad(next_num::text, 3, '0');
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Drop old trigger if exists, then create new one
DROP TRIGGER IF EXISTS set_order_number ON orders;
CREATE TRIGGER set_order_number
  BEFORE INSERT ON orders
  FOR EACH ROW
  EXECUTE FUNCTION generate_order_number();