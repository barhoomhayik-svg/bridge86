/*
  # Only the laboratory side can move a case into delivery

  The orders UPDATE policy lets every party write every column, and the guard
  trigger pinned only delivered_at / delivered_by. The ordering account could
  therefore PATCH status to 'delivering' or 'delivered' itself, faking a
  shipment (and unlocking the review gate). This adds a status check: those two
  statuses may only be set by the laboratory, one of its drivers, or the
  assigned technician. Every other guard in the trigger is preserved verbatim.
*/

CREATE OR REPLACE FUNCTION public.enforce_order_update_guards()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public', 'pg_temp'
AS $function$
DECLARE
uid uuid := auth.uid();
is_lab_side boolean;
is_driver_only boolean;
is_technician_only boolean;
BEGIN
-- Redo window
IF NEW.status = 'redo'
AND OLD.status = 'delivered'
AND OLD.delivered_at IS NOT NULL
AND (now() - OLD.delivered_at) > INTERVAL '30 days' THEN
RAISE EXCEPTION 'Redo not allowed: the 30-day window since delivery has passed'
USING ERRCODE = 'check_violation';
END IF;

IF uid IS NULL THEN
RETURN NEW;
END IF;

-- Moving a case into delivery is a laboratory-side action.
IF NEW.status IS DISTINCT FROM OLD.status
AND NEW.status IN ('delivering', 'delivered') THEN
IF NOT (
OLD.lab_id = uid
OR (OLD.assigned_technician_id IS NOT NULL AND OLD.assigned_technician_id = uid)
OR EXISTS (
SELECT 1 FROM public.lab_drivers d
WHERE d.driver_id = uid AND d.lab_id = OLD.lab_id
)
) THEN
RAISE EXCEPTION 'Only the laboratory or its team can mark an order as out for delivery or delivered'
USING ERRCODE = 'check_violation';
END IF;
END IF;

-- A caller who is only a driver may confirm deliveries and nothing else.
is_driver_only := uid IS DISTINCT FROM OLD.lab_id
AND uid IS DISTINCT FROM OLD.from_id
AND (OLD.doctor_id IS NULL OR uid IS DISTINCT FROM OLD.doctor_id)
AND (OLD.assigned_technician_id IS NULL OR uid IS DISTINCT FROM OLD.assigned_technician_id)
AND NOT EXISTS (
SELECT 1 FROM public.center_members cm
WHERE cm.center_id = OLD.from_id AND cm.doctor_id = uid
)
AND EXISTS (
SELECT 1 FROM public.lab_drivers d
WHERE d.driver_id = uid AND d.lab_id = OLD.lab_id
);

IF is_driver_only THEN
IF NEW.id IS DISTINCT FROM OLD.id
OR NEW.order_number IS DISTINCT FROM OLD.order_number
OR NEW.from_id IS DISTINCT FROM OLD.from_id
OR NEW.lab_id IS DISTINCT FROM OLD.lab_id
OR NEW.doctor_id IS DISTINCT FROM OLD.doctor_id
OR NEW.file_number IS DISTINCT FROM OLD.file_number
OR NEW.patient_name IS DISTINCT FROM OLD.patient_name
OR NEW.dr_name IS DISTINCT FROM OLD.dr_name
OR NEW.shade IS DISTINCT FROM OLD.shade
OR NEW.teeth_numbers IS DISTINCT FROM OLD.teeth_numbers
OR NEW.service_id IS DISTINCT FROM OLD.service_id
OR NEW.notes IS DISTINCT FROM OLD.notes
OR NEW.due_date IS DISTINCT FROM OLD.due_date
OR NEW.created_at IS DISTINCT FROM OLD.created_at
OR NEW.parent_order_id IS DISTINCT FROM OLD.parent_order_id
OR NEW.bill_to IS DISTINCT FROM OLD.bill_to
OR NEW.try_in IS DISTINCT FROM OLD.try_in
OR NEW.is_final IS DISTINCT FROM OLD.is_final
OR NEW.assigned_technician_id IS DISTINCT FROM OLD.assigned_technician_id THEN
RAISE EXCEPTION 'A driver can only confirm delivery on an order'
USING ERRCODE = 'check_violation';
END IF;
END IF;

-- A caller who is only the assigned technician may update status and updated_at only.
is_technician_only := uid IS DISTINCT FROM OLD.lab_id
AND uid IS DISTINCT FROM OLD.from_id
AND (OLD.doctor_id IS NULL OR uid IS DISTINCT FROM OLD.doctor_id)
AND OLD.assigned_technician_id IS NOT NULL
AND uid = OLD.assigned_technician_id
AND NOT EXISTS (
SELECT 1 FROM public.center_members cm
WHERE cm.center_id = OLD.from_id AND cm.doctor_id = uid
)
AND NOT EXISTS (
SELECT 1 FROM public.lab_drivers d
WHERE d.driver_id = uid AND d.lab_id = OLD.lab_id
);

IF is_technician_only THEN
IF NEW.id IS DISTINCT FROM OLD.id
OR NEW.order_number IS DISTINCT FROM OLD.order_number
OR NEW.from_id IS DISTINCT FROM OLD.from_id
OR NEW.lab_id IS DISTINCT FROM OLD.lab_id
OR NEW.doctor_id IS DISTINCT FROM OLD.doctor_id
OR NEW.file_number IS DISTINCT FROM OLD.file_number
OR NEW.patient_name IS DISTINCT FROM OLD.patient_name
OR NEW.dr_name IS DISTINCT FROM OLD.dr_name
OR NEW.shade IS DISTINCT FROM OLD.shade
OR NEW.teeth_numbers IS DISTINCT FROM OLD.teeth_numbers
OR NEW.service_id IS DISTINCT FROM OLD.service_id
OR NEW.notes IS DISTINCT FROM OLD.notes
OR NEW.due_date IS DISTINCT FROM OLD.due_date
OR NEW.created_at IS DISTINCT FROM OLD.created_at
OR NEW.parent_order_id IS DISTINCT FROM OLD.parent_order_id
OR NEW.bill_to IS DISTINCT FROM OLD.bill_to
OR NEW.try_in IS DISTINCT FROM OLD.try_in
OR NEW.is_final IS DISTINCT FROM OLD.is_final
OR NEW.delivered_at IS DISTINCT FROM OLD.delivered_at
OR NEW.delivered_by IS DISTINCT FROM OLD.delivered_by
OR NEW.assigned_technician_id IS DISTINCT FROM OLD.assigned_technician_id THEN
RAISE EXCEPTION 'A technician can only update the status of an assigned order'
USING ERRCODE = 'check_violation';
END IF;
END IF;

-- The lab that owns the case can never be reassigned by a client.
IF NEW.lab_id IS DISTINCT FROM OLD.lab_id THEN
RAISE EXCEPTION 'The laboratory on an order cannot be changed'
USING ERRCODE = 'check_violation';
END IF;

-- The ordering account may only change in the try-in hand-over.
IF NEW.from_id IS DISTINCT FROM OLD.from_id THEN
IF NOT (OLD.status = 'try_in' AND OLD.doctor_id = uid AND NEW.from_id = uid) THEN
RAISE EXCEPTION 'The ordering account on an order cannot be changed'
USING ERRCODE = 'check_violation';
END IF;
END IF;

IF NEW.doctor_id IS DISTINCT FROM OLD.doctor_id THEN
IF NOT (
(OLD.doctor_id = uid AND NEW.doctor_id IS NULL)
OR OLD.from_id = uid
) THEN
RAISE EXCEPTION 'The assigned doctor on an order cannot be changed'
USING ERRCODE = 'check_violation';
END IF;
END IF;

-- Delivery stamps: write-once, set by the lab or one of its drivers, and
-- always timed by the server.
IF NEW.delivered_at IS DISTINCT FROM OLD.delivered_at
OR NEW.delivered_by IS DISTINCT FROM OLD.delivered_by THEN

IF OLD.delivered_at IS NOT NULL THEN
NEW.delivered_at := OLD.delivered_at;
NEW.delivered_by := OLD.delivered_by;
ELSE
is_lab_side := (OLD.lab_id = uid)
OR EXISTS (SELECT 1 FROM public.lab_drivers d WHERE d.driver_id = uid AND d.lab_id = OLD.lab_id);

IF NOT is_lab_side THEN
RAISE EXCEPTION 'Only the laboratory or its driver can mark an order delivered'
USING ERRCODE = 'check_violation';
END IF;

IF NEW.delivered_at IS NOT NULL THEN
NEW.delivered_at := now();
NEW.delivered_by := uid;
END IF;
END IF;
END IF;

RETURN NEW;
END;
$function$;
