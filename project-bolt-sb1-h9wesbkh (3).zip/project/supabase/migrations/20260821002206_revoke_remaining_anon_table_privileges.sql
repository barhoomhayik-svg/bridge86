/*
  # Remove the remaining non-read privileges from the unauthenticated role

  1. Why
     - After revoking writes, `anon` still held TRUNCATE, TRIGGER and REFERENCES on
       every application table, inherited from the default grant. TRUNCATE is not
       filtered by row level security, so it should not sit with the
       unauthenticated role even though the REST API does not expose it.

  2. Change
     - Revoke TRUNCATE, TRIGGER and REFERENCES from `anon` on the application
       tables, leaving SELECT untouched.

  3. Security
     - No read path changes, and nothing in the app uses these privileges.
*/

DO $$
DECLARE
  t text;
BEGIN
  FOREACH t IN ARRAY ARRAY[
    'profiles','orders','order_services','order_attachments','order_comments',
    'order_comment_reads','quotations','quotation_services','services',
    'case_photos','center_members','center_labs','lab_drivers','lab_reviews',
    'favourite_labs','notifications'
  ]
  LOOP
    EXECUTE format('REVOKE TRUNCATE, TRIGGER, REFERENCES ON public.%I FROM anon', t);
  END LOOP;
END $$;
