/*
  # Restrict attachment uploads to the people involved in the case

  1. Security
    - `order_attachments_insert` checked only `bucket_id`, so any signed-in user
      could write a file into any other case's attachment folder. It now requires
      the caller to be a party to the order named in the object path, matching the
      rule already enforced on the `order_attachments` table.
*/

DROP POLICY IF EXISTS order_attachments_insert ON storage.objects;

CREATE POLICY order_attachments_insert ON storage.objects
  FOR INSERT TO authenticated
  WITH CHECK (
    bucket_id = 'order-attachments'
    AND public.can_access_order_object(name, auth.uid())
  );
