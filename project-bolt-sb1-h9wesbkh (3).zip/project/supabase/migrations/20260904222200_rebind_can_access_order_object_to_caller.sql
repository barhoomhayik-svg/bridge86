/*
  # The case-file access helper is bound to the caller again

  A later migration recreated this function and dropped the check that the uid
  argument matches the session, so any signed-in user could pass someone else's
  id and learn whether that person is attached to a given case. The binding is
  restored; storage policies pass auth.uid() and are unaffected.
*/

CREATE OR REPLACE FUNCTION public.can_access_order_object(object_name text, uid uuid)
RETURNS boolean
LANGUAGE plpgsql
STABLE SECURITY DEFINER
SET search_path TO 'public', 'storage', 'pg_temp'
AS $function$
DECLARE
seg text;
ord_id uuid;
BEGIN
IF uid IS NULL OR object_name IS NULL THEN
RETURN false;
END IF;

-- A signed-in caller may only ask about themselves.
IF auth.uid() IS NOT NULL AND uid IS DISTINCT FROM auth.uid() THEN
RETURN false;
END IF;

FOREACH seg IN ARRAY storage.foldername(object_name)
LOOP
BEGIN
ord_id := seg::uuid;
EXCEPTION WHEN others THEN
CONTINUE;
END;

IF EXISTS (
SELECT 1 FROM public.orders o
WHERE o.id = ord_id
AND (
o.from_id = uid
OR o.lab_id = uid
OR o.doctor_id = uid
OR o.assigned_technician_id = uid
OR EXISTS (
SELECT 1 FROM public.lab_drivers d
WHERE d.driver_id = uid AND d.lab_id = o.lab_id
)
OR EXISTS (
SELECT 1 FROM public.center_members cm
WHERE cm.center_id = o.from_id AND cm.doctor_id = uid
)
)
) THEN
RETURN true;
END IF;
END LOOP;

RETURN false;
END;
$function$;

REVOKE ALL ON FUNCTION public.can_access_order_object(text, uuid) FROM PUBLIC;
REVOKE ALL ON FUNCTION public.can_access_order_object(text, uuid) FROM anon;
GRANT EXECUTE ON FUNCTION public.can_access_order_object(text, uuid) TO authenticated;
