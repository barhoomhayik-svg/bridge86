/*
# Scope center team-order visibility to membership start time

## Problem
The current `orders_select` policy lets a center see EVERY order placed by any
doctor currently in its team — including orders the doctor placed BEFORE joining
this center (e.g. old orders from when the doctor was on another center's team,
or orders placed from the doctor's own account before being added). This leaks
historical order data that belongs to a previous center or to the doctor
personally.

## Fix
Tighten the `center_members` EXISTS sub-query so a center can only see an order
when BOTH are true:
  1. The doctor is (or was) a member of this center, AND
  2. The order was created on or after the moment that membership started
     (`center_members.created_at <= orders.created_at`).

This means:
  - Orders the doctor placed while on a DIFFERENT center's team (or before being
    added to this center) are NOT visible to this center.
  - Only new orders placed after the doctor joined the center are visible.
  - If the doctor is later removed from the center, old orders that were visible
    while they were a member remain visible only if the membership row still
    exists; since removal deletes the `center_members` row, the center loses
    visibility — which is the intended behaviour.

The same scoping is applied to `order_attachments_select` so attachment
visibility mirrors order visibility.

## Security notes
- Centers still can only READ these orders; insert/update/delete policies are
  unchanged.
- No new tables or columns. `center_members.created_at` already exists.
- The `orders.created_at` column already exists.
*/

-- Tighten orders SELECT: center sees team-doctor orders only from membership start
DROP POLICY IF EXISTS "orders_select" ON orders;
CREATE POLICY "orders_select" ON orders FOR SELECT TO authenticated
  USING (
    auth.uid() = from_id
    OR auth.uid() = lab_id
    OR EXISTS (
      SELECT 1 FROM center_members
      WHERE center_members.center_id = auth.uid()
        AND center_members.doctor_id = orders.from_id
        AND center_members.created_at <= orders.created_at
    )
  );

-- Tighten order_attachments SELECT to mirror the scoped orders visibility
DROP POLICY IF EXISTS "order_attachments_select" ON order_attachments;
CREATE POLICY "order_attachments_select" ON order_attachments FOR SELECT TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM orders
      WHERE orders.id = order_attachments.order_id
        AND (
          orders.from_id = auth.uid()
          OR orders.lab_id = auth.uid()
          OR EXISTS (
            SELECT 1 FROM center_members
            WHERE center_members.center_id = auth.uid()
              AND center_members.doctor_id = orders.from_id
              AND center_members.created_at <= orders.created_at
          )
        )
    )
  );
