/*
# Lab & Case Reviews

1. New Tables
- `lab_reviews`
  - `id` (uuid, pk)
  - `order_id` (uuid, fk → orders.id on delete cascade) — the case being reviewed
  - `lab_id` (uuid, fk → profiles.id) — the lab being rated
  - `reviewer_id` (uuid, fk → auth.users.id) — the doctor/center who submitted the review
  - `rating` (int 1-5, not null)
  - `comment` (text, nullable)
  - `created_at` (timestamptz, default now())
  - `updated_at` (timestamptz, default now())
- Unique constraint on `order_id` so each case can only be reviewed once.

2. Indexes
- `lab_reviews_lab_id_idx` on `lab_id` for fast average-rating lookups.
- `lab_reviews_reviewer_id_idx` on `reviewer_id`.

3. Security (RLS)
- Enable RLS on `lab_reviews`.
- SELECT: any authenticated user can read reviews (they are public — shown on lab cards).
- INSERT: only the user who placed the order can review, and only once per order (enforced by unique constraint). The reviewer must be the order's `from_id`.
- UPDATE: only the reviewer can update their own review.
- DELETE: only the reviewer can delete their own review.

4. Important Notes
- A review can only be created for an order that has been delivered.
- The unique constraint on `order_id` guarantees one review per case.
*/

CREATE TABLE IF NOT EXISTS lab_reviews (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id uuid NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  lab_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  reviewer_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  rating smallint NOT NULL CHECK (rating >= 1 AND rating <= 5),
  comment text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (order_id)
);

CREATE INDEX IF NOT EXISTS lab_reviews_lab_id_idx ON lab_reviews(lab_id);
CREATE INDEX IF NOT EXISTS lab_reviews_reviewer_id_idx ON lab_reviews(reviewer_id);

ALTER TABLE lab_reviews ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_lab_reviews" ON lab_reviews;
CREATE POLICY "select_lab_reviews"
  ON lab_reviews FOR SELECT
  TO authenticated USING (true);

DROP POLICY IF EXISTS "insert_lab_reviews" ON lab_reviews;
CREATE POLICY "insert_lab_reviews"
  ON lab_reviews FOR INSERT
  TO authenticated
  WITH CHECK (
    auth.uid() = reviewer_id
    AND EXISTS (
      SELECT 1 FROM orders o
      WHERE o.id = order_id
        AND o.from_id = auth.uid()
        AND o.status = 'delivered'
    )
  );

DROP POLICY IF EXISTS "update_lab_reviews" ON lab_reviews;
CREATE POLICY "update_lab_reviews"
  ON lab_reviews FOR UPDATE
  TO authenticated
  USING (auth.uid() = reviewer_id)
  WITH CHECK (auth.uid() = reviewer_id);

DROP POLICY IF EXISTS "delete_lab_reviews" ON lab_reviews;
CREATE POLICY "delete_lab_reviews"
  ON lab_reviews FOR DELETE
  TO authenticated
  USING (auth.uid() = reviewer_id);
