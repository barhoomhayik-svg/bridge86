/*
# Add bill_to column to orders

1. Changes
- Adds `bill_to` text column to `orders` table.
- Values: 'doctor' (invoice the doctor directly) or 'center' (invoice the center).
- Defaults to 'doctor' for backwards compatibility with existing rows.
- Added CHECK constraint to enforce valid values.
- No RLS changes needed; existing policies already cover the column.

2. Purpose
- Lets a doctor who belongs to a center choose, at order creation time, whether
  the lab should invoice them personally or the center they work with.
- The lab sees this field on the order detail so they know who to bill.
*/

ALTER TABLE orders ADD COLUMN IF NOT EXISTS bill_to text NOT NULL DEFAULT 'doctor';

ALTER TABLE orders DROP CONSTRAINT IF EXISTS orders_bill_to_check;
ALTER TABLE orders ADD CONSTRAINT orders_bill_to_check CHECK (bill_to IN ('doctor', 'center'));
