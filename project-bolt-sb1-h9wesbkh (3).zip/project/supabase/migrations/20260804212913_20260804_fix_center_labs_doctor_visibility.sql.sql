-- Fix: allow center team doctors to read their center's formal labs
-- so they can select them when placing an order on behalf of the center.

DROP POLICY IF EXISTS "select_center_labs" ON center_labs;

CREATE POLICY "select_center_labs"
ON center_labs FOR SELECT
TO authenticated
USING (
  auth.uid() = center_id
  OR auth.uid() = lab_id
  OR EXISTS (
    SELECT 1 FROM center_members cm
    WHERE cm.center_id = center_labs.center_id
      AND cm.doctor_id = auth.uid()
  )
);
