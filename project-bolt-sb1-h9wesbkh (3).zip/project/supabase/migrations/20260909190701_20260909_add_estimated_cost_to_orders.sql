/*
# Add estimated_cost column to orders

1. Changes
   - Adds `estimated_cost` numeric(10,2) nullable column to `orders` table.
   - This stores the total case cost set by the lab (either from an accepted quotation
     or entered manually by the lab).
   - Nullable so existing orders without pricing are unaffected.
   - No RLS changes needed; existing policies already cover the column.
     Visibility is controlled in the front-end (only doctors and centers see the value).

2. Purpose
   - Lets doctors and centers see the estimated cost of each case on their order list
     and order detail view.
   - The lab writes this value but does not see it displayed as a label — only their
     editable input.
*/

ALTER TABLE orders ADD COLUMN IF NOT EXISTS estimated_cost numeric(10,2);
