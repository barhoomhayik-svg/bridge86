/*
  # Limit a driver's order updates to delivery confirmation

  1. Why
     - `orders_update` lets any driver of the lab update a row, and row level
       security is row-level, so a driver could rewrite clinical and scheduling
       fields (patient name, notes, shade, teeth, due date) on every case of their
       lab. The driver screens only ever confirm deliveries.

  2. Change
     - `enforce_order_update_guards()` now detects a caller who is only a driver of
       the lab (not the lab itself, not a client party) and rejects the update if
       anything other than `status`, `delivered_at`, `delivered_by` or `updated_at`
       changed.

  3. Security
     - All existing guards are preserved verbatim: redo window, immutable lab,
       try-in hand-over rules, and server-timed write-once delivery stamps.
     - The driver screens keep working: they send exactly the allowed columns.
*/

CREATE OR REPLACE FUNCTION public.enforce_order_update_guards()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public', 'pg_temp'
AS $function$
DECLARE
  uid uuid := auth.uid();
  is_lab_side boolean;
  is_driver_only boolean;
BEGIN
  -- Redo window: enforced for every caller, on any update, from the stored
  -- delivery timestamp.
  IF NEW.status = 'redo'
    AND OLD.status = 'delivered'
    AND OLD.delivered_at IS NOT NULL
    AND (now() - OLD.delivered_at) > INTERVAL '30 days' THEN
    RAISE EXCEPTION 'Redo not allowed: the 30-day window since delivery has passed'
      USING ERRCODE = 'check_violation';
  END IF;

  IF uid IS NULL THEN
    RETURN NEW;
  END IF;

  -- A caller who is only one of the lab's drivers may confirm deliveries and
  -- nothing else.
  is_driver_only := uid IS DISTINCT FROM OLD.lab_id
    AND uid IS DISTINCT FROM OLD.from_id
    AND (OLD.doctor_id IS NULL OR uid IS DISTINCT FROM OLD.doctor_id)
    AND NOT EXISTS (
      SELECT 1 FROM public.center_members cm
      WHERE cm.center_id = OLD.from_id AND cm.doctor_id = uid
    )
    AND EXISTS (
      SELECT 1 FROM public.lab_drivers d
      WHERE d.driver_id = uid AND d.lab_id = OLD.lab_id
    );

  IF is_driver_only THEN
    IF NEW.id IS DISTINCT FROM OLD.id
      OR NEW.order_number IS DISTINCT FROM OLD.order_number
      OR NEW.from_id IS DISTINCT FROM OLD.from_id
      OR NEW.lab_id IS DISTINCT FROM OLD.lab_id
      OR NEW.doctor_id IS DISTINCT FROM OLD.doctor_id
      OR NEW.file_number IS DISTINCT FROM OLD.file_number
      OR NEW.patient_name IS DISTINCT FROM OLD.patient_name
      OR NEW.dr_name IS DISTINCT FROM OLD.dr_name
      OR NEW.shade IS DISTINCT FROM OLD.shade
      OR NEW.teeth_numbers IS DISTINCT FROM OLD.teeth_numbers
      OR NEW.service_id IS DISTINCT FROM OLD.service_id
      OR NEW.notes IS DISTINCT FROM OLD.notes
      OR NEW.due_date IS DISTINCT FROM OLD.due_date
      OR NEW.created_at IS DISTINCT FROM OLD.created_at
      OR NEW.parent_order_id IS DISTINCT FROM OLD.parent_order_id
      OR NEW.bill_to IS DISTINCT FROM OLD.bill_to
      OR NEW.try_in IS DISTINCT FROM OLD.try_in
      OR NEW.is_final IS DISTINCT FROM OLD.is_final THEN
      RAISE EXCEPTION 'A driver can only confirm delivery on an order'
        USING ERRCODE = 'check_violation';
    END IF;
  END IF;

  -- The lab that owns the case can never be reassigned by a client.
  IF NEW.lab_id IS DISTINCT FROM OLD.lab_id THEN
    RAISE EXCEPTION 'The laboratory on an order cannot be changed'
      USING ERRCODE = 'check_violation';
  END IF;

  -- The ordering account may only change in the try-in hand-over: the doctor
  -- named on the case approves a try-in placed by their center, and the case
  -- continues on that doctor's own account.
  IF NEW.from_id IS DISTINCT FROM OLD.from_id THEN
    IF NOT (OLD.status = 'try_in' AND OLD.doctor_id = uid AND NEW.from_id = uid) THEN
      RAISE EXCEPTION 'The ordering account on an order cannot be changed'
        USING ERRCODE = 'check_violation';
    END IF;
  END IF;

  IF NEW.doctor_id IS DISTINCT FROM OLD.doctor_id THEN
    IF NOT (
      (OLD.doctor_id = uid AND NEW.doctor_id IS NULL)
      OR OLD.from_id = uid
    ) THEN
      RAISE EXCEPTION 'The assigned doctor on an order cannot be changed'
        USING ERRCODE = 'check_violation';
    END IF;
  END IF;

  -- Delivery stamps: write-once, set by the lab or one of its drivers, and
  -- always timed by the server.
  IF NEW.delivered_at IS DISTINCT FROM OLD.delivered_at
    OR NEW.delivered_by IS DISTINCT FROM OLD.delivered_by THEN

    IF OLD.delivered_at IS NOT NULL THEN
      NEW.delivered_at := OLD.delivered_at;
      NEW.delivered_by := OLD.delivered_by;
    ELSE
      is_lab_side := (OLD.lab_id = uid)
        OR EXISTS (SELECT 1 FROM public.lab_drivers d WHERE d.driver_id = uid AND d.lab_id = OLD.lab_id);

      IF NOT is_lab_side THEN
        RAISE EXCEPTION 'Only the laboratory or its driver can mark an order delivered'
          USING ERRCODE = 'check_violation';
      END IF;

      IF NEW.delivered_at IS NOT NULL THEN
        NEW.delivered_at := now();
        NEW.delivered_by := uid;
      END IF;
    END IF;
  END IF;

  RETURN NEW;
END;
$function$;
