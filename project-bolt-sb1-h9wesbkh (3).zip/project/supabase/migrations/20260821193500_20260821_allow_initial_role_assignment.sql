/*
# Allow one-time role assignment for OAuth accounts

1. New Function
  - `assign_initial_role(desired_role text)` — SECURITY DEFINER function that lets a
    freshly created OAuth account set its role exactly once.
  - Only succeeds when:
    a) The caller is authenticated.
    b) Their profile currently has the default role ('doctor') assigned by the
       `handle_new_user` trigger.
    c) Their account was created less than 5 minutes ago (prevents abuse by
       existing accounts).
    d) The desired role is one of 'center', 'doctor', or 'lab'.
  - Bypasses the `enforce_profile_update_guards` trigger because it runs as
    SECURITY DEFINER (auth.uid() is NULL inside the function body when it performs
    the UPDATE, so the trigger's guard is skipped).
  - Returns void; raises an exception on invalid input or when conditions are not met.

2. Security
  - EXECUTE granted only to `authenticated` (not anon).
  - Search path pinned to `public`.
  - Cannot be used to change an already-chosen role (only works when current = 'doctor'
    and account age < 5 minutes).
*/

CREATE OR REPLACE FUNCTION public.assign_initial_role(desired_role text)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  caller_id uuid := auth.uid();
  current_role text;
  created_at_ts timestamptz;
BEGIN
  IF caller_id IS NULL THEN
    RAISE EXCEPTION 'Not authenticated' USING ERRCODE = 'insufficient_privilege';
  END IF;

  IF desired_role NOT IN ('center', 'doctor', 'lab') THEN
    RAISE EXCEPTION 'Invalid role' USING ERRCODE = 'check_violation';
  END IF;

  SELECT p.role, u.created_at
  INTO current_role, created_at_ts
  FROM public.profiles p
  JOIN auth.users u ON u.id = p.id
  WHERE p.id = caller_id;

  IF current_role IS NULL THEN
    RAISE EXCEPTION 'Profile not found' USING ERRCODE = 'no_data_found';
  END IF;

  -- Only allow assignment if the role is still the trigger default
  -- and the account was just created (within 5 minutes)
  IF current_role <> 'doctor' THEN
    RAISE EXCEPTION 'Role already assigned' USING ERRCODE = 'check_violation';
  END IF;

  IF created_at_ts < now() - interval '5 minutes' THEN
    RAISE EXCEPTION 'Assignment window expired' USING ERRCODE = 'check_violation';
  END IF;

  -- Perform the update as SECURITY DEFINER (auth.uid() is NULL inside this context
  -- for the trigger check, so it passes through)
  UPDATE public.profiles SET role = desired_role WHERE id = caller_id;
END;
$$;

REVOKE ALL ON FUNCTION public.assign_initial_role(text) FROM PUBLIC;
REVOKE ALL ON FUNCTION public.assign_initial_role(text) FROM anon;
GRANT EXECUTE ON FUNCTION public.assign_initial_role(text) TO authenticated;
