/*
# Add quotations table to realtime publication

1. Changes
  - Adds the `quotations` table to the `supabase_realtime` publication so that
    real-time subscriptions on quotations (insert/update) actually fire events
    to connected clients.

2. Context
  - The app subscribes to quotation changes via `postgres_changes` but the table
    was never added to the publication, so no events were delivered.
*/

ALTER PUBLICATION supabase_realtime ADD TABLE quotations;
