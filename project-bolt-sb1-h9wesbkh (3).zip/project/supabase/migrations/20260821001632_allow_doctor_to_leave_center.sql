/*
  # Let a doctor remove their own center link

  1. Why
     - `center_members` only had a DELETE policy for the center, so the Leave
       action in the doctor's "My Centers" screen matched zero rows and silently
       did nothing. A doctor therefore could not revoke a center's access to their
       profile, even though the app tells them they can leave at any time.

  2. Change
     - New DELETE policy so the doctor named on the membership can remove it.

  3. Security
     - Scoped to the authenticated role and to the caller's own membership rows.
     - The center's existing DELETE policy is unchanged.
*/

DROP POLICY IF EXISTS "cm_delete_self" ON public.center_members;

CREATE POLICY "cm_delete_self" ON public.center_members
  FOR DELETE TO authenticated
  USING (auth.uid() = doctor_id);
