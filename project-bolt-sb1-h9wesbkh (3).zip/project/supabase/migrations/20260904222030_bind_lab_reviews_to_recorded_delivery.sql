/*
  # A rating requires a delivery the laboratory actually recorded

  The review policies required only status = 'delivered', a value the reviewer
  could write to their own order. delivered_at is write-once and can only be
  stamped by the laboratory or one of its drivers, so the review is now bound
  to that instead. Legitimate reviews are unaffected: a real delivery always
  sets delivered_at.
*/

DROP POLICY IF EXISTS insert_lab_reviews ON public.lab_reviews;
CREATE POLICY insert_lab_reviews ON public.lab_reviews
FOR INSERT TO authenticated
WITH CHECK (
  auth.uid() = reviewer_id
  AND EXISTS (
    SELECT 1 FROM public.orders o
    WHERE o.id = lab_reviews.order_id
      AND o.from_id = auth.uid()
      AND o.lab_id = lab_reviews.lab_id
      AND o.status = 'delivered'
      AND o.delivered_at IS NOT NULL
  )
);

DROP POLICY IF EXISTS update_lab_reviews ON public.lab_reviews;
CREATE POLICY update_lab_reviews ON public.lab_reviews
FOR UPDATE TO authenticated
USING (auth.uid() = reviewer_id)
WITH CHECK (
  auth.uid() = reviewer_id
  AND EXISTS (
    SELECT 1 FROM public.orders o
    WHERE o.id = lab_reviews.order_id
      AND o.from_id = auth.uid()
      AND o.lab_id = lab_reviews.lab_id
      AND o.delivered_at IS NOT NULL
  )
);
