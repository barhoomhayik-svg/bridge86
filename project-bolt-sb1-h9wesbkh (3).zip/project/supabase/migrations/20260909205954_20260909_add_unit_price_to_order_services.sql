/*
# Add unit_price to order_services

1. Modified Tables
   - `order_services`
     - `unit_price` (numeric, nullable) -- the per-unit price for this service
       line, typically copied from the lab's service catalog or the accepted
       quotation at order-creation time.

2. Backfill
   - Existing rows are populated with the service catalog's `price_from` where
     a matching `service_id` exists, so historical orders show a cost.

3. Notes
   - No RLS or policy changes needed -- the column inherits the existing
     row-level policies on `order_services`.
*/

DO $$ BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema = 'public'
      AND table_name = 'order_services'
      AND column_name = 'unit_price'
  ) THEN
    ALTER TABLE order_services ADD COLUMN unit_price numeric;
  END IF;
END $$;

-- Backfill from service catalog for existing rows
UPDATE order_services os
SET unit_price = s.price_from
FROM services s
WHERE os.service_id = s.id
  AND os.unit_price IS NULL
  AND s.price_from IS NOT NULL;
