/*
# Fix: Add tables to supabase_realtime publication

## Problem
The `supabase_realtime` publication exists but has NO tables added to it.
This means ALL realtime subscriptions in the app are broken —
order comments don't appear live, notifications don't update, etc.

## Fix
Add the tables the app subscribes to via realtime channels:
- order_comments (conversation in OrderDetailModal)
- orders (order status updates in useRealtimeOrders)
- notifications (NotificationBell)
*/

ALTER PUBLICATION supabase_realtime ADD TABLE order_comments;
ALTER PUBLICATION supabase_realtime ADD TABLE orders;
ALTER PUBLICATION supabase_realtime ADD TABLE notifications;
