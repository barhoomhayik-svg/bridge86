/*
# Allow audio MIME types in order-attachments storage bucket

1. Changes
   - Adds common audio MIME types to the `order-attachments` bucket's
     `allowed_mime_types` list so voice messages recorded in the browser
     can be uploaded alongside existing file types.
   - Added types: audio/webm, audio/ogg, audio/mp4, audio/mpeg, audio/wav,
     audio/aac, audio/mp3.

2. Purpose
   - Enables voice message uploads in the order chat without changing any
     RLS policies or table schemas — voice messages are stored as regular
     comment attachments.
*/

UPDATE storage.buckets
SET allowed_mime_types = ARRAY[
  'image/png','image/jpeg','image/jpg','image/webp','image/gif','image/heic','image/heif',
  'application/pdf','application/zip','application/x-zip-compressed',
  'application/dicom','model/stl','model/obj','application/sla',
  'application/octet-stream','text/plain',
  'audio/webm','audio/ogg','audio/mp4','audio/mpeg','audio/wav','audio/aac','audio/mp3'
]
WHERE id = 'order-attachments';
