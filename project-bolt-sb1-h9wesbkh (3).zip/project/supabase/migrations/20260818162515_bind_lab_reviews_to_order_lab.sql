/*
  # Bind a review to the lab that did the work

  1. Security
    - `insert_lab_reviews` checked the reviewer owns a delivered order but never
      checked that `lab_id` matched that order's lab, so a reviewer could post a
      one-star review against any lab in the directory using their own delivered
      order as the ticket.
    - The check now requires `lab_reviews.lab_id = orders.lab_id`, and updates can
      no longer move a review to a different lab or order.
*/

DROP POLICY IF EXISTS insert_lab_reviews ON public.lab_reviews;

CREATE POLICY insert_lab_reviews ON public.lab_reviews
  FOR INSERT TO authenticated
  WITH CHECK (
    auth.uid() = reviewer_id
    AND EXISTS (
      SELECT 1 FROM public.orders o
      WHERE o.id = lab_reviews.order_id
        AND o.from_id = auth.uid()
        AND o.status = 'delivered'
        AND o.lab_id = lab_reviews.lab_id
    )
  );

DROP POLICY IF EXISTS update_lab_reviews ON public.lab_reviews;

CREATE POLICY update_lab_reviews ON public.lab_reviews
  FOR UPDATE TO authenticated
  USING (auth.uid() = reviewer_id)
  WITH CHECK (
    auth.uid() = reviewer_id
    AND EXISTS (
      SELECT 1 FROM public.orders o
      WHERE o.id = lab_reviews.order_id
        AND o.from_id = auth.uid()
        AND o.lab_id = lab_reviews.lab_id
    )
  );
