/*
# Fix: order_comments RLS blocks doctor sending from center

## Problem
order_comments SELECT and INSERT policies only allow
`orders.from_id = auth.uid() OR orders.lab_id = auth.uid()`.
When a doctor sends an order from a center, from_id is the center's ID,
so the doctor cannot read or post comments in the order conversation.

## Fix
Extend SELECT and INSERT to also allow doctor-members of the center
that owns the order (via center_members), matching the pattern used
in orders_insert and order_services fixes.
*/

-- SELECT
DROP POLICY IF EXISTS "order_comments_select" ON order_comments;
CREATE POLICY "order_comments_select" ON order_comments FOR SELECT TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM orders o
      WHERE o.id = order_id
      AND (
        o.from_id = auth.uid()
        OR o.lab_id = auth.uid()
        OR o.doctor_id = auth.uid()
        OR EXISTS (
          SELECT 1 FROM center_members cm
          WHERE cm.center_id = o.from_id AND cm.doctor_id = auth.uid()
        )
      )
    )
  );

-- INSERT
DROP POLICY IF EXISTS "order_comments_insert" ON order_comments;
CREATE POLICY "order_comments_insert" ON order_comments FOR INSERT TO authenticated
  WITH CHECK (
    auth.uid() = author_id AND
    EXISTS (
      SELECT 1 FROM orders o
      WHERE o.id = order_id
      AND (
        o.from_id = auth.uid()
        OR o.lab_id = auth.uid()
        OR o.doctor_id = auth.uid()
        OR EXISTS (
          SELECT 1 FROM center_members cm
          WHERE cm.center_id = o.from_id AND cm.doctor_id = auth.uid()
        )
      )
    )
  );
