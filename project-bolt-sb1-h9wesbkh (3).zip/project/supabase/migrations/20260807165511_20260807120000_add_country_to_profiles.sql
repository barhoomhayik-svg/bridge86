/*
# Add country selection to user profiles

1. New Columns
- Add `country` to `public.profiles` for the country selected during signup.

2. Modified Behavior
- New accounts copy the selected country from signup metadata into `profiles.country`.
- Existing profile data, including the current `city` field, remains unchanged.

3. Security
- No new table or policy is introduced.
- The existing profile access policies continue to protect the new column through the profiles table.

4. Important Notes
- The change is additive and preserves all existing user data.
- The signup trigger remains responsible for creating the initial profile row.
*/

ALTER TABLE public.profiles
  ADD COLUMN IF NOT EXISTS country text;

CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.profiles (id, role, name, phone, city, country, avatar_url)
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data->>'role', 'doctor'),
    COALESCE(NEW.raw_user_meta_data->>'name', NEW.raw_user_meta_data->>'full_name', split_part(NEW.email, '@', 1)),
    NEW.raw_user_meta_data->>'phone',
    NEW.raw_user_meta_data->>'city',
    NEW.raw_user_meta_data->>'country',
    NEW.raw_user_meta_data->>'avatar_url'
  );
  RETURN NEW;
END;
$$;