-- Add 'redo' to the orders status check constraint
ALTER TABLE orders DROP CONSTRAINT IF EXISTS orders_status_check;
ALTER TABLE orders ADD CONSTRAINT orders_status_check
  CHECK (status IN ('pending', 'accepted', 'in_progress', 'completed', 'rejected', 'cancelled', 'redo'));
