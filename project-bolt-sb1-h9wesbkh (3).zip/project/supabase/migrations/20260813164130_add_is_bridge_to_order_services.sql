ALTER TABLE order_services
  ADD COLUMN IF NOT EXISTS is_bridge boolean NOT NULL DEFAULT false;
