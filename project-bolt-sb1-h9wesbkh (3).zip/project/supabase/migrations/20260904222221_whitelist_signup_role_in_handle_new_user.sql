/*
  # Self-signup can only choose a self-service account type

  The profile row was created with whatever role the signup request put in its
  metadata, so a caller could hand themselves a staff role at registration.
  Only 'center', 'doctor' and 'lab' are accepted now; anything else falls back
  to 'doctor'. Driver and technician profiles are still written explicitly by
  the privileged create-driver / create-technician functions after signup, so
  those flows are unchanged.
*/

CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public', 'pg_temp'
AS $function$
DECLARE
requested text := NEW.raw_user_meta_data->>'role';
safe_role text;
BEGIN
IF requested IN ('center', 'doctor', 'lab') THEN
safe_role := requested;
ELSE
safe_role := 'doctor';
END IF;

INSERT INTO public.profiles (id, role, name, phone, city, country, avatar_url)
VALUES (
NEW.id,
safe_role,
COALESCE(NEW.raw_user_meta_data->>'name', NEW.raw_user_meta_data->>'full_name', split_part(NEW.email, '@', 1)),
NEW.raw_user_meta_data->>'phone',
NEW.raw_user_meta_data->>'city',
NEW.raw_user_meta_data->>'country',
NEW.raw_user_meta_data->>'avatar_url'
);
RETURN NEW;
END;
$function$;
