/*
# Restore handle_new_user trigger function and auth.users trigger

## Problem
The `handle_new_user()` function and its `on_auth_user_created` trigger on
`auth.users` were lost from the live database. Without them, new signups
create an `auth.users` row but no matching `profiles` row, which breaks the
entire app -- the user cannot sign in because the auth context expects a
profile to exist.

## Changes
1. Recreate `public.handle_new_user()` as a SECURITY DEFINER trigger function
   with a pinned search_path ('public', 'pg_temp').
   - Only allows self-service roles: center, doctor, lab. Falls back to doctor.
   - Inserts a profiles row from the signup metadata.
2. Recreate the `on_auth_user_created` AFTER INSERT trigger on `auth.users`.
3. Revoke EXECUTE from anon and authenticated (trigger-only function).

## Security
- SECURITY DEFINER with pinned search_path.
- EXECUTE revoked from anon and authenticated -- only the trigger invokes it.
*/

-- 1. Recreate the function
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public', 'pg_temp'
AS $function$
DECLARE
  requested text := NEW.raw_user_meta_data->>'role';
  safe_role text;
BEGIN
  IF requested IN ('center', 'doctor', 'lab') THEN
    safe_role := requested;
  ELSE
    safe_role := 'doctor';
  END IF;

  INSERT INTO public.profiles (id, role, name, phone, city, country, avatar_url)
  VALUES (
    NEW.id,
    safe_role,
    COALESCE(NEW.raw_user_meta_data->>'name', NEW.raw_user_meta_data->>'full_name', split_part(NEW.email, '@', 1)),
    NEW.raw_user_meta_data->>'phone',
    NEW.raw_user_meta_data->>'city',
    NEW.raw_user_meta_data->>'country',
    NEW.raw_user_meta_data->>'avatar_url'
  )
  ON CONFLICT (id) DO NOTHING;

  RETURN NEW;
END;
$function$;

-- 2. Recreate the trigger
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- 3. Revoke direct execution (trigger-only)
REVOKE EXECUTE ON FUNCTION public.handle_new_user() FROM anon, authenticated;
