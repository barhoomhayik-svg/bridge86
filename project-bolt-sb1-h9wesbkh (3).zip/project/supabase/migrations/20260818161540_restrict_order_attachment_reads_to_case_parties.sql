/*
  # Close public read access to case attachments

  1. Helper
    - `public.can_access_order_object(text, uuid)`: SECURITY DEFINER helper that
      pulls any order id out of a storage object path and reports whether the
      given user is a party to that order. Used by the storage policies so the
      predicate cannot be bypassed and cannot recurse into RLS.

  2. Security
    - `order-attachments` bucket is no longer public, so objects are not served
      without a token.
    - `order_attachments_select` was `TO public USING (bucket_id = ...)`, which let
      anonymous callers list and download every uploaded scan. It is replaced by
      an `authenticated` policy that requires the caller to be a party to the
      order named in the object path.
*/

CREATE OR REPLACE FUNCTION public.can_access_order_object(object_name text, uid uuid)
RETURNS boolean
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = public, storage, pg_temp
AS $$
DECLARE
  seg text;
  ord_id uuid;
BEGIN
  IF uid IS NULL OR object_name IS NULL THEN
    RETURN false;
  END IF;

  FOREACH seg IN ARRAY storage.foldername(object_name)
  LOOP
    BEGIN
      ord_id := seg::uuid;
    EXCEPTION WHEN others THEN
      CONTINUE;
    END;

    IF EXISTS (
      SELECT 1 FROM public.orders o
      WHERE o.id = ord_id
        AND (
          o.from_id = uid
          OR o.lab_id = uid
          OR o.doctor_id = uid
          OR EXISTS (
            SELECT 1 FROM public.lab_drivers d
            WHERE d.driver_id = uid AND d.lab_id = o.lab_id
          )
          OR EXISTS (
            SELECT 1 FROM public.center_members cm
            WHERE cm.center_id = o.from_id AND cm.doctor_id = uid
          )
        )
    ) THEN
      RETURN true;
    END IF;
  END LOOP;

  RETURN false;
END;
$$;

REVOKE ALL ON FUNCTION public.can_access_order_object(text, uuid) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.can_access_order_object(text, uuid) TO authenticated;

UPDATE storage.buckets SET public = false WHERE id = 'order-attachments';

DROP POLICY IF EXISTS order_attachments_select ON storage.objects;

CREATE POLICY order_attachments_select ON storage.objects
  FOR SELECT TO authenticated
  USING (
    bucket_id = 'order-attachments'
    AND public.can_access_order_object(name, auth.uid())
  );
