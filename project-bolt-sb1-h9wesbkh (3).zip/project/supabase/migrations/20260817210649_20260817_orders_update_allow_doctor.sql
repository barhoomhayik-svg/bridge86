-- Allow assigned doctor to update the order (needed for try-in approval that also
-- transfers ownership from center to doctor).
DROP POLICY IF EXISTS "orders_update" ON orders;
CREATE POLICY "orders_update" ON orders FOR UPDATE TO authenticated
  USING (
    auth.uid() = from_id
    OR auth.uid() = lab_id
    OR auth.uid() = doctor_id
    OR EXISTS (
      SELECT 1 FROM lab_drivers
      WHERE lab_drivers.driver_id = auth.uid()
        AND lab_drivers.lab_id = orders.lab_id
    )
  )
  WITH CHECK (
    auth.uid() = from_id
    OR auth.uid() = lab_id
    OR auth.uid() = doctor_id
    OR EXISTS (
      SELECT 1 FROM lab_drivers
      WHERE lab_drivers.driver_id = auth.uid()
        AND lab_drivers.lab_id = orders.lab_id
    )
  );
