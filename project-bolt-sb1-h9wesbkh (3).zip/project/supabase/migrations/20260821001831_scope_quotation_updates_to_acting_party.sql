/*
  # Scope quotation updates to the party they belong to

  1. Why
     - `quotations_update` allows both the requesting account and the lab to write
       every column, so a lab could mark its own quote as accepted by the clinic,
       and a clinic could rewrite the lab's written response.

  2. Change
     - New BEFORE UPDATE trigger on `public.quotations`:
       - `from_id` and `lab_id` are immutable.
       - `response_notes` may only be changed by the lab.
       - Only the lab may move a quote to `responded`; only the requesting account
         may move it to `accepted` or `declined`.

  3. Security
     - Service-role and trigger-internal writes (no `auth.uid()`) are unaffected.
     - Both existing screens keep working: the lab responds with a price and notes,
       the clinic accepts or declines.
*/

CREATE OR REPLACE FUNCTION public.enforce_quotation_update_guards()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public', 'pg_temp'
AS $function$
DECLARE
  uid uuid := auth.uid();
BEGIN
  IF uid IS NULL THEN
    RETURN NEW;
  END IF;

  IF NEW.from_id IS DISTINCT FROM OLD.from_id OR NEW.lab_id IS DISTINCT FROM OLD.lab_id THEN
    RAISE EXCEPTION 'The parties on a quotation cannot be changed'
      USING ERRCODE = 'check_violation';
  END IF;

  IF NEW.response_notes IS DISTINCT FROM OLD.response_notes AND uid IS DISTINCT FROM OLD.lab_id THEN
    RAISE EXCEPTION 'Only the laboratory can write the response on a quotation'
      USING ERRCODE = 'check_violation';
  END IF;

  IF NEW.status IS DISTINCT FROM OLD.status THEN
    IF uid = OLD.lab_id AND NEW.status = 'responded' THEN
      NULL;
    ELSIF uid = OLD.from_id AND NEW.status IN ('accepted', 'declined') THEN
      NULL;
    ELSE
      RAISE EXCEPTION 'This quotation status change is not allowed for your account'
        USING ERRCODE = 'check_violation';
    END IF;
  END IF;

  RETURN NEW;
END;
$function$;

DROP TRIGGER IF EXISTS trg_enforce_quotation_update_guards ON public.quotations;

CREATE TRIGGER trg_enforce_quotation_update_guards
  BEFORE UPDATE ON public.quotations
  FOR EACH ROW EXECUTE FUNCTION public.enforce_quotation_update_guards();
