/*
# Add description column to order_attachments

1. Modified Tables
   - `order_attachments`
     - Added `description` (text, nullable) — optional description/caption for the attachment

2. Important Notes
   - This lets labs add context (name, description) to case photos that doctors can see.
   - Nullable column, no default — backward-compatible with existing rows.
*/

DO $$ BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'order_attachments' AND column_name = 'description'
  ) THEN
    ALTER TABLE order_attachments ADD COLUMN description text;
  END IF;
END $$;
