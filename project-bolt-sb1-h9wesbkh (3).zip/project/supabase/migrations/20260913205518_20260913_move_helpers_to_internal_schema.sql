-- Move RLS/storage helper functions to internal schema
-- ====================================================
-- Problem: Four SECURITY DEFINER functions in public schema are exposed via
-- PostgREST REST API. Two helpers (can_access_order_object, can_view_profile)
-- should NOT be directly callable. Two app-facing functions
-- (assign_initial_role, search_doctor_profiles) need anon access revoked.
--
-- Changes:
-- 1. Create internal schema (not exposed by PostgREST).
-- 2. Recreate helper functions in internal schema.
-- 3. Grant EXECUTE to authenticated so policies still evaluate.
-- 4. Update policies to reference internal.* versions.
-- 5. Drop public versions.
-- 6. Revoke anon/public EXECUTE on assign_initial_role and search_doctor_profiles.

-- 1. Create internal schema
CREATE SCHEMA IF NOT EXISTS internal;

-- 2a. Recreate can_access_order_object in internal schema
CREATE OR REPLACE FUNCTION internal.can_access_order_object(object_name text, uid uuid)
RETURNS boolean
LANGUAGE plpgsql
STABLE SECURITY DEFINER
SET search_path TO 'public', 'storage', 'pg_temp'
AS $fn_cao$
DECLARE
  seg text;
  ord_id uuid;
BEGIN
  IF uid IS NULL OR object_name IS NULL THEN
    RETURN false;
  END IF;

  IF auth.uid() IS NOT NULL AND uid IS DISTINCT FROM auth.uid() THEN
    RETURN false;
  END IF;

  FOREACH seg IN ARRAY storage.foldername(object_name)
  LOOP
    BEGIN
      ord_id := seg::uuid;
    EXCEPTION WHEN others THEN
      CONTINUE;
    END;

    IF EXISTS (
      SELECT 1 FROM public.orders o
      WHERE o.id = ord_id
        AND (
          o.from_id = uid
          OR o.lab_id = uid
          OR o.doctor_id = uid
          OR o.assigned_technician_id = uid
          OR EXISTS (
            SELECT 1 FROM public.lab_drivers d
            WHERE d.driver_id = uid AND d.lab_id = o.lab_id
          )
          OR EXISTS (
            SELECT 1 FROM public.center_members cm
            WHERE cm.center_id = o.from_id AND cm.doctor_id = uid
          )
        )
    ) THEN
      RETURN true;
    END IF;
  END LOOP;

  RETURN false;
END;
$fn_cao$;

-- 2b. Recreate can_view_profile in internal schema
CREATE OR REPLACE FUNCTION internal.can_view_profile(target uuid)
RETURNS boolean
LANGUAGE sql
STABLE SECURITY DEFINER
SET search_path TO 'public', 'pg_temp'
AS $fn_cvp$
SELECT
  auth.uid() IS NOT NULL
  AND (
    target = auth.uid()
    OR EXISTS (SELECT 1 FROM public.profiles p WHERE p.id = target AND p.role = 'lab')
    OR EXISTS (
      SELECT 1 FROM public.orders o
      WHERE (o.from_id = target OR o.lab_id = target OR o.doctor_id = target OR o.assigned_technician_id = target)
        AND (
          o.from_id = auth.uid() OR o.lab_id = auth.uid() OR o.doctor_id = auth.uid()
          OR o.assigned_technician_id = auth.uid()
          OR EXISTS (SELECT 1 FROM public.lab_drivers d WHERE d.driver_id = auth.uid() AND d.lab_id = o.lab_id)
          OR EXISTS (SELECT 1 FROM public.center_members cm WHERE cm.center_id = o.from_id AND cm.doctor_id = auth.uid())
        )
    )
    OR EXISTS (
      SELECT 1 FROM public.center_members cm
      WHERE (cm.center_id = auth.uid() AND cm.doctor_id = target)
         OR (cm.doctor_id = auth.uid() AND cm.center_id = target)
    )
    OR EXISTS (
      SELECT 1 FROM public.lab_drivers d
      WHERE (d.lab_id = auth.uid() AND d.driver_id = target)
         OR (d.driver_id = auth.uid() AND d.lab_id = target)
    )
    OR EXISTS (
      SELECT 1 FROM public.lab_technicians t
      WHERE (t.lab_id = auth.uid() AND t.technician_id = target)
         OR (t.technician_id = auth.uid() AND t.lab_id = target)
    )
  );
$fn_cvp$;

-- 3. Grant EXECUTE on internal functions to authenticated (policy evaluation)
GRANT USAGE ON SCHEMA internal TO authenticated;
GRANT EXECUTE ON FUNCTION internal.can_access_order_object(text, uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION internal.can_view_profile(uuid) TO authenticated;

-- 4a. Update profiles_select policy
DROP POLICY IF EXISTS "profiles_select" ON public.profiles;
CREATE POLICY "profiles_select" ON public.profiles
  FOR SELECT TO authenticated
  USING (internal.can_view_profile(id));

-- 4b. Update storage policies
DROP POLICY IF EXISTS "order_attachments_select" ON storage.objects;
CREATE POLICY "order_attachments_select" ON storage.objects
  FOR SELECT TO authenticated
  USING (
    bucket_id = 'order-attachments'
    AND internal.can_access_order_object(name, auth.uid())
  );

DROP POLICY IF EXISTS "order_attachments_insert" ON storage.objects;
CREATE POLICY "order_attachments_insert" ON storage.objects
  FOR INSERT TO authenticated
  WITH CHECK (
    bucket_id = 'order-attachments'
    AND internal.can_access_order_object(name, auth.uid())
  );

-- 5. Drop public versions
DROP FUNCTION IF EXISTS public.can_access_order_object(text, uuid);
DROP FUNCTION IF EXISTS public.can_view_profile(uuid);

-- 6. Tighten the two app-facing functions (revoke anon + public role)
REVOKE EXECUTE ON FUNCTION public.assign_initial_role(text) FROM public, anon;
GRANT EXECUTE ON FUNCTION public.assign_initial_role(text) TO authenticated;

REVOKE EXECUTE ON FUNCTION public.search_doctor_profiles(text) FROM public, anon;
GRANT EXECUTE ON FUNCTION public.search_doctor_profiles(text) TO authenticated;
