/*
  # Remove write privileges from the unauthenticated role

  1. Why
     - The `anon` role held INSERT, UPDATE and DELETE on every application table.
       No policy targets `anon`, so row level security blocks those writes today,
       but the privilege is a standing hazard: the moment any table gains an `anon`
       policy or loses its own, unauthenticated writes are already permitted.

  2. Change
     - Revoke INSERT, UPDATE, DELETE from `anon` on the application tables.

  3. Security
     - SELECT is deliberately left untouched, so no existing read can regress.
     - The app never talks to the database without a session (the landing page makes
       no database calls), so nothing legitimate loses access.
*/

REVOKE INSERT, UPDATE, DELETE ON public.profiles FROM anon;
REVOKE INSERT, UPDATE, DELETE ON public.orders FROM anon;
REVOKE INSERT, UPDATE, DELETE ON public.order_services FROM anon;
REVOKE INSERT, UPDATE, DELETE ON public.order_attachments FROM anon;
REVOKE INSERT, UPDATE, DELETE ON public.order_comments FROM anon;
REVOKE INSERT, UPDATE, DELETE ON public.order_comment_reads FROM anon;
REVOKE INSERT, UPDATE, DELETE ON public.quotations FROM anon;
REVOKE INSERT, UPDATE, DELETE ON public.quotation_services FROM anon;
REVOKE INSERT, UPDATE, DELETE ON public.services FROM anon;
REVOKE INSERT, UPDATE, DELETE ON public.case_photos FROM anon;
REVOKE INSERT, UPDATE, DELETE ON public.center_members FROM anon;
REVOKE INSERT, UPDATE, DELETE ON public.center_labs FROM anon;
REVOKE INSERT, UPDATE, DELETE ON public.lab_drivers FROM anon;
REVOKE INSERT, UPDATE, DELETE ON public.lab_reviews FROM anon;
REVOKE INSERT, UPDATE, DELETE ON public.favourite_labs FROM anon;
REVOKE INSERT, UPDATE, DELETE ON public.notifications FROM anon;
