/*
# Allow drivers to post and read order comments

1. Security Changes
   - Updated `order_comments_insert` policy to allow lab drivers to post comments
     on orders belonging to their lab (proof of delivery photos).
   - Updated `order_comments_select` policy to allow lab drivers to read comments
     on orders belonging to their lab.

2. Important Notes
   - Drivers are linked to labs via the `lab_drivers` table.
   - A driver can only comment on orders where `orders.lab_id` matches their
     lab assignment in `lab_drivers`.
*/

-- Update INSERT policy to include drivers
DROP POLICY IF EXISTS "order_comments_insert" ON order_comments;
CREATE POLICY "order_comments_insert" ON order_comments FOR INSERT
TO authenticated
WITH CHECK (
  auth.uid() = author_id
  AND EXISTS (
    SELECT 1 FROM orders o
    WHERE o.id = order_comments.order_id
    AND (
      o.from_id = auth.uid()
      OR o.lab_id = auth.uid()
      OR o.doctor_id = auth.uid()
      OR EXISTS (SELECT 1 FROM center_members cm WHERE cm.center_id = o.from_id AND cm.doctor_id = auth.uid())
      OR EXISTS (SELECT 1 FROM lab_drivers ld WHERE ld.lab_id = o.lab_id AND ld.driver_id = auth.uid())
    )
  )
);

-- Update SELECT policy to include drivers
DROP POLICY IF EXISTS "order_comments_select" ON order_comments;
CREATE POLICY "order_comments_select" ON order_comments FOR SELECT
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM orders o
    WHERE o.id = order_comments.order_id
    AND (
      o.from_id = auth.uid()
      OR o.lab_id = auth.uid()
      OR o.doctor_id = auth.uid()
      OR EXISTS (SELECT 1 FROM center_members cm WHERE cm.center_id = o.from_id AND cm.doctor_id = auth.uid())
      OR EXISTS (SELECT 1 FROM lab_drivers ld WHERE ld.lab_id = o.lab_id AND ld.driver_id = auth.uid())
    )
  )
);
