/*
# Fix: Doctor "Send Order From Center" fails RLS

## Problem
When a doctor who belongs to a center selects "send from center" in the
New Order modal, the order is inserted with `from_id` = the center's ID
(not the doctor's own ID). The existing `orders_insert` policy only
allows `auth.uid() = from_id`, so the insert is rejected by RLS.

The same issue affects `order_attachments_insert`: it checks
`orders.from_id = auth.uid()`, which fails when the order's `from_id`
is the center, not the doctor who uploaded the file.

## Changes
1. `orders_insert` — allow the insert when EITHER:
   - `auth.uid() = from_id` (original behavior), OR
   - The authenticated user is a doctor who is a member of the center
     referenced by `from_id` (via `center_members`).
2. `order_attachments_insert` — allow the insert when EITHER:
   - `orders.from_id = auth.uid()` (original behavior), OR
   - The authenticated user is a doctor-member of the center that is the
     order's `from_id`.

## Security
- No data is lost; only RLS policies are replaced.
- The membership check uses the existing `center_members` table, so only
  doctors explicitly linked to a center can create orders on its behalf.
*/

-- orders_insert: allow doctor members of a center to insert orders with from_id = center
DROP POLICY IF EXISTS "orders_insert" ON orders;
CREATE POLICY "orders_insert" ON orders FOR INSERT TO authenticated WITH CHECK (
  (
    auth.uid() = from_id
    OR (
      EXISTS (
        SELECT 1 FROM center_members
        WHERE center_members.center_id = from_id
          AND center_members.doctor_id = auth.uid()
      )
      AND EXISTS (
        SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'doctor'
      )
    )
  )
  AND EXISTS (
    SELECT 1 FROM profiles WHERE id = auth.uid() AND role IN ('center', 'doctor')
  )
);

-- order_attachments_insert: allow doctor members of the center that owns the order
DROP POLICY IF EXISTS "order_attachments_insert" ON order_attachments;
CREATE POLICY "order_attachments_insert" ON order_attachments FOR INSERT TO authenticated WITH CHECK (
  auth.uid() = uploader_id
  AND (
    EXISTS (
      SELECT 1 FROM orders
      WHERE orders.id = order_id
        AND (orders.from_id = auth.uid() OR orders.lab_id = auth.uid())
    )
    OR EXISTS (
      SELECT 1 FROM orders
      JOIN center_members ON center_members.center_id = orders.from_id
      WHERE orders.id = order_id
        AND center_members.doctor_id = auth.uid()
    )
  )
);