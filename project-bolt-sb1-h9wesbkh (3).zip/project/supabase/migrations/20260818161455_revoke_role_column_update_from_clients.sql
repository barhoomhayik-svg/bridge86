/*
  # Prevent users from changing their own account type

  1. Security
    - Revoke UPDATE on `profiles.role` from `authenticated` and `anon`.
      The row policy `profiles_update` is row-level and therefore authorised
      writes to every column of the caller's own row, including `role`, which
      four other policies key on. The client never updates `role`; the
      create-driver edge function writes it with the service role, which is
      not affected by column grants.
*/

REVOKE UPDATE (role) ON public.profiles FROM authenticated;
REVOKE UPDATE (role) ON public.profiles FROM anon;
