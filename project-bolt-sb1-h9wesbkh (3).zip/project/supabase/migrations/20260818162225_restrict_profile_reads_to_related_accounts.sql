/*
  # Restrict profile reads to related accounts

  1. Security
    - `profiles_select` was `USING (true)`, so any signed-in account could read
      every profile row: names, phone numbers, addresses, e-mail-derived contact
      details and the `profile_code` values used to link doctors to centers.
    - Reads are now limited to: the caller's own profile, lab profiles (the lab
      directory is intentionally public inside the app), and profiles the caller
      shares an order, center membership or driver relationship with.
    - Doctor lookup for the "add team member" flow keeps working through the new
      `search_doctor_profiles` function, which returns only non-sensitive columns
      and requires an exact code or a name of at least two characters.
*/

CREATE OR REPLACE FUNCTION public.can_view_profile(target uuid)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
  SELECT
    auth.uid() IS NOT NULL
    AND (
      target = auth.uid()
      OR EXISTS (SELECT 1 FROM public.profiles p WHERE p.id = target AND p.role = 'lab')
      OR EXISTS (
        SELECT 1 FROM public.orders o
        WHERE (o.from_id = target OR o.lab_id = target OR o.doctor_id = target)
          AND (
            o.from_id = auth.uid() OR o.lab_id = auth.uid() OR o.doctor_id = auth.uid()
            OR EXISTS (SELECT 1 FROM public.lab_drivers d WHERE d.driver_id = auth.uid() AND d.lab_id = o.lab_id)
            OR EXISTS (SELECT 1 FROM public.center_members cm WHERE cm.center_id = o.from_id AND cm.doctor_id = auth.uid())
          )
      )
      OR EXISTS (
        SELECT 1 FROM public.center_members cm
        WHERE (cm.center_id = auth.uid() AND cm.doctor_id = target)
           OR (cm.doctor_id = auth.uid() AND cm.center_id = target)
      )
      OR EXISTS (
        SELECT 1 FROM public.lab_drivers d
        WHERE (d.lab_id = auth.uid() AND d.driver_id = target)
           OR (d.driver_id = auth.uid() AND d.lab_id = target)
      )
    );
$$;

REVOKE ALL ON FUNCTION public.can_view_profile(uuid) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.can_view_profile(uuid) TO authenticated;

DROP POLICY IF EXISTS profiles_select ON public.profiles;

CREATE POLICY profiles_select ON public.profiles
  FOR SELECT TO authenticated
  USING (public.can_view_profile(id));

CREATE OR REPLACE FUNCTION public.search_doctor_profiles(term text)
RETURNS TABLE (id uuid, name text, profile_code text, city text, logo_url text, role text)
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
DECLARE
  q text := btrim(coalesce(term, ''));
BEGIN
  IF auth.uid() IS NULL OR length(q) < 2 THEN
    RETURN;
  END IF;

  RETURN QUERY
  SELECT p.id, p.name, p.profile_code, p.city, p.logo_url, p.role
  FROM public.profiles p
  WHERE p.role = 'doctor'
    AND (
      upper(p.profile_code) = upper(q)
      OR p.name ILIKE '%' || q || '%'
    )
  ORDER BY (upper(p.profile_code) = upper(q)) DESC, p.name
  LIMIT 10;
END;
$$;

REVOKE ALL ON FUNCTION public.search_doctor_profiles(text) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.search_doctor_profiles(text) TO authenticated;
