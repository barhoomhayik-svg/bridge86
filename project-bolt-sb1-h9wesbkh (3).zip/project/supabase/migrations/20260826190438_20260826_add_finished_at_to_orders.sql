/*
# Add finished_at column to orders

1. Modified Tables
   - `orders`
     - `finished_at` (timestamptz, nullable) — timestamp when doctor marks an order as finished

2. Important Notes
   - Doctors can manually mark delivered orders as finished.
   - If finished_at is NULL, the 30-day auto-threshold still applies on the frontend.
   - No policy changes needed; existing UPDATE policies cover this column.
*/

DO $$ BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema = 'public' AND table_name = 'orders' AND column_name = 'finished_at'
  ) THEN
    ALTER TABLE orders ADD COLUMN finished_at timestamptz;
  END IF;
END $$;
