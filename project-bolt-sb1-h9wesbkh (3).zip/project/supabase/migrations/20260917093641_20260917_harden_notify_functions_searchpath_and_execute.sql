/*
# Harden notification and utility functions

1. Security Changes
   - Pin `search_path` to '' (empty) on 7 public functions that had a mutable search_path:
     fn_notify_new_order, fn_notify_order_status, fn_notify_new_quotation,
     fn_notify_quotation_update, generate_profile_code, fn_notify_new_comment,
     fn_notify_doctor_order.
   - Revoke EXECUTE from anon and authenticated on all SECURITY DEFINER trigger/utility
     functions that must not be callable via the REST API:
     fn_notify_new_order, fn_notify_order_status, fn_notify_new_quotation,
     fn_notify_quotation_update, fn_notify_new_comment, fn_notify_doctor_order,
     generate_profile_code, rls_auto_enable.

2. Important Notes
   - These functions are invoked only by internal triggers, not by client code.
   - Revoking EXECUTE from anon/authenticated does not affect trigger execution
     because triggers run with the function owner's privileges.
*/

-- 1. Pin search_path on all 7 functions
ALTER FUNCTION public.fn_notify_new_order()      SET search_path = '';
ALTER FUNCTION public.fn_notify_order_status()    SET search_path = '';
ALTER FUNCTION public.fn_notify_new_quotation()   SET search_path = '';
ALTER FUNCTION public.fn_notify_quotation_update() SET search_path = '';
ALTER FUNCTION public.generate_profile_code()     SET search_path = '';
ALTER FUNCTION public.fn_notify_new_comment()     SET search_path = '';
ALTER FUNCTION public.fn_notify_doctor_order()    SET search_path = '';

-- 2. Revoke EXECUTE from anon and authenticated on all SECURITY DEFINER functions
REVOKE EXECUTE ON FUNCTION public.fn_notify_new_order()       FROM anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.fn_notify_order_status()    FROM anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.fn_notify_new_quotation()   FROM anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.fn_notify_quotation_update() FROM anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.fn_notify_new_comment()     FROM anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.fn_notify_doctor_order()    FROM anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.generate_profile_code()     FROM anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.rls_auto_enable()           FROM anon, authenticated;
