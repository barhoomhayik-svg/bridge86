/*
# Add cover_url to profiles

1. Changes
  - Add `cover_url` (text, nullable) to `profiles` to store the lab's cover photo displayed as the banner on the lab discovery page.
2. Security
  - No policy changes. Existing UPDATE policies on `profiles` already allow the owner to write this new column.
*/

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema = 'public' AND table_name = 'profiles' AND column_name = 'cover_url'
  ) THEN
    ALTER TABLE public.profiles ADD COLUMN cover_url text;
  END IF;
END $$;
