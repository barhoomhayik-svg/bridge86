/*
  # Restore EXECUTE on the storage access helper

  The previous migration revoked EXECUTE on can_access_order_object from
  authenticated, but that function is called from the order-attachments storage
  policies, which are evaluated as the calling role. Without the grant, legitimate
  attachment reads and uploads would fail. The grant is restored; anon still has
  no access.
*/

GRANT EXECUTE ON FUNCTION public.can_access_order_object(text, uuid) TO authenticated;
