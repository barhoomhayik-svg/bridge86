/*
  # Restrict doctor lookup to an exact account code

  1. Why
     - `search_doctor_profiles` matched doctor names by substring for any signed-in
       caller, so the whole doctor directory (including each doctor's id and account
       code) could be enumerated two characters at a time. That id is all a "center"
       account needs to attach a doctor to its team unilaterally and then read that
       doctor's phone, address and coordinates.

  2. Change
     - The function now resolves a doctor only by an exact, case-insensitive
       `profile_code` match, which is the flow the app documents ("share your
       Account ID with a center"). Signature and return shape are unchanged.

  3. Security
     - Still SECURITY DEFINER with a pinned search_path and a session requirement.
     - No table, policy or grant is changed.
*/

CREATE OR REPLACE FUNCTION public.search_doctor_profiles(term text)
RETURNS TABLE(id uuid, name text, profile_code text, city text, logo_url text, role text)
LANGUAGE plpgsql
STABLE SECURITY DEFINER
SET search_path TO 'public', 'pg_temp'
AS $function$
DECLARE
  q text := btrim(coalesce(term, ''));
BEGIN
  -- A session is required, and the caller must know the doctor's account code.
  IF auth.uid() IS NULL OR length(q) < 4 THEN
    RETURN;
  END IF;

  RETURN QUERY
  SELECT p.id, p.name, p.profile_code, p.city, p.logo_url, p.role
  FROM public.profiles p
  WHERE p.role = 'doctor'
    AND p.profile_code IS NOT NULL
    AND upper(p.profile_code) = upper(q)
  LIMIT 1;
END;
$function$;
