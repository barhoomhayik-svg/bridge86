/*
  # Allow order_number to be shared across parent+redo chain

  Removes the global UNIQUE constraint on orders.order_number so that a redo
  order can carry the same number as its parent. Replaces it with a regular
  index to keep lookups fast.
*/

ALTER TABLE orders DROP CONSTRAINT IF EXISTS orders_order_number_key;
DROP INDEX IF EXISTS orders_order_number_key;
CREATE INDEX IF NOT EXISTS orders_order_number_idx ON orders (order_number);
