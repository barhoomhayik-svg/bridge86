/*
  # Guard ownership and delivery fields on order updates

  1. Security
    - `orders_update` is a row policy whose USING and WITH CHECK both accept any
      party of the case, so any party could rewrite `lab_id`, `from_id` or
      `doctor_id` and move someone else's case onto another account or lab.
    - `delivered_at` / `delivered_by` were fully client-writable, and the redo
      window trigger fired only on `UPDATE OF status`, so a doctor could back-date
      or overwrite the delivery timestamp (in an update that touched no status)
      and reopen the expired 30-day remake window.
    - This trigger runs for client-authenticated updates only (service-role calls
      have no `auth.uid()`), pins the lab, allows the try-in hand-over to the
      doctor named on the case and nothing else, makes delivery stamps
      write-once and server-timed, and re-checks the redo window on every update.
*/

CREATE OR REPLACE FUNCTION public.enforce_order_update_guards()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
DECLARE
  uid uuid := auth.uid();
  is_lab_side boolean;
BEGIN
  -- Redo window: enforced for every caller, on any update, from the stored
  -- delivery timestamp.
  IF NEW.status = 'redo'
     AND OLD.status = 'delivered'
     AND OLD.delivered_at IS NOT NULL
     AND (now() - OLD.delivered_at) > INTERVAL '30 days' THEN
    RAISE EXCEPTION 'Redo not allowed: the 30-day window since delivery has passed'
      USING ERRCODE = 'check_violation';
  END IF;

  IF uid IS NULL THEN
    RETURN NEW;
  END IF;

  -- The lab that owns the case can never be reassigned by a client.
  IF NEW.lab_id IS DISTINCT FROM OLD.lab_id THEN
    RAISE EXCEPTION 'The laboratory on an order cannot be changed'
      USING ERRCODE = 'check_violation';
  END IF;

  -- The ordering account may only change in the try-in hand-over: the doctor
  -- named on the case approves a try-in placed by their center, and the case
  -- continues on that doctor's own account.
  IF NEW.from_id IS DISTINCT FROM OLD.from_id THEN
    IF NOT (OLD.status = 'try_in' AND OLD.doctor_id = uid AND NEW.from_id = uid) THEN
      RAISE EXCEPTION 'The ordering account on an order cannot be changed'
        USING ERRCODE = 'check_violation';
    END IF;
  END IF;

  IF NEW.doctor_id IS DISTINCT FROM OLD.doctor_id THEN
    IF NOT (
      (OLD.doctor_id = uid AND NEW.doctor_id IS NULL)
      OR OLD.from_id = uid
    ) THEN
      RAISE EXCEPTION 'The assigned doctor on an order cannot be changed'
        USING ERRCODE = 'check_violation';
    END IF;
  END IF;

  -- Delivery stamps: write-once, set by the lab or one of its drivers, and
  -- always timed by the server.
  IF NEW.delivered_at IS DISTINCT FROM OLD.delivered_at
     OR NEW.delivered_by IS DISTINCT FROM OLD.delivered_by THEN

    IF OLD.delivered_at IS NOT NULL THEN
      NEW.delivered_at := OLD.delivered_at;
      NEW.delivered_by := OLD.delivered_by;
    ELSE
      is_lab_side := (OLD.lab_id = uid)
        OR EXISTS (SELECT 1 FROM public.lab_drivers d WHERE d.driver_id = uid AND d.lab_id = OLD.lab_id);

      IF NOT is_lab_side THEN
        RAISE EXCEPTION 'Only the laboratory or its driver can mark an order delivered'
          USING ERRCODE = 'check_violation';
      END IF;

      IF NEW.delivered_at IS NOT NULL THEN
        NEW.delivered_at := now();
        NEW.delivered_by := uid;
      END IF;
    END IF;
  END IF;

  RETURN NEW;
END;
$$;

REVOKE ALL ON FUNCTION public.enforce_order_update_guards() FROM PUBLIC;

DROP TRIGGER IF EXISTS trg_enforce_redo_window ON public.orders;
DROP TRIGGER IF EXISTS trg_enforce_order_update_guards ON public.orders;

CREATE TRIGGER trg_enforce_order_update_guards
  BEFORE UPDATE ON public.orders
  FOR EACH ROW
  EXECUTE FUNCTION public.enforce_order_update_guards();
