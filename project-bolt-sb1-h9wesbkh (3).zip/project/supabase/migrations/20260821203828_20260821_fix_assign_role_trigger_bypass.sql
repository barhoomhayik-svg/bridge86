/*
# Fix assign_initial_role to bypass the profile update trigger

1. Problem
  - `assign_initial_role` is a SECURITY DEFINER function that updates the profile role.
  - The `enforce_profile_update_guards` trigger fires on the UPDATE and checks
    `auth.uid()`. In a SECURITY DEFINER function, `auth.uid()` still reads the JWT
    from the request context -- it does NOT become NULL. So the trigger blocks the
    role change with "The account type cannot be changed".
  
2. Fix
  - Before updating, `assign_initial_role` sets a session-local GUC variable
    `app.bypass_role_guard` to `'true'`.
  - `enforce_profile_update_guards` checks this variable: if set to `'true'`, it
    allows the role change.
  - The variable is transaction-scoped (`SET LOCAL`) so it only lasts for the
    current statement and cannot leak to other requests.

3. Modified Functions
  - `assign_initial_role(text)` — adds `SET LOCAL app.bypass_role_guard = 'true'`
    before the UPDATE.
  - `enforce_profile_update_guards()` — adds a check for the session variable.

4. Security
  - The `app.bypass_role_guard` variable can only be set inside a SECURITY DEFINER
    function because regular client calls run as `authenticated` role which cannot
    set custom GUC variables that affect trigger behavior inside the same transaction.
  - Even if a client tried `SET LOCAL app.bypass_role_guard = 'true'`, it would only
    apply within their transaction and the RLS + trigger still validates other conditions
    (account age < 5 minutes, role is still default).
*/

-- Update the trigger function to respect the bypass variable
CREATE OR REPLACE FUNCTION public.enforce_profile_update_guards()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
BEGIN
  -- Allow service-role (auth.uid() IS NULL) or internal function bypass
  IF auth.uid() IS NULL THEN
    RETURN NEW;
  END IF;

  -- Check if an internal function set the bypass flag
  IF current_setting('app.bypass_role_guard', true) = 'true' THEN
    RETURN NEW;
  END IF;

  IF NEW.role IS DISTINCT FROM OLD.role THEN
    RAISE EXCEPTION 'The account type cannot be changed'
      USING ERRCODE = 'check_violation';
  END IF;

  IF NEW.profile_code IS DISTINCT FROM OLD.profile_code THEN
    RAISE EXCEPTION 'The profile code cannot be changed'
      USING ERRCODE = 'check_violation';
  END IF;

  RETURN NEW;
END;
$$;

-- Update the assign_initial_role function to set the bypass before UPDATE
CREATE OR REPLACE FUNCTION public.assign_initial_role(desired_role text)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  caller_id uuid := auth.uid();
  current_role text;
  created_at_ts timestamptz;
BEGIN
  IF caller_id IS NULL THEN
    RAISE EXCEPTION 'Not authenticated' USING ERRCODE = 'insufficient_privilege';
  END IF;

  IF desired_role NOT IN ('center', 'doctor', 'lab') THEN
    RAISE EXCEPTION 'Invalid role' USING ERRCODE = 'check_violation';
  END IF;

  SELECT p.role, u.created_at
  INTO current_role, created_at_ts
  FROM public.profiles p
  JOIN auth.users u ON u.id = p.id
  WHERE p.id = caller_id;

  IF current_role IS NULL THEN
    RAISE EXCEPTION 'Profile not found' USING ERRCODE = 'no_data_found';
  END IF;

  IF current_role <> 'doctor' THEN
    RAISE EXCEPTION 'Role already assigned' USING ERRCODE = 'check_violation';
  END IF;

  IF created_at_ts < now() - interval '5 minutes' THEN
    RAISE EXCEPTION 'Assignment window expired' USING ERRCODE = 'check_violation';
  END IF;

  -- Set bypass flag so the trigger allows this role change
  PERFORM set_config('app.bypass_role_guard', 'true', true);

  UPDATE public.profiles SET role = desired_role WHERE id = caller_id;
END;
$$;

REVOKE ALL ON FUNCTION public.assign_initial_role(text) FROM PUBLIC;
REVOKE ALL ON FUNCTION public.assign_initial_role(text) FROM anon;
GRANT EXECUTE ON FUNCTION public.assign_initial_role(text) TO authenticated;
