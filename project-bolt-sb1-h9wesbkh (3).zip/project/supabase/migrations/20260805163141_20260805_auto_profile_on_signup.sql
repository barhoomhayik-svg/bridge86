/*
# Auto-create profile on signup (email + OAuth)

1. New Function
- `handle_new_user()` — SECURITY DEFINER trigger function that fires AFTER INSERT on `auth.users`.
  Reads `raw_user_meta_data` (populated by `supabase.auth.signUp({ options: { data } })` and by OAuth providers) and inserts a matching row into `public.profiles`.
  Falls back to sensible defaults when metadata is missing (role → 'doctor', name → email local-part).
  Uses `ON CONFLICT (id) DO NOTHING` so it is safe alongside any existing manual profile insert.

2. Trigger
- `on_auth_user_created` AFTER INSERT on `auth.users` — calls `handle_new_user()`.

3. Why
- Email/password signups already create a profile manually in the frontend. This trigger covers OAuth sign-ins (Google, Apple) where no frontend insert happens — the user lands back in the app with an auth.users row but no profile row, which would break the app.
- The trigger is idempotent (`ON CONFLICT DO NOTHING`) so email signups that also pass metadata won't conflict.

4. Security
- `SECURITY DEFINER` so it can write to `public.profiles` during the auth insert.
- Search path fixed to `public` to prevent schema-spoofing.
*/

CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.profiles (id, role, name, phone, city, avatar_url)
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data->>'role', 'doctor'),
    COALESCE(
      NEW.raw_user_meta_data->>'full_name',
      NEW.raw_user_meta_data->>'name',
      split_part(NEW.email, '@', 1)
    ),
    NEW.raw_user_meta_data->>'phone',
    NEW.raw_user_meta_data->>'city',
    NEW.raw_user_meta_data->>'avatar_url'
  )
  ON CONFLICT (id) DO NOTHING;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();
