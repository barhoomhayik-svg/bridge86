-- Add 'try_in' to the orders.status CHECK constraint
ALTER TABLE orders DROP CONSTRAINT IF EXISTS orders_status_check;
ALTER TABLE orders ADD CONSTRAINT orders_status_check
  CHECK (status IN ('pending', 'accepted', 'in_progress', 'completed', 'try_in', 'delivering', 'delivered', 'rejected', 'cancelled', 'redo'));

-- Update the notification trigger to handle the try_in status
CREATE OR REPLACE FUNCTION fn_notify_order_status()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER AS $$
BEGIN
  IF OLD.status IS DISTINCT FROM NEW.status THEN
    IF NEW.status = 'accepted' THEN
      INSERT INTO notifications (user_id, type, title, body, related_id)
      VALUES (NEW.from_id, 'order_accepted', 'Order Accepted – ' || NEW.order_number,
        'Your order has been accepted by the lab.', NEW.id);
    ELSIF NEW.status = 'rejected' THEN
      INSERT INTO notifications (user_id, type, title, body, related_id)
      VALUES (NEW.from_id, 'order_rejected', 'Order Rejected – ' || NEW.order_number,
        'Your order has been rejected by the lab.', NEW.id);
    ELSIF NEW.status = 'in_progress' THEN
      INSERT INTO notifications (user_id, type, title, body, related_id)
      VALUES (NEW.from_id, 'order_update', 'Order In Progress – ' || NEW.order_number,
        'The lab has started working on your order.', NEW.id);
    ELSIF NEW.status = 'completed' THEN
      INSERT INTO notifications (user_id, type, title, body, related_id)
      VALUES (NEW.from_id, 'order_completed', 'Order Completed – ' || NEW.order_number,
        'Your order is ready for delivery.', NEW.id);
    ELSIF NEW.status = 'try_in' THEN
      INSERT INTO notifications (user_id, type, title, body, related_id)
      VALUES (NEW.from_id, 'order_try_in', 'Try In Ready – ' || NEW.order_number,
        'Your case is ready for try-in before final fit.', NEW.id);
    ELSIF NEW.status = 'delivering' THEN
      INSERT INTO notifications (user_id, type, title, body, related_id)
      VALUES (NEW.from_id, 'order_delivering', 'Out for Delivery – ' || NEW.order_number,
        'Your case is on its way to you.', NEW.id);
    ELSIF NEW.status = 'cancelled' THEN
      INSERT INTO notifications (user_id, type, title, body, related_id)
      VALUES (NEW.from_id, 'order_cancelled', 'Order Cancelled – ' || NEW.order_number,
        'This order has been cancelled.', NEW.id);
    ELSIF NEW.status = 'redo' THEN
      INSERT INTO notifications (user_id, type, title, body, related_id)
      VALUES (NEW.from_id, 'order_redo', 'Redo Requested – ' || NEW.order_number,
        'A redo has been requested for this order.', NEW.id);
    ELSE
      INSERT INTO notifications (user_id, type, title, body, related_id)
      VALUES (NEW.from_id, 'order_update', 'Order Status Changed',
        'Order ' || NEW.order_number || ' is now ' || REPLACE(NEW.status, '_', ' '), NEW.id);
    END IF;
  END IF;
  RETURN NEW;
END;
$$;
