-- Enforce a 30-day window from delivered_at for a doctor to request a redo.
-- The status transition from 'delivered' to 'redo' is only permitted while
-- (now() - delivered_at) is less than 30 days.

CREATE OR REPLACE FUNCTION enforce_redo_window()
RETURNS TRIGGER AS $$
BEGIN
  IF NEW.status = 'redo'
     AND OLD.status = 'delivered'
     AND OLD.delivered_at IS NOT NULL
     AND (now() - OLD.delivered_at) > INTERVAL '30 days' THEN
    RAISE EXCEPTION 'Redo not allowed: the 30-day window since delivery has passed for order %', OLD.id
      USING ERRCODE = 'check_violation';
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_enforce_redo_window ON orders;
CREATE TRIGGER trg_enforce_redo_window
  BEFORE UPDATE OF status ON orders
  FOR EACH ROW
  EXECUTE FUNCTION enforce_redo_window();
