/*
  # Stop a user deleting and re-creating their own profile row

  1. Why
     - `enforce_profile_update_guards()` makes `role` and `profile_code` immutable
       on UPDATE, but `profiles_delete` and `profiles_insert` let a signed-in user
       delete their own profile row through the data API and insert it again with a
       different account type, defeating that control and cascading deletes across
       their data.

  2. Change
     - Drop the client-facing DELETE and INSERT policies on `public.profiles`.

  3. Security
     - Sign-up is unaffected: `handle_new_user()` is SECURITY DEFINER and does not
       consult row level security when it creates the profile row.
     - No application code inserts or deletes a profile row, so no feature relies
       on these policies.
     - Reads and updates of one's own profile are unchanged.
*/

DROP POLICY IF EXISTS "profiles_delete" ON public.profiles;
DROP POLICY IF EXISTS "profiles_insert" ON public.profiles;
