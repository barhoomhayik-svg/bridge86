/*
# Fix: order_services INSERT/UPDATE/DELETE fails when doctor sends from center

## Problem
The `order_services` INSERT/UPDATE/DELETE policies only allow
`o.from_id = auth.uid() OR o.lab_id = auth.uid()`. When a doctor sends
an order from a center, `from_id` is the center's ID, not the doctor's.
The order itself inserts fine (fixed in an earlier migration), but the
`order_services` rows are rejected by RLS, causing the entire order
creation to fail.

## Fix
Extend the ownership check to also allow doctor-members of the center
that owns the order (via `center_members`), matching the pattern used
in the `orders_insert` fix.
*/

-- INSERT
DROP POLICY IF EXISTS "insert_order_services" ON order_services;
CREATE POLICY "insert_order_services" ON order_services FOR INSERT
  TO authenticated WITH CHECK (
    EXISTS (
      SELECT 1 FROM orders o
      WHERE o.id = order_services.order_id
      AND (
        o.from_id = auth.uid()
        OR o.lab_id = auth.uid()
        OR EXISTS (
          SELECT 1 FROM center_members cm
          WHERE cm.center_id = o.from_id AND cm.doctor_id = auth.uid()
        )
      )
    )
  );

-- UPDATE
DROP POLICY IF EXISTS "update_order_services" ON order_services;
CREATE POLICY "update_order_services" ON order_services FOR UPDATE
  TO authenticated USING (
    EXISTS (
      SELECT 1 FROM orders o
      WHERE o.id = order_services.order_id
      AND (
        o.from_id = auth.uid()
        OR o.lab_id = auth.uid()
        OR EXISTS (
          SELECT 1 FROM center_members cm
          WHERE cm.center_id = o.from_id AND cm.doctor_id = auth.uid()
        )
      )
    )
  ) WITH CHECK (
    EXISTS (
      SELECT 1 FROM orders o
      WHERE o.id = order_services.order_id
      AND (
        o.from_id = auth.uid()
        OR o.lab_id = auth.uid()
        OR EXISTS (
          SELECT 1 FROM center_members cm
          WHERE cm.center_id = o.from_id AND cm.doctor_id = auth.uid()
        )
      )
    )
  );

-- DELETE
DROP POLICY IF EXISTS "delete_order_services" ON order_services;
CREATE POLICY "delete_order_services" ON order_services FOR DELETE
  TO authenticated USING (
    EXISTS (
      SELECT 1 FROM orders o
      WHERE o.id = order_services.order_id
      AND (
        o.from_id = auth.uid()
        OR o.lab_id = auth.uid()
        OR EXISTS (
          SELECT 1 FROM center_members cm
          WHERE cm.center_id = o.from_id AND cm.doctor_id = auth.uid()
        )
      )
    )
  );
