/*
# Add attachments to order comments

1. Modified Tables
- `order_comments`
  - `attachment_url`  (text, nullable) — public storage URL of the attached file
  - `attachment_name` (text, nullable) — original file name
  - `attachment_size` (bigint, nullable) — file size in bytes
  - `attachment_mime` (text, nullable) — MIME type

2. Notes
- The existing `body` column has a CHECK constraint requiring non-empty trimmed text.
  When a comment is attachment-only (no text), we still store a short placeholder body
  ("📎 Attachment") so the constraint is satisfied. The frontend renders the attachment
  and hides the placeholder body when an attachment is present.
- RLS policies already on `order_comments` cover the new columns automatically — no
  policy changes needed.
*/

ALTER TABLE order_comments
  ADD COLUMN IF NOT EXISTS attachment_url  text,
  ADD COLUMN IF NOT EXISTS attachment_name text,
  ADD COLUMN IF NOT EXISTS attachment_size bigint,
  ADD COLUMN IF NOT EXISTS attachment_mime text;
