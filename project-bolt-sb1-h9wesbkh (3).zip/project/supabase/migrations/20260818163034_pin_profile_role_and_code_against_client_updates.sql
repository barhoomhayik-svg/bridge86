/*
  # Pin account type and profile code against client updates

  1. Security
    - `profiles_update` is a row policy, so a signed-in user could update every
      column of their own row, including `role`, which four other policies and the
      driver-creation function key on: setting it to 'lab' grants lab powers.
    - An earlier column-level REVOKE could not take effect because the table-level
      UPDATE grant still implies the column, so the rule is enforced here instead:
      client-authenticated updates cannot change `role` or `profile_code`.
      Service-role calls (edge functions, admin tasks) are unaffected.
*/

CREATE OR REPLACE FUNCTION public.enforce_profile_update_guards()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
BEGIN
  IF auth.uid() IS NULL THEN
    RETURN NEW;
  END IF;

  IF NEW.role IS DISTINCT FROM OLD.role THEN
    RAISE EXCEPTION 'The account type cannot be changed'
      USING ERRCODE = 'check_violation';
  END IF;

  IF NEW.profile_code IS DISTINCT FROM OLD.profile_code THEN
    RAISE EXCEPTION 'The profile code cannot be changed'
      USING ERRCODE = 'check_violation';
  END IF;

  RETURN NEW;
END;
$$;

REVOKE ALL ON FUNCTION public.enforce_profile_update_guards() FROM PUBLIC;
REVOKE ALL ON FUNCTION public.enforce_profile_update_guards() FROM anon;
REVOKE ALL ON FUNCTION public.enforce_profile_update_guards() FROM authenticated;

DROP TRIGGER IF EXISTS trg_enforce_profile_update_guards ON public.profiles;

CREATE TRIGGER trg_enforce_profile_update_guards
  BEFORE UPDATE ON public.profiles
  FOR EACH ROW
  EXECUTE FUNCTION public.enforce_profile_update_guards();
