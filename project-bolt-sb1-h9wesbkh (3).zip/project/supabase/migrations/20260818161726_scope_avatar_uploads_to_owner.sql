/*
  # Restrict logo and cover uploads to the owner's own files

  1. Security
    - `avatars_insert` and `avatars_update` checked only `bucket_id`, so any
      signed-in user could upsert over `logos/<other user id>.png` and replace
      another business's logo or cover image.
    - Both policies now require the object path to belong to the caller, matching
      the paths the app writes: `logos/<uid>.<ext>` and `covers/<uid>-<ts>.<ext>`.
    - Public read of this bucket is intentional: logos and covers are shown on
      public lab profiles and printed letterheads.
*/

DROP POLICY IF EXISTS avatars_insert ON storage.objects;
DROP POLICY IF EXISTS avatars_update ON storage.objects;

CREATE POLICY avatars_insert ON storage.objects
  FOR INSERT TO authenticated
  WITH CHECK (
    bucket_id = 'avatars'
    AND (
      name LIKE ('logos/' || auth.uid()::text || '.%')
      OR name LIKE ('covers/' || auth.uid()::text || '-%')
      OR name LIKE (auth.uid()::text || '/%')
    )
  );

CREATE POLICY avatars_update ON storage.objects
  FOR UPDATE TO authenticated
  USING (
    bucket_id = 'avatars'
    AND (
      name LIKE ('logos/' || auth.uid()::text || '.%')
      OR name LIKE ('covers/' || auth.uid()::text || '-%')
      OR name LIKE (auth.uid()::text || '/%')
    )
  )
  WITH CHECK (
    bucket_id = 'avatars'
    AND (
      name LIKE ('logos/' || auth.uid()::text || '.%')
      OR name LIKE ('covers/' || auth.uid()::text || '-%')
      OR name LIKE (auth.uid()::text || '/%')
    )
  );
