import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.dentallink.app',
  appName: 'Bridge',
  webDir: 'dist',
  server: {
    androidScheme: 'https',
  },
  ios: {
    contentInset: 'automatic',
    backgroundColor: '#ffffff',
    // Use the full screen including safe areas; our CSS handles the insets
    scrollEnabled: false,
  },
  android: {
    backgroundColor: '#ffffff',
  },
  plugins: {
    SplashScreen: {
      launchShowDuration: 1500,
      backgroundColor: '#0d9488',
      androidSplashResourceName: 'splash',
      showSpinner: false,
      iosFadeOutDuration: 300,
    },
    StatusBar: {
      style: 'DEFAULT',
      backgroundColor: '#0d9488',
      // iOS: overlays the webview; our safe-area CSS handles padding
      overlaysWebView: true,
    },
    Keyboard: {
      resize: 'native',
      style: 'LIGHT',
      resizeOnFullScreen: true,
    },
  },
};

export default config;
