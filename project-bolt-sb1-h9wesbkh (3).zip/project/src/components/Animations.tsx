import React, { useState, useEffect, useRef, useCallback } from 'react';

/* ── Reveal: scroll-triggered fade + slide ── */

interface RevealProps {
  children: React.ReactNode;
  className?: string;
  delay?: number;
  direction?: 'up' | 'down' | 'left' | 'right';
  distance?: number;
  once?: boolean;
}

export function Reveal({
  children,
  className = '',
  delay = 0,
  direction = 'up',
  distance = 24,
  once = true,
}: RevealProps) {
  const ref = useRef<HTMLDivElement>(null);
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const obs = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setVisible(true);
          if (once) obs.disconnect();
        } else if (!once) {
          setVisible(false);
        }
      },
      { threshold: 0.12 },
    );
    obs.observe(el);
    return () => obs.disconnect();
  }, [once]);

  const transform = {
    up: `translateY(${distance}px)`,
    down: `translateY(-${distance}px)`,
    left: `translateX(${distance}px)`,
    right: `translateX(-${distance}px)`,
  }[direction];

  return (
    <div
      ref={ref}
      className={className}
      style={{
        opacity: visible ? 1 : 0,
        transform: visible ? 'none' : transform,
        transition: `opacity 600ms cubic-bezier(0.16, 1, 0.3, 1) ${delay}ms, transform 600ms cubic-bezier(0.16, 1, 0.3, 1) ${delay}ms`,
      }}
    >
      {children}
    </div>
  );
}

/* ── Stagger: sequential reveal for child items ── */

interface StaggerProps {
  children: React.ReactNode;
  className?: string;
  staggerDelay?: number;
  baseDelay?: number;
}

export function Stagger({ children, className = '', staggerDelay = 70, baseDelay = 0 }: StaggerProps) {
  const items = React.Children.toArray(children);
  return (
    <div className={className}>
      {items.map((child, i) => (
        <Reveal key={i} delay={baseDelay + i * staggerDelay}>
          {child}
        </Reveal>
      ))}
    </div>
  );
}

/* ── CountUp: animated number tween ── */

interface CountUpProps {
  end: number;
  duration?: number;
  prefix?: string;
  suffix?: string;
  className?: string;
  decimals?: number;
}

export function CountUp({ end, duration = 1200, prefix = '', suffix = '', className = '', decimals = 0 }: CountUpProps) {
  const ref = useRef<HTMLSpanElement>(null);
  const [value, setValue] = useState(0);
  const [started, setStarted] = useState(false);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const obs = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting) { setStarted(true); obs.disconnect(); } },
      { threshold: 0.3 },
    );
    obs.observe(el);
    return () => obs.disconnect();
  }, []);

  useEffect(() => {
    if (!started) return;
    const startTime = performance.now();
    let raf: number;

    const tick = (now: number) => {
      const elapsed = now - startTime;
      const progress = Math.min(elapsed / duration, 1);
      const eased = 1 - Math.pow(1 - progress, 3);
      setValue(eased * end);
      if (progress < 1) raf = requestAnimationFrame(tick);
    };

    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [started, end, duration]);

  return (
    <span ref={ref} className={className}>
      {prefix}{value.toFixed(decimals)}{suffix}
    </span>
  );
}

/* ── LiftCard: perspective tilt toward cursor on hover ── */

interface LiftCardProps {
  children: React.ReactNode;
  className?: string;
  tiltAmount?: number;
}

export function LiftCard({ children, className = '', tiltAmount = 6 }: LiftCardProps) {
  const ref = useRef<HTMLDivElement>(null);
  const [style, setStyle] = useState<React.CSSProperties>({});

  const handleMove = useCallback((e: React.MouseEvent<HTMLDivElement>) => {
    const el = ref.current;
    if (!el) return;
    const rect = el.getBoundingClientRect();
    const x = (e.clientX - rect.left) / rect.width - 0.5;
    const y = (e.clientY - rect.top) / rect.height - 0.5;
    setStyle({
      transform: `perspective(600px) rotateY(${x * tiltAmount}deg) rotateX(${-y * tiltAmount}deg) translateY(-2px)`,
      transition: 'transform 150ms ease-out',
    });
  }, [tiltAmount]);

  const handleLeave = useCallback(() => {
    setStyle({
      transform: 'perspective(600px) rotateY(0deg) rotateX(0deg) translateY(0)',
      transition: 'transform 400ms cubic-bezier(0.16, 1, 0.3, 1)',
    });
  }, []);

  return (
    <div
      ref={ref}
      className={className}
      style={style}
      onMouseMove={handleMove}
      onMouseLeave={handleLeave}
    >
      {children}
    </div>
  );
}

/* ── CandyButton: glossy 3D button with gradient, lip shadow, rim highlight ── */

interface CandyButtonProps {
  children: React.ReactNode;
  onClick?: () => void;
  disabled?: boolean;
  className?: string;
  color?: 'primary' | 'dark' | 'white';
  size?: 'sm' | 'md' | 'lg';
  type?: 'button' | 'submit';
}

const candyColors = {
  primary: {
    body: 'from-primary-500 to-primary-600',
    lip: 'bg-primary-700',
    text: 'text-white',
    rim: 'bg-white/20',
    hover: 'hover:from-primary-400 hover:to-primary-500',
  },
  dark: {
    body: 'from-neutral-800 to-neutral-900',
    lip: 'bg-neutral-950',
    text: 'text-white',
    rim: 'bg-white/10',
    hover: 'hover:from-neutral-700 hover:to-neutral-800',
  },
  white: {
    body: 'from-white to-neutral-50',
    lip: 'bg-neutral-200',
    text: 'text-neutral-900',
    rim: 'bg-white/60',
    hover: 'hover:from-white hover:to-white',
  },
};

const candySizes = {
  sm: 'px-4 py-2 text-sm',
  md: 'px-6 py-3 text-sm',
  lg: 'px-8 py-3.5 text-base',
};

export function CandyButton({
  children,
  onClick,
  disabled = false,
  className = '',
  color = 'primary',
  size = 'md',
  type = 'button',
}: CandyButtonProps) {
  const c = candyColors[color];

  return (
    <button
      type={type}
      onClick={onClick}
      disabled={disabled}
      className={`
        no-lift relative inline-flex items-center justify-center gap-2 font-bold rounded-xl
        transition-all duration-200 active:translate-y-0.5 active:shadow-none
        disabled:opacity-60 disabled:pointer-events-none
        ${candySizes[size]} ${c.text} ${className}
      `}
      style={{ WebkitTapHighlightColor: 'transparent' }}
    >
      {/* Lip shadow */}
      <span className={`absolute inset-x-0 bottom-0 h-1.5 rounded-b-xl ${c.lip}`} />
      {/* Gradient body */}
      <span className={`absolute inset-0 rounded-xl bg-gradient-to-b ${c.body} ${c.hover} transition-colors`} />
      {/* Rim highlight */}
      <span className={`absolute inset-x-1 top-px h-px rounded-full ${c.rim}`} />
      {/* Content */}
      <span className="relative z-10 flex items-center gap-2">{children}</span>
    </button>
  );
}
