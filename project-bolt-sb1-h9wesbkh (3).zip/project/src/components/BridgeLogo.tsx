import { FlaskConical, Stethoscope } from 'lucide-react';

interface BridgeLogoProps {
  className?: string;
  iconClassName?: string;
  compact?: boolean;
}

export default function BridgeLogo({ className = 'w-10 h-10', iconClassName = 'w-4 h-4', compact = false }: BridgeLogoProps) {
  return (
    <div className={`relative flex items-center justify-center ${className}`} aria-label="Bridge">
      <div className="absolute inset-x-[18%] top-[31%] h-[35%] rounded-t-full border-t-2 border-l-2 border-r-2 border-current opacity-80" />
      <div className="absolute inset-x-[15%] bottom-[22%] h-0.5 rounded-full bg-current opacity-80" />
      <div className={`relative z-10 flex items-center justify-between ${compact ? 'w-[78%]' : 'w-[74%]'}`}>
        <Stethoscope className={iconClassName} strokeWidth={2.2} />
        <FlaskConical className={iconClassName} strokeWidth={2.2} />
      </div>
    </div>
  );
}
