import React, { useRef, useEffect, useState, useCallback } from 'react';
import { Loader2, RotateCw } from 'lucide-react';

interface OtpInputProps {
  length?: number;
  onComplete: (code: string) => void;
  onResend: () => Promise<void>;
  loading?: boolean;
  error?: string;
  email: string;
  title: string;
  subtitle?: string;
}

export default function OtpInput({
  length = 6,
  onComplete,
  onResend,
  loading = false,
  error,
  email,
  title,
  subtitle,
}: OtpInputProps) {
  const [digits, setDigits] = useState<string[]>(Array(length).fill(''));
  const [cooldown, setCooldown] = useState(60);
  const [resending, setResending] = useState(false);
  const inputsRef = useRef<(HTMLInputElement | null)[]>([]);

  useEffect(() => {
    inputsRef.current[0]?.focus();
  }, []);

  useEffect(() => {
    if (cooldown <= 0) return;
    const t = setTimeout(() => setCooldown(c => c - 1), 1000);
    return () => clearTimeout(t);
  }, [cooldown]);

  const submitCode = useCallback(
    (d: string[]) => {
      const code = d.join('');
      if (code.length === length) onComplete(code);
    },
    [length, onComplete],
  );

  const handleChange = (idx: number, value: string) => {
    if (loading) return;
    const char = value.replace(/\D/g, '').slice(-1);
    const next = [...digits];
    next[idx] = char;
    setDigits(next);

    if (char && idx < length - 1) {
      inputsRef.current[idx + 1]?.focus();
    }
    if (next.every(d => d !== '')) submitCode(next);
  };

  const handleKeyDown = (idx: number, e: React.KeyboardEvent) => {
    if (e.key === 'Backspace' && !digits[idx] && idx > 0) {
      const next = [...digits];
      next[idx - 1] = '';
      setDigits(next);
      inputsRef.current[idx - 1]?.focus();
    }
  };

  const handlePaste = (e: React.ClipboardEvent) => {
    e.preventDefault();
    const text = e.clipboardData.getData('text').replace(/\D/g, '').slice(0, length);
    if (!text) return;
    const next = [...digits];
    for (let i = 0; i < text.length; i++) next[i] = text[i];
    setDigits(next);
    const focusIdx = Math.min(text.length, length - 1);
    inputsRef.current[focusIdx]?.focus();
    if (next.every(d => d !== '')) submitCode(next);
  };

  const handleResend = async () => {
    if (cooldown > 0 || resending) return;
    setResending(true);
    try {
      await onResend();
      setCooldown(60);
      setDigits(Array(length).fill(''));
      inputsRef.current[0]?.focus();
    } finally {
      setResending(false);
    }
  };

  return (
    <div className="text-center" style={{ animation: 'fadeInDown 0.4s ease' }}>
      <div className="w-16 h-16 bg-primary-50 rounded-2xl flex items-center justify-center mx-auto mb-4">
        <svg className="w-7 h-7 text-primary-500" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
          <path strokeLinecap="round" strokeLinejoin="round" d="M16.5 10.5V6.75a4.5 4.5 0 1 0-9 0v3.75m-.75 11.25h10.5a2.25 2.25 0 0 0 2.25-2.25v-6.75a2.25 2.25 0 0 0-2.25-2.25H6.75a2.25 2.25 0 0 0-2.25 2.25v6.75a2.25 2.25 0 0 0 2.25 2.25Z" />
        </svg>
      </div>

      <h3 className="font-display text-lg font-bold text-neutral-800 mb-1">{title}</h3>
      <p className="text-sm text-neutral-500 mb-1">
        {subtitle ?? 'Enter the 6-digit code we sent to'}
      </p>
      <p className="text-sm font-semibold text-neutral-800 mb-6 break-all">{email}</p>

      <div className="flex justify-center gap-2.5 mb-4" onPaste={handlePaste}>
        {digits.map((d, i) => (
          <input
            key={i}
            ref={el => { inputsRef.current[i] = el; }}
            type="text"
            inputMode="numeric"
            maxLength={1}
            value={d}
            onChange={e => handleChange(i, e.target.value)}
            onKeyDown={e => handleKeyDown(i, e)}
            disabled={loading}
            className={`w-11 h-13 text-center text-xl font-bold rounded-xl border-2 transition-all duration-150 focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-primary-500 disabled:bg-neutral-50 disabled:text-neutral-400 ${
              error ? 'border-red-300 bg-red-50/50' : d ? 'border-primary-400 bg-primary-50/50' : 'border-neutral-300'
            }`}
            autoComplete="one-time-code"
          />
        ))}
      </div>

      {loading && (
        <div className="flex items-center justify-center gap-2 text-sm text-primary-600 mb-3">
          <Loader2 className="w-4 h-4 animate-spin" />
          Verifying...
        </div>
      )}

      {error && (
        <div className="bg-red-50 border border-red-200/80 text-red-600 text-sm rounded-xl px-3.5 py-2.5 mb-3 text-left">
          {error}
        </div>
      )}

      <div className="flex items-center justify-center gap-1.5 text-sm">
        {cooldown > 0 ? (
          <span className="text-neutral-400">
            Resend code in <span className="font-semibold text-neutral-600">{cooldown}s</span>
          </span>
        ) : (
          <button
            onClick={handleResend}
            disabled={resending}
            className="flex items-center gap-1.5 text-primary-600 hover:text-primary-700 font-semibold transition-colors disabled:opacity-50"
          >
            {resending ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <RotateCw className="w-3.5 h-3.5" />}
            Resend code
          </button>
        )}
      </div>
    </div>
  );
}
