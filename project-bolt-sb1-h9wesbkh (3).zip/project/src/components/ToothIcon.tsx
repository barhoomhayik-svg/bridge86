interface ToothIconProps {
  className?: string;
  variant?: 'default' | 'check' | 'spin' | 'sparkle' | 'x' | 'slash' | 'redo' | 'half';
}

export function ToothIcon({ className = 'w-4 h-4', variant = 'default' }: ToothIconProps) {
  return (
    <svg
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.8"
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
    >
      {/* Tooth base shape */}
      <path d="M9 3C7 3 5 4.5 5 7c0 1.5.5 3 1 5 .8 3.2 1.2 6 2 8 .3.8.8 1 1.5 1s1-.5 1.5-1.5c.4-1 .7-2 1-2s.6 1 1 2c.5 1 .8 1.5 1.5 1.5s1.2-.2 1.5-1C16.8 18 17.2 15.2 18 12c.5-2 1-3.5 1-5 0-2.5-2-4-4-4-1 0-2 .5-2.5 1-.5-.5-1.5-1-3.5-1z" />
      {/* Variant overlays */}
      {variant === 'check' && (
        <path d="M9 11l2 2 4-4" strokeWidth="2" />
      )}
      {variant === 'spin' && (
        <path d="M12 8v4l2 2" strokeWidth="2" />
      )}
      {variant === 'sparkle' && (
        <>
          <path d="M15 5l.5-1.5" strokeWidth="1.5" />
          <path d="M17 7l1.5-.5" strokeWidth="1.5" />
        </>
      )}
      {variant === 'x' && (
        <>
          <line x1="9.5" y1="9.5" x2="14.5" y2="14.5" strokeWidth="2" />
          <line x1="14.5" y1="9.5" x2="9.5" y2="14.5" strokeWidth="2" />
        </>
      )}
      {variant === 'slash' && (
        <line x1="8" y1="15" x2="16" y2="9" strokeWidth="2" />
      )}
      {variant === 'redo' && (
        <path d="M15 7c-1-.8-2-1-3-1" strokeWidth="1.8" />
      )}
      {variant === 'half' && (
        <>
          <path
            d="M12 4.2C11.5 3.7 10.5 3.2 9 3.2 7 3.2 5 4.7 5 7.2c0 1.5.5 3 1 5 .8 3.2 1.2 6 2 8 .3.8.8 1 1.5 1s1-.5 1.5-1.5c.4-1 .7-2 1-2V4.2z"
            fill="currentColor"
            stroke="none"
            fillOpacity="0.85"
          />
          <line x1="12" y1="4" x2="12" y2="19.5" strokeWidth="1.8" />
        </>
      )}
    </svg>
  );
}
