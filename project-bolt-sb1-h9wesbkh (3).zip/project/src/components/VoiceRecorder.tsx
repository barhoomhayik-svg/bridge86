import { useState, useRef, useEffect, useCallback } from 'react';
import { Mic, Square, X, Play, Pause } from 'lucide-react';

const MAX_DURATION = 120;

function fmt(s: number) {
  const m = Math.floor(s / 60);
  const sec = Math.floor(s % 60);
  return `${m}:${sec.toString().padStart(2, '0')}`;
}

interface Props {
  onRecorded: (file: File) => void;
  disabled?: boolean;
}

export default function VoiceRecorder({ onRecorded, disabled }: Props) {
  const [state, setState] = useState<'idle' | 'recording' | 'preview'>('idle');
  const [elapsed, setElapsed] = useState(0);
  const [blob, setBlob] = useState<Blob | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [playing, setPlaying] = useState(false);
  const [micError, setMicError] = useState(false);

  const recorderRef = useRef<MediaRecorder | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const chunksRef = useRef<Blob[]>([]);

  const supportsRecording = typeof navigator !== 'undefined' && !!navigator.mediaDevices?.getUserMedia;

  const cleanup = useCallback(() => {
    if (timerRef.current) { clearInterval(timerRef.current); timerRef.current = null; }
    if (recorderRef.current?.state === 'recording') recorderRef.current.stop();
    streamRef.current?.getTracks().forEach(t => t.stop());
    streamRef.current = null;
    recorderRef.current = null;
  }, []);

  useEffect(() => () => {
    cleanup();
    if (previewUrl) URL.revokeObjectURL(previewUrl);
  }, [cleanup, previewUrl]);

  const startRecording = async () => {
    setMicError(false);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      streamRef.current = stream;

      const mimeType = MediaRecorder.isTypeSupported('audio/webm;codecs=opus')
        ? 'audio/webm;codecs=opus'
        : MediaRecorder.isTypeSupported('audio/mp4')
          ? 'audio/mp4'
          : '';

      const recorder = new MediaRecorder(stream, mimeType ? { mimeType } : undefined);
      recorderRef.current = recorder;
      chunksRef.current = [];

      recorder.ondataavailable = e => { if (e.data.size > 0) chunksRef.current.push(e.data); };
      recorder.onstop = () => {
        const recorded = new Blob(chunksRef.current, { type: recorder.mimeType || 'audio/webm' });
        setBlob(recorded);
        const url = URL.createObjectURL(recorded);
        if (previewUrl) URL.revokeObjectURL(previewUrl);
        setPreviewUrl(url);
        setState('preview');
        streamRef.current?.getTracks().forEach(t => t.stop());
      };

      recorder.start(250);
      setElapsed(0);
      setState('recording');
      timerRef.current = setInterval(() => {
        setElapsed(prev => {
          if (prev + 1 >= MAX_DURATION) {
            recorderRef.current?.stop();
            if (timerRef.current) clearInterval(timerRef.current);
            return MAX_DURATION;
          }
          return prev + 1;
        });
      }, 1000);
    } catch {
      setMicError(true);
    }
  };

  const stopRecording = () => {
    if (timerRef.current) { clearInterval(timerRef.current); timerRef.current = null; }
    recorderRef.current?.stop();
  };

  const cancelPreview = () => {
    if (previewUrl) URL.revokeObjectURL(previewUrl);
    setPreviewUrl(null);
    setBlob(null);
    setPlaying(false);
    setState('idle');
    setElapsed(0);
  };

  const send = () => {
    if (!blob) return;
    const ext = blob.type.includes('mp4') ? 'mp4' : blob.type.includes('ogg') ? 'ogg' : 'webm';
    const file = new File([blob], `voice-${Date.now()}.${ext}`, { type: blob.type });
    onRecorded(file);
    cancelPreview();
  };

  const togglePlay = () => {
    if (!audioRef.current || !previewUrl) return;
    if (playing) { audioRef.current.pause(); }
    else { audioRef.current.currentTime = 0; audioRef.current.play(); }
    setPlaying(!playing);
  };

  if (!supportsRecording) return null;

  if (state === 'recording') {
    return (
      <div className="flex items-center gap-2 w-full">
        <div className="flex items-center gap-2 flex-1 px-3 py-2 bg-red-50 border border-red-200 rounded-xl">
          <span className="w-2.5 h-2.5 rounded-full bg-red-500 animate-pulse flex-shrink-0" />
          <span className="text-sm font-semibold text-red-700 tabular-nums">{fmt(elapsed)}</span>
          <div className="flex-1 flex items-center gap-0.5 h-4 overflow-hidden">
            {Array.from({ length: 24 }, (_, i) => (
              <span key={i} className="w-1 bg-red-300 rounded-full animate-pulse"
                style={{ height: `${Math.max(20, Math.random() * 100)}%`, animationDelay: `${i * 80}ms` }} />
            ))}
          </div>
        </div>
        <button onClick={stopRecording}
          className="w-9 h-9 flex items-center justify-center bg-red-600 hover:bg-red-700 text-white rounded-xl transition-colors flex-shrink-0"
          title="Stop recording"
        >
          <Square className="w-4 h-4" />
        </button>
      </div>
    );
  }

  if (state === 'preview' && previewUrl) {
    return (
      <div className="flex items-center gap-2 w-full">
        <audio ref={audioRef} src={previewUrl} onEnded={() => setPlaying(false)} className="hidden" />
        <div className="flex items-center gap-2 flex-1 px-3 py-2 bg-primary-50 border border-primary-200 rounded-xl">
          <button onClick={togglePlay}
            className="w-7 h-7 flex items-center justify-center bg-primary-600 text-white rounded-lg flex-shrink-0 hover:bg-primary-700 transition-colors"
          >
            {playing ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5 ml-0.5" />}
          </button>
          <div className="flex-1 flex items-center gap-0.5 h-4 overflow-hidden">
            {Array.from({ length: 24 }, (_, i) => (
              <span key={i} className="w-1 bg-primary-300 rounded-full"
                style={{ height: `${Math.max(20, Math.random() * 100)}%` }} />
            ))}
          </div>
          <span className="text-xs font-semibold text-primary-600 tabular-nums flex-shrink-0">{fmt(elapsed)}</span>
          <button onClick={cancelPreview}
            className="w-5 h-5 flex items-center justify-center rounded hover:bg-primary-200 text-primary-600 flex-shrink-0"
          >
            <X className="w-3 h-3" />
          </button>
        </div>
        <button onClick={send}
          className="w-9 h-9 flex items-center justify-center bg-primary-600 hover:bg-primary-700 text-white rounded-xl transition-colors flex-shrink-0"
          title="Send voice message"
        >
          <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <line x1="22" y1="2" x2="11" y2="13" /><polygon points="22 2 15 22 11 13 2 9 22 2" />
          </svg>
        </button>
      </div>
    );
  }

  return (
    <>
      <button
        onClick={startRecording}
        disabled={disabled}
        className="self-end w-9 h-9 flex items-center justify-center bg-white border border-neutral-200 text-neutral-500 hover:text-red-500 hover:border-red-300 rounded-xl transition-colors disabled:opacity-40 flex-shrink-0"
        title="Record voice message"
      >
        <Mic className="w-4 h-4" />
      </button>
      {micError && (
        <div className="absolute bottom-full left-0 right-0 mb-1 px-3 py-2 bg-red-50 border border-red-200 rounded-xl text-xs text-red-700 text-center">
          Microphone access is needed for voice messages. Please allow it in your browser settings.
        </div>
      )}
    </>
  );
}

interface PlayerProps {
  url: string;
  duration?: number;
  isOwn: boolean;
}

export function VoicePlayer({ url, isOwn }: PlayerProps) {
  const audioRef = useRef<HTMLAudioElement>(null);
  const [playing, setPlaying] = useState(false);
  const [progress, setProgress] = useState(0);
  const [dur, setDur] = useState(0);
  const animRef = useRef<number>(0);

  const tick = useCallback(() => {
    const a = audioRef.current;
    if (a && a.duration) {
      setProgress(a.currentTime / a.duration);
      setDur(a.duration);
    }
    if (playing) animRef.current = requestAnimationFrame(tick);
  }, [playing]);

  useEffect(() => {
    if (playing) animRef.current = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(animRef.current);
  }, [playing, tick]);

  const toggle = () => {
    const a = audioRef.current;
    if (!a) return;
    if (playing) { a.pause(); setPlaying(false); }
    else { a.play().then(() => setPlaying(true)).catch(() => {}); }
  };

  return (
    <div className="flex items-center gap-2 min-w-[180px]">
      <audio ref={audioRef} src={url} preload="metadata"
        onEnded={() => { setPlaying(false); setProgress(0); }}
        onLoadedMetadata={() => { if (audioRef.current) setDur(audioRef.current.duration); }}
      />
      <button onClick={toggle}
        className={`w-8 h-8 flex items-center justify-center rounded-full flex-shrink-0 transition-colors ${
          isOwn ? 'bg-white/20 hover:bg-white/30 text-white' : 'bg-neutral-200 hover:bg-neutral-300 text-neutral-700'
        }`}
      >
        {playing ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5 ml-0.5" />}
      </button>
      <div className="flex-1 flex flex-col gap-1">
        <div className={`h-1.5 rounded-full overflow-hidden ${isOwn ? 'bg-white/20' : 'bg-neutral-200'}`}>
          <div className={`h-full rounded-full transition-all duration-100 ${isOwn ? 'bg-white' : 'bg-primary-500'}`}
            style={{ width: `${progress * 100}%` }} />
        </div>
        <span className={`text-[10px] tabular-nums ${isOwn ? 'text-white/70' : 'text-neutral-400'}`}>
          {dur > 0 ? fmt(playing ? audioRef.current?.currentTime ?? 0 : dur) : '0:00'}
        </span>
      </div>
    </div>
  );
}
