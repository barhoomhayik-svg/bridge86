import React, { useEffect, useMemo, useRef, useState } from 'react';
import QRCode from 'qrcode';
import { Order } from '../lib/supabase';
import { X, Printer, Download } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { jsPDF } from 'jspdf';

interface Props {
  order: Order;
  onClose: () => void;
}

interface Row {
  label: string;
  value: string;
}

export default function OrderSticker({ order, onClose }: Props) {
  const [qrDataUrl, setQrDataUrl] = useState('');
  const [logoDataUrl, setLogoDataUrl] = useState('');
  const iframeRef = useRef<HTMLIFrameElement | null>(null);

  useEffect(() => {
    const base = import.meta.env.VITE_SUPABASE_URL as string;
    const payload = `${base}/functions/v1/order-view?id=${order.id}`;
    QRCode.toDataURL(payload, { margin: 0, width: 512, errorCorrectionLevel: 'M' })
      .then(setQrDataUrl)
      .catch(() => setQrDataUrl(''));
  }, [order.id]);

  useEffect(() => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => {
      const c = document.createElement('canvas');
      c.width = img.naturalWidth;
      c.height = img.naturalHeight;
      const cx = c.getContext('2d');
      if (cx) {
        cx.drawImage(img, 0, 0);
        setLogoDataUrl(c.toDataURL('image/png'));
      }
    };
    img.src = '/logo_ copy 8.png';
  }, []);

  const rows: Row[] = useMemo(() => {
    const dash = '\u2014';
    return [
      { label: 'Dr', value: (order.dr_name || '').trim() || dash },
      { label: 'Pt', value: (order.patient_name || '').trim() || dash },
      { label: 'File', value: (order.file_number || '').trim() || dash },
    ];
  }, [order]);

  // ========== STICKER HTML (compact label for print) ==========
  const buildStickerHtml = () => `<!doctype html><html><head><meta charset="utf-8" /><title>Sticker ${escapeHtml(order.order_number)}</title>
<style>
  @page { size: 50mm 50mm; margin: 0; }
  * { box-sizing: border-box; }
  html, body { margin: 0; padding: 0; font-family: -apple-system, "Segoe UI", Roboto, sans-serif; -webkit-print-color-adjust: exact; print-color-adjust: exact; }
  .card { width: 50mm; height: 50mm; padding: 3mm; display: flex; gap: 3mm; align-items: stretch; background: #ffffff; }
  .qr { width: 22mm; height: 22mm; flex-shrink: 0; align-self: center; }
  .qr img { width: 100%; height: 100%; display: block; }
  .info { flex: 1; min-width: 0; display: flex; flex-direction: column; justify-content: center; gap: 0.4mm; color: #0f172a; }
  .info .num { font-weight: 800; font-size: 11pt; letter-spacing: -0.02em; color: #0f172a; line-height: 1.05; margin-bottom: 0.6mm; }
  .info .row { font-size: 7pt; line-height: 1.2; color: #0f172a; word-wrap: break-word; overflow-wrap: anywhere; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
  .info .row .lbl { color: #64748b; font-size: 5.5pt; font-weight: 700; text-transform: uppercase; letter-spacing: 0.04em; margin-right: 1mm; }
  .info .row .val { font-weight: 600; }
  .brand { margin-top: 0.6mm; display: flex; align-items: center; }
  .brand img { height: 5mm; width: auto; display: block; }
</style></head><body>
<div class="card">
  <div class="qr"><img src="${qrDataUrl}" alt="QR" /></div>
  <div class="info">
    <div class="num">#${escapeHtml(order.order_number)}</div>
    ${rows.map(r => `<div class="row"><span class="lbl">${escapeHtml(r.label)}</span><span class="val">${escapeHtml(r.value)}</span></div>`).join('')}
    <div class="brand"><img src="${logoDataUrl}" alt="Bridge" /></div>
  </div>
</div>
</body></html>`;

  const handlePrint = () => {
    if (!qrDataUrl) return;
    const iframe = iframeRef.current;
    if (!iframe) return;
    const doc = iframe.contentDocument;
    const win = iframe.contentWindow;
    if (!doc || !win) return;

    doc.open();
    doc.write(buildStickerHtml());
    doc.close();

    const runPrint = () => {
      try { win.focus(); win.print(); } catch { /* ignore */ }
    };

    const imgs = doc.querySelectorAll('img');
    let loaded = 0;
    const total = imgs.length;
    if (total === 0) { setTimeout(runPrint, 120); return; }
    const onLoad = () => { loaded++; if (loaded >= total) setTimeout(runPrint, 100); };
    imgs.forEach(img => {
      if (img.complete && img.naturalWidth > 0) onLoad();
      else { img.addEventListener('load', onLoad); img.addEventListener('error', onLoad); }
    });
  };

  const handleDownloadPdf = () => {
    if (!qrDataUrl) return;
    const W = 50;
    const H = 50;
    const pad = 3;
    const pdf = new jsPDF({ orientation: 'portrait', unit: 'mm', format: [W, H] });

    const qrSize = 22;
    const qrX = pad;
    const qrY = (H - qrSize) / 2;
    pdf.addImage(qrDataUrl, 'PNG', qrX, qrY, qrSize, qrSize);

    const textX = pad + qrSize + 2.5;
    let y = pad + 2;

    pdf.setFont('helvetica', 'bold');
    pdf.setFontSize(10);
    pdf.setTextColor(15, 23, 42);
    pdf.text(`#${order.order_number}`, textX, y);
    y += 5;

    pdf.setFontSize(6.5);
    for (const r of rows) {
      pdf.setFont('helvetica', 'bold');
      pdf.setTextColor(100, 116, 139);
      pdf.text(r.label.toUpperCase(), textX, y);
      const lblW = pdf.getTextWidth(r.label.toUpperCase()) + 1;
      pdf.setFont('helvetica', 'bold');
      pdf.setTextColor(15, 23, 42);
      const maxW = W - textX - pad;
      const truncated = truncateText(pdf, r.value, maxW - lblW);
      pdf.text(truncated, textX + lblW, y);
      y += 3.6;
    }

    if (logoDataUrl) {
      try {
        const logoH = 4;
        const logoW = 12;
        pdf.addImage(logoDataUrl, 'PNG', textX, H - pad - logoH, logoW, logoH);
      } catch { /* logo embed failed, skip */ }
    }

    pdf.save(`sticker-${order.order_number}.pdf`);
  };

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm transform-gpu flex items-center justify-center z-[70] p-4 pt-[env(safe-area-inset-top,16px)] pb-[env(safe-area-inset-bottom,16px)] px-[max(env(safe-area-inset-left,16px),16px)] animate-modal-in">
      <div className="bg-white rounded-2xl shadow-modal w-full max-w-[90vw] sm:max-w-lg max-h-[85vh] overflow-y-auto break-words">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-neutral-200">
          <div>
            <h2 className="font-bold text-neutral-900">Order Sticker</h2>
            <p className="text-xs text-neutral-500">5 x 5 cm compact label</p>
          </div>
          <button onClick={onClose} className="w-8 h-8 flex items-center justify-center rounded-lg hover:bg-neutral-100 transition-colors">
            <X className="w-4 h-4" />
          </button>
        </div>



        {/* Preview */}
        <div className="p-4">
          <div className="flex justify-center bg-neutral-50 rounded-xl border border-neutral-200 p-4">
            <div
              className="bg-white rounded-xl border border-neutral-200 shadow-sm p-3 flex items-center gap-3 w-full max-w-sm"
              style={{ aspectRatio: '1 / 1' }}
            >
              <div className="w-24 h-24 flex-shrink-0 flex items-center justify-center bg-white rounded-md border border-neutral-200/60">
                {qrDataUrl
                  ? <img src={qrDataUrl} alt="Order QR" className="w-full h-full" />
                  : <div className="w-full h-full animate-pulse bg-neutral-100" />
                }
              </div>
              <div className="flex-1 min-w-0 text-[10px] leading-tight text-neutral-800 space-y-[1px]">
                <p className="font-extrabold text-sm text-neutral-900 truncate mb-0.5">#{order.order_number}</p>
                {rows.map(r => (
                  <p key={r.label} className="truncate">
                    <span className="text-neutral-500 text-[8px] font-bold uppercase tracking-wider mr-1">{r.label}</span>
                    <span className="font-semibold">{r.value}</span>
                  </p>
                ))}
                {logoDataUrl && <img src={logoDataUrl} alt="Bridge" className="h-3 w-auto object-contain mt-1" />}
              </div>
            </div>
          </div>
        </div>

        {/* Actions */}
        <div className="p-4 border-t border-neutral-200 grid grid-cols-3 gap-2">
          <button onClick={onClose} className="py-2.5 border border-neutral-300 text-neutral-700 font-semibold rounded-xl text-sm hover:bg-neutral-50 active:scale-[0.98] transition-all duration-200">
            Close
          </button>
          <button onClick={handleDownloadPdf} disabled={!qrDataUrl}
            className="flex items-center justify-center gap-1.5 py-2.5 border border-teal-300 text-teal-700 font-semibold rounded-xl text-sm hover:bg-teal-50 disabled:opacity-50 active:scale-[0.98] transition-all duration-200">
            <Download className="w-3.5 h-3.5" /> PDF
          </button>
          <button onClick={handlePrint} disabled={!qrDataUrl}
            className="flex items-center justify-center gap-1.5 py-2.5 bg-teal-600 hover:bg-teal-700 disabled:bg-teal-400 text-white font-semibold rounded-xl text-sm active:scale-[0.98] transition-all duration-200">
            <Printer className="w-4 h-4" /> Print
          </button>
        </div>
      </div>

      <iframe
        ref={iframeRef}
        title="print-frame"
        style={{ position: 'fixed', right: 0, bottom: 0, width: 0, height: 0, border: 0, opacity: 0, pointerEvents: 'none' }}
      />
    </div>
  );
}

function escapeHtml(s: string | null | undefined): string {
  return (s ?? '').replace(/[&<>"']/g, ch => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[ch] as string));
}

function truncateText(pdf: jsPDF, text: string, maxW: number): string {
  if (pdf.getTextWidth(text) <= maxW) return text;
  let t = text;
  while (t.length > 0 && pdf.getTextWidth(t + '...') > maxW) t = t.slice(0, -1);
  return t + '...';
}
