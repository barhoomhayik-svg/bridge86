import { MeshGradient } from '@paper-design/shaders-react';

// Animated shader background with the Bridge logo rendered as a liquid-glass
// element floating on top. The glass effect is achieved by clipping a
// backdrop-blur/saturate layer to the logo's silhouette using a CSS mask,
// with a soft fresnel-like rim and specular highlight overlaid on top.
export default function LogoGlassBackground({ className = '' }: { className?: string }) {
  const maskStyle: React.CSSProperties = {
    WebkitMaskImage: 'url(/icon.svg)',
    maskImage: 'url(/icon.svg)',
    WebkitMaskRepeat: 'no-repeat',
    maskRepeat: 'no-repeat',
    WebkitMaskPosition: 'center',
    maskPosition: 'center',
    WebkitMaskSize: 'contain',
    maskSize: 'contain',
  };

  return (
    <div className={`absolute inset-0 overflow-hidden ${className}`} aria-hidden>
      <MeshGradient
        style={{ position: 'absolute', inset: 0, width: '100%', height: '100%' }}
        colors={['#042f2e', '#0d9488', '#134e4a', '#0e7490', '#5eead4']}
        speed={0.35}
        distortion={0.9}
        swirl={0.55}
      />

      {/* Liquid glass logo — a large centred emblem that refracts the shader
          beneath it via backdrop-filter, masked to the logo silhouette. */}
      <div className="pointer-events-none absolute inset-0 flex items-center justify-center">
        <div className="relative w-[62vmin] h-[62vmin] max-w-[520px] max-h-[520px] animate-float-slow">
          {/* Soft outer bloom */}
          <div
            className="absolute inset-0 blur-3xl opacity-40"
            style={{
              ...maskStyle,
              background: 'radial-gradient(closest-side, #5eead4 0%, rgba(94,234,212,0) 70%)',
            }}
          />

          {/* Refractive glass body (frosted blur + subtle tint) */}
          <div
            className="absolute inset-0"
            style={{
              ...maskStyle,
              backdropFilter: 'blur(14px) saturate(160%) brightness(1.08)',
              WebkitBackdropFilter: 'blur(14px) saturate(160%) brightness(1.08)',
              background:
                'linear-gradient(135deg, rgba(255,255,255,0.28) 0%, rgba(255,255,255,0.06) 45%, rgba(94,234,212,0.18) 100%)',
              boxShadow:
                'inset 0 2px 0 rgba(255,255,255,0.45), inset 0 -2px 0 rgba(0,0,0,0.15)',
            }}
          />

          {/* Fresnel-like rim highlight */}
          <div
            className="absolute inset-0"
            style={{
              ...maskStyle,
              background:
                'radial-gradient(ellipse at 30% 20%, rgba(255,255,255,0.55) 0%, rgba(255,255,255,0) 35%), radial-gradient(ellipse at 75% 85%, rgba(94,234,212,0.5) 0%, rgba(94,234,212,0) 45%)',
              mixBlendMode: 'screen',
            }}
          />

          {/* Specular sweep — subtle animated shine across the glass */}
          <div
            className="absolute inset-0 opacity-70 animate-glass-shine"
            style={{
              ...maskStyle,
              background:
                'linear-gradient(115deg, transparent 40%, rgba(255,255,255,0.55) 50%, transparent 60%)',
              mixBlendMode: 'screen',
            }}
          />
        </div>
      </div>
    </div>
  );
}
