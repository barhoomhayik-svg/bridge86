import React, { useState } from 'react';
import { supabase } from '../lib/supabase';
import { Building2, Stethoscope, FlaskConical, Eye, EyeOff, CheckCircle2, ArrowLeft, Mail, Loader2, Sparkles } from 'lucide-react';
import OtpInput from '../components/OtpInput';

type Mode = 'login' | 'register';
type Role = 'center' | 'doctor' | 'lab';

const roles = [
  { value: 'center' as Role, label: 'Dental Center', desc: 'A clinic or dental center placing orders', icon: Building2 },
  { value: 'doctor' as Role, label: 'Dentist / Doctor', desc: 'An individual dental practitioner', icon: Stethoscope },
  { value: 'lab' as Role, label: 'Dental Laboratory', desc: 'A lab receiving and fulfilling orders', icon: FlaskConical },
];

const countryDialCodes: Record<string, string> = {
  'Saudi Arabia': '+966', 'United Arab Emirates': '+971', 'Egypt': '+20', 'Qatar': '+974',
  'Kuwait': '+965', 'Bahrain': '+973', 'Oman': '+968', 'Jordan': '+962', 'Lebanon': '+961',
  'Syria': '+963', 'Iraq': '+964', 'Yemen': '+967', 'Palestine': '+970', 'Israel': '+972',
  'Turkey': '+90', 'Iran': '+98',
  'Afghanistan': '+93', 'Albania': '+355', 'Algeria': '+213', 'Andorra': '+376', 'Angola': '+244',
  'Antigua and Barbuda': '+1-268', 'Argentina': '+54', 'Armenia': '+374', 'Australia': '+61',
  'Austria': '+43', 'Azerbaijan': '+994', 'Bahamas': '+1-242', 'Bangladesh': '+880', 'Barbados': '+1-246',
  'Belarus': '+375', 'Belgium': '+32', 'Belize': '+501', 'Benin': '+229', 'Bhutan': '+975',
  'Bolivia': '+591', 'Bosnia and Herzegovina': '+387', 'Botswana': '+267', 'Brazil': '+55',
  'Brunei': '+673', 'Bulgaria': '+359', 'Burkina Faso': '+226', 'Burundi': '+257', 'Cabo Verde': '+238',
  'Cambodia': '+855', 'Cameroon': '+237', 'Canada': '+1', 'Central African Republic': '+236',
  'Chad': '+235', 'Chile': '+56', 'China': '+86', 'Colombia': '+57', 'Comoros': '+269',
  'Congo (Brazzaville)': '+242', 'Congo (Kinshasa)': '+243', 'Costa Rica': '+506', 'Croatia': '+385',
  'Cuba': '+53', 'Cyprus': '+357', 'Czechia': '+420', "Côte d'Ivoire": '+225', 'Denmark': '+45',
  'Djibouti': '+253', 'Dominica': '+1-767', 'Dominican Republic': '+1-809', 'Ecuador': '+593',
  'El Salvador': '+503', 'Equatorial Guinea': '+240', 'Eritrea': '+291', 'Estonia': '+372',
  'Eswatini': '+268', 'Ethiopia': '+251', 'Fiji': '+679', 'Finland': '+358', 'France': '+33',
  'Gabon': '+241', 'Gambia': '+220', 'Georgia': '+995', 'Germany': '+49', 'Ghana': '+233',
  'Greece': '+30', 'Grenada': '+1-473', 'Guatemala': '+502', 'Guinea': '+224', 'Guinea-Bissau': '+245',
  'Guyana': '+592', 'Haiti': '+509', 'Honduras': '+504', 'Hong Kong': '+852', 'Hungary': '+36',
  'Iceland': '+354', 'India': '+91', 'Indonesia': '+62', 'Ireland': '+353', 'Italy': '+39',
  'Jamaica': '+1-876', 'Japan': '+81', 'Kazakhstan': '+7', 'Kenya': '+254', 'Kiribati': '+686',
  'Kosovo': '+383', 'Kyrgyzstan': '+996', 'Laos': '+856', 'Latvia': '+371', 'Lesotho': '+266',
  'Liberia': '+231', 'Libya': '+218', 'Liechtenstein': '+423', 'Lithuania': '+370', 'Luxembourg': '+352',
  'Macau': '+853', 'Madagascar': '+261', 'Malawi': '+265', 'Malaysia': '+60', 'Maldives': '+960',
  'Mali': '+223', 'Malta': '+356', 'Marshall Islands': '+692', 'Mauritania': '+222', 'Mauritius': '+230',
  'Mexico': '+52', 'Micronesia': '+691', 'Moldova': '+373', 'Monaco': '+377', 'Mongolia': '+976',
  'Montenegro': '+382', 'Morocco': '+212', 'Mozambique': '+258', 'Myanmar': '+95', 'Namibia': '+264',
  'Nauru': '+674', 'Nepal': '+977', 'Netherlands': '+31', 'New Zealand': '+64', 'Nicaragua': '+505',
  'Niger': '+227', 'Nigeria': '+234', 'North Korea': '+850', 'North Macedonia': '+389',
  'Norway': '+47', 'Pakistan': '+92', 'Palau': '+680', 'Panama': '+507', 'Papua New Guinea': '+675',
  'Paraguay': '+595', 'Peru': '+51', 'Philippines': '+63', 'Poland': '+48', 'Portugal': '+351',
  'Puerto Rico': '+1-787', 'Romania': '+40', 'Russia': '+7', 'Rwanda': '+250',
  'Saint Kitts and Nevis': '+1-869', 'Saint Lucia': '+1-758',
  'Saint Vincent and the Grenadines': '+1-784', 'Samoa': '+685', 'San Marino': '+378',
  'Sao Tome and Principe': '+239', 'Senegal': '+221', 'Serbia': '+381', 'Seychelles': '+248',
  'Sierra Leone': '+232', 'Singapore': '+65', 'Slovakia': '+421', 'Slovenia': '+386',
  'Solomon Islands': '+677', 'Somalia': '+252', 'South Africa': '+27', 'South Korea': '+82',
  'South Sudan': '+211', 'Spain': '+34', 'Sri Lanka': '+94', 'Sudan': '+249', 'Suriname': '+597',
  'Sweden': '+46', 'Switzerland': '+41', 'Taiwan': '+886', 'Tajikistan': '+992', 'Tanzania': '+255',
  'Thailand': '+66', 'Timor-Leste': '+670', 'Togo': '+228', 'Tonga': '+676',
  'Trinidad and Tobago': '+1-868', 'Tunisia': '+216', 'Turkmenistan': '+993', 'Tuvalu': '+688',
  'Uganda': '+256', 'Ukraine': '+380', 'United Kingdom': '+44', 'United States': '+1',
  'Uruguay': '+598', 'Uzbekistan': '+998', 'Vanuatu': '+678', 'Vatican City': '+39',
  'Venezuela': '+58', 'Vietnam': '+84', 'Zambia': '+260', 'Zimbabwe': '+263',
};

const middleEastCountries = [
  'Saudi Arabia', 'United Arab Emirates', 'Egypt', 'Qatar', 'Kuwait', 'Bahrain', 'Oman',
  'Jordan', 'Lebanon', 'Syria', 'Iraq', 'Yemen', 'Palestine', 'Israel', 'Turkey', 'Iran',
];

const otherCountries = Object.keys(countryDialCodes)
  .filter(c => !middleEastCountries.includes(c))
  .sort((a, b) => a.localeCompare(b));

type ForgotStep = 'email' | 'otp' | 'newpass' | 'done';

/* ── Shared styling constants ── */
const INPUT_CLS = 'w-full px-3.5 py-3 rounded-xl border border-neutral-200 bg-neutral-50 text-sm text-neutral-900 placeholder:text-neutral-400 focus:outline-none focus:ring-2 focus:ring-primary-400/40 focus:border-primary-400 transition-colors';
const LABEL_CLS = 'block text-xs font-semibold text-neutral-500 mb-1.5 tracking-wide';
const BTN_PRIMARY = 'w-full py-3.5 bg-gradient-to-b from-primary-400 to-primary-600 hover:from-primary-500 hover:to-primary-700 disabled:from-primary-300 disabled:to-primary-400 text-white font-bold rounded-xl text-sm transition-all flex items-center justify-center gap-2 shadow-[0_3px_0_0_#1B504B,0_6px_16px_rgba(47,122,115,0.25)] hover:shadow-[0_2px_0_0_#1B504B,0_4px_12px_rgba(47,122,115,0.2)] active:shadow-[0_1px_0_0_#1B504B] active:translate-y-0.5';
const BTN_OUTLINE = 'flex items-center justify-center gap-2 py-3 border border-neutral-200 rounded-xl text-sm font-semibold text-neutral-700 hover:bg-neutral-50 hover:border-neutral-300 disabled:opacity-50 transition-all';

export default function AuthPage({ onBack }: { onBack?: () => void }) {
  const [mode, setMode] = useState<Mode>('login');
  const [role, setRole] = useState<Role>('center');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [country, setCountry] = useState('');
  const [phone, setPhone] = useState('');
  const [showPass, setShowPass] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [slideDir, setSlideDir] = useState<1 | -1>(1);

  const [signupOtp, setSignupOtp] = useState(false);
  const [signupOtpEmail, setSignupOtpEmail] = useState('');
  const [signupOtpLoading, setSignupOtpLoading] = useState(false);
  const [signupOtpError, setSignupOtpError] = useState('');

  const [forgot, setForgot] = useState(false);
  const [forgotStep, setForgotStep] = useState<ForgotStep>('email');
  const [forgotEmail, setForgotEmail] = useState('');
  const [forgotLoading, setForgotLoading] = useState(false);
  const [forgotError, setForgotError] = useState('');
  const [forgotOtpLoading, setForgotOtpLoading] = useState(false);
  const [forgotOtpError, setForgotOtpError] = useState('');
  const [newPw, setNewPw] = useState('');
  const [newPwConfirm, setNewPwConfirm] = useState('');
  const [newPwLoading, setNewPwLoading] = useState(false);
  const [newPwError, setNewPwError] = useState('');
  const [showNewPass, setShowNewPass] = useState(false);

  const [magicLink, setMagicLink] = useState(false);
  const [magicEmail, setMagicEmail] = useState('');
  const [magicLoading, setMagicLoading] = useState(false);
  const [magicSent, setMagicSent] = useState(false);
  const [magicError, setMagicError] = useState('');

  const [oauthRolePicker, setOauthRolePicker] = useState<'google' | 'apple' | null>(null);
  const [oauthRole, setOauthRole] = useState<Role>('center');

  /* ── Forgot password handlers ── */

  const handleForgotSendEmail = async (e: React.FormEvent) => {
    e.preventDefault();
    setForgotError('');
    setForgotLoading(true);
    try {
      const { error } = await supabase.auth.resetPasswordForEmail(forgotEmail);
      if (error) throw error;
      setForgotStep('otp');
    } catch {
      setForgotError('Could not send the reset code right now. Please try again in a moment.');
    } finally {
      setForgotLoading(false);
    }
  };

  const handleForgotVerifyOtp = async (code: string) => {
    setForgotOtpError('');
    setForgotOtpLoading(true);
    try {
      const { error } = await supabase.auth.verifyOtp({
        email: forgotEmail,
        token: code,
        type: 'recovery',
      });
      if (error) throw error;
      setForgotStep('newpass');
    } catch {
      setForgotOtpError('Invalid or expired code. Please check and try again.');
    } finally {
      setForgotOtpLoading(false);
    }
  };

  const handleForgotResendOtp = async () => {
    await supabase.auth.resetPasswordForEmail(forgotEmail);
  };

  const handleNewPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setNewPwError('');
    if (newPw.length < 6) { setNewPwError('Password must be at least 6 characters.'); return; }
    if (!/(?=.*[a-z])(?=.*[A-Z])(?=.*[^A-Za-z0-9])/.test(newPw)) {
      setNewPwError('Include a lowercase letter, an uppercase letter, and a symbol.');
      return;
    }
    if (newPw !== newPwConfirm) { setNewPwError('Passwords do not match.'); return; }
    setNewPwLoading(true);
    try {
      const { error } = await supabase.auth.updateUser({ password: newPw });
      if (error) throw error;
      setForgotStep('done');
    } catch {
      setNewPwError('Could not update your password. Please try again.');
    } finally {
      setNewPwLoading(false);
    }
  };

  const closeForgot = () => {
    setForgot(false);
    setForgotStep('email');
    setForgotEmail('');
    setForgotError('');
    setForgotOtpError('');
    setNewPw('');
    setNewPwConfirm('');
    setNewPwError('');
  };

  /* ── Sign-up OTP handlers ── */

  const handleSignupVerifyOtp = async (code: string) => {
    setSignupOtpError('');
    setSignupOtpLoading(true);
    try {
      const { error } = await supabase.auth.verifyOtp({
        email: signupOtpEmail,
        token: code,
        type: 'email',
      });
      if (error) throw error;
    } catch {
      setSignupOtpError('Invalid or expired code. Please check and try again.');
    } finally {
      setSignupOtpLoading(false);
    }
  };

  const handleSignupResendOtp = async () => {
    await supabase.auth.signInWithOtp({
      email: signupOtpEmail,
      options: { shouldCreateUser: false },
    });
  };

  /* ── Mode switch ── */

  const switchMode = (m: Mode, dir: 1 | -1) => {
    setSlideDir(dir);
    setMode(m);
    setError('');
    setSignupOtp(false);
    setSignupOtpError('');
  };

  /* ── Main form submit (login / register) ── */

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    if (mode === 'register' && !/(?=.*[a-z])(?=.*[A-Z])(?=.*[^A-Za-z0-9]).{6,}/.test(password)) {
      setError('Password must be at least 6 characters and include a lowercase letter, an uppercase letter, and a symbol.');
      return;
    }
    setLoading(true);
    try {
      if (mode === 'login') {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) {
          throw new Error('We could not sign you in. Check your email and password and try again.');
        }
      } else {
        const { error } = await supabase.auth.signUp({
          email,
          password,
          options: {
            data: {
              role,
              name,
              full_name: name,
              phone: phone ? `${countryDialCodes[country] ?? ''}${phone}` : null,
              country: country || null,
            },
          },
        });
        if (error) {
          throw new Error('Could not create your account. If you already have one, sign in or reset your password instead.');
        }
        await supabase.auth.signOut();
        await supabase.auth.signInWithOtp({
          email,
          options: { shouldCreateUser: false },
        });
        setSignupOtpEmail(email);
        setSignupOtp(true);
        setPassword('');
      }
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Something went wrong');
    } finally {
      setLoading(false);
    }
  };

  /* ── Magic link ── */

  const handleMagicLink = async (e: React.FormEvent) => {
    e.preventDefault();
    setMagicError('');
    setMagicLoading(true);
    try {
      const { error } = await supabase.auth.signInWithOtp({
        email: magicEmail,
        options: { emailRedirectTo: window.location.origin + '/auth/callback' },
      });
      if (error) throw error;
      setMagicSent(true);
    } catch {
      setMagicError('Could not send the magic link. Please try again in a moment.');
    } finally {
      setMagicLoading(false);
    }
  };

  const closeMagicLink = () => {
    setMagicLink(false);
    setMagicSent(false);
    setMagicEmail('');
    setMagicError('');
  };

  /* ── OAuth ── */

  const startOAuth = (provider: 'google' | 'apple') => {
    setOauthRolePicker(provider);
  };

  const confirmOAuthRole = async () => {
    if (!oauthRolePicker) return;
    setError('');
    setLoading(true);
    localStorage.setItem('pending_oauth_role', oauthRole);
    try {
      const { error } = await supabase.auth.signInWithOAuth({
        provider: oauthRolePicker,
        options: { redirectTo: window.location.origin },
      });
      if (error) throw error;
    } catch {
      localStorage.removeItem('pending_oauth_role');
      setError('Could not start sign-in. Please try again.');
      setLoading(false);
    }
  };

  /* ── Brand panel (left side on desktop) ── */

  const BrandPanel = () => (
    <div className="hidden min-[1000px]:flex relative w-[45%] min-h-screen bg-gradient-to-br from-[#0F4540] via-[#134E48] to-[#0B3B36] flex-col items-center justify-center p-12 overflow-hidden">
      {/* Decorative circles */}
      <div className="absolute top-[-80px] right-[-60px] w-[280px] h-[280px] rounded-full bg-white/[0.04] animate-float-slow" />
      <div className="absolute bottom-[-100px] left-[-40px] w-[220px] h-[220px] rounded-full bg-white/[0.03]" style={{ animationDelay: '2s' }} />
      <div className="absolute top-1/3 left-[15%] w-[120px] h-[120px] rounded-full bg-coral-400/[0.08] animate-float-slow" style={{ animationDelay: '4s' }} />

      {/* Tooth icon */}
      <div className="relative mb-10">
        <div className="w-24 h-24 rounded-3xl bg-white/10 backdrop-blur-sm flex items-center justify-center animate-tooth-bounce">
          <svg width="48" height="48" viewBox="0 0 48 48" fill="none">
            <path d="M24 4C18.5 4 16 8 14 10C12 12 8 13 8 20C8 27 10 32 13 36C16 40 17 44 20 44C23 44 23 38 24 38C25 38 25 44 28 44C31 44 32 40 35 36C38 32 40 27 40 20C40 13 36 12 34 10C32 8 29.5 4 24 4Z" fill="white" fillOpacity="0.9"/>
          </svg>
        </div>
        <div className="absolute -top-2 -right-2 w-6 h-6 rounded-full bg-primary-400/30 animate-tooth-shine" />
      </div>

      {/* Brand text */}
      <div className="text-center relative z-10">
        <h1 className="font-display text-4xl font-extrabold text-white mb-3 tracking-tight">
          Bridge
        </h1>
        <p className="text-primary-200/80 text-lg font-medium mb-8">
          Dental Lab Platform
        </p>
        <div className="w-16 h-px bg-white/20 mx-auto mb-8" />
        <p className="text-white/50 text-sm max-w-[260px] leading-relaxed">
          Connecting dental labs, clinics, and practitioners on one seamless platform.
        </p>
      </div>

      {/* Stats row */}
      <div className="mt-12 flex gap-8">
        {[
          { n: '500+', label: 'Labs' },
          { n: '2K+', label: 'Doctors' },
          { n: '50K+', label: 'Orders' },
        ].map(s => (
          <div key={s.label} className="text-center">
            <p className="font-display text-2xl font-bold text-white">{s.n}</p>
            <p className="text-primary-300/60 text-xs mt-0.5">{s.label}</p>
          </div>
        ))}
      </div>
    </div>
  );

  /* ── Form wrapper with consistent styling ── */

  const FormShell = ({ children }: { children: React.ReactNode }) => (
    <div className="min-h-dvh flex">
      <BrandPanel />
      <div className="flex-1 min-h-dvh bg-[#F7F6F1] flex items-center justify-center p-4 sm:p-8 py-safe px-safe overflow-y-auto">
        <div className="relative w-full max-w-[420px]">
          {/* Mobile logo (hidden on desktop where brand panel shows) */}
          <div className="flex min-[1000px]:hidden items-center justify-center gap-3 mb-8 pt-safe-sm">
            <img src="/logo_%20copy%208.png" alt="Bridge" className="w-10 h-10 rounded-xl object-contain" />
            <div>
              <h1 className="font-display text-neutral-900 font-bold text-xl leading-none">Bridge</h1>
              <p className="text-neutral-400 text-xs">Dental Lab Platform</p>
            </div>
          </div>

          {onBack && (
            <button onClick={onBack}
              className="absolute top-4 left-0 flex items-center gap-1.5 text-sm text-neutral-400 hover:text-neutral-700 transition-colors z-10 no-lift">
              <ArrowLeft className="w-4 h-4" />
              Back
            </button>
          )}

          {children}

          <div className="text-center mt-8 pb-safe-sm space-y-2">
            <div className="flex items-center justify-center gap-3 text-xs text-neutral-400">
              <a href="/privacy-policy" className="hover:text-neutral-600 transition-colors">Privacy Policy</a>
              <span className="text-neutral-300">&middot;</span>
              <a href="/terms-of-service" className="hover:text-neutral-600 transition-colors">Terms of Service</a>
            </div>
            <p className="text-neutral-300 text-xs">&copy; 2026 Bridge 86. All rights reserved.</p>
          </div>
        </div>
      </div>
    </div>
  );

  /* ── OAuth role picker screen ── */

  if (oauthRolePicker) {
    return (
      <FormShell>
        <button
          onClick={() => { setOauthRolePicker(null); setLoading(false); }}
          className="flex items-center gap-1.5 text-sm text-neutral-400 hover:text-neutral-700 transition-colors mb-6 no-lift"
        >
          <ArrowLeft className="w-4 h-4" />
          Back
        </button>

        <div className="bg-white rounded-2xl border border-neutral-200 shadow-card p-6 sm:p-8">
          <h2 className="font-display text-xl font-bold text-neutral-900 text-center mb-1">Choose your account type</h2>
          <p className="text-sm text-neutral-500 text-center mb-6">
            Select what best describes you before signing in with {oauthRolePicker === 'google' ? 'Google' : 'Apple'}
          </p>

          <div className="space-y-2.5 mb-6">
            {roles.map(r => {
              const Icon = r.icon;
              const active = oauthRole === r.value;
              return (
                <label
                  key={r.value}
                  className={`flex items-center gap-3.5 p-4 rounded-xl border-2 cursor-pointer transition-all ${
                    active ? 'border-primary-500 bg-primary-50/60 shadow-sm' : 'border-neutral-200 hover:border-neutral-300 hover:bg-neutral-50'
                  }`}
                >
                  <input type="radio" name="oauth-role" value={r.value} checked={active} onChange={() => setOauthRole(r.value)} className="sr-only" />
                  <div className={`w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 transition-colors ${active ? 'bg-primary-500' : 'bg-neutral-100'}`}>
                    <Icon className={`w-5 h-5 ${active ? 'text-white' : 'text-neutral-500'}`} />
                  </div>
                  <div className="min-w-0">
                    <p className="text-sm font-semibold text-neutral-800">{r.label}</p>
                    <p className="text-xs text-neutral-500">{r.desc}</p>
                  </div>
                </label>
              );
            })}
          </div>

          <button onClick={confirmOAuthRole} disabled={loading} className={BTN_PRIMARY}>
            {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : null}
            {loading ? 'Connecting...' : `Continue with ${oauthRolePicker === 'google' ? 'Google' : 'Apple'}`}
          </button>
        </div>
      </FormShell>
    );
  }

  /* ── Main auth page ── */

  return (
    <FormShell>
      <div className="bg-white rounded-2xl shadow-card border border-neutral-200/80 overflow-hidden">
        {/* Tab switcher */}
        <div className="flex border-b border-neutral-200/80">
          {(['login', 'register'] as Mode[]).map((m) => (
            <button
              key={m}
              onClick={() => switchMode(m, m === 'login' ? -1 : 1)}
              className={`no-lift flex-1 py-4 text-sm font-semibold transition-all relative ${
                mode === m ? 'text-primary-600' : 'text-neutral-400 hover:text-neutral-600'
              }`}
            >
              {m === 'login' ? 'Sign In' : 'Create Account'}
              {mode === m && (
                <span className="absolute bottom-0 left-1/4 right-1/4 h-0.5 bg-primary-500 rounded-full" />
              )}
            </button>
          ))}
        </div>

        <div className="overflow-hidden">
          {/* ── Sign-up OTP verification ── */}
          {signupOtp ? (
            <div key="signup-otp" className="p-6 sm:p-8" style={{ animation: 'stagger-in 0.4s cubic-bezier(0.16, 1, 0.3, 1)' }}>
              <button
                onClick={() => { setSignupOtp(false); setSignupOtpError(''); }}
                className="flex items-center gap-1.5 text-sm text-neutral-400 hover:text-neutral-700 mb-4 transition-colors no-lift"
              >
                <ArrowLeft className="w-4 h-4" />
                Back
              </button>
              <OtpInput
                email={signupOtpEmail}
                title="Verify your email"
                subtitle="Enter the 6-digit code we sent to"
                loading={signupOtpLoading}
                error={signupOtpError}
                onComplete={handleSignupVerifyOtp}
                onResend={handleSignupResendOtp}
              />
            </div>

          ) : magicLink ? (
            <div key="magic" style={{ animation: 'stagger-in 0.4s cubic-bezier(0.16, 1, 0.3, 1)' }}>
              <div className="p-6 sm:p-8">
                <button
                  onClick={closeMagicLink}
                  className="flex items-center gap-1.5 text-sm text-neutral-400 hover:text-neutral-700 mb-4 transition-colors no-lift"
                >
                  <ArrowLeft className="w-4 h-4" />
                  Back to sign in
                </button>

                {magicSent ? (
                  <div className="text-center py-6" style={{ animation: 'rise-in 0.4s ease' }}>
                    <div className="w-16 h-16 bg-primary-50 rounded-2xl flex items-center justify-center mx-auto mb-4">
                      <Mail className="w-7 h-7 text-primary-500" />
                    </div>
                    <h3 className="font-display text-lg font-bold text-neutral-800 mb-2">Check your email</h3>
                    <p className="text-sm text-neutral-500 mb-2">We sent a magic link to</p>
                    <p className="text-sm font-semibold text-neutral-800 mb-5 break-all">{magicEmail}</p>
                    <p className="text-sm text-neutral-400 mb-6">
                      Click the link in the email to sign in instantly -- no password needed.
                    </p>
                    <button onClick={closeMagicLink} className={BTN_PRIMARY}>
                      Back to sign in
                    </button>
                  </div>
                ) : (
                  <>
                    <div className="flex items-center gap-2 mb-1.5">
                      <Sparkles className="w-5 h-5 text-primary-500" />
                      <h3 className="font-display text-lg font-bold text-neutral-800">Magic Link</h3>
                    </div>
                    <p className="text-sm text-neutral-500 mb-5">
                      Enter your email and we'll send you a link to sign in instantly without a password.
                    </p>
                    <form onSubmit={handleMagicLink} className="space-y-4">
                      <div>
                        <label className={LABEL_CLS}>Email</label>
                        <input type="email" required value={magicEmail} onChange={e => setMagicEmail(e.target.value)} placeholder="you@example.com" className={INPUT_CLS} />
                      </div>
                      {magicError && <ErrorBanner message={magicError} />}
                      <button type="submit" disabled={magicLoading} className={BTN_PRIMARY}>
                        {magicLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Mail className="w-4 h-4" />}
                        {magicLoading ? 'Sending...' : 'Send Magic Link'}
                      </button>
                    </form>
                  </>
                )}
              </div>
            </div>

          ) : forgot ? (
            <div key="forgot" style={{ animation: 'stagger-in 0.4s cubic-bezier(0.16, 1, 0.3, 1)' }}>
              <div className="p-6 sm:p-8">
                <button
                  onClick={closeForgot}
                  className="flex items-center gap-1.5 text-sm text-neutral-400 hover:text-neutral-700 mb-4 transition-colors no-lift"
                >
                  <ArrowLeft className="w-4 h-4" />
                  Back to sign in
                </button>

                {forgotStep === 'email' && (
                  <>
                    <h3 className="font-display text-lg font-bold text-neutral-800 mb-1.5">Forgot password?</h3>
                    <p className="text-sm text-neutral-500 mb-5">
                      Enter your email and we'll send you a 6-digit code to reset your password.
                    </p>
                    <form onSubmit={handleForgotSendEmail} className="space-y-4">
                      <div>
                        <label className={LABEL_CLS}>Email</label>
                        <input type="email" required value={forgotEmail} onChange={e => setForgotEmail(e.target.value)} placeholder="you@example.com" className={INPUT_CLS} />
                      </div>
                      {forgotError && <ErrorBanner message={forgotError} />}
                      <button type="submit" disabled={forgotLoading} className={BTN_PRIMARY}>
                        {forgotLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : null}
                        {forgotLoading ? 'Sending...' : 'Send reset code'}
                      </button>
                    </form>
                  </>
                )}

                {forgotStep === 'otp' && (
                  <OtpInput
                    email={forgotEmail}
                    title="Enter reset code"
                    subtitle="Enter the 6-digit code we sent to"
                    loading={forgotOtpLoading}
                    error={forgotOtpError}
                    onComplete={handleForgotVerifyOtp}
                    onResend={handleForgotResendOtp}
                  />
                )}

                {forgotStep === 'newpass' && (
                  <div style={{ animation: 'rise-in 0.4s ease' }}>
                    <h3 className="font-display text-lg font-bold text-neutral-800 mb-1.5">Set a new password</h3>
                    <p className="text-sm text-neutral-500 mb-5">Choose a strong password for your account.</p>
                    <form onSubmit={handleNewPassword} className="space-y-4">
                      <div>
                        <label className={LABEL_CLS}>New Password</label>
                        <div className="relative">
                          <input
                            type={showNewPass ? 'text' : 'password'} required value={newPw} onChange={e => setNewPw(e.target.value)}
                            minLength={6} placeholder="6+ chars: Aa and a symbol"
                            className={INPUT_CLS + ' pr-10'}
                          />
                          <button type="button" onClick={() => setShowNewPass(!showNewPass)} className="absolute right-3 top-1/2 -translate-y-1/2 text-neutral-400 hover:text-neutral-600 no-lift">
                            {showNewPass ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                          </button>
                        </div>
                      </div>
                      <div>
                        <label className={LABEL_CLS}>Confirm Password</label>
                        <input type="password" required value={newPwConfirm} onChange={e => setNewPwConfirm(e.target.value)} placeholder="Re-enter your password" className={INPUT_CLS} />
                      </div>
                      {newPwError && <ErrorBanner message={newPwError} />}
                      <button type="submit" disabled={newPwLoading} className={BTN_PRIMARY}>
                        {newPwLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : null}
                        {newPwLoading ? 'Saving...' : 'Update Password'}
                      </button>
                    </form>
                  </div>
                )}

                {forgotStep === 'done' && (
                  <div className="text-center py-6" style={{ animation: 'rise-in 0.4s ease' }}>
                    <div className="w-16 h-16 bg-green-50 rounded-2xl flex items-center justify-center mx-auto mb-4">
                      <CheckCircle2 className="w-7 h-7 text-green-500" />
                    </div>
                    <h3 className="font-display text-lg font-bold text-neutral-800 mb-2">Password updated</h3>
                    <p className="text-sm text-neutral-500 mb-6">Your password has been changed successfully. You can now sign in with your new password.</p>
                    <button onClick={closeForgot} className={BTN_PRIMARY}>
                      Back to sign in
                    </button>
                  </div>
                )}
              </div>
            </div>

          ) : (
            <div
              key={mode}
              style={{ animation: `slideIn-${slideDir === 1 ? 'right' : 'left'} 0.42s cubic-bezier(0.22, 1, 0.36, 1)` }}
            >
              <form onSubmit={handleSubmit} className="p-6 sm:p-8 space-y-4">
                {mode === 'register' && (
                  <>
                    <div>
                      <label className={LABEL_CLS}>Account Type</label>
                      <div className="grid grid-cols-1 gap-2 mt-1">
                        {roles.map(r => {
                          const Icon = r.icon;
                          const active = role === r.value;
                          return (
                            <label
                              key={r.value}
                              className={`flex items-center gap-3.5 p-3.5 rounded-xl border-2 cursor-pointer transition-all ${
                                active ? 'border-primary-500 bg-primary-50/60 shadow-sm' : 'border-neutral-200 hover:border-neutral-300 hover:bg-neutral-50'
                              }`}
                            >
                              <input type="radio" name="role" value={r.value} checked={active} onChange={() => setRole(r.value)} className="sr-only" />
                              <div className={`w-9 h-9 rounded-lg flex items-center justify-center flex-shrink-0 transition-colors ${active ? 'bg-primary-500' : 'bg-neutral-100'}`}>
                                <Icon className={`w-4 h-4 ${active ? 'text-white' : 'text-neutral-500'}`} />
                              </div>
                              <div className="min-w-0">
                                <p className="text-sm font-semibold text-neutral-800">{r.label}</p>
                                <p className="text-xs text-neutral-500">{r.desc}</p>
                              </div>
                            </label>
                          );
                        })}
                      </div>
                    </div>

                    <div>
                      <label className={LABEL_CLS}>
                        {role === 'lab' ? 'Lab Name' : role === 'center' ? 'Center Name' : 'Doctor Name'}
                      </label>
                      <input type="text" required value={name} onChange={e => setName(e.target.value)} placeholder="Full name" className={INPUT_CLS} />
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label className={LABEL_CLS}>Country</label>
                        <select required value={country} onChange={e => setCountry(e.target.value)} className={INPUT_CLS + ' bg-neutral-50'}>
                          <option value="">Select country</option>
                          <optgroup label="Middle East">
                            {middleEastCountries.map(o => <option key={o} value={o}>{o}</option>)}
                          </optgroup>
                          <optgroup label="All countries">
                            {otherCountries.map(o => <option key={o} value={o}>{o}</option>)}
                          </optgroup>
                        </select>
                      </div>
                      <div>
                        <label className={LABEL_CLS}>Phone</label>
                        <div className="relative">
                          <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-sm text-neutral-500 pointer-events-none select-none">
                            {country ? countryDialCodes[country] ?? '+' : '+'}
                          </span>
                          <input
                            type="tel" inputMode="numeric" value={phone}
                            onChange={e => setPhone(e.target.value.replace(/[^0-9]/g, ''))}
                            placeholder="1234567890"
                            className={INPUT_CLS + ' pl-14'}
                          />
                        </div>
                      </div>
                    </div>
                  </>
                )}

                <div>
                  <label className={LABEL_CLS}>Email</label>
                  <input type="email" required value={email} onChange={e => setEmail(e.target.value)} placeholder="you@example.com" className={INPUT_CLS} />
                </div>

                <div>
                  <label className={LABEL_CLS}>Password</label>
                  <div className="relative">
                    <input
                      type={showPass ? 'text' : 'password'} required value={password} onChange={e => setPassword(e.target.value)}
                      minLength={mode === 'register' ? 6 : undefined}
                      pattern={mode === 'register' ? '(?=.*[a-z])(?=.*[A-Z])(?=.*[^A-Za-z0-9]).{6,}' : undefined}
                      title={mode === 'register' ? 'Use at least 6 characters with a lowercase letter, an uppercase letter, and a symbol.' : undefined}
                      placeholder={mode === 'register' ? '6+ chars: Aa and a symbol' : 'Enter your password'}
                      className={INPUT_CLS + ' pr-10'}
                    />
                    <button type="button" onClick={() => setShowPass(!showPass)} className="absolute right-3 top-1/2 -translate-y-1/2 text-neutral-400 hover:text-neutral-600 no-lift">
                      {showPass ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                  {mode === 'login' && (
                    <button
                      type="button"
                      onClick={() => { setForgot(true); setForgotStep('email'); setForgotError(''); }}
                      className="mt-2 text-xs font-medium text-primary-600 hover:text-primary-700 transition-colors no-lift"
                    >
                      Forgot password?
                    </button>
                  )}
                </div>

                {error && <ErrorBanner message={error} />}

                <button type="submit" disabled={loading} className={BTN_PRIMARY}>
                  {loading ? 'Please wait...' : mode === 'login' ? 'Sign In' : 'Create Account'}
                </button>

                <div className="relative py-1">
                  <div className="absolute inset-0 flex items-center"><div className="w-full border-t border-neutral-200" /></div>
                  <div className="relative flex justify-center"><span className="bg-white px-3 text-xs text-neutral-400">or continue with</span></div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <button type="button" onClick={() => startOAuth('google')} disabled={loading} className={BTN_OUTLINE}>
                    {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : (
                      <svg className="w-4 h-4" viewBox="0 0 24 24">
                        <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                        <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                        <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/>
                        <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
                      </svg>
                    )}
                    Google
                  </button>
                  <button type="button" onClick={() => startOAuth('apple')} disabled={loading} className={BTN_OUTLINE}>
                    {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : (
                      <svg className="w-4 h-4" viewBox="0 0 24 24" fill="currentColor">
                        <path d="M17.05 20.28c-.98.95-2.05.88-3.08.4-1.09-.5-2.08-.48-3.24 0-1.44.62-2.2.44-3.06-.4C2.79 15.25 3.51 7.59 9.05 7.31c1.35.07 2.29.74 3.08.8 1.18-.24 2.31-.93 3.57-.84 1.51.12 2.65.72 3.4 1.8-3.12 1.87-2.38 5.98.48 7.13-.57 1.5-1.31 2.99-2.54 4.09zM12.03 7.25c-.15-2.23 1.66-4.07 3.74-4.25.29 2.58-2.34 4.5-3.74 4.25z"/>
                      </svg>
                    )}
                    Apple
                  </button>
                </div>
              </form>
              {mode === 'login' && (
                <div className="px-6 sm:px-8 pb-5 -mt-1">
                  <p className="text-center text-xs text-neutral-400">
                    Drivers: sign in with the credentials your lab provided.
                  </p>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </FormShell>
  );
}

function ErrorBanner({ message }: { message: string }) {
  return (
    <div className="bg-red-50 border border-red-200/80 text-red-600 text-sm rounded-xl px-3.5 py-2.5">
      <p>{message}</p>
    </div>
  );
}
