import { useEffect, useState, useCallback, useMemo } from 'react';
import { supabase, Profile, Order } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import {
  Users, TrendingUp, Clock, Award, ChevronDown, Calendar,
  BarChart3, Target, X, ChevronRight, Pencil, Check,
  Eye,
} from 'lucide-react';
import { CountUp } from '../lib/CountUp';
import {
  BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer,
  AreaChart, Area, Cell,
} from 'recharts';

/* ── types ── */

interface Technician {
  technician_id: string;
  monthly_target_units: number | null;
  technician_profile: Profile;
}

interface HistoryOrder extends Order {
  from_profile?: Profile;
}

/* ── constants ── */

const CHART_COLORS = [
  '#3b82f6', '#10b981', '#f59e0b', '#f43f5e',
  '#06b6d4', '#8b5cf6', '#ec4899', '#84cc16',
];

const DONE_STATUSES = ['completed', 'delivered', 'delivering'];

/* ── helpers ── */

function countTeeth(teethStr: string | null): number {
  if (!teethStr) return 0;
  let count = 0;
  for (const part of teethStr.split(',')) {
    const trimmed = part.trim();
    if (!trimmed) continue;
    if (trimmed.includes('-')) {
      count += trimmed.split('-').filter(s => !isNaN(Number(s.trim()))).length;
    } else if (!isNaN(Number(trimmed))) {
      count += 1;
    }
  }
  return count;
}

function teethForOrder(o: Order): number {
  if (o.order_services?.length) {
    return o.order_services.reduce((sum, os) => sum + countTeeth(os.teeth_numbers), 0);
  }
  return countTeeth(o.teeth_numbers);
}

function monthLabel(date: Date) {
  return date.toLocaleString('default', { month: 'long', year: 'numeric' });
}

function dayLabel(dateStr: string) {
  const d = new Date(dateStr);
  return `${d.getDate()}/${d.getMonth() + 1}`;
}

function monthRange(monthStr: string) {
  const [y, m] = monthStr.split('-').map(Number);
  const start = `${monthStr}-01`;
  const last = new Date(y, m, 0).getDate();
  const end = `${monthStr}-${String(last).padStart(2, '0')}`;
  return { start, end, daysInMonth: last, y, m };
}

/* ── main component ── */

interface Props {
  onOpenOrder?: (orderId: string) => void;
}

export default function TechnicianAnalytics({ onOpenOrder }: Props) {
  const { profile } = useAuth();
  const [technicians, setTechnicians] = useState<Technician[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [historicOrders, setHistoricOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedTechId, setSelectedTechId] = useState<string>('all');
  const [month, setMonth] = useState(() => {
    const now = new Date();
    return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
  });
  const [showTechDropdown, setShowTechDropdown] = useState(false);
  const [showMonthDropdown, setShowMonthDropdown] = useState(false);

  // History panel
  const [historyTechId, setHistoryTechId] = useState<string | null>(null);
  const [historyOrders, setHistoryOrders] = useState<HistoryOrder[]>([]);
  const [historyLoading, setHistoryLoading] = useState(false);

  // Inline target editing
  const [editingTargetId, setEditingTargetId] = useState<string | null>(null);
  const [editingTargetValue, setEditingTargetValue] = useState('');

  const { start: monthStart, end: monthEnd, daysInMonth, y: curY, m: curM } = useMemo(() => monthRange(month), [month]);

  const monthOptions = useMemo(() => {
    const opts: { value: string; label: string }[] = [];
    const now = new Date();
    for (let i = 0; i < 12; i++) {
      const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
      const val = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
      opts.push({ value: val, label: monthLabel(d) });
    }
    return opts;
  }, []);

  // Fetch current month orders + technicians
  const fetchData = useCallback(async () => {
    if (!profile) return;
    setLoading(true);
    const [techRes, ordersRes] = await Promise.all([
      supabase
        .from('lab_technicians')
        .select('technician_id, monthly_target_units, technician_profile:profiles!lab_technicians_technician_id_fkey(id, name, phone, avatar_url)')
        .eq('lab_id', profile.id),
      supabase
        .from('orders')
        .select('*, order_services(*, service:services(*))')
        .eq('lab_id', profile.id)
        .not('assigned_technician_id', 'is', null)
        .in('status', DONE_STATUSES)
        .gte('finished_at', monthStart)
        .lte('finished_at', `${monthEnd}T23:59:59`),
    ]);
    setTechnicians((techRes.data as any) ?? []);
    setOrders((ordersRes.data as Order[]) ?? []);
    setLoading(false);
  }, [profile, monthStart, monthEnd]);

  // Fetch previous 3 months for auto target calculation
  const fetchHistoricOrders = useCallback(async () => {
    if (!profile) return;
    const now = new Date(curY, curM - 1, 1); // first of selected month
    const threeMonthsAgo = new Date(now.getFullYear(), now.getMonth() - 3, 1);
    const histStart = `${threeMonthsAgo.getFullYear()}-${String(threeMonthsAgo.getMonth() + 1).padStart(2, '0')}-01`;
    const histEnd = new Date(now.getTime() - 1);
    const histEndStr = `${histEnd.getFullYear()}-${String(histEnd.getMonth() + 1).padStart(2, '0')}-${String(histEnd.getDate()).padStart(2, '0')}`;

    const { data } = await supabase
      .from('orders')
      .select('assigned_technician_id, teeth_numbers, order_services(teeth_numbers), finished_at')
      .eq('lab_id', profile.id)
      .not('assigned_technician_id', 'is', null)
      .in('status', DONE_STATUSES)
      .gte('finished_at', histStart)
      .lte('finished_at', `${histEndStr}T23:59:59`);
    setHistoricOrders((data as any) ?? []);
  }, [profile, curY, curM]);

  useEffect(() => { fetchData(); }, [fetchData]);
  useEffect(() => { fetchHistoricOrders(); }, [fetchHistoricOrders]);

  // Compute auto targets from rolling 3-month average
  const autoTargets = useMemo(() => {
    const map = new Map<string, number>();
    for (const o of historicOrders) {
      if (!o.assigned_technician_id) continue;
      const teeth = teethForOrder(o);
      map.set(o.assigned_technician_id, (map.get(o.assigned_technician_id) ?? 0) + teeth);
    }
    const result = new Map<string, number>();
    for (const [id, total] of map) {
      result.set(id, Math.round(total / 3));
    }
    return result;
  }, [historicOrders]);

  function getTarget(tech: Technician): number {
    if (tech.monthly_target_units != null && tech.monthly_target_units > 0) return tech.monthly_target_units;
    return autoTargets.get(tech.technician_id) ?? 0;
  }

  // Filter orders by selected technician
  const filtered = useMemo(() =>
    selectedTechId === 'all' ? orders : orders.filter(o => o.assigned_technician_id === selectedTechId),
  [orders, selectedTechId]);

  const totalTeeth = useMemo(() => filtered.reduce((sum, o) => sum + teethForOrder(o), 0), [filtered]);

  const avgCompletionDays = useMemo(() => {
    const durations: number[] = [];
    for (const o of filtered) {
      if (o.finished_at && o.created_at) {
        durations.push((new Date(o.finished_at).getTime() - new Date(o.created_at).getTime()) / 86_400_000);
      }
    }
    return durations.length ? durations.reduce((a, b) => a + b, 0) / durations.length : 0;
  }, [filtered]);

  const topTechnician = useMemo(() => {
    if (!technicians.length) return null;
    const counts = new Map<string, number>();
    for (const o of orders) {
      if (!o.assigned_technician_id) continue;
      counts.set(o.assigned_technician_id, (counts.get(o.assigned_technician_id) ?? 0) + teethForOrder(o));
    }
    let topId = '', topCount = 0;
    for (const [id, c] of counts) { if (c > topCount) { topId = id; topCount = c; } }
    const tech = technicians.find(t => t.technician_id === topId);
    return tech ? { profile: tech.technician_profile, count: topCount } : null;
  }, [orders, technicians]);

  const serviceBreakdown = useMemo(() => {
    const map = new Map<string, number>();
    for (const o of filtered) {
      if (o.order_services?.length) {
        for (const os of o.order_services) {
          const name = os.service?.name ?? os.service_name ?? 'Other';
          map.set(name, (map.get(name) ?? 0) + countTeeth(os.teeth_numbers));
        }
      } else {
        const name = (o as any).service?.name ?? 'General';
        map.set(name, (map.get(name) ?? 0) + countTeeth(o.teeth_numbers));
      }
    }
    return Array.from(map.entries()).map(([name, value]) => ({ name, value })).sort((a, b) => b.value - a.value);
  }, [filtered]);

  const dailyTrend = useMemo(() => {
    const map = new Map<string, number>();
    for (let d = 1; d <= daysInMonth; d++) {
      map.set(`${month}-${String(d).padStart(2, '0')}`, 0);
    }
    for (const o of filtered) {
      if (!o.finished_at) continue;
      const key = o.finished_at.slice(0, 10);
      if (map.has(key)) map.set(key, (map.get(key) ?? 0) + teethForOrder(o));
    }
    return Array.from(map.entries()).map(([date, units]) => ({ date, units, label: dayLabel(date) }));
  }, [filtered, month, daysInMonth]);

  const techPerformance = useMemo(() => {
    return technicians.map(t => {
      const techOrders = orders.filter(o => o.assigned_technician_id === t.technician_id);
      const teeth = techOrders.reduce((sum, o) => sum + teethForOrder(o), 0);
      const durations: number[] = [];
      for (const o of techOrders) {
        if (o.finished_at && o.created_at) {
          durations.push((new Date(o.finished_at).getTime() - new Date(o.created_at).getTime()) / 86_400_000);
        }
      }
      const target = getTarget(t);
      const pct = target > 0 ? Math.min(100, Math.round((teeth / target) * 100)) : 0;
      return {
        id: t.technician_id,
        profile: t.technician_profile,
        teeth,
        orders: techOrders.length,
        avgDays: durations.length ? durations.reduce((a, b) => a + b, 0) / durations.length : 0,
        target,
        pct,
        isManualTarget: t.monthly_target_units != null && t.monthly_target_units > 0,
      };
    }).sort((a, b) => b.teeth - a.teeth);
  }, [orders, technicians, autoTargets]);

  // Save target
  const saveTarget = async (techId: string) => {
    const val = editingTargetValue.trim();
    const numVal = val === '' ? null : parseInt(val, 10);
    if (val !== '' && (isNaN(numVal!) || numVal! < 0)) return;

    await supabase
      .from('lab_technicians')
      .update({ monthly_target_units: numVal })
      .eq('lab_id', profile!.id)
      .eq('technician_id', techId);

    setEditingTargetId(null);
    fetchData();
  };

  // Open history panel
  const openHistory = async (techId: string) => {
    setHistoryTechId(techId);
    setHistoryLoading(true);
    const { data } = await supabase
      .from('orders')
      .select('*, from_profile:profiles!orders_from_id_fkey(id, name, avatar_url), order_services(*, service:services(*))')
      .eq('lab_id', profile!.id)
      .eq('assigned_technician_id', techId)
      .in('status', DONE_STATUSES)
      .gte('finished_at', monthStart)
      .lte('finished_at', `${monthEnd}T23:59:59`)
      .order('finished_at', { ascending: false });
    setHistoryOrders((data as HistoryOrder[]) ?? []);
    setHistoryLoading(false);
  };

  const historyTech = technicians.find(t => t.technician_id === historyTechId);
  const currentMonthLabel = monthOptions.find(o => o.value === month)?.label ?? month;

  if (loading) {
    return (
      <div className="p-6 max-w-5xl mx-auto">
        <div className="flex flex-col items-center justify-center py-20">
          <div className="w-10 h-10 border-2 border-primary-200 border-t-primary-600 rounded-full animate-spin" />
          <p className="text-sm text-neutral-400 mt-3">Loading analytics...</p>
        </div>
      </div>
    );
  }

  if (!technicians.length) {
    return (
      <div className="p-6 max-w-5xl mx-auto">
        <div className="bg-white rounded-2xl shadow-card p-8 text-center">
          <Users className="w-12 h-12 text-neutral-300 mx-auto mb-3" />
          <h2 className="font-display text-lg font-bold text-neutral-900 mb-1">No Technicians Yet</h2>
          <p className="text-sm text-neutral-500">Add technicians to your lab to start tracking performance.</p>
        </div>
      </div>
    );
  }

  return (
    <>
      <div className="p-4 sm:p-6 max-w-5xl mx-auto space-y-5">
        {/* Header */}
        <div>
          <h1 className="font-display text-xl sm:text-2xl font-bold text-neutral-900">Team Analytics</h1>
          <p className="text-sm text-neutral-500 mt-0.5">Track technician performance and production</p>
        </div>

        {/* Filters */}
        <div className="flex flex-wrap gap-3">
          {/* Month picker */}
          <div className="relative">
            <button
              type="button"
              onClick={() => { setShowMonthDropdown(v => !v); setShowTechDropdown(false); }}
              className="flex items-center gap-2 bg-white border border-neutral-200 rounded-xl px-3.5 py-2 text-sm font-medium text-neutral-700 hover:border-primary-300 transition-colors shadow-sm"
            >
              <Calendar className="w-4 h-4 text-primary-500" />
              {currentMonthLabel}
              <ChevronDown className="w-3.5 h-3.5 text-neutral-400" />
            </button>
            {showMonthDropdown && (
              <>
                <div className="fixed inset-0 z-30" onClick={() => setShowMonthDropdown(false)} />
                <div className="absolute top-full left-0 mt-1 z-40 bg-white border border-neutral-200 rounded-xl shadow-lg py-1 w-48 max-h-60 overflow-y-auto">
                  {monthOptions.map(opt => (
                    <button
                      key={opt.value}
                      onClick={() => { setMonth(opt.value); setShowMonthDropdown(false); }}
                      className={`w-full text-left px-3.5 py-2 text-sm transition-colors ${
                        opt.value === month ? 'bg-primary-50 text-primary-700 font-semibold' : 'text-neutral-700 hover:bg-neutral-50'
                      }`}
                    >
                      {opt.label}
                    </button>
                  ))}
                </div>
              </>
            )}
          </div>

          {/* Technician selector */}
          <div className="relative">
            <button
              type="button"
              onClick={() => { setShowTechDropdown(v => !v); setShowMonthDropdown(false); }}
              className="flex items-center gap-2 bg-white border border-neutral-200 rounded-xl px-3.5 py-2 text-sm font-medium text-neutral-700 hover:border-primary-300 transition-colors shadow-sm"
            >
              <Users className="w-4 h-4 text-primary-500" />
              {selectedTechId === 'all'
                ? 'All Technicians'
                : technicians.find(t => t.technician_id === selectedTechId)?.technician_profile.name ?? 'Unknown'}
              <ChevronDown className="w-3.5 h-3.5 text-neutral-400" />
            </button>
            {showTechDropdown && (
              <>
                <div className="fixed inset-0 z-30" onClick={() => setShowTechDropdown(false)} />
                <div className="absolute top-full left-0 mt-1 z-40 bg-white border border-neutral-200 rounded-xl shadow-lg py-1 w-56 max-h-60 overflow-y-auto">
                  <button
                    onClick={() => { setSelectedTechId('all'); setShowTechDropdown(false); }}
                    className={`w-full text-left px-3.5 py-2 text-sm transition-colors ${
                      selectedTechId === 'all' ? 'bg-primary-50 text-primary-700 font-semibold' : 'text-neutral-700 hover:bg-neutral-50'
                    }`}
                  >
                    All Technicians
                  </button>
                  {technicians.map(t => (
                    <button
                      key={t.technician_id}
                      onClick={() => { setSelectedTechId(t.technician_id); setShowTechDropdown(false); }}
                      className={`w-full text-left px-3.5 py-2 text-sm transition-colors flex items-center gap-2 ${
                        selectedTechId === t.technician_id ? 'bg-primary-50 text-primary-700 font-semibold' : 'text-neutral-700 hover:bg-neutral-50'
                      }`}
                    >
                      {t.technician_profile.avatar_url ? (
                        <img src={t.technician_profile.avatar_url} className="w-5 h-5 rounded-full object-cover" alt="" />
                      ) : (
                        <div className="w-5 h-5 rounded-full bg-primary-100 flex items-center justify-center text-[9px] font-bold text-primary-600">
                          {t.technician_profile.name?.[0] ?? '?'}
                        </div>
                      )}
                      {t.technician_profile.name}
                    </button>
                  ))}
                </div>
              </>
            )}
          </div>
        </div>

        {/* KPI Cards */}
        <div className="grid grid-cols-2 lg:grid-cols-3 gap-3 sm:gap-4">
          <div className="bg-white rounded-2xl p-4 sm:p-5 shadow-card animate-rise-in">
            <div className="w-10 h-10 bg-primary-50 rounded-xl flex items-center justify-center">
              <Target className="w-5 h-5 text-primary-600" />
            </div>
            <p className="text-2xl sm:text-3xl font-bold text-neutral-900 mt-3"><CountUp value={totalTeeth} /></p>
            <p className="text-xs sm:text-sm text-neutral-500 mt-0.5">Units Completed</p>
          </div>

          <div className="bg-white rounded-2xl p-4 sm:p-5 shadow-card animate-rise-in" style={{ animationDelay: '70ms' }}>
            <div className="w-10 h-10 bg-teal-50 rounded-xl flex items-center justify-center">
              <Clock className="w-5 h-5 text-teal-600" />
            </div>
            <p className="text-2xl sm:text-3xl font-bold text-neutral-900 mt-3">{avgCompletionDays.toFixed(1)}</p>
            <p className="text-xs sm:text-sm text-neutral-500 mt-0.5">Avg. Days / Order</p>
          </div>

          <div className="col-span-2 lg:col-span-1 bg-gradient-to-br from-amber-50 to-white rounded-2xl p-4 sm:p-5 shadow-card border border-amber-100 animate-rise-in" style={{ animationDelay: '140ms' }}>
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-amber-100 rounded-xl flex items-center justify-center">
                <Award className="w-5 h-5 text-amber-600" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-xs text-amber-600 font-semibold uppercase tracking-wide">Top Performer</p>
                {topTechnician ? (
                  <div className="flex items-center gap-2 mt-1">
                    {topTechnician.profile.avatar_url ? (
                      <img src={topTechnician.profile.avatar_url} className="w-7 h-7 rounded-full object-cover flex-shrink-0" alt="" />
                    ) : (
                      <div className="w-7 h-7 rounded-full bg-amber-200 flex items-center justify-center text-xs font-bold text-amber-700 flex-shrink-0">
                        {topTechnician.profile.name?.[0] ?? '?'}
                      </div>
                    )}
                    <div className="min-w-0">
                      <p className="text-sm font-bold text-neutral-900 truncate">{topTechnician.profile.name}</p>
                      <p className="text-xs text-amber-700">{topTechnician.count} units</p>
                    </div>
                  </div>
                ) : (
                  <p className="text-sm text-neutral-400 mt-1">No data yet</p>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Charts */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {/* Service Breakdown */}
          <div className="bg-white rounded-2xl p-4 sm:p-5 shadow-card">
            <h3 className="font-display text-sm font-bold text-neutral-900 mb-4 flex items-center gap-2">
              <BarChart3 className="w-4 h-4 text-primary-500" />
              Units by Service
            </h3>
            {serviceBreakdown.length > 0 ? (
              <div className="h-56">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={serviceBreakdown.slice(0, 8)} layout="vertical" margin={{ left: 0, right: 12, top: 0, bottom: 0 }}>
                    <XAxis type="number" tick={{ fontSize: 11, fill: '#9ca3af' }} axisLine={false} tickLine={false} />
                    <YAxis dataKey="name" type="category" width={90} tick={{ fontSize: 11, fill: '#525252' }} axisLine={false} tickLine={false} />
                    <Tooltip contentStyle={{ borderRadius: 12, border: '1px solid #e5e7eb', fontSize: 13 }} formatter={(v: number) => [`${v} units`, 'Completed']} />
                    <Bar dataKey="value" radius={[0, 6, 6, 0]} maxBarSize={24}>
                      {serviceBreakdown.slice(0, 8).map((_, i) => (
                        <Cell key={i} fill={CHART_COLORS[i % CHART_COLORS.length]} />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </div>
            ) : (
              <div className="h-56 flex items-center justify-center">
                <p className="text-sm text-neutral-400">No completed work this period</p>
              </div>
            )}
          </div>

          {/* Daily Trend */}
          <div className="bg-white rounded-2xl p-4 sm:p-5 shadow-card">
            <h3 className="font-display text-sm font-bold text-neutral-900 mb-4 flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-teal-500" />
              Daily Production
            </h3>
            <div className="h-56">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={dailyTrend} margin={{ left: -10, right: 8, top: 4, bottom: 0 }}>
                  <defs>
                    <linearGradient id="trendGrad" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.2} />
                      <stop offset="95%" stopColor="#3b82f6" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <XAxis dataKey="label" tick={{ fontSize: 10, fill: '#9ca3af' }} axisLine={false} tickLine={false} interval={Math.max(0, Math.floor(dailyTrend.length / 8) - 1)} />
                  <YAxis tick={{ fontSize: 11, fill: '#9ca3af' }} axisLine={false} tickLine={false} />
                  <Tooltip contentStyle={{ borderRadius: 12, border: '1px solid #e5e7eb', fontSize: 13 }} formatter={(v: number) => [`${v} units`, 'Completed']} labelFormatter={(l) => `Day ${l}`} />
                  <Area type="monotone" dataKey="units" stroke="#3b82f6" strokeWidth={2} fill="url(#trendGrad)" dot={false} activeDot={{ r: 4, fill: '#3b82f6' }} />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>

        {/* Team Performance */}
        <div className="bg-white rounded-2xl shadow-card overflow-hidden">
          <div className="px-4 sm:px-5 py-4 border-b border-neutral-200/60">
            <h3 className="font-display text-sm font-bold text-neutral-900 flex items-center gap-2">
              <Users className="w-4 h-4 text-primary-500" />
              Team Performance
            </h3>
          </div>
          <div className="divide-y divide-neutral-50">
            {techPerformance.map((tech, idx) => (
              <div key={tech.id} className="px-4 sm:px-5 py-3.5 hover:bg-neutral-50/50 transition-colors">
                <div className="flex items-center gap-3">
                  {/* Avatar */}
                  <div className="relative flex-shrink-0">
                    {tech.profile.avatar_url ? (
                      <img src={tech.profile.avatar_url} className="w-10 h-10 rounded-xl object-cover" alt="" />
                    ) : (
                      <div className="w-10 h-10 rounded-xl bg-primary-50 flex items-center justify-center text-sm font-bold text-primary-600">
                        {tech.profile.name?.[0] ?? '?'}
                      </div>
                    )}
                    {idx === 0 && techPerformance.length > 1 && (
                      <span className="absolute -top-1 -right-1 w-4 h-4 bg-amber-400 rounded-full flex items-center justify-center">
                        <Award className="w-2.5 h-2.5 text-white" />
                      </span>
                    )}
                  </div>

                  {/* Info */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 justify-between">
                      <p className="text-sm font-semibold text-neutral-900 truncate">{tech.profile.name}</p>
                      <div className="flex items-center gap-2 flex-shrink-0">
                        {/* Target badge */}
                        {editingTargetId === tech.id ? (
                          <div className="flex items-center gap-1">
                            <input
                              type="number"
                              min={0}
                              value={editingTargetValue}
                              onChange={e => setEditingTargetValue(e.target.value)}
                              onKeyDown={e => { if (e.key === 'Enter') saveTarget(tech.id); if (e.key === 'Escape') setEditingTargetId(null); }}
                              className="w-16 text-xs border border-primary-300 rounded-lg px-2 py-1 text-center focus:outline-none focus:ring-1 focus:ring-primary-400"
                              placeholder="Auto"
                              autoFocus
                            />
                            <button onClick={() => saveTarget(tech.id)} className="w-5 h-5 rounded-md bg-primary-500 text-white flex items-center justify-center hover:bg-primary-600 transition-colors">
                              <Check className="w-3 h-3" />
                            </button>
                            <button onClick={() => setEditingTargetId(null)} className="w-5 h-5 rounded-md bg-neutral-200 text-neutral-600 flex items-center justify-center hover:bg-neutral-300 transition-colors">
                              <X className="w-3 h-3" />
                            </button>
                          </div>
                        ) : (
                          <button
                            onClick={() => { setEditingTargetId(tech.id); setEditingTargetValue(tech.isManualTarget ? String(tech.target) : ''); }}
                            className="flex items-center gap-1 text-[10px] font-medium text-neutral-500 hover:text-primary-600 transition-colors group"
                          >
                            <Target className="w-3 h-3" />
                            <span>{tech.target > 0 ? `${tech.target}u` : 'No target'}</span>
                            {tech.isManualTarget && <span className="text-primary-400">(set)</span>}
                            <Pencil className="w-2.5 h-2.5 opacity-0 group-hover:opacity-100 transition-opacity" />
                          </button>
                        )}
                      </div>
                    </div>

                    {/* Progress bar */}
                    <div className="mt-1.5 flex items-center gap-2.5">
                      <div className="flex-1 h-2 bg-neutral-100 rounded-full overflow-hidden">
                        <div
                          className="h-full rounded-full transition-all duration-700 ease-out"
                          style={{
                            width: `${tech.target > 0 ? tech.pct : 0}%`,
                            backgroundColor: CHART_COLORS[idx % CHART_COLORS.length],
                          }}
                        />
                      </div>
                      {tech.target > 0 && (
                        <span className="text-xs font-bold tabular-nums w-10 text-right" style={{ color: CHART_COLORS[idx % CHART_COLORS.length] }}>
                          {tech.pct}%
                        </span>
                      )}
                      <span className="text-[11px] font-semibold text-neutral-600 tabular-nums">{tech.teeth}u</span>
                    </div>
                  </div>

                  {/* Desktop stats + actions */}
                  <div className="hidden sm:flex items-center gap-3 flex-shrink-0">
                    <div className="text-right">
                      <p className="text-[10px] text-neutral-400">Orders</p>
                      <p className="text-sm font-bold text-neutral-900">{tech.orders}</p>
                    </div>
                    <div className="text-right">
                      <p className="text-[10px] text-neutral-400">Avg Days</p>
                      <p className="text-sm font-bold text-neutral-900">{tech.avgDays.toFixed(1)}</p>
                    </div>
                    <button
                      onClick={() => openHistory(tech.id)}
                      className="flex items-center gap-1 text-xs font-medium text-primary-600 hover:text-primary-700 bg-primary-50 hover:bg-primary-100 rounded-lg px-2.5 py-1.5 transition-colors"
                    >
                      <Eye className="w-3.5 h-3.5" />
                      History
                    </button>
                  </div>
                </div>

                {/* Mobile action row */}
                <div className="sm:hidden flex items-center justify-between mt-2 pt-2 border-t border-neutral-200/60">
                  <div className="flex items-center gap-4 text-xs text-neutral-500">
                    <span>{tech.orders} orders</span>
                    <span>{tech.avgDays.toFixed(1)} avg days</span>
                  </div>
                  <button
                    onClick={() => openHistory(tech.id)}
                    className="flex items-center gap-1 text-xs font-medium text-primary-600 hover:text-primary-700 transition-colors"
                  >
                    <Eye className="w-3.5 h-3.5" />
                    View History
                    <ChevronRight className="w-3 h-3" />
                  </button>
                </div>
              </div>
            ))}
            {techPerformance.length === 0 && (
              <div className="px-5 py-8 text-center text-sm text-neutral-400">No team data for this period</div>
            )}
          </div>
        </div>
      </div>

      {/* ── History Slide-Over Panel ── */}
      {historyTechId && (
        <>
          <div className="fixed inset-0 bg-black/40 backdrop-blur-sm z-40 transition-opacity" onClick={() => setHistoryTechId(null)} />
          <div className="fixed top-0 right-0 bottom-0 w-full max-w-md bg-white shadow-2xl z-50 flex flex-col animate-slide-in-right">
            {/* Panel header */}
            <div className="flex items-center gap-3 px-5 py-4 border-b border-neutral-200/60 pt-[max(env(safe-area-inset-top,16px),16px)]">
              {historyTech?.technician_profile.avatar_url ? (
                <img src={historyTech.technician_profile.avatar_url} className="w-9 h-9 rounded-xl object-cover" alt="" />
              ) : (
                <div className="w-9 h-9 rounded-xl bg-primary-50 flex items-center justify-center text-sm font-bold text-primary-600">
                  {historyTech?.technician_profile.name?.[0] ?? '?'}
                </div>
              )}
              <div className="flex-1 min-w-0">
                <p className="text-sm font-bold text-neutral-900 truncate">{historyTech?.technician_profile.name}</p>
                <p className="text-xs text-neutral-400">{currentMonthLabel}</p>
              </div>
              <button onClick={() => setHistoryTechId(null)} className="w-8 h-8 rounded-lg bg-neutral-100 hover:bg-neutral-200 flex items-center justify-center transition-colors">
                <X className="w-4 h-4 text-neutral-600" />
              </button>
            </div>

            {/* Panel body */}
            <div className="flex-1 overflow-y-auto pb-[env(safe-area-inset-bottom,16px)]">
              {historyLoading ? (
                <div className="flex items-center justify-center py-16">
                  <div className="w-8 h-8 border-2 border-primary-200 border-t-primary-600 rounded-full animate-spin" />
                </div>
              ) : historyOrders.length === 0 ? (
                <div className="text-center py-16 text-sm text-neutral-400">No completed cases this month</div>
              ) : (
                <div className="divide-y divide-neutral-50">
                  {historyOrders.map(order => {
                    const teeth = teethForOrder(order);
                    const services = order.order_services?.length
                      ? order.order_services.map(os => os.service?.name ?? os.service_name).join(', ')
                      : (order as any).service?.name ?? 'General';
                    const finDate = order.finished_at
                      ? new Date(order.finished_at).toLocaleDateString('default', { month: 'short', day: 'numeric' })
                      : '';
                    return (
                      <button
                        key={order.id}
                        type="button"
                        onClick={() => onOpenOrder?.(order.id)}
                        className="w-full text-left px-5 py-3.5 hover:bg-neutral-50 transition-colors group"
                      >
                        <div className="flex items-start justify-between gap-3">
                          <div className="min-w-0 flex-1">
                            <p className="text-sm font-semibold text-neutral-900 truncate group-hover:text-primary-600 transition-colors">
                              {order.patient_name}
                            </p>
                            <p className="text-xs text-neutral-500 mt-0.5 truncate">{services}</p>
                            <div className="flex items-center gap-3 mt-1.5 text-[11px] text-neutral-400">
                              {order.shade && <span className="bg-neutral-100 rounded px-1.5 py-0.5">{order.shade}</span>}
                              {finDate && <span>{finDate}</span>}
                              {order.from_profile?.name && <span className="truncate">{order.from_profile.name}</span>}
                            </div>
                          </div>
                          <div className="flex flex-col items-end gap-1 flex-shrink-0">
                            <span className="text-xs font-bold text-primary-600 bg-primary-50 rounded-md px-2 py-0.5">{teeth}u</span>
                            <ChevronRight className="w-3.5 h-3.5 text-neutral-300 group-hover:text-primary-400 transition-colors" />
                          </div>
                        </div>
                      </button>
                    );
                  })}
                </div>
              )}
            </div>
          </div>
        </>
      )}
    </>
  );
}
