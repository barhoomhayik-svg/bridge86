import React, { useState, useEffect, useCallback } from 'react';
import { supabase, Order, OrderStatus, Profile } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import OrderDetailModal from '../components/OrderDetailModal';
import { Wrench, ClipboardList, Clock, CheckCircle2, Package, AlertTriangle, Search, Filter } from 'lucide-react';

const STATUS_LABELS: Record<OrderStatus, string> = {
  pending: 'Pending', accepted: 'Accepted', in_progress: 'In Progress',
  completed: 'Completed', try_in: 'Try In', delivering: 'Delivering', delivered: 'Delivered',
  rejected: 'Rejected', cancelled: 'Cancelled', redo: 'Redo',
};

const statusColor: Record<OrderStatus, string> = {
  pending:     'bg-amber-50 text-amber-700 border-amber-200',
  accepted:    'bg-blue-50 text-blue-700 border-blue-200',
  in_progress: 'bg-primary-50 text-primary-700 border-primary-200',
  completed:   'bg-teal-50 text-teal-700 border-teal-200',
  try_in:      'bg-amber-50 text-amber-700 border-amber-300',
  delivering:  'bg-cyan-50 text-cyan-700 border-cyan-200',
  delivered:   'bg-emerald-50 text-emerald-700 border-emerald-200',
  rejected:    'bg-red-50 text-red-700 border-red-200',
  cancelled:   'bg-neutral-100 text-neutral-600 border-neutral-200',
  redo:        'bg-orange-50 text-orange-700 border-orange-200',
};

export default function TechnicianDashboard() {
  const { profile } = useAuth();
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const [filter, setFilter] = useState<'active' | 'all'>('active');
  const [search, setSearch] = useState('');
  const [labProfile, setLabProfile] = useState<Profile | null>(null);

  const fetchOrders = useCallback(async () => {
    if (!profile) return;
    const { data } = await supabase
      .from('orders')
      .select('*, from_profile:profiles!orders_from_id_fkey(*), lab_profile:profiles!orders_lab_id_fkey(*), service:services(*), attachments:order_attachments(*), order_services(*, service:services(*))')
      .eq('assigned_technician_id', profile.id)
      .order('updated_at', { ascending: false });
    setOrders(data as Order[] ?? []);
    setLoading(false);
  }, [profile]);

  useEffect(() => { fetchOrders(); }, [fetchOrders]);

  useEffect(() => {
    if (!profile) return;
    supabase
      .from('lab_technicians')
      .select('lab_id, lab_profile:profiles!lab_technicians_lab_id_fkey(*)')
      .eq('technician_id', profile.id)
      .maybeSingle()
      .then(({ data }) => {
        if (data) setLabProfile((data as any).lab_profile as Profile);
      });
  }, [profile]);

  // Realtime: listen for updates on orders assigned to this technician
  useEffect(() => {
    if (!profile) return;
    const channel = supabase
      .channel(`tech_orders_rt:${profile.id}`)
      .on('postgres_changes', {
        event: '*',
        schema: 'public',
        table: 'orders',
        filter: `assigned_technician_id=eq.${profile.id}`,
      }, () => fetchOrders())
      .subscribe();
    return () => { supabase.removeChannel(channel); };
  }, [profile, fetchOrders]);

  const activeStatuses: OrderStatus[] = ['pending', 'accepted', 'in_progress', 'redo', 'try_in'];
  const filtered = orders.filter(o => {
    if (filter === 'active' && !activeStatuses.includes(o.status)) return false;
    if (search) {
      const q = search.toLowerCase();
      const match = (o.patient_name ?? '').toLowerCase().includes(q)
        || (o.order_number ?? '').toLowerCase().includes(q)
        || (o.file_number ?? '').toLowerCase().includes(q)
        || (o.dr_name ?? '').toLowerCase().includes(q);
      if (!match) return false;
    }
    return true;
  });

  const activeCount = orders.filter(o => activeStatuses.includes(o.status)).length;
  const completedCount = orders.filter(o => o.status === 'completed' || o.status === 'delivered').length;

  if (loading) {
    return (
      <div className="max-w-4xl mx-auto px-4 sm:px-6 py-6">
        <div className="space-y-3">
          {[1, 2, 3].map(i => (
            <div key={i} className="bg-white rounded-2xl h-24 animate-pulse shadow-card" />
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 py-6">
      {/* Header */}
      <div className="flex items-center gap-3 mb-6">
        <div className="w-11 h-11 bg-blue-100 rounded-2xl flex items-center justify-center">
          <Wrench className="w-6 h-6 text-blue-600" />
        </div>
        <div>
          <h1 className="font-display text-xl font-bold text-neutral-900">My Assigned Orders</h1>
          {labProfile && (
            <p className="text-sm text-neutral-500">Working at {labProfile.name}</p>
          )}
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-3 mb-6">
        <div className="bg-white rounded-2xl p-4 shadow-card">
          <div className="flex items-center gap-2">
            <ClipboardList className="w-5 h-5 text-blue-500" />
            <div>
              <p className="text-xl font-bold text-neutral-900">{orders.length}</p>
              <p className="text-xs text-neutral-500">Total</p>
            </div>
          </div>
        </div>
        <div className="bg-white rounded-2xl p-4 shadow-card">
          <div className="flex items-center gap-2">
            <Clock className="w-5 h-5 text-amber-500" />
            <div>
              <p className="text-xl font-bold text-neutral-900">{activeCount}</p>
              <p className="text-xs text-neutral-500">Active</p>
            </div>
          </div>
        </div>
        <div className="bg-white rounded-2xl p-4 shadow-card">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-5 h-5 text-emerald-500" />
            <div>
              <p className="text-xl font-bold text-neutral-900">{completedCount}</p>
              <p className="text-xs text-neutral-500">Done</p>
            </div>
          </div>
        </div>
      </div>

      {/* Filters */}
      <div className="flex items-center gap-3 mb-4">
        <div className="flex gap-1 bg-neutral-100 p-1 rounded-xl">
          <button
            onClick={() => setFilter('active')}
            className={`px-4 py-1.5 rounded-lg text-sm font-semibold transition-all ${filter === 'active' ? 'bg-white text-neutral-900 shadow-card' : 'text-neutral-500'}`}
          >
            Active
          </button>
          <button
            onClick={() => setFilter('all')}
            className={`px-4 py-1.5 rounded-lg text-sm font-semibold transition-all ${filter === 'all' ? 'bg-white text-neutral-900 shadow-card' : 'text-neutral-500'}`}
          >
            All
          </button>
        </div>
        <div className="flex-1 relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-neutral-400" />
          <input
            type="text"
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="Search orders..."
            className="w-full pl-9 pr-3 py-2 rounded-xl border border-neutral-200 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white"
          />
        </div>
      </div>

      {/* Orders list */}
      {filtered.length === 0 ? (
        <div className="text-center py-16">
          <div className="w-14 h-14 bg-neutral-100 rounded-2xl flex items-center justify-center mx-auto mb-3">
            <Package className="w-7 h-7 text-neutral-300" />
          </div>
          <p className="font-medium text-neutral-500">
            {filter === 'active' ? 'No active orders assigned to you' : 'No orders yet'}
          </p>
          <p className="text-sm text-neutral-400 mt-1">
            Orders assigned by the lab will appear here
          </p>
        </div>
      ) : (
        <div className="space-y-2">
          {filtered.map(order => {
            const services = order.order_services?.map(s => s.service_name).join(', ') || order.service?.name || '—';
            return (
              <button
                key={order.id}
                onClick={() => setSelectedOrder(order)}
                className="w-full text-left bg-white rounded-2xl p-4 shadow-card border border-transparent hover:border-blue-200 hover:shadow-md transition-all"
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-bold text-neutral-900 text-sm">{order.order_number}</span>
                      <span className={`text-[11px] font-semibold px-2 py-0.5 rounded-full border ${statusColor[order.status]}`}>
                        {STATUS_LABELS[order.status]}
                      </span>
                      {order.try_in && (
                        <span className="text-[11px] font-semibold px-2 py-0.5 rounded-full border bg-amber-50 text-amber-700 border-amber-300">
                          Try In
                        </span>
                      )}
                    </div>
                    <p className="text-sm text-neutral-600 mt-1 truncate">
                      {order.patient_name ?? '—'} {order.dr_name ? `· Dr. ${order.dr_name}` : ''}
                    </p>
                    <p className="text-xs text-neutral-400 mt-0.5 truncate">{services}</p>
                  </div>
                  <div className="text-right flex-shrink-0">
                    {order.due_date && (
                      <p className="text-xs text-neutral-500">
                        Due {new Date(order.due_date).toLocaleDateString([], { month: 'short', day: 'numeric' })}
                      </p>
                    )}
                    <p className="text-[11px] text-neutral-400 mt-0.5">
                      {new Date(order.updated_at).toLocaleDateString([], { month: 'short', day: 'numeric' })}
                    </p>
                  </div>
                </div>
              </button>
            );
          })}
        </div>
      )}

      {selectedOrder && (
        <OrderDetailModal
          order={selectedOrder}
          isLab={true}
          isTechnician={true}
          onClose={() => setSelectedOrder(null)}
          onStatusChange={() => { setSelectedOrder(null); fetchOrders(); }}
        />
      )}
    </div>
  );
}
