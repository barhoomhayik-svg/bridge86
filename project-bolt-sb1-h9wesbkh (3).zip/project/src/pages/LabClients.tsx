import React, { useEffect, useState, useMemo } from 'react';
import { supabase, Order, Profile } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { Search, Building2, Stethoscope, Microscope, ClipboardList, X, ChevronRight, Calendar, Receipt, Download, FileText, Eye } from 'lucide-react';
import OrderDetailModal from '../components/OrderDetailModal';
import { CountUp } from '../lib/CountUp';
import { escapeHtml } from '../lib/escapeHtml';

interface ClientInfo {
  profile: Profile;
  orderCount: number;
  lastOrderAt: string | null;
  pendingCount: number;
  completedCount: number;
}

const STATUS_CONFIG: Record<string, { label: string; color: string; bg: string }> = {
  pending:     { label: 'Pending',     color: 'text-amber-700',   bg: 'bg-amber-50 border-amber-200' },
  accepted:    { label: 'Accepted',    color: 'text-blue-700',    bg: 'bg-blue-50 border-blue-200' },
  in_progress: { label: 'In Progress', color: 'text-primary-700', bg: 'bg-primary-50 border-primary-200' },
  delivering:  { label: 'Delivering',  color: 'text-cyan-700',    bg: 'bg-cyan-50 border-cyan-200' },
  delivered:   { label: 'Delivered',   color: 'text-indigo-700',  bg: 'bg-indigo-50 border-indigo-200' },
  completed:   { label: 'Completed',   color: 'text-teal-700',    bg: 'bg-teal-50 border-teal-200' },
  rejected:    { label: 'Rejected',    color: 'text-red-700',     bg: 'bg-red-50 border-red-200' },
  cancelled:   { label: 'Cancelled',   color: 'text-neutral-600', bg: 'bg-neutral-50 border-neutral-200' },
  redo:        { label: 'Redo',        color: 'text-orange-700',  bg: 'bg-orange-50 border-orange-200' },
};

export default function LabClients() {
  const { profile } = useAuth();
  const [clients, setClients] = useState<ClientInfo[]>([]);
  const [ordersByClient, setOrdersByClient] = useState<Map<string, Order[]>>(new Map());
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [selectedClient, setSelectedClient] = useState<ClientInfo | null>(null);
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);

  useEffect(() => {
    if (!profile) return;
    (async () => {
      setLoading(true);
      const { data: orders } = await supabase
        .from('orders')
        .select('*, from_profile:profiles!orders_from_id_fkey(*), lab_profile:profiles!orders_lab_id_fkey(*), service:services(*), attachments:order_attachments(*), order_services(*, service:services(*))')
        .eq('lab_id', profile.id)
        .order('created_at', { ascending: false });

      if (!orders) { setLoading(false); return; }

      const byClient = new Map<string, Order[]>();
      for (const o of orders) {
        const arr = byClient.get(o.from_id) ?? [];
        arr.push(o);
        byClient.set(o.from_id, arr);
      }
      setOrdersByClient(byClient);

      const infos: ClientInfo[] = [];
      for (const [clientId, clientOrders] of byClient) {
        const p = clientOrders[0]?.from_profile;
        if (!p) continue;
        infos.push({
          profile: p,
          orderCount: clientOrders.length,
          lastOrderAt: clientOrders[0].created_at,
          pendingCount: clientOrders.filter(o => o.status === 'pending' || o.status === 'accepted' || o.status === 'in_progress').length,
          completedCount: clientOrders.filter(o => o.status === 'completed').length,
        });
      }
      infos.sort((a, b) => b.orderCount - a.orderCount);
      setClients(infos);
      setLoading(false);
    })();
  }, [profile]);

  const filtered = useMemo(() => {
    if (!search.trim()) return clients;
    const q = search.toLowerCase();
    return clients.filter(c => c.profile.name.toLowerCase().includes(q));
  }, [clients, search]);

  if (selectedClient) {
    return (
      <>
      <ClientDetail
        client={selectedClient}
        orders={ordersByClient.get(selectedClient.profile.id) ?? []}
        onBack={() => setSelectedClient(null)}
        onOpenOrder={(o) => setSelectedOrder(o)}
      />
      {selectedOrder && (
        <OrderDetailModal
          order={selectedOrder}
          isLab
          onClose={() => setSelectedOrder(null)}
          onStatusChange={async () => {
            if (!profile) return;
            const { data } = await supabase
              .from('orders')
              .select('*, from_profile:profiles!orders_from_id_fkey(*), lab_profile:profiles!orders_lab_id_fkey(*), service:services(*), attachments:order_attachments(*), order_services(*, service:services(*))')
              .eq('id', selectedOrder.id)
              .single();
            if (data) setSelectedOrder(data);
          }}
        />
      )}
      </>
    );
  }

  return (
    <div className="p-6 max-w-5xl mx-auto">
      <div className="mb-5">
        <h1 className="font-display text-2xl font-bold text-neutral-900">Our Clients</h1>
        <p className="text-neutral-500 text-sm mt-1">Centers and doctors who work with you</p>
      </div>

      {/* Summary stats */}
      <div className="grid grid-cols-3 gap-3 mb-5">
        <div className="bg-white rounded-2xl p-4 shadow-card animate-rise-in transition-transform duration-200 hover:-translate-y-0.5 hover:shadow-lg" style={{ animationDelay: '0ms' }}>
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 bg-primary-50 rounded-xl flex items-center justify-center">
              <Building2 className="w-4.5 h-4.5 text-primary-600" />
            </div>
            <div>
              <p className="text-xl font-bold text-neutral-900"><CountUp value={clients.filter(c => c.profile.role === 'center').length} /></p>
              <p className="text-xs text-neutral-500">Centers</p>
            </div>
          </div>
        </div>
        <div className="bg-white rounded-2xl p-4 shadow-card animate-rise-in transition-transform duration-200 hover:-translate-y-0.5 hover:shadow-lg" style={{ animationDelay: '70ms' }}>
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 bg-teal-50 rounded-xl flex items-center justify-center">
              <Stethoscope className="w-4.5 h-4.5 text-teal-600" />
            </div>
            <div>
              <p className="text-xl font-bold text-neutral-900"><CountUp value={clients.filter(c => c.profile.role === 'doctor').length} /></p>
              <p className="text-xs text-neutral-500">Doctors</p>
            </div>
          </div>
        </div>
        <div className="bg-white rounded-2xl p-4 shadow-card animate-rise-in transition-transform duration-200 hover:-translate-y-0.5 hover:shadow-lg" style={{ animationDelay: '140ms' }}>
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 bg-amber-50 rounded-xl flex items-center justify-center">
              <ClipboardList className="w-4.5 h-4.5 text-amber-600" />
            </div>
            <div>
              <p className="text-xl font-bold text-neutral-900"><CountUp value={clients.reduce((s, c) => s + c.orderCount, 0)} /></p>
              <p className="text-xs text-neutral-500">Total Orders</p>
            </div>
          </div>
        </div>
      </div>

      {/* Search */}
      <div className="relative mb-4">
        <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-neutral-400" />
        <input
          type="text"
          placeholder="Search by client name..."
          value={search}
          onChange={e => setSearch(e.target.value)}
          className="w-full pl-10 pr-9 py-2.5 rounded-xl border border-neutral-200 bg-white text-sm focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-transparent shadow-card"
        />
        {search && (
          <button onClick={() => setSearch('')} className="absolute right-3 top-1/2 -translate-y-1/2 text-neutral-400 hover:text-neutral-600">
            <X className="w-4 h-4" />
          </button>
        )}
      </div>

      {loading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {[1,2,3,4].map(i => <div key={i} className="bg-white rounded-xl h-28 animate-pulse shadow-card" />)}
        </div>
      ) : filtered.length === 0 ? (
        <div className="text-center py-16">
          <Building2 className="w-12 h-12 text-neutral-300 mx-auto mb-3" />
          <p className="text-neutral-500 font-medium">{search ? `No clients matching "${search}"` : 'No clients yet'}</p>
          <p className="text-neutral-400 text-sm">Orders from centers and doctors will appear here</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {filtered.map((c, i) => {
            const isCenter = c.profile.role === 'center';
            return (
              <button
                key={c.profile.id}
                onClick={() => setSelectedClient(c)}
                style={{ animationDelay: `${i * 40}ms` }}
                className="bg-white rounded-xl p-4 shadow-card hover:shadow-card-hover transition-all text-left flex items-center gap-4 group border border-transparent hover:border-primary-100 animate-rise-in hover:-translate-y-0.5 active:scale-[0.99]"
              >
                {c.profile.logo_url ? (
                  <img src={c.profile.logo_url} alt={c.profile.name} className="w-12 h-12 rounded-xl object-cover flex-shrink-0" />
                ) : (
                  <div className={`w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0 ${isCenter ? 'bg-primary-50' : 'bg-teal-50'}`}>
                    {isCenter
                      ? <Building2 className="w-6 h-6 text-primary-600" />
                      : <Stethoscope className="w-6 h-6 text-teal-600" />}
                  </div>
                )}
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-0.5">
                    <span className="font-semibold text-neutral-900 text-sm truncate">{c.profile.name}</span>
                    <span className={`text-[10px] font-semibold px-1.5 py-0.5 rounded-full ${isCenter ? 'bg-primary-50 text-primary-600' : 'bg-teal-50 text-teal-600'}`}>
                      {isCenter ? 'Center' : 'Doctor'}
                    </span>
                  </div>
                  {c.profile.city && (
                    <p className="text-xs text-neutral-500 truncate">{c.profile.city}</p>
                  )}
                  <div className="flex items-center gap-3 mt-1.5 text-xs">
                    <span className="text-neutral-600 font-medium">{c.orderCount} order{c.orderCount !== 1 ? 's' : ''}</span>
                    {c.pendingCount > 0 && (
                      <span className="text-amber-600 font-medium">{c.pendingCount} active</span>
                    )}
                    {c.completedCount > 0 && (
                      <span className="text-teal-600 font-medium">{c.completedCount} done</span>
                    )}
                  </div>
                </div>
                <ChevronRight className="w-4 h-4 text-neutral-300 group-hover:text-primary-500 transition-colors flex-shrink-0" />
              </button>
            );
          })}
        </div>
      )}
    </div>
  );
}

function ClientDetail({ client, orders, onBack, onOpenOrder }: { client: ClientInfo; orders: Order[]; onBack: () => void; onOpenOrder: (o: Order) => void }) {
  const isCenter = client.profile.role === 'center';
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [dateFrom, setDateFrom] = useState('');
  const [dateTo, setDateTo] = useState('');

  const filtered = useMemo(() => {
    let result = orders;
    if (statusFilter !== 'all') result = result.filter(o => o.status === statusFilter);
    if (dateFrom) {
      const from = new Date(dateFrom); from.setHours(0,0,0,0);
      result = result.filter(o => new Date(o.created_at) >= from);
    }
    if (dateTo) {
      const to = new Date(dateTo); to.setHours(23,59,59,999);
      result = result.filter(o => new Date(o.created_at) <= to);
    }
    return result;
  }, [orders, statusFilter, dateFrom, dateTo]);

  const exportCSV = () => {
    const headers = ['Order #', 'Patient', 'Doctor', 'Status', 'Created', 'Due Date', 'Bill To', 'Notes'];
    const rows = filtered.map(o => [
      o.order_number,
      o.patient_name,
      o.dr_name,
      STATUS_CONFIG[o.status]?.label ?? o.status,
      new Date(o.created_at).toLocaleDateString(),
      o.due_date ? new Date(o.due_date).toLocaleDateString() : '',
      o.bill_to === 'center' ? 'Center' : 'Doctor',
      (o.notes ?? '').replace(/\n/g, ' '),
    ]);
    // Case text is written by other accounts, so a leading =, +, - or @ is
    // neutralised: spreadsheet applications would otherwise run it as a formula.
    const csvCell = (cell: unknown) => {
      const value = String(cell ?? '');
      const safe = /^[=+\-@\t\r]/.test(value) ? `'${value}` : value;
      return `"${safe.replace(/"/g, '""')}"`;
    };
    const csv = [headers, ...rows].map(r => r.map(csvCell).join(',')).join('\n');
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${client.profile.name.replace(/\s+/g, '_')}_orders_${dateFrom || 'all'}_${dateTo || 'now'}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  // Shared escaper: it also handles the single quote, which matters because these
  // values land inside HTML attributes in the exported report.
  const esc = (s: string | null | undefined) => escapeHtml(s ?? '');

  const serviceLabel = (o: Order): string => {
    const names: string[] = [];
    if (o.order_services && o.order_services.length > 0) {
      for (const os of o.order_services) {
        const name = os.service?.name ?? os.service_name;
        if (name) names.push(name);
      }
    } else if (o.service?.name) {
      names.push(o.service.name);
    }
    return names.length ? names.join(', ') : '—';
  };

  const countUnits = (o: Order): number => {
    const teethSources: string[] = [];
    if (o.order_services && o.order_services.length > 0) {
      for (const os of o.order_services) {
        if (os.teeth_numbers) teethSources.push(os.teeth_numbers);
      }
    }
    if (o.teeth_numbers) teethSources.push(o.teeth_numbers);
    const teeth = teethSources.join(',').split(',').map(s => s.trim()).filter(Boolean);
    return teeth.length;
  };

  const exportPDF = () => {
    const rowsHtml = filtered.map((o, i) => `
      <tr>
        <td class="idx">${i + 1}</td>
        <td class="mono">${esc(o.order_number)}</td>
        <td class="mono">${esc(o.file_number)}</td>
        <td>${esc(o.patient_name)}</td>
        <td>Dr. ${esc(o.dr_name)}</td>
        <td>${esc(serviceLabel(o))}</td>
        <td class="num">${countUnits(o)}</td>
        <td><span class="badge ${esc(o.status)}">${esc(STATUS_CONFIG[o.status]?.label ?? o.status)}</span></td>
      </tr>`).join('');
    const html = `
      <html><head><title>Orders Report — ${esc(client.profile.name)}</title>
      <style>
        * { box-sizing: border-box; }
        body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', system-ui, sans-serif; padding: 48px; color: #171717; margin: 0; }
        .doc { max-width: 900px; margin: 0 auto; }
        .header { display: flex; align-items: center; gap: 18px; padding-bottom: 24px; border-bottom: 3px solid #0d9488; margin-bottom: 28px; }
        .logo { width: 56px; height: 56px; border-radius: 14px; background: linear-gradient(135deg, #0d9488, #14b8a6); display: flex; align-items: center; justify-content: center; color: #fff; font-size: 26px; font-weight: 800; flex-shrink: 0; }
        .header h1 { font-size: 24px; margin: 0; font-weight: 800; letter-spacing: -0.02em; }
        .header .sub { font-size: 13px; color: #737373; margin-top: 2px; }
        .meta-bar { display: flex; justify-content: space-between; align-items: center; margin-bottom: 22px; font-size: 12px; color: #525252; }
        .meta-bar .pill { background: #f5f5f5; padding: 6px 12px; border-radius: 999px; font-weight: 600; }
        .stats { display: flex; gap: 14px; margin-bottom: 28px; }
        .stat { flex: 1; background: linear-gradient(135deg, #fafafa, #f5f5f5); border-radius: 14px; padding: 16px 20px; text-align: center; border: 1px solid #eee; }
        .stat .num { font-size: 28px; font-weight: 800; color: #0d9488; line-height: 1; }
        .stat .lbl { font-size: 10px; color: #737373; text-transform: uppercase; letter-spacing: 0.06em; margin-top: 6px; font-weight: 600; }
        table { width: 100%; border-collapse: collapse; font-size: 12px; border-radius: 12px; overflow: hidden; box-shadow: 0 1px 3px rgba(0,0,0,0.06); }
        thead th { text-align: left; padding: 12px 12px; background: #171717; color: #fff; font-size: 10px; text-transform: uppercase; letter-spacing: 0.05em; font-weight: 700; }
        thead th:first-child { border-top-left-radius: 12px; }
        thead th:last-child { border-top-right-radius: 12px; }
        tbody td { padding: 11px 12px; border-bottom: 1px solid #f0f0f0; vertical-align: top; }
        tbody tr:nth-child(even) { background: #fafafa; }
        tbody tr:last-child td { border-bottom: none; }
        .idx { color: #a3a3a3; font-weight: 600; width: 28px; }
        .mono { font-family: 'SF Mono', 'JetBrains Mono', Menlo, monospace; font-size: 11px; font-weight: 600; color: #404040; }
        .num { text-align: center; font-weight: 700; color: #0d9488; }
        .badge { display: inline-block; padding: 3px 9px; border-radius: 999px; font-size: 10px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.03em; background: #f5f5f5; color: #525252; }
        .badge.completed { background: #d1fae5; color: #047857; }
        .badge.pending { background: #fef3c7; color: #b45309; }
        .badge.accepted { background: #dbeafe; color: #1d4ed8; }
        .badge.in_progress { background: #e0e7ff; color: #4338ca; }
        .badge.delivering { background: #cffafe; color: #0e7490; }
        .badge.delivered { background: #e0e7ff; color: #4338ca; }
        .badge.rejected { background: #fee2e2; color: #b91c1c; }
        .badge.cancelled { background: #f3f4f6; color: #525252; }
        .badge.redo { background: #ffedd5; color: #c2410c; }
        .footer { margin-top: 36px; padding-top: 16px; border-top: 1px solid #e5e5e5; font-size: 11px; color: #a3a3a3; text-align: center; }
        .footer .brand { font-weight: 700; color: #737373; }
        @media print { body { padding: 0; } .doc { max-width: 100%; } }
      </style></head><body>
        <div class="doc">
          <div class="header">
            <div class="logo">B</div>
            <div>
              <h1>Orders Report</h1>
              <div class="sub">${esc(client.profile.name)} · ${isCenter ? 'Dental Center' : 'Doctor'}${client.profile.city ? ' · ' + esc(client.profile.city) : ''}${client.profile.phone ? ' · ' + esc(client.profile.phone) : ''}</div>
            </div>
          </div>
          <div class="meta-bar">
            <span>Report period: <strong>${dateFrom || 'Beginning'}</strong> → <strong>${dateTo || 'Today'}</strong></span>
            <span class="pill">Generated ${new Date().toLocaleString()}</span>
          </div>
          <div class="stats">
            <div class="stat"><div class="num">${filtered.length}</div><div class="lbl">Total Orders</div></div>
            <div class="stat"><div class="num">${filtered.reduce((n, o) => n + countUnits(o), 0)}</div><div class="lbl">Total Units</div></div>
            <div class="stat"><div class="num">${filtered.filter(o => o.status === 'completed').length}</div><div class="lbl">Completed</div></div>
            <div class="stat"><div class="num">${filtered.filter(o => ['pending','accepted','in_progress'].includes(o.status)).length}</div><div class="lbl">Active</div></div>
          </div>
          <table>
            <thead><tr><th>#</th><th>Order No.</th><th>File No.</th><th>Patient Name</th><th>Dr. Name</th><th>Service</th><th>Units</th><th>Status</th></tr></thead>
            <tbody>${rowsHtml}</tbody>
          </table>
          <div class="footer"><span class="brand">Bridge</span> · Dental Lab Platform · This report is system generated</div>
        </div>
        <script>window.onload = () => setTimeout(() => window.print(), 300);</script>
      </body></html>`;
    const blob = new Blob([html], { type: 'text/html;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const win = window.open(url, '_blank');
    if (!win) {
      alert('Please allow popups to export the PDF.');
      URL.revokeObjectURL(url);
      return;
    }
    setTimeout(() => URL.revokeObjectURL(url), 60000);
  };

  const clearDates = () => { setDateFrom(''); setDateTo(''); };

  return (
    <div className="p-6 max-w-4xl mx-auto">
      <button onClick={onBack} className="flex items-center gap-1.5 text-sm text-neutral-500 hover:text-neutral-700 mb-5 transition-colors">
        <ChevronRight className="w-4 h-4 rotate-180" /> Back to clients
      </button>

      {/* Client header */}
      <div className="bg-white rounded-2xl shadow-card p-6 mb-5">
        <div className="flex items-center gap-4">
          {client.profile.logo_url ? (
            <img src={client.profile.logo_url} alt={client.profile.name} className="w-16 h-16 rounded-2xl object-cover" />
          ) : (
            <div className={`w-16 h-16 rounded-2xl flex items-center justify-center ${isCenter ? 'bg-primary-50' : 'bg-teal-50'}`}>
              {isCenter
                ? <Building2 className="w-8 h-8 text-primary-600" />
                : <Stethoscope className="w-8 h-8 text-teal-600" />}
            </div>
          )}
          <div className="flex-1">
            <div className="flex items-center gap-2">
              <h2 className="font-display text-xl font-bold text-neutral-900">{client.profile.name}</h2>
              <span className={`text-xs font-semibold px-2 py-0.5 rounded-full ${isCenter ? 'bg-primary-50 text-primary-600' : 'bg-teal-50 text-teal-600'}`}>
                {isCenter ? 'Dental Center' : 'Doctor'}
              </span>
            </div>
            {client.profile.city && <p className="text-sm text-neutral-500 mt-0.5">{client.profile.city}</p>}
            {client.profile.phone && <p className="text-xs text-neutral-400 mt-0.5">{client.profile.phone}</p>}
          </div>
        </div>

        <div className="grid grid-cols-3 gap-3 mt-5">
          <div className="bg-neutral-50 rounded-xl p-3 text-center">
            <p className="text-2xl font-bold text-neutral-900"><CountUp value={client.orderCount} /></p>
            <p className="text-xs text-neutral-500">Total Orders</p>
          </div>
          <div className="bg-amber-50 rounded-xl p-3 text-center">
            <p className="text-2xl font-bold text-amber-700"><CountUp value={client.pendingCount} /></p>
            <p className="text-xs text-amber-600">Active</p>
          </div>
          <div className="bg-teal-50 rounded-xl p-3 text-center">
            <p className="text-2xl font-bold text-teal-700"><CountUp value={client.completedCount} /></p>
            <p className="text-xs text-teal-600">Completed</p>
          </div>
        </div>
      </div>

      {/* Date range + export */}
      <div className="bg-white rounded-xl p-4 shadow-card mb-4 border border-neutral-200/60">
        <div className="flex flex-wrap items-end gap-3">
          <div>
            <label className="block text-xs font-semibold text-neutral-500 mb-1 uppercase tracking-wide">From</label>
            <input type="date" value={dateFrom} onChange={e => setDateFrom(e.target.value)} className="px-3 py-2 rounded-lg border border-neutral-200 bg-neutral-50 text-sm focus:outline-none focus:ring-2 focus:ring-primary-400/40 focus:border-primary-400" />
          </div>
          <div>
            <label className="block text-xs font-semibold text-neutral-500 mb-1 uppercase tracking-wide">To</label>
            <input type="date" value={dateTo} onChange={e => setDateTo(e.target.value)} className="px-3 py-2 rounded-lg border border-neutral-200 bg-neutral-50 text-sm focus:outline-none focus:ring-2 focus:ring-primary-400/40 focus:border-primary-400" />
          </div>
          {(dateFrom || dateTo) && (
            <button onClick={clearDates} className="px-3 py-2 text-xs font-semibold text-neutral-500 hover:text-neutral-700">Clear</button>
          )}
          <div className="ml-auto flex gap-2">
            <button onClick={exportCSV} disabled={filtered.length === 0}
              className="flex items-center gap-1.5 px-3 py-2 bg-teal-50 hover:bg-teal-100 text-teal-700 border border-teal-200 text-xs font-semibold rounded-lg transition-colors disabled:opacity-40">
              <Download className="w-3.5 h-3.5" /> CSV
            </button>
            <button onClick={exportPDF} disabled={filtered.length === 0}
              className="flex items-center gap-1.5 px-3 py-2 bg-primary-600 hover:bg-primary-700 text-white text-xs font-semibold rounded-lg transition-colors disabled:opacity-40">
              <FileText className="w-3.5 h-3.5" /> PDF
            </button>
          </div>
        </div>
        {(dateFrom || dateTo) && (
          <p className="text-xs text-neutral-400 mt-2">Showing {filtered.length} of {orders.length} orders in selected range</p>
        )}
      </div>

      {/* Status filter */}
      <div className="flex gap-1.5 mb-4 overflow-x-auto pb-1">
        <button
          onClick={() => setStatusFilter('all')}
          className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-all ${statusFilter === 'all' ? 'bg-neutral-900 text-white' : 'bg-white border border-neutral-200 text-neutral-600 hover:border-neutral-300'}`}
        >
          All ({filtered.length})
        </button>
        {Object.entries(STATUS_CONFIG).map(([key, cfg]) => {
          const count = orders.filter(o => o.status === key).length;
          if (count === 0) return null;
          return (
            <button
              key={key}
              onClick={() => setStatusFilter(key)}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-all border ${statusFilter === key ? `${cfg.bg} ${cfg.color}` : 'bg-white border-neutral-200 text-neutral-500 hover:border-neutral-300'}`}
            >
              {cfg.label} ({count})
            </button>
          );
        })}
      </div>

      {/* Orders list */}
      {filtered.length === 0 ? (
        <div className="text-center py-12">
          <ClipboardList className="w-10 h-10 text-neutral-300 mx-auto mb-2" />
          <p className="text-neutral-500 text-sm">No orders in this filter</p>
        </div>
      ) : (
        <div className="space-y-2">
          {filtered.map(order => {
            const cfg = STATUS_CONFIG[order.status] ?? { label: order.status, color: 'text-neutral-600', bg: 'bg-neutral-50 border-neutral-200' };
            return (
              <div key={order.id} className="bg-white rounded-xl p-4 shadow-card border border-neutral-200/60 hover:border-primary-200 hover:shadow-card-hover transition-all">
                <div className="flex items-center justify-between mb-1.5">
                  <span className="font-semibold text-neutral-900 text-sm">{order.order_number}</span>
                  <div className="flex items-center gap-2">
                    <span className={`text-xs font-medium px-2 py-0.5 rounded-full border ${cfg.bg} ${cfg.color}`}>{cfg.label}</span>
                    <button
                      onClick={() => onOpenOrder(order)}
                      className="flex items-center gap-1 px-2 py-1 text-xs font-semibold text-primary-600 hover:bg-primary-50 rounded-lg transition-colors"
                    >
                      <Eye className="w-3.5 h-3.5" /> View
                    </button>
                  </div>
                </div>
                <div
                  onClick={() => onOpenOrder(order)}
                  className="cursor-pointer"
                >
                  <p className="text-sm text-neutral-600">
                    Patient: <span className="font-medium">{order.patient_name}</span> &bull; Dr. {order.dr_name}
                  </p>
                  <div className="flex items-center gap-3 mt-1.5 text-xs text-neutral-400">
                    <span className="flex items-center gap-1">
                      <Calendar className="w-3 h-3" />
                      {new Date(order.created_at).toLocaleDateString()}
                    </span>
                    {order.due_date && (
                      <span className="flex items-center gap-1 text-amber-600">
                        <Calendar className="w-3 h-3" />
                        Due {new Date(order.due_date).toLocaleDateString()}
                      </span>
                    )}
                    {order.bill_to === 'center' && (
                      <span className="flex items-center gap-1 text-blue-600 font-medium">
                        <Receipt className="w-3 h-3" />
                        Bill to center
                      </span>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
