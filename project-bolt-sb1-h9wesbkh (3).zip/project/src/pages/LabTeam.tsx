import { useEffect, useState, useCallback } from 'react';
import { supabase, Order, OrderStatus, Profile } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import OrderDetailModal from '../components/OrderDetailModal';
import {
  Users, Wrench, Clock, CheckCircle2, Package, ChevronRight,
  ChevronLeft, AlertTriangle, Search, Filter,
} from 'lucide-react';

interface Technician {
  technician_id: string;
  technician_profile: Profile;
}

const ACTIVE_STATUSES: OrderStatus[] = ['pending', 'accepted', 'in_progress', 'redo', 'try_in'];

const STATUS_COLORS: Record<string, string> = {
  pending:     'bg-amber-50 text-amber-700 border-amber-200',
  accepted:    'bg-blue-50 text-blue-700 border-blue-200',
  in_progress: 'bg-primary-50 text-primary-700 border-primary-200',
  completed:   'bg-teal-50 text-teal-700 border-teal-200',
  try_in:      'bg-amber-50 text-amber-700 border-amber-300',
  delivering:  'bg-cyan-50 text-cyan-700 border-cyan-200',
  delivered:   'bg-emerald-50 text-emerald-700 border-emerald-200',
  rejected:    'bg-red-50 text-red-700 border-red-200',
  cancelled:   'bg-neutral-100 text-neutral-600 border-neutral-200',
  redo:        'bg-orange-50 text-orange-700 border-orange-200',
};

const STATUS_LABELS: Record<string, string> = {
  pending: 'Pending', accepted: 'Accepted', in_progress: 'In Progress',
  completed: 'Completed', try_in: 'Try In', delivering: 'Delivering',
  delivered: 'Delivered', rejected: 'Rejected', cancelled: 'Cancelled', redo: 'Redo',
};

export default function LabTeam() {
  const { profile } = useAuth();
  const [technicians, setTechnicians] = useState<Technician[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const [expandedTech, setExpandedTech] = useState<string | null>(null);
  const [techFilter, setTechFilter] = useState<'active' | 'all'>('active');
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);

  const fetchData = useCallback(async () => {
    if (!profile) return;
    const [techRes, ordersRes] = await Promise.all([
      supabase
        .from('lab_technicians')
        .select('technician_id, technician_profile:profiles!lab_technicians_technician_id_fkey(id, name, phone, avatar_url)')
        .eq('lab_id', profile.id),
      supabase
        .from('orders')
        .select('*, from_profile:profiles!orders_from_id_fkey(*), service:services(*), order_services(*, service:services(*))')
        .eq('lab_id', profile.id)
        .not('assigned_technician_id', 'is', null)
        .order('updated_at', { ascending: false }),
    ]);
    setTechnicians((techRes.data as any) ?? []);
    setOrders((ordersRes.data as Order[]) ?? []);
    setLoading(false);
  }, [profile]);

  useEffect(() => { fetchData(); }, [fetchData]);

  // Realtime refresh
  useEffect(() => {
    if (!profile) return;
    const channel = supabase
      .channel(`lab_team_rt:${profile.id}`)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'orders', filter: `lab_id=eq.${profile.id}` }, () => fetchData())
      .subscribe();
    return () => { supabase.removeChannel(channel); };
  }, [profile, fetchData]);

  const ordersByTech = (techId: string) => orders.filter(o => o.assigned_technician_id === techId);
  const activeOrders = (techId: string) => ordersByTech(techId).filter(o => ACTIVE_STATUSES.includes(o.status));
  const doneOrders = (techId: string) => ordersByTech(techId).filter(o => o.status === 'completed' || o.status === 'delivered');
  const unassignedCount = orders.length === 0 ? 0 : 0; // all fetched orders have assigned_technician_id

  // Count orders in the lab with no technician assigned
  const [unassigned, setUnassigned] = useState(0);
  useEffect(() => {
    if (!profile) return;
    supabase
      .from('orders')
      .select('id', { count: 'exact', head: true })
      .eq('lab_id', profile.id)
      .is('assigned_technician_id', null)
      .in('status', ACTIVE_STATUSES)
      .then(({ count }) => setUnassigned(count ?? 0));
  }, [profile, orders]);

  const totalActive = technicians.reduce((s, t) => s + activeOrders(t.technician_id).length, 0);
  const totalDone = technicians.reduce((s, t) => s + doneOrders(t.technician_id).length, 0);

  const statusBreakdown = (techId: string) => {
    const list = techFilter === 'active' ? activeOrders(techId) : ordersByTech(techId);
    const counts: Record<string, number> = {};
    list.forEach(o => { counts[o.status] = (counts[o.status] || 0) + 1; });
    return Object.entries(counts).sort((a, b) => b[1] - a[1]);
  };

  const visibleOrders = (techId: string) => {
    const list = techFilter === 'active' ? activeOrders(techId) : ordersByTech(techId);
    return list;
  };

  if (loading) {
    return (
      <div className="max-w-4xl mx-auto px-4 sm:px-6 py-6">
        <div className="space-y-3">
          {[1, 2, 3].map(i => <div key={i} className="bg-white rounded-2xl h-28 animate-pulse shadow-card" />)}
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 py-6">
      {/* Header */}
      <div className="flex items-center gap-3 mb-6">
        <div className="w-11 h-11 bg-blue-100 rounded-2xl flex items-center justify-center">
          <Users className="w-6 h-6 text-blue-600" />
        </div>
        <div>
          <h1 className="font-display text-xl font-bold text-neutral-900">My Team</h1>
          <p className="text-sm text-neutral-500">{technicians.length} technician{technicians.length !== 1 ? 's' : ''}</p>
        </div>
      </div>

      {/* Summary stats */}
      <div className="grid grid-cols-3 gap-3 mb-6">
        <div className="bg-white rounded-2xl p-4 shadow-card">
          <div className="flex items-center gap-2">
            <Clock className="w-5 h-5 text-amber-500" />
            <div>
              <p className="text-xl font-bold text-neutral-900">{totalActive}</p>
              <p className="text-xs text-neutral-500">Active</p>
            </div>
          </div>
        </div>
        <div className="bg-white rounded-2xl p-4 shadow-card">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-5 h-5 text-emerald-500" />
            <div>
              <p className="text-xl font-bold text-neutral-900">{totalDone}</p>
              <p className="text-xs text-neutral-500">Done</p>
            </div>
          </div>
        </div>
        <div className="bg-white rounded-2xl p-4 shadow-card">
          <div className="flex items-center gap-2">
            <AlertTriangle className="w-5 h-5 text-red-400" />
            <div>
              <p className="text-xl font-bold text-neutral-900">{unassigned}</p>
              <p className="text-xs text-neutral-500">Unassigned</p>
            </div>
          </div>
        </div>
      </div>

      {/* Filter toggle */}
      <div className="flex items-center gap-3 mb-4">
        <div className="flex gap-1 bg-neutral-100 p-1 rounded-xl">
          <button
            onClick={() => setTechFilter('active')}
            className={`px-4 py-1.5 rounded-lg text-sm font-semibold transition-all ${techFilter === 'active' ? 'bg-white text-neutral-900 shadow-card' : 'text-neutral-500'}`}
          >
            Active Orders
          </button>
          <button
            onClick={() => setTechFilter('all')}
            className={`px-4 py-1.5 rounded-lg text-sm font-semibold transition-all ${techFilter === 'all' ? 'bg-white text-neutral-900 shadow-card' : 'text-neutral-500'}`}
          >
            All Orders
          </button>
        </div>
      </div>

      {technicians.length === 0 ? (
        <div className="text-center py-16">
          <div className="w-14 h-14 bg-neutral-100 rounded-2xl flex items-center justify-center mx-auto mb-3">
            <Users className="w-7 h-7 text-neutral-300" />
          </div>
          <p className="font-medium text-neutral-500">No technicians yet</p>
          <p className="text-sm text-neutral-400 mt-1">Add technicians from the Profile page</p>
        </div>
      ) : (
        <div className="space-y-3">
          {technicians.map(tech => {
            const tp = tech.technician_profile;
            const active = activeOrders(tech.technician_id).length;
            const done = doneOrders(tech.technician_id).length;
            const isExpanded = expandedTech === tech.technician_id;
            const breakdown = statusBreakdown(tech.technician_id);
            const techOrders = visibleOrders(tech.technician_id);

            return (
              <div key={tech.technician_id} className="bg-white rounded-2xl shadow-card border border-transparent overflow-hidden transition-all">
                {/* Card header */}
                <button
                  onClick={() => setExpandedTech(isExpanded ? null : tech.technician_id)}
                  className="w-full text-left p-4 flex items-center gap-3 hover:bg-neutral-50 transition-colors"
                >
                  {/* Avatar */}
                  {tp.avatar_url ? (
                    <img src={tp.avatar_url} alt="" className="w-11 h-11 rounded-xl object-cover flex-shrink-0" />
                  ) : (
                    <div className="w-11 h-11 rounded-xl bg-blue-100 flex items-center justify-center flex-shrink-0">
                      <Wrench className="w-5 h-5 text-blue-600" />
                    </div>
                  )}

                  <div className="flex-1 min-w-0">
                    <p className="font-bold text-neutral-900 text-sm truncate">{tp.name}</p>
                    <div className="flex items-center gap-3 mt-0.5">
                      <span className="text-xs text-amber-600 font-semibold">{active} active</span>
                      <span className="text-xs text-emerald-600 font-semibold">{done} done</span>
                    </div>
                    {/* Status pills */}
                    {breakdown.length > 0 && (
                      <div className="flex flex-wrap gap-1 mt-1.5">
                        {breakdown.slice(0, 4).map(([status, count]) => (
                          <span key={status} className={`text-[10px] font-semibold px-1.5 py-0.5 rounded-full border ${STATUS_COLORS[status] ?? 'bg-neutral-100 text-neutral-600 border-neutral-200'}`}>
                            {count} {STATUS_LABELS[status] ?? status}
                          </span>
                        ))}
                      </div>
                    )}
                  </div>

                  <ChevronRight className={`w-5 h-5 text-neutral-300 flex-shrink-0 transition-transform ${isExpanded ? 'rotate-90' : ''}`} />
                </button>

                {/* Expanded order list */}
                {isExpanded && (
                  <div className="border-t border-neutral-200/60">
                    {techOrders.length === 0 ? (
                      <div className="px-4 py-8 text-center">
                        <Package className="w-6 h-6 text-neutral-300 mx-auto mb-1" />
                        <p className="text-sm text-neutral-400">
                          {techFilter === 'active' ? 'No active orders' : 'No orders assigned'}
                        </p>
                      </div>
                    ) : (
                      <div className="divide-y divide-neutral-100">
                        {techOrders.map(order => {
                          const services = order.order_services?.map(s => s.service_name).join(', ') || order.service?.name || '';
                          return (
                            <button
                              key={order.id}
                              onClick={() => setSelectedOrder(order)}
                              className="w-full text-left px-4 py-3 hover:bg-blue-50/50 transition-colors"
                            >
                              <div className="flex items-start justify-between gap-3">
                                <div className="flex-1 min-w-0">
                                  <div className="flex items-center gap-2 flex-wrap">
                                    <span className="font-bold text-neutral-900 text-xs">{order.order_number}</span>
                                    <span className={`text-[10px] font-semibold px-1.5 py-0.5 rounded-full border ${STATUS_COLORS[order.status]}`}>
                                      {STATUS_LABELS[order.status]}
                                    </span>
                                  </div>
                                  <p className="text-xs text-neutral-500 mt-0.5 truncate">
                                    {order.patient_name ?? '—'}{order.dr_name ? ` · Dr. ${order.dr_name}` : ''}
                                  </p>
                                  {services && <p className="text-[11px] text-neutral-400 truncate">{services}</p>}
                                </div>
                                <div className="text-right flex-shrink-0">
                                  {order.due_date && (
                                    <p className="text-[11px] text-neutral-500">
                                      Due {new Date(order.due_date).toLocaleDateString([], { month: 'short', day: 'numeric' })}
                                    </p>
                                  )}
                                </div>
                              </div>
                            </button>
                          );
                        })}
                      </div>
                    )}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      {selectedOrder && (
        <OrderDetailModal
          order={selectedOrder}
          isLab={true}
          onClose={() => setSelectedOrder(null)}
          onStatusChange={() => { setSelectedOrder(null); fetchData(); }}
        />
      )}
    </div>
  );
}
