import { useEffect, useState, useCallback, useMemo, useRef } from 'react';
import { supabase, Order, OrderStatus, Service } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { CountUp } from '../lib/CountUp';
import {
  ClipboardList, Clock, CheckCircle2, XCircle, Loader2,
  ChevronRight, TrendingUp, TrendingDown, Microscope, RefreshCw,
  Truck, FlaskConical, BadgeCheck, Users, Percent, ChevronDown,
  BarChart3, Wrench,
} from 'lucide-react';
import OrderDetailModal from '../components/OrderDetailModal';
import { ToothIcon } from '../components/ToothIcon';
import { useRealtimeLabOrders } from '../lib/useRealtimeOrders';
import {
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip as ReTooltip,
  ResponsiveContainer, PieChart, Pie, Cell,
  BarChart, Bar, Legend,
} from 'recharts';
import type { Profile } from '../lib/supabase';

interface LabTechnician {
  technician_id: string;
  technician_profile: Profile;
}

/* ── Status config (unchanged) ── */
const STATUS_CONFIG: Record<string, { label: string; color: string; bg: string; border: string; icon: React.ReactNode }> = {
  pending:     { label: 'Pending',     color: 'text-amber-700',   bg: 'bg-amber-50',   border: 'border-amber-200',   icon: <ToothIcon className="w-4 h-4" variant="default" /> },
  accepted:    { label: 'Accepted',    color: 'text-blue-700',    bg: 'bg-blue-50',    border: 'border-blue-200',    icon: <ToothIcon className="w-4 h-4" variant="check" /> },
  in_progress: { label: 'In Progress', color: 'text-primary-700', bg: 'bg-primary-50', border: 'border-primary-200', icon: <ToothIcon className="w-4 h-4" variant="spin" /> },
  completed:   { label: 'Completed',   color: 'text-teal-700',    bg: 'bg-teal-50',    border: 'border-teal-200',    icon: <ToothIcon className="w-4 h-4" variant="sparkle" /> },
  try_in:      { label: 'Try In',      color: 'text-amber-700',   bg: 'bg-amber-50',   border: 'border-amber-300',   icon: <FlaskConical className="w-4 h-4" /> },
  delivering:  { label: 'Delivering',  color: 'text-cyan-700',    bg: 'bg-cyan-50',    border: 'border-cyan-200',    icon: <Truck className="w-4 h-4" /> },
  delivered:   { label: 'Delivered',   color: 'text-emerald-700', bg: 'bg-emerald-50', border: 'border-emerald-200', icon: <CheckCircle2 className="w-4 h-4" /> },
  rejected:    { label: 'Rejected',    color: 'text-red-700',     bg: 'bg-red-50',     border: 'border-red-200',     icon: <ToothIcon className="w-4 h-4" variant="x" /> },
  cancelled:   { label: 'Cancelled',   color: 'text-neutral-600', bg: 'bg-neutral-50', border: 'border-neutral-200', icon: <ToothIcon className="w-4 h-4" variant="slash" /> },
  redo:        { label: 'Redo',        color: 'text-orange-700',  bg: 'bg-orange-50',  border: 'border-orange-200',  icon: <ToothIcon className="w-4 h-4" variant="redo" /> },
  finished:    { label: 'Finished',    color: 'text-green-800',   bg: 'bg-green-50',   border: 'border-green-300',   icon: <BadgeCheck className="w-4 h-4" /> },
};

const FILTER_STATUSES = ['pending', 'accepted', 'in_progress', 'completed', 'try_in', 'delivered', 'rejected', 'cancelled', 'redo', 'finished'] as const;
type FilterValue = typeof FILTER_STATUSES[number] | 'all';
type CustomFilter = 
  | { type: 'none' }
  | { type: 'kpi'; key: 'clients' | 'completed' | 'pending' }
  | { type: 'technician'; id: string; name: string }
  | { type: 'client'; name: string };

const THIRTY_DAYS_MS = 30 * 24 * 60 * 60 * 1000;
const DONE_STATUSES = new Set<string>(['completed', 'delivered', 'delivering']);
const ACTIVE_STATUSES = new Set<string>(['pending', 'accepted', 'in_progress', 'try_in', 'redo']);

type DateRange = '7d' | '30d' | 'year';
const DATE_RANGE_LABELS: Record<DateRange, string> = { '7d': 'Last 7 Days', '30d': 'Last 30 Days', 'year': 'This Year' };

const DONUT_COLORS = ['#0ea5e9', '#22c55e', '#94a3b8'];

interface Props { onNavigateOrders: () => void; }

/* ── Helpers ── */
function rangeStart(range: DateRange): Date {
  const now = new Date();
  if (range === '7d') return new Date(now.getTime() - 7 * 86400000);
  if (range === '30d') return new Date(now.getTime() - 30 * 86400000);
  return new Date(now.getFullYear(), 0, 1);
}

function prevRangeStart(range: DateRange): Date {
  const now = new Date();
  if (range === '7d') return new Date(now.getTime() - 14 * 86400000);
  if (range === '30d') return new Date(now.getTime() - 60 * 86400000);
  return new Date(now.getFullYear() - 1, 0, 1);
}

function prevRangeEnd(range: DateRange): Date {
  return rangeStart(range);
}

function growthPct(curr: number, prev: number): number | null {
  if (prev === 0 && curr === 0) return null;
  if (prev === 0) return 100;
  return Math.round(((curr - prev) / prev) * 100);
}

function buildTimeSeriesData(orders: Order[], range: DateRange) {
  const start = rangeStart(range);
  const now = new Date();
  const completedOrders = orders.filter(o => DONE_STATUSES.has(o.status) && new Date(o.created_at) >= start);

  if (range === 'year') {
    const months: Record<string, number> = {};
    for (let m = 0; m <= now.getMonth(); m++) {
      const key = new Date(now.getFullYear(), m, 1).toLocaleDateString('en', { month: 'short' });
      months[key] = 0;
    }
    completedOrders.forEach(o => {
      const d = new Date(o.created_at);
      const key = d.toLocaleDateString('en', { month: 'short' });
      if (key in months) months[key]++;
    });
    return Object.entries(months).map(([name, cases]) => ({ name, cases }));
  }

  const days = range === '7d' ? 7 : 30;
  const data: { name: string; cases: number }[] = [];
  for (let i = days - 1; i >= 0; i--) {
    const d = new Date(now.getTime() - i * 86400000);
    const label = d.toLocaleDateString('en', { month: 'short', day: 'numeric' });
    const dayStr = d.toISOString().slice(0, 10);
    const count = completedOrders.filter(o => o.created_at.slice(0, 10) === dayStr).length;
    data.push({ name: label, cases: count });
  }
  return data;
}

function buildClientDonutData(orders: Order[]) {
  const now = Date.now();
  const byClient = new Map<string, Order[]>();
  orders.forEach(o => {
    const arr = byClient.get(o.from_id) ?? [];
    arr.push(o);
    byClient.set(o.from_id, arr);
  });

  let active = 0, onboarding = 0, inactive = 0;
  byClient.forEach(clientOrders => {
    const latest = Math.max(...clientOrders.map(o => new Date(o.created_at).getTime()));
    const earliest = Math.min(...clientOrders.map(o => new Date(o.created_at).getTime()));
    const daysSinceLatest = (now - latest) / 86400000;
    const daysSinceFirst = (now - earliest) / 86400000;
    if (daysSinceLatest <= 30) {
      if (daysSinceFirst <= 14) onboarding++;
      else active++;
    } else {
      inactive++;
    }
  });
  return [
    { name: 'Active', value: active },
    { name: 'New', value: onboarding },
    { name: 'Inactive', value: inactive },
  ].filter(d => d.value > 0);
}

function buildTopClientsData(orders: Order[]) {
  const map = new Map<string, { name: string; count: number; id: string }>();
  orders.filter(o => DONE_STATUSES.has(o.status)).forEach(o => {
    const entry = map.get(o.from_id) ?? { name: o.from_profile?.name ?? 'Unknown', count: 0, id: o.from_id };
    entry.count++;
    map.set(o.from_id, entry);
  });
  return [...map.values()].sort((a, b) => b.count - a.count).slice(0, 5);
}

/* ── Custom Tooltip ── */
function ChartTooltip({ active, payload, label }: any) {
  if (!active || !payload?.length) return null;
  return (
    <div className="bg-white/95 backdrop-blur-md rounded-xl shadow-lg border border-neutral-200 px-4 py-2.5">
      <p className="text-xs font-semibold text-neutral-500 mb-0.5">{label}</p>
      {payload.map((p: any, i: number) => (
        <p key={i} className="text-sm font-bold" style={{ color: p.color ?? '#0ea5e9' }}>
          {p.value} {p.name ?? 'cases'}
        </p>
      ))}
    </div>
  );
}

function DonutTooltip({ active, payload }: any) {
  if (!active || !payload?.length) return null;
  return (
    <div className="bg-white/95 backdrop-blur-md rounded-xl shadow-lg border border-neutral-200 px-4 py-2.5">
      <p className="text-sm font-bold text-neutral-900">{payload[0].name}: {payload[0].value}</p>
    </div>
  );
}

/* ── Main component ── */
export default function LabOverview({ onNavigateOrders }: Props) {
  const { profile } = useAuth();
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<FilterValue>('all');
  const [selected, setSelected] = useState<Order | null>(null);
  const [dateRange, setDateRange] = useState<DateRange>('30d');
  const [showRangeMenu, setShowRangeMenu] = useState(false);
  const [technicians, setTechnicians] = useState<LabTechnician[]>([]);
  const [customFilter, setCustomFilter] = useState<CustomFilter>({ type: 'none' });
  const ordersRef = useRef<HTMLDivElement>(null);

  const scrollToOrders = useCallback(() => {
    setTimeout(() => ordersRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' }), 80);
  }, []);

  const fetchOrders = useCallback(async () => {
    if (!profile) return;
    setLoading(true);
    const { data } = await supabase
      .from('orders')
      .select('*, from_profile:profiles!orders_from_id_fkey(*), service:services(*), attachments:order_attachments(*), order_services(*, service:services(*))')
      .eq('lab_id', profile.id)
      .order('created_at', { ascending: false });
    setOrders(data ?? []);
    setLoading(false);
  }, [profile]);

  useEffect(() => {
    if (!profile) return;
    supabase
      .from('lab_technicians')
      .select('technician_id, technician_profile:profiles!lab_technicians_technician_id_fkey(id, name, avatar_url)')
      .eq('lab_id', profile.id)
      .then(({ data }) => setTechnicians((data as any) ?? []));
  }, [profile]);

  useEffect(() => { fetchOrders(); }, [fetchOrders]);
  useRealtimeLabOrders(profile?.id, fetchOrders);

  /* ── Derived data ── */
  const start = useMemo(() => rangeStart(dateRange), [dateRange]);
  const prevStart = useMemo(() => prevRangeStart(dateRange), [dateRange]);
  const prevEnd = useMemo(() => prevRangeEnd(dateRange), [dateRange]);

  const rangedOrders = useMemo(() => orders.filter(o => new Date(o.created_at) >= start), [orders, start]);
  const prevOrders = useMemo(() => orders.filter(o => { const d = new Date(o.created_at); return d >= prevStart && d < prevEnd; }), [orders, prevStart, prevEnd]);

  const uniqueClients = useMemo(() => new Set(rangedOrders.map(o => o.from_id)).size, [rangedOrders]);
  const prevClients = useMemo(() => new Set(prevOrders.map(o => o.from_id)).size, [prevOrders]);
  const completedCount = useMemo(() => rangedOrders.filter(o => DONE_STATUSES.has(o.status)).length, [rangedOrders]);
  const prevCompleted = useMemo(() => prevOrders.filter(o => DONE_STATUSES.has(o.status)).length, [prevOrders]);
  const pendingCount = useMemo(() => rangedOrders.filter(o => ACTIVE_STATUSES.has(o.status)).length, [rangedOrders]);
  const prevPending = useMemo(() => prevOrders.filter(o => ACTIVE_STATUSES.has(o.status)).length, [prevOrders]);
  const completionRate = useMemo(() => rangedOrders.length === 0 ? 0 : Math.round((completedCount / rangedOrders.length) * 100), [completedCount, rangedOrders]);
  const prevRate = useMemo(() => prevOrders.length === 0 ? 0 : Math.round((prevCompleted / prevOrders.length) * 100), [prevCompleted, prevOrders]);

  const timeSeriesData = useMemo(() => buildTimeSeriesData(orders, dateRange), [orders, dateRange]);
  const donutData = useMemo(() => buildClientDonutData(orders), [orders]);
  const topClientsData = useMemo(() => buildTopClientsData(rangedOrders), [rangedOrders]);

  /* ── Status filter counts (uses ALL orders, not date-ranged) ── */
  const counts = orders.reduce((acc, o) => {
    if (o.status === 'delivered') {
      if (o.finished_at || Date.now() - new Date(o.updated_at ?? o.created_at).getTime() > THIRTY_DAYS_MS) {
        acc['finished'] = (acc['finished'] ?? 0) + 1;
      } else {
        acc['delivered'] = (acc['delivered'] ?? 0) + 1;
      }
    } else {
      acc[o.status] = (acc[o.status] ?? 0) + 1;
    }
    return acc;
  }, {} as Record<string, number>);

  const baseFiltered = filter === 'all' ? orders
    : filter === 'finished' ? orders.filter(o => o.status === 'delivered' && (o.finished_at || Date.now() - new Date(o.updated_at ?? o.created_at).getTime() > THIRTY_DAYS_MS))
    : filter === 'delivered' ? orders.filter(o => o.status === 'delivered' && !o.finished_at && Date.now() - new Date(o.updated_at ?? o.created_at).getTime() <= THIRTY_DAYS_MS)
    : orders.filter(o => o.status === filter);

  const filtered = useMemo(() => {
    if (customFilter.type === 'none') return baseFiltered;
    if (customFilter.type === 'kpi') {
      const k = customFilter.key;
      if (k === 'completed') return baseFiltered.filter(o => DONE_STATUSES.has(o.status));
      if (k === 'pending') return baseFiltered.filter(o => ACTIVE_STATUSES.has(o.status));
      return baseFiltered;
    }
    if (customFilter.type === 'technician') return baseFiltered.filter(o => o.assigned_technician_id === customFilter.id);
    if (customFilter.type === 'client') return baseFiltered.filter(o => o.from_profile?.name === customFilter.name);
    return baseFiltered;
  }, [baseFiltered, customFilter]);

  const activeFilterLabel = customFilter.type === 'technician' ? `Technician: ${customFilter.name}`
    : customFilter.type === 'client' ? `Client: ${customFilter.name}`
    : customFilter.type === 'kpi' ? `Showing: ${customFilter.key === 'completed' ? 'Completed' : customFilter.key === 'pending' ? 'Pending' : 'All Clients'}`
    : null;

  const clearCustomFilter = () => setCustomFilter({ type: 'none' });

  const applyCustomFilter = useCallback((cf: CustomFilter) => {
    setCustomFilter(prev => prev.type === cf.type && JSON.stringify(prev) === JSON.stringify(cf) ? { type: 'none' } : cf);
    scrollToOrders();
  }, [scrollToOrders]);

  return (
    <div className="p-4 sm:p-6 max-w-5xl mx-auto">
      {/* Header + date range */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="font-display text-2xl font-bold text-neutral-900">Lab Dashboard</h1>
          <p className="text-neutral-500 text-sm mt-1">Welcome back, {profile?.name}</p>
        </div>
        <div className="relative">
          <button
            onClick={() => setShowRangeMenu(!showRangeMenu)}
            className="flex items-center gap-2 px-4 py-2 bg-white rounded-xl border border-neutral-200 shadow-card text-sm font-semibold text-neutral-700 hover:border-neutral-300 transition-colors"
          >
            {DATE_RANGE_LABELS[dateRange]}
            <ChevronDown className="w-4 h-4 text-neutral-400" />
          </button>
          {showRangeMenu && (
            <>
              <div className="fixed inset-0 z-20" onClick={() => setShowRangeMenu(false)} />
              <div className="absolute right-0 top-full mt-1 bg-white rounded-xl border border-neutral-200 shadow-lg z-30 overflow-hidden min-w-[160px]">
                {(['7d', '30d', 'year'] as DateRange[]).map(r => (
                  <button
                    key={r}
                    onClick={() => { setDateRange(r); setShowRangeMenu(false); }}
                    className={`w-full text-left px-4 py-2.5 text-sm font-medium transition-colors ${r === dateRange ? 'bg-blue-50 text-blue-700' : 'text-neutral-700 hover:bg-neutral-50'}`}
                  >
                    {DATE_RANGE_LABELS[r]}
                  </button>
                ))}
              </div>
            </>
          )}
        </div>
      </div>

      {/* ── KPI Cards ── */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4 mb-6">
        <KpiCard icon={<Users className="w-5 h-5 text-blue-600" />} bg="bg-blue-50" value={uniqueClients} label="Total Clients" growth={growthPct(uniqueClients, prevClients)} index={0} onClick={() => applyCustomFilter({ type: 'kpi', key: 'clients' })} active={customFilter.type === 'kpi' && customFilter.key === 'clients'} />
        <KpiCard icon={<CheckCircle2 className="w-5 h-5 text-teal-600" />} bg="bg-teal-50" value={completedCount} label="Completed" growth={growthPct(completedCount, prevCompleted)} index={1} onClick={() => applyCustomFilter({ type: 'kpi', key: 'completed' })} active={customFilter.type === 'kpi' && customFilter.key === 'completed'} />
        <KpiCard icon={<Clock className="w-5 h-5 text-amber-600" />} bg="bg-amber-50" value={pendingCount} label="Pending" growth={growthPct(pendingCount, prevPending)} index={2} onClick={() => applyCustomFilter({ type: 'kpi', key: 'pending' })} active={customFilter.type === 'kpi' && customFilter.key === 'pending'} />
        <KpiCard icon={<Percent className="w-5 h-5 text-primary-600" />} bg="bg-primary-50" value={completionRate} label="Completion %" growth={growthPct(completionRate, prevRate)} suffix="%" index={3} />
      </div>

      {/* ── Completed Cases Chart ── */}
      <div className="bg-white rounded-2xl shadow-card border border-neutral-200/60 p-5 mb-6 animate-rise-in" style={{ animationDelay: '200ms' }}>
        <div className="flex items-center gap-2 mb-4">
          <BarChart3 className="w-5 h-5 text-blue-600" />
          <h2 className="font-display font-bold text-neutral-900">Completed Cases</h2>
          <span className="text-xs text-neutral-400 ml-auto">{DATE_RANGE_LABELS[dateRange]}</span>
        </div>
        <div className="h-56 sm:h-64">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={timeSeriesData} margin={{ top: 4, right: 4, left: -20, bottom: 0 }}>
              <defs>
                <linearGradient id="areaGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#0ea5e9" stopOpacity={0.25} />
                  <stop offset="95%" stopColor="#0ea5e9" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
              <XAxis dataKey="name" tick={{ fontSize: 11, fill: '#94a3b8' }} axisLine={false} tickLine={false} />
              <YAxis allowDecimals={false} tick={{ fontSize: 11, fill: '#94a3b8' }} axisLine={false} tickLine={false} />
              <ReTooltip content={<ChartTooltip />} />
              <Area type="monotone" dataKey="cases" stroke="#0ea5e9" strokeWidth={2.5} fill="url(#areaGrad)" dot={false} activeDot={{ r: 5, fill: '#0ea5e9', stroke: '#fff', strokeWidth: 2 }} />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* ── Client Breakdown Row ── */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
        {/* Donut */}
        <div className="bg-white rounded-2xl shadow-card border border-neutral-200/60 p-5 animate-rise-in" style={{ animationDelay: '280ms' }}>
          <h2 className="font-display font-bold text-neutral-900 mb-3">Client Status</h2>
          {donutData.length === 0 ? (
            <p className="text-sm text-neutral-400 text-center py-10">No client data yet</p>
          ) : (
            <div className="h-52 flex items-center justify-center">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={donutData}
                    cx="50%" cy="50%"
                    innerRadius="55%"
                    outerRadius="80%"
                    paddingAngle={3}
                    dataKey="value"
                    stroke="none"
                  >
                    {donutData.map((_, i) => <Cell key={i} fill={DONUT_COLORS[i % DONUT_COLORS.length]} />)}
                  </Pie>
                  <ReTooltip content={<DonutTooltip />} />
                  <Legend
                    verticalAlign="bottom"
                    iconType="circle"
                    formatter={(v: string) => <span className="text-xs font-medium text-neutral-600">{v}</span>}
                  />
                </PieChart>
              </ResponsiveContainer>
            </div>
          )}
        </div>

        {/* Top clients bar */}
        <div className="bg-white rounded-2xl shadow-card border border-neutral-200/60 p-5 animate-rise-in" style={{ animationDelay: '340ms' }}>
          <h2 className="font-display font-bold text-neutral-900 mb-3">Top Clients</h2>
          {topClientsData.length === 0 ? (
            <p className="text-sm text-neutral-400 text-center py-10">No completed cases yet</p>
          ) : (
            <div className="h-52">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={topClientsData} layout="vertical" margin={{ top: 0, right: 12, left: 0, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" horizontal={false} />
                  <XAxis type="number" allowDecimals={false} tick={{ fontSize: 11, fill: '#94a3b8' }} axisLine={false} tickLine={false} />
                  <YAxis dataKey="name" type="category" tick={{ fontSize: 11, fill: '#64748b', fontWeight: 600 }} width={90} axisLine={false} tickLine={false} />
                  <ReTooltip content={<ChartTooltip />} />
                  <Bar dataKey="count" name="cases" fill="#0ea5e9" radius={[0, 6, 6, 0]} barSize={20} cursor="pointer" onClick={(data: any) => { if (data?.name) applyCustomFilter({ type: 'client', name: data.name }); }} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          )}
        </div>
      </div>

      {/* ── Technician Workload ── */}
      {technicians.length > 0 && (
        <div className="bg-white rounded-2xl shadow-card border border-neutral-200/60 p-5 mb-6 animate-rise-in" style={{ animationDelay: '400ms' }}>
          <div className="flex items-center gap-2 mb-4">
            <Wrench className="w-5 h-5 text-blue-600" />
            <h2 className="font-display font-bold text-neutral-900">Technician Workload</h2>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
            {technicians.map(t => {
              const techOrders = orders.filter(o => o.assigned_technician_id === t.technician_id);
              const active = techOrders.filter(o => ACTIVE_STATUSES.has(o.status)).length;
              const done = techOrders.filter(o => DONE_STATUSES.has(o.status)).length;
              const tp = t.technician_profile;
              return (
                <button key={t.technician_id} onClick={() => applyCustomFilter({ type: 'technician', id: t.technician_id, name: tp.name })} className={`flex items-center gap-3 p-3 rounded-xl border transition-colors text-left cursor-pointer ${customFilter.type === 'technician' && customFilter.id === t.technician_id ? 'bg-blue-50 border-blue-300 ring-2 ring-blue-200' : 'bg-neutral-50 border-neutral-200/60 hover:border-blue-200'}`}>
                  {tp.avatar_url ? (
                    <img src={tp.avatar_url} alt="" className="w-9 h-9 rounded-lg object-cover flex-shrink-0" />
                  ) : (
                    <div className="w-9 h-9 rounded-lg bg-blue-100 flex items-center justify-center flex-shrink-0">
                      <Wrench className="w-4 h-4 text-blue-600" />
                    </div>
                  )}
                  <div className="min-w-0">
                    <p className="text-sm font-bold text-neutral-900 truncate">{tp.name}</p>
                    <div className="flex items-center gap-2 mt-0.5">
                      <span className="text-xs font-semibold text-amber-600">{active} active</span>
                      <span className="text-xs font-semibold text-emerald-600">{done} done</span>
                    </div>
                  </div>
                </button>
              );
            })}
          </div>
        </div>
      )}

      {/* ── Status filter strip ── */}
      <div className="grid grid-cols-4 md:grid-cols-10 gap-2 mb-5">
        {FILTER_STATUSES.map((s, i) => {
          const cfg = STATUS_CONFIG[s];
          const active = filter === s;
          return (
            <button
              key={s}
              onClick={() => setFilter(active ? 'all' : s)}
              style={{ animationDelay: `${i * 40}ms` }}
              className={`px-2 py-2.5 rounded-xl text-center transition-all border animate-rise-in hover:-translate-y-0.5 active:scale-[0.97] ${
                active
                  ? `${cfg.bg} ${cfg.color} ${cfg.border}`
                  : 'bg-white border-neutral-200 text-neutral-500 hover:border-neutral-300'
              }`}
            >
              <div className={`w-7 h-7 rounded-lg flex items-center justify-center mx-auto mb-1 ${active ? 'bg-white/60' : cfg.bg} ${cfg.color}`}>
                {cfg.icon}
              </div>
              <p className="text-base font-bold leading-none"><CountUp value={counts[s] ?? 0} /></p>
              <p className="text-[10px] font-medium mt-0.5">{cfg.label}</p>
            </button>
          );
        })}
      </div>

      {/* ── Active filter banner ── */}
      {activeFilterLabel && (
        <div ref={ordersRef} className="flex items-center justify-between bg-blue-50 border border-blue-200 rounded-xl px-4 py-2.5 mb-4 animate-rise-in">
          <span className="text-sm font-semibold text-blue-800">{activeFilterLabel}</span>
          <button onClick={clearCustomFilter} className="text-xs font-bold text-blue-600 hover:text-blue-800 transition-colors px-2 py-1 rounded-lg hover:bg-blue-100">
            Clear
          </button>
        </div>
      )}

      {/* ── Orders list ── */}
      {!activeFilterLabel && <div ref={ordersRef} />}
      {loading ? (
        <div className="space-y-3">
          {[1, 2, 3].map(i => <div key={i} className="bg-white rounded-xl h-20 animate-pulse shadow-card" />)}
        </div>
      ) : filtered.length === 0 ? (
        <div className="text-center py-16 bg-white rounded-2xl shadow-card border border-neutral-200/60">
          {orders.length === 0 ? (
            <>
              <Microscope className="w-12 h-12 text-neutral-300 mx-auto mb-3" />
              <p className="text-neutral-500 font-medium">No orders yet</p>
              <p className="text-neutral-400 text-sm mt-1">Orders from doctors will appear here</p>
            </>
          ) : (
            <>
              <ClipboardList className="w-12 h-12 text-neutral-300 mx-auto mb-3" />
              <p className="text-neutral-500 font-medium">No {STATUS_CONFIG[filter]?.label ?? 'matching'} orders</p>
            </>
          )}
        </div>
      ) : (
        <div className="space-y-2">
          {filtered.map(order => {
            const cfg = STATUS_CONFIG[order.status];
            return (
              <button
                key={order.id}
                onClick={() => setSelected(order)}
                className="w-full bg-white rounded-xl p-4 shadow-card hover:shadow-card-hover transition-all text-left flex items-center gap-4 group border border-transparent hover:border-primary-100"
              >
                <div className={`w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 ${cfg.bg} ${cfg.color} border ${cfg.border}`}>
                  {cfg.icon}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-0.5 flex-wrap">
                    <span className="font-semibold text-neutral-900 text-sm">{order.order_number}</span>
                    <span className={`text-xs font-medium px-2 py-0.5 rounded-full border ${cfg.bg} ${cfg.color} ${cfg.border}`}>
                      {cfg.label}
                    </span>
                  </div>
                  <p className="text-sm text-neutral-600 truncate">
                    From: <span className="font-medium">{order.from_profile?.name ?? '—'}</span>
                    {' '}&bull; Patient: {order.patient_name}
                    {order.service && <span className="text-neutral-400"> · {order.service.name}</span>}
                  </p>
                  <p className="text-xs text-neutral-400 mt-0.5">File #{order.file_number}</p>
                </div>
                <div className="text-right flex-shrink-0">
                  <p className="text-xs text-neutral-400">{new Date(order.created_at).toLocaleDateString()}</p>
                  {order.due_date && (
                    <p className="text-xs text-amber-600 font-medium">Due {new Date(order.due_date).toLocaleDateString()}</p>
                  )}
                </div>
                <ChevronRight className="w-4 h-4 text-neutral-300 group-hover:text-primary-500 transition-colors ml-1" />
              </button>
            );
          })}
        </div>
      )}

      {selected && (
        <OrderDetailModal
          order={selected}
          isLab={true}
          onClose={() => setSelected(null)}
          onStatusChange={() => { fetchOrders(); setSelected(null); }}
        />
      )}
    </div>
  );
}

/* ── KPI Card ── */
function KpiCard({ icon, bg, value, label, growth, suffix, index = 0, onClick, active }: {
  icon: React.ReactNode; bg: string; value: number; label: string; growth: number | null; suffix?: string; index?: number; onClick?: () => void; active?: boolean;
}) {
  return (
    <div
      onClick={onClick}
      className={`bg-white rounded-2xl p-4 sm:p-5 shadow-card animate-rise-in transition-all duration-200 hover:-translate-y-0.5 hover:shadow-lg border ${active ? 'border-blue-300 ring-2 ring-blue-200' : 'border-neutral-200/60'} ${onClick ? 'cursor-pointer' : ''}`}
      style={{ animationDelay: `${index * 70}ms` }}
    >
      <div className="flex items-start justify-between gap-2">
        <div className={`w-10 h-10 ${bg} rounded-xl flex items-center justify-center flex-shrink-0`}>
          {icon}
        </div>
        {growth !== null && (
          <span className={`flex items-center gap-0.5 text-xs font-bold px-2 py-0.5 rounded-full ${growth >= 0 ? 'bg-emerald-50 text-emerald-600' : 'bg-red-50 text-red-500'}`}>
            {growth >= 0 ? <TrendingUp className="w-3 h-3" /> : <TrendingDown className="w-3 h-3" />}
            {growth >= 0 ? '+' : ''}{growth}%
          </span>
        )}
      </div>
      <p className="text-2xl font-bold text-neutral-900 mt-3"><CountUp value={value} />{suffix}</p>
      <p className="text-sm text-neutral-500">{label}</p>
    </div>
  );
}
