import { useEffect, useState, useCallback, useMemo, useRef } from 'react';
import { supabase, Order, Profile } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { CountUp } from '../lib/CountUp';
import { escapeHtml } from '../lib/escapeHtml';
import {
  ClipboardList, Clock, CheckCircle2,
  ChevronRight, Users, Stethoscope, TrendingUp, TrendingDown, AlertCircle,
  Search, Microscope, X, ArrowUpDown, ChevronDown, RefreshCw, Truck, FlaskConical, BadgeCheck,
  BarChart3, Percent, FileDown,
} from 'lucide-react';
import OrderDetailModal from '../components/OrderDetailModal';
import { ToothIcon } from '../components/ToothIcon';
import { useRealtimeCenterOrders } from '../lib/useRealtimeOrders';
import {
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip as ReTooltip,
  ResponsiveContainer, PieChart, Pie, Cell, Legend,
  BarChart, Bar,
} from 'recharts';
import {
  type DateRange, DATE_RANGE_LABELS, DONE_STATUSES, ACTIVE_STATUSES, DONUT_COLORS,
  rangeStart, prevRangeStart, prevRangeEnd, growthPct,
  buildTimeSeriesData, buildEntityDonutData, buildTopEntitiesData,
} from '../lib/dashboardAnalytics';

const STATUS_CONFIG: Record<string, { label: string; color: string; bg: string; border: string; icon: React.ReactNode }> = {
  pending:     { label: 'Pending',     color: 'text-amber-700',   bg: 'bg-amber-50',   border: 'border-amber-200',   icon: <ToothIcon className="w-4 h-4" variant="default" /> },
  accepted:    { label: 'Accepted',    color: 'text-blue-700',    bg: 'bg-blue-50',    border: 'border-blue-200',    icon: <ToothIcon className="w-4 h-4" variant="check" /> },
  in_progress: { label: 'In Progress', color: 'text-primary-700', bg: 'bg-primary-50', border: 'border-primary-200', icon: <ToothIcon className="w-4 h-4" variant="spin" /> },
  completed:   { label: 'Completed',   color: 'text-teal-700',    bg: 'bg-teal-50',    border: 'border-teal-200',    icon: <ToothIcon className="w-4 h-4" variant="sparkle" /> },
  try_in:      { label: 'Try In',      color: 'text-amber-700',   bg: 'bg-amber-50',   border: 'border-amber-300',   icon: <FlaskConical className="w-4 h-4" /> },
  delivering:  { label: 'Delivering',  color: 'text-cyan-700',    bg: 'bg-cyan-50',    border: 'border-cyan-200',    icon: <Truck className="w-4 h-4" /> },
  delivered:   { label: 'Delivered',   color: 'text-emerald-700', bg: 'bg-emerald-50', border: 'border-emerald-200', icon: <CheckCircle2 className="w-4 h-4" /> },
  rejected:    { label: 'Rejected',    color: 'text-red-700',     bg: 'bg-red-50',     border: 'border-red-200',     icon: <ToothIcon className="w-4 h-4" variant="x" /> },
  cancelled:   { label: 'Cancelled',   color: 'text-neutral-600', bg: 'bg-neutral-50', border: 'border-neutral-200', icon: <ToothIcon className="w-4 h-4" variant="slash" /> },
  redo:        { label: 'Redo',        color: 'text-orange-700',  bg: 'bg-orange-50',  border: 'border-orange-200',  icon: <ToothIcon className="w-4 h-4" variant="redo" /> },
  finished:    { label: 'Finished',    color: 'text-green-800',   bg: 'bg-green-50',   border: 'border-green-300',   icon: <BadgeCheck className="w-4 h-4" /> },
};
const FILTER_STATUSES = ['pending', 'accepted', 'in_progress', 'completed', 'try_in', 'delivered', 'rejected', 'cancelled', 'redo', 'finished'] as const;
type FilterValue = typeof FILTER_STATUSES[number] | 'all';
type CustomFilter =
  | { type: 'none' }
  | { type: 'kpi'; key: 'completed' | 'pending' | 'labs' }
  | { type: 'lab'; name: string }
  | { type: 'doctor'; name: string };

const THIRTY_DAYS_MS = 30 * 24 * 60 * 60 * 1000;

type SortKey = 'date_desc' | 'date_asc' | 'doctor_asc' | 'doctor_desc';
const SORT_LABELS: Record<SortKey, string> = {
  date_desc: 'Newest first',
  date_asc: 'Oldest first',
  doctor_asc: 'Doctor A \u2192 Z',
  doctor_desc: 'Doctor Z \u2192 A',
};

function getDoctorName(order: Order, centerId: string): string {
  return order.from_id === centerId
    ? (order.dr_name ?? '')
    : (order.from_profile?.name ?? order.dr_name ?? '');
}

function ChartTooltip({ active, payload, label }: any) {
  if (!active || !payload?.length) return null;
  return (
    <div className="bg-white/95 backdrop-blur-md rounded-xl shadow-lg border border-neutral-200 px-4 py-2.5">
      <p className="text-xs font-semibold text-neutral-500 mb-0.5">{label}</p>
      {payload.map((p: any, i: number) => (
        <p key={i} className="text-sm font-bold" style={{ color: p.color ?? '#0ea5e9' }}>
          {p.value} {p.name ?? 'cases'}
        </p>
      ))}
    </div>
  );
}

function DonutTooltip({ active, payload }: any) {
  if (!active || !payload?.length) return null;
  return (
    <div className="bg-white/95 backdrop-blur-md rounded-xl shadow-lg border border-neutral-200 px-4 py-2.5">
      <p className="text-sm font-bold text-neutral-900">{payload[0].name}: {payload[0].value}</p>
    </div>
  );
}

function buildDoctorBarData(orders: Order[], centerId: string) {
  const map = new Map<string, { name: string; count: number }>();
  orders.filter(o => DONE_STATUSES.has(o.status)).forEach(o => {
    const name = getDoctorName(o, centerId);
    if (!name) return;
    const entry = map.get(name) ?? { name, count: 0 };
    entry.count++;
    map.set(name, entry);
  });
  return [...map.values()].sort((a, b) => b.count - a.count).slice(0, 8);
}

export default function CenterDashboard() {
  const { profile } = useAuth();
  const [orders, setOrders] = useState<Order[]>([]);
  const [members, setMembers] = useState<Profile[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<FilterValue>('all');
  const [doctorFilter, setDoctorFilter] = useState<string>('all');
  const [sortKey, setSortKey] = useState<SortKey>('date_desc');
  const [sortOpen, setSortOpen] = useState(false);
  const [selected, setSelected] = useState<Order | null>(null);
  const [dateRange, setDateRange] = useState<DateRange>('30d');
  const [showRangeMenu, setShowRangeMenu] = useState(false);
  const [customFilter, setCustomFilter] = useState<CustomFilter>({ type: 'none' });
  const sortRef = useRef<HTMLDivElement>(null);
  const ordersRef = useRef<HTMLDivElement>(null);

  const scrollToOrders = useCallback(() => {
    setTimeout(() => ordersRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' }), 80);
  }, []);

  const fetchData = useCallback(async () => {
    if (!profile) return;
    setLoading(true);

    const { data: memberRows } = await supabase
      .from('center_members')
      .select('doctor_id, doctor_profile:profiles!center_members_doctor_id_fkey(*)')
      .eq('center_id', profile.id);

    const doctorProfiles = (memberRows ?? []).map((r: { doctor_id: string; doctor_profile: Profile }) => r.doctor_profile).filter(Boolean);
    setMembers(doctorProfiles);

    const senderIds = [profile.id, ...(memberRows ?? []).map((r: { doctor_id: string }) => r.doctor_id)];

    const { data: orderData } = await supabase
      .from('orders')
      .select('*, from_profile:profiles!orders_from_id_fkey(*), lab_profile:profiles!orders_lab_id_fkey(*), service:services(*), attachments:order_attachments(*), order_services(*, service:services(*))')
      .in('from_id', senderIds)
      .order('created_at', { ascending: false });

    setOrders(orderData ?? []);
    setLoading(false);
  }, [profile]);

  useEffect(() => { fetchData(); }, [fetchData]);

  const doctorIds = (members ?? []).map((m: Profile) => m.id);
  useRealtimeCenterOrders(profile?.id, doctorIds, fetchData);

  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (sortRef.current && !sortRef.current.contains(e.target as Node)) setSortOpen(false);
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  /* ── Analytics derived data ── */
  const start = useMemo(() => rangeStart(dateRange), [dateRange]);
  const prevStart = useMemo(() => prevRangeStart(dateRange), [dateRange]);
  const prevEnd = useMemo(() => prevRangeEnd(dateRange), [dateRange]);

  const rangedOrders = useMemo(() => orders.filter(o => new Date(o.created_at) >= start), [orders, start]);
  const prevOrders = useMemo(() => orders.filter(o => { const d = new Date(o.created_at); return d >= prevStart && d < prevEnd; }), [orders, prevStart, prevEnd]);

  const uniqueLabs = useMemo(() => new Set(rangedOrders.map(o => o.lab_id)).size, [rangedOrders]);
  const prevLabs = useMemo(() => new Set(prevOrders.map(o => o.lab_id)).size, [prevOrders]);
  const completedCount = useMemo(() => rangedOrders.filter(o => DONE_STATUSES.has(o.status)).length, [rangedOrders]);
  const prevCompleted = useMemo(() => prevOrders.filter(o => DONE_STATUSES.has(o.status)).length, [prevOrders]);
  const pendingCount = useMemo(() => rangedOrders.filter(o => ACTIVE_STATUSES.has(o.status)).length, [rangedOrders]);
  const prevPending = useMemo(() => prevOrders.filter(o => ACTIVE_STATUSES.has(o.status)).length, [prevOrders]);
  const completionRate = useMemo(() => rangedOrders.length === 0 ? 0 : Math.round((completedCount / rangedOrders.length) * 100), [completedCount, rangedOrders]);
  const prevRate = useMemo(() => prevOrders.length === 0 ? 0 : Math.round((prevCompleted / prevOrders.length) * 100), [prevCompleted, prevOrders]);

  const timeSeriesData = useMemo(() => buildTimeSeriesData(orders, dateRange), [orders, dateRange]);
  const labDonutData = useMemo(() => buildEntityDonutData(orders, 'lab_id'), [orders]);
  const topLabsData = useMemo(() => buildTopEntitiesData(rangedOrders, 'lab_id', 'lab_profile'), [rangedOrders]);
  const doctorBarData = useMemo(() => buildDoctorBarData(rangedOrders, profile?.id ?? ''), [rangedOrders, profile]);

  /* ── Status counts (all orders) ── */
  const counts = orders.reduce((acc, o) => {
    if (o.status === 'delivered') {
      if (o.finished_at || Date.now() - new Date(o.updated_at ?? o.created_at).getTime() > THIRTY_DAYS_MS) {
        acc['finished'] = (acc['finished'] ?? 0) + 1;
      } else {
        acc['delivered'] = (acc['delivered'] ?? 0) + 1;
      }
    } else {
      acc[o.status] = (acc[o.status] ?? 0) + 1;
    }
    return acc;
  }, {} as Record<string, number>);

  const teamDoctorNames = members.map(m => m.name).filter(Boolean);
  const drNamesFromOrders = orders.filter(o => o.from_id === profile?.id && o.dr_name).map(o => o.dr_name as string);
  const allDoctorNames = Array.from(new Set([...teamDoctorNames, ...drNamesFromOrders])).sort();

  /* ── Filtering + sorting ── */
  const statusFiltered = useMemo(() => {
    let list = filter === 'all' ? orders
      : filter === 'finished' ? orders.filter(o => o.status === 'delivered' && (o.finished_at || Date.now() - new Date(o.updated_at ?? o.created_at).getTime() > THIRTY_DAYS_MS))
      : filter === 'delivered' ? orders.filter(o => o.status === 'delivered' && !o.finished_at && Date.now() - new Date(o.updated_at ?? o.created_at).getTime() <= THIRTY_DAYS_MS)
      : filter === 'redo' ? orders.filter(o => o.status === 'redo')
      : orders.filter(o => o.status === filter);

    if (doctorFilter !== 'all') {
      list = list.filter(o => getDoctorName(o, profile?.id ?? '') === doctorFilter);
    }

    return [...list].sort((a, b) => {
      if (sortKey === 'date_desc') return new Date(b.created_at).getTime() - new Date(a.created_at).getTime();
      if (sortKey === 'date_asc')  return new Date(a.created_at).getTime() - new Date(b.created_at).getTime();
      const da = getDoctorName(a, profile?.id ?? '').toLowerCase();
      const db = getDoctorName(b, profile?.id ?? '').toLowerCase();
      if (sortKey === 'doctor_asc')  return da.localeCompare(db);
      return db.localeCompare(da);
    });
  }, [orders, filter, doctorFilter, sortKey, profile]);

  const displayOrders = useMemo(() => {
    if (customFilter.type === 'none') return statusFiltered;
    if (customFilter.type === 'kpi') {
      if (customFilter.key === 'completed') return statusFiltered.filter(o => DONE_STATUSES.has(o.status));
      if (customFilter.key === 'pending') return statusFiltered.filter(o => ACTIVE_STATUSES.has(o.status));
      return statusFiltered;
    }
    if (customFilter.type === 'lab') return statusFiltered.filter(o => o.lab_profile?.name === customFilter.name);
    if (customFilter.type === 'doctor') return statusFiltered.filter(o => getDoctorName(o, profile?.id ?? '') === customFilter.name);
    return statusFiltered;
  }, [statusFiltered, customFilter, profile]);

  const activeFilterLabel = customFilter.type === 'lab' ? `Lab: ${customFilter.name}`
    : customFilter.type === 'doctor' ? `Doctor: ${customFilter.name}`
    : customFilter.type === 'kpi' ? `Showing: ${customFilter.key === 'completed' ? 'Completed' : customFilter.key === 'pending' ? 'Pending' : 'All Labs'}`
    : null;

  const clearCustomFilter = () => setCustomFilter({ type: 'none' });

  const applyCustomFilter = useCallback((cf: CustomFilter) => {
    setCustomFilter(prev => prev.type === cf.type && JSON.stringify(prev) === JSON.stringify(cf) ? { type: 'none' } : cf);
    scrollToOrders();
  }, [scrollToOrders]);

  /* ── PDF export ── */
  const handleExportPDF = () => {
    const centerId = profile?.id ?? '';
    const centerName = profile?.name ?? 'Center';
    const title = doctorFilter !== 'all' ? `Orders — ${doctorFilter}` : 'All Team Orders';
    const now = new Date().toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' });

    const rows = displayOrders.map(o => {
      const doctor = getDoctorName(o, centerId);
      const status = STATUS_CONFIG[o.status]?.label ?? o.status;
      const date = new Date(o.created_at).toLocaleDateString('en-GB');
      const due = o.due_date ? new Date(o.due_date).toLocaleDateString('en-GB') : '\u2014';
      return `
        <tr>
          <td>${escapeHtml(o.order_number)}</td>
          <td>${escapeHtml(doctor || '\u2014')}</td>
          <td>${escapeHtml(o.patient_name)}</td>
          <td>${escapeHtml(o.lab_profile?.name ?? '\u2014')}</td>
          <td>${escapeHtml(o.service?.name ?? '\u2014')}</td>
          <td><span class="badge status-${escapeHtml(o.status)}">${escapeHtml(status)}</span></td>
          <td>${escapeHtml(date)}</td>
          <td>${escapeHtml(due)}</td>
        </tr>`;
    }).join('');

    const printDiv = document.getElementById('print-orders')!;
    printDiv.innerHTML = `
      <style>
        @page { margin: 16mm 14mm; size: A4 landscape; }
        body { font-family: Inter, system-ui, sans-serif; color: #111; }
        #print-orders { padding: 0; }
        .ph { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 20px; border-bottom: 2px solid #0ea5e9; padding-bottom: 12px; }
        .ph-left h1 { font-size: 18px; font-weight: 700; margin: 0 0 2px; }
        .ph-left p { font-size: 11px; color: #64748b; margin: 0; }
        .ph-right { text-align: right; font-size: 11px; color: #64748b; }
        .ph-right strong { display: block; font-size: 13px; color: #111; }
        table { width: 100%; border-collapse: collapse; font-size: 11px; }
        th { background: #f1f5f9; text-align: left; padding: 7px 10px; font-weight: 600; color: #475569; border-bottom: 1px solid #e2e8f0; font-size: 10px; text-transform: uppercase; letter-spacing: .04em; }
        td { padding: 7px 10px; border-bottom: 1px solid #f1f5f9; color: #334155; vertical-align: middle; }
        tr:last-child td { border-bottom: none; }
        .badge { display: inline-block; padding: 2px 7px; border-radius: 99px; font-size: 10px; font-weight: 600; }
        .status-pending     { background:#fef3c7; color:#92400e; }
        .status-accepted    { background:#dbeafe; color:#1e40af; }
        .status-in_progress { background:#e0f2fe; color:#0c4a6e; }
        .status-completed   { background:#ccfbf1; color:#134e4a; }
        .status-try_in      { background:#fef3c7; color:#92400e; }
        .status-delivering  { background:#cffafe; color:#155e75; }
        .status-delivered   { background:#d1fae5; color:#065f46; }
        .status-rejected    { background:#fee2e2; color:#991b1b; }
        .status-cancelled   { background:#f1f5f9; color:#475569; }
        .footer { margin-top: 16px; font-size: 10px; color: #94a3b8; text-align: right; }
      </style>
      <div class="ph">
        <div class="ph-left">
          <h1>${escapeHtml(title)}</h1>
          <p>Exported on ${now}</p>
        </div>
        <div class="ph-right">
          <strong>${escapeHtml(centerName)}</strong>
          ${displayOrders.length} order${displayOrders.length !== 1 ? 's' : ''}
        </div>
      </div>
      <table>
        <thead>
          <tr>
            <th>Order #</th><th>Doctor</th><th>Patient</th><th>Lab</th>
            <th>Service</th><th>Status</th><th>Date</th><th>Due</th>
          </tr>
        </thead>
        <tbody>${rows}</tbody>
      </table>
      <div class="footer">Bridge Dental Platform</div>
    `;
    window.print();
  };

  return (
    <div className="p-4 sm:p-6 max-w-5xl mx-auto">
      {/* Header + date range */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="font-display text-2xl font-bold text-neutral-900">Center Dashboard</h1>
          <p className="text-neutral-500 text-sm mt-1">Welcome back, {profile?.name}</p>
        </div>
        <div className="flex items-center gap-2">
          <div className="relative">
            <button
              onClick={() => setShowRangeMenu(!showRangeMenu)}
              className="flex items-center gap-2 px-4 py-2 bg-white rounded-xl border border-neutral-200 shadow-card text-sm font-semibold text-neutral-700 hover:border-neutral-300 transition-colors"
            >
              <span className="hidden sm:inline">{DATE_RANGE_LABELS[dateRange]}</span>
              <span className="sm:hidden text-xs">{dateRange === 'year' ? 'Year' : dateRange}</span>
              <ChevronDown className="w-4 h-4 text-neutral-400" />
            </button>
            {showRangeMenu && (
              <>
                <div className="fixed inset-0 z-20" onClick={() => setShowRangeMenu(false)} />
                <div className="absolute right-0 top-full mt-1 bg-white rounded-xl border border-neutral-200 shadow-lg z-30 overflow-hidden min-w-[160px]">
                  {(['7d', '30d', 'year'] as DateRange[]).map(r => (
                    <button key={r} onClick={() => { setDateRange(r); setShowRangeMenu(false); }}
                      className={`w-full text-left px-4 py-2.5 text-sm font-medium transition-colors ${r === dateRange ? 'bg-blue-50 text-blue-700' : 'text-neutral-700 hover:bg-neutral-50'}`}
                    >{DATE_RANGE_LABELS[r]}</button>
                  ))}
                </div>
              </>
            )}
          </div>
          <button onClick={handleExportPDF}
            className="flex items-center gap-2 px-4 py-2.5 bg-primary-600 hover:bg-primary-700 text-white text-sm font-semibold rounded-xl transition-colors shadow-sm"
          >
            <FileDown className="w-4 h-4" />
            <span className="hidden sm:inline">Export</span>
          </button>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4 mb-6">
        <KpiCard icon={<Microscope className="w-5 h-5 text-blue-600" />} bg="bg-blue-50" value={uniqueLabs} label="Labs Used" growth={growthPct(uniqueLabs, prevLabs)} index={0} onClick={() => applyCustomFilter({ type: 'kpi', key: 'labs' })} active={customFilter.type === 'kpi' && customFilter.key === 'labs'} />
        <KpiCard icon={<CheckCircle2 className="w-5 h-5 text-teal-600" />} bg="bg-teal-50" value={completedCount} label="Completed" growth={growthPct(completedCount, prevCompleted)} index={1} onClick={() => applyCustomFilter({ type: 'kpi', key: 'completed' })} active={customFilter.type === 'kpi' && customFilter.key === 'completed'} />
        <KpiCard icon={<Clock className="w-5 h-5 text-amber-600" />} bg="bg-amber-50" value={pendingCount} label="Pending" growth={growthPct(pendingCount, prevPending)} index={2} onClick={() => applyCustomFilter({ type: 'kpi', key: 'pending' })} active={customFilter.type === 'kpi' && customFilter.key === 'pending'} />
        <KpiCard icon={<Percent className="w-5 h-5 text-primary-600" />} bg="bg-primary-50" value={completionRate} label="Completion %" growth={growthPct(completionRate, prevRate)} suffix="%" index={3} />
      </div>

      {/* Completed Cases Chart */}
      <div className="bg-white rounded-2xl shadow-card border border-neutral-200/60 p-5 mb-6 animate-rise-in" style={{ animationDelay: '200ms' }}>
        <div className="flex items-center gap-2 mb-4">
          <BarChart3 className="w-5 h-5 text-blue-600" />
          <h2 className="font-display font-bold text-neutral-900">Completed Cases</h2>
          <span className="text-xs text-neutral-400 ml-auto">{DATE_RANGE_LABELS[dateRange]}</span>
        </div>
        <div className="h-56 sm:h-64">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={timeSeriesData} margin={{ top: 4, right: 4, left: -20, bottom: 0 }}>
              <defs>
                <linearGradient id="ctAreaGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#0ea5e9" stopOpacity={0.25} />
                  <stop offset="95%" stopColor="#0ea5e9" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
              <XAxis dataKey="name" tick={{ fontSize: 11, fill: '#94a3b8' }} axisLine={false} tickLine={false} />
              <YAxis allowDecimals={false} tick={{ fontSize: 11, fill: '#94a3b8' }} axisLine={false} tickLine={false} />
              <ReTooltip content={<ChartTooltip />} />
              <Area type="monotone" dataKey="cases" stroke="#0ea5e9" strokeWidth={2.5} fill="url(#ctAreaGrad)" dot={false} activeDot={{ r: 5, fill: '#0ea5e9', stroke: '#fff', strokeWidth: 2 }} />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Lab Breakdown + Doctor Performance */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
        <div className="bg-white rounded-2xl shadow-card border border-neutral-200/60 p-5 animate-rise-in" style={{ animationDelay: '280ms' }}>
          <h2 className="font-display font-bold text-neutral-900 mb-3">Lab Status</h2>
          {labDonutData.length === 0 ? (
            <p className="text-sm text-neutral-400 text-center py-10">No lab data yet</p>
          ) : (
            <div className="h-52 flex items-center justify-center">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie data={labDonutData} cx="50%" cy="50%" innerRadius="55%" outerRadius="80%" paddingAngle={3} dataKey="value" stroke="none">
                    {labDonutData.map((_, i) => <Cell key={i} fill={DONUT_COLORS[i % DONUT_COLORS.length]} />)}
                  </Pie>
                  <ReTooltip content={<DonutTooltip />} />
                  <Legend verticalAlign="bottom" iconType="circle" formatter={(v: string) => <span className="text-xs font-medium text-neutral-600">{v}</span>} />
                </PieChart>
              </ResponsiveContainer>
            </div>
          )}
        </div>

        <div className="bg-white rounded-2xl shadow-card border border-neutral-200/60 p-5 animate-rise-in" style={{ animationDelay: '340ms' }}>
          <h2 className="font-display font-bold text-neutral-900 mb-3">Doctor Performance</h2>
          {doctorBarData.length === 0 ? (
            <p className="text-sm text-neutral-400 text-center py-10">No completed cases yet</p>
          ) : (
            <div className="h-52">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={doctorBarData} layout="vertical" margin={{ top: 0, right: 12, left: 0, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" horizontal={false} />
                  <XAxis type="number" allowDecimals={false} tick={{ fontSize: 11, fill: '#94a3b8' }} axisLine={false} tickLine={false} />
                  <YAxis dataKey="name" type="category" tick={{ fontSize: 11, fill: '#64748b', fontWeight: 600 }} width={90} axisLine={false} tickLine={false} />
                  <ReTooltip content={<ChartTooltip />} />
                  <Bar dataKey="count" name="cases" fill="#22c55e" radius={[0, 6, 6, 0]} barSize={20} cursor="pointer" onClick={(data: any) => { if (data?.name) applyCustomFilter({ type: 'doctor', name: data.name }); }} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          )}
        </div>
      </div>

      {/* Top Labs bar (extra insight) */}
      {topLabsData.length > 0 && (
        <div className="bg-white rounded-2xl shadow-card border border-neutral-200/60 p-5 mb-6 animate-rise-in" style={{ animationDelay: '400ms' }}>
          <div className="flex items-center gap-2 mb-4">
            <Microscope className="w-5 h-5 text-blue-600" />
            <h2 className="font-display font-bold text-neutral-900">Top Labs</h2>
          </div>
          <div className="h-44">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={topLabsData} layout="vertical" margin={{ top: 0, right: 12, left: 0, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" horizontal={false} />
                <XAxis type="number" allowDecimals={false} tick={{ fontSize: 11, fill: '#94a3b8' }} axisLine={false} tickLine={false} />
                <YAxis dataKey="name" type="category" tick={{ fontSize: 11, fill: '#64748b', fontWeight: 600 }} width={90} axisLine={false} tickLine={false} />
                <ReTooltip content={<ChartTooltip />} />
                <Bar dataKey="count" name="cases" fill="#0ea5e9" radius={[0, 6, 6, 0]} barSize={20} cursor="pointer" onClick={(data: any) => { if (data?.name) applyCustomFilter({ type: 'lab', name: data.name }); }} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      )}

      {/* Status filter strip */}
      <div className="grid grid-cols-4 md:grid-cols-10 gap-2 mb-4">
        {FILTER_STATUSES.map((s, i) => {
          const cfg = STATUS_CONFIG[s];
          const active = filter === s;
          return (
            <button key={s} onClick={() => setFilter(active ? 'all' : s)} style={{ animationDelay: `${i * 40}ms` }}
              className={`px-2 py-2.5 rounded-xl text-center transition-all border animate-rise-in hover:-translate-y-0.5 active:scale-[0.97] ${active ? `${cfg.bg} ${cfg.color} ${cfg.border}` : 'bg-white border-neutral-200 text-neutral-500 hover:border-neutral-300'}`}
            >
              <div className={`w-7 h-7 rounded-lg flex items-center justify-center mx-auto mb-1 ${active ? 'bg-white/60' : cfg.bg} ${cfg.color}`}>
                {cfg.icon}
              </div>
              <p className="text-base font-bold leading-none"><CountUp value={counts[s] ?? 0} /></p>
              <p className="text-[10px] font-medium mt-0.5">{cfg.label}</p>
            </button>
          );
        })}
      </div>

      {/* Doctor filter + sort bar */}
      <div className="flex items-center gap-2 mb-5 flex-wrap">
        <div className="flex items-center gap-1.5 flex-wrap flex-1">
          <button onClick={() => setDoctorFilter('all')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all border ${doctorFilter === 'all' ? 'bg-primary-600 text-white border-primary-600' : 'bg-white text-neutral-500 border-neutral-200 hover:border-neutral-300'}`}
          ><Users className="w-3 h-3" /> All Doctors</button>
          {allDoctorNames.map(name => (
            <button key={name} onClick={() => setDoctorFilter(doctorFilter === name ? 'all' : name)}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all border ${doctorFilter === name ? 'bg-blue-600 text-white border-blue-600' : 'bg-white text-neutral-500 border-neutral-200 hover:border-neutral-300'}`}
            ><Stethoscope className="w-3 h-3" /> {name}</button>
          ))}
        </div>

        <div className="relative" ref={sortRef}>
          <button onClick={() => setSortOpen(o => !o)}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-white border border-neutral-200 hover:border-neutral-300 text-neutral-600 text-xs font-semibold rounded-lg transition-all"
          >
            <ArrowUpDown className="w-3.5 h-3.5" />
            {SORT_LABELS[sortKey]}
            <ChevronDown className={`w-3 h-3 transition-transform ${sortOpen ? 'rotate-180' : ''}`} />
          </button>
          {sortOpen && (
            <div className="absolute right-0 top-full mt-1.5 bg-white border border-neutral-200 rounded-xl shadow-lg z-20 py-1 min-w-[160px]">
              {(Object.keys(SORT_LABELS) as SortKey[]).map(k => (
                <button key={k} onClick={() => { setSortKey(k); setSortOpen(false); }}
                  className={`w-full text-left px-3.5 py-2 text-xs font-medium transition-colors ${sortKey === k ? 'text-primary-600 bg-primary-50' : 'text-neutral-700 hover:bg-neutral-50'}`}
                >{SORT_LABELS[k]}</button>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Active filter banner */}
      {activeFilterLabel && (
        <div ref={ordersRef} className="flex items-center justify-between bg-blue-50 border border-blue-200 rounded-xl px-4 py-2.5 mb-4 animate-rise-in">
          <span className="text-sm font-semibold text-blue-800">{activeFilterLabel}</span>
          <button onClick={clearCustomFilter} className="text-xs font-bold text-blue-600 hover:text-blue-800 transition-colors px-2 py-1 rounded-lg hover:bg-blue-100">Clear</button>
        </div>
      )}

      {/* Orders list */}
      {!activeFilterLabel && <div ref={ordersRef} />}
      {loading ? (
        <div className="space-y-3">
          {[1, 2, 3].map(i => <div key={i} className="bg-white rounded-xl h-20 animate-pulse shadow-card" />)}
        </div>
      ) : displayOrders.length === 0 ? (
        <div className="text-center py-16 bg-white rounded-2xl shadow-card border border-neutral-200/60">
          {orders.length === 0 ? (
            <>
              <AlertCircle className="w-12 h-12 text-neutral-300 mx-auto mb-3" />
              <p className="text-neutral-500 font-medium">No orders yet</p>
              <p className="text-neutral-400 text-sm mt-1">
                {members.length === 0 ? 'Add doctors to your team so they can place orders' : 'Your team doctors have not placed any orders yet'}
              </p>
            </>
          ) : (
            <>
              <ClipboardList className="w-12 h-12 text-neutral-300 mx-auto mb-3" />
              <p className="text-neutral-500 font-medium">No orders match this filter</p>
            </>
          )}
        </div>
      ) : (
        <div className="space-y-2">
          {displayOrders.map(order => {
            const cfg = STATUS_CONFIG[order.status];
            const isFromCenter = order.from_id === profile?.id;
            const doctorName = getDoctorName(order, profile?.id ?? '');
            return (
              <button key={order.id} onClick={() => setSelected(order)}
                className="w-full bg-white rounded-xl p-4 shadow-card hover:shadow-card-hover transition-all text-left flex items-center gap-4 group border border-transparent hover:border-primary-100"
              >
                <div className={`w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 ${cfg.bg} ${cfg.color} border ${cfg.border}`}>
                  {cfg.icon}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-0.5 flex-wrap">
                    <span className="font-semibold text-neutral-900 text-sm">{order.order_number}</span>
                    <span className={`text-xs font-medium px-2 py-0.5 rounded-full border ${cfg.bg} ${cfg.color} ${cfg.border}`}>{cfg.label}</span>
                    {order.parent_order_id && (
                      <span className="flex items-center gap-1 text-[11px] font-semibold text-orange-700 bg-orange-50 border border-orange-200 px-2 py-0.5 rounded-full">
                        <RefreshCw className="w-2.5 h-2.5" /> Redo
                      </span>
                    )}
                    {doctorName && (
                      <span className={`flex items-center gap-1 text-xs px-2 py-0.5 rounded-full border ${isFromCenter ? 'text-violet-600 bg-violet-50 border-violet-200' : 'text-blue-600 bg-blue-50 border-blue-200'}`}>
                        <Stethoscope className="w-3 h-3" /> {doctorName}
                      </span>
                    )}
                  </div>
                  <p className="text-sm text-neutral-600 truncate">
                    To: <span className="font-medium">{order.lab_profile?.name ?? '\u2014'}</span>
                    {' '}&bull; Patient: {order.patient_name}
                  </p>
                  <p className="text-xs text-neutral-400 mt-0.5">File #{order.file_number}</p>
                </div>
                <div className="text-right flex-shrink-0">
                  <p className="text-xs text-neutral-400">{new Date(order.created_at).toLocaleDateString()}</p>
                  {order.due_date && (
                    <p className="text-xs text-amber-600 font-medium">Due {new Date(order.due_date).toLocaleDateString()}</p>
                  )}
                </div>
                <ChevronRight className="w-4 h-4 text-neutral-300 group-hover:text-primary-500 transition-colors ml-1" />
              </button>
            );
          })}
        </div>
      )}

      {selected && (
        <OrderDetailModal order={selected} isLab={false} onClose={() => setSelected(null)} onStatusChange={() => { fetchData(); setSelected(null); }} />
      )}
    </div>
  );
}

/* ─── KPI Card ──────────────────────────────────────────────────────────────── */

function KpiCard({ icon, bg, value, label, growth, suffix, index = 0, onClick, active }: {
  icon: React.ReactNode; bg: string; value: number; label: string; growth: number | null; suffix?: string; index?: number; onClick?: () => void; active?: boolean;
}) {
  return (
    <div onClick={onClick}
      className={`bg-white rounded-2xl p-4 sm:p-5 shadow-card animate-rise-in transition-all duration-200 hover:-translate-y-0.5 hover:shadow-lg border ${active ? 'border-blue-300 ring-2 ring-blue-200' : 'border-neutral-200/60'} ${onClick ? 'cursor-pointer' : ''}`}
      style={{ animationDelay: `${index * 70}ms` }}
    >
      <div className="flex items-start justify-between gap-2">
        <div className={`w-10 h-10 ${bg} rounded-xl flex items-center justify-center flex-shrink-0`}>{icon}</div>
        {growth !== null && (
          <span className={`flex items-center gap-0.5 text-xs font-bold px-2 py-0.5 rounded-full ${growth >= 0 ? 'bg-emerald-50 text-emerald-600' : 'bg-red-50 text-red-500'}`}>
            {growth >= 0 ? <TrendingUp className="w-3 h-3" /> : <TrendingDown className="w-3 h-3" />}
            {growth >= 0 ? '+' : ''}{growth}%
          </span>
        )}
      </div>
      <p className="text-2xl font-bold text-neutral-900 mt-3"><CountUp value={value} />{suffix}</p>
      <p className="text-sm text-neutral-500">{label}</p>
    </div>
  );
}
