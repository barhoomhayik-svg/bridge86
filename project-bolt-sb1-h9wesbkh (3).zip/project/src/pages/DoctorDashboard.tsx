import { useEffect, useState, useCallback, useMemo, useRef } from 'react';
import { supabase, Order, Profile, Service } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { CountUp } from '../lib/CountUp';
import {
  ClipboardList, Clock, CheckCircle2,
  ChevronRight, TrendingUp, TrendingDown, Plus, Search, Microscope, X,
  Heart, MapPin, FlaskConical, RefreshCw, Wallet, Building2, Truck, BadgeCheck,
  ChevronDown, BarChart3, Percent,
} from 'lucide-react';
import OrderDetailModal from '../components/OrderDetailModal';
import NewOrderModal from '../components/NewOrderModal';
import { ToothIcon } from '../components/ToothIcon';
import { useRealtimeOrders } from '../lib/useRealtimeOrders';
import {
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip as ReTooltip,
  ResponsiveContainer, PieChart, Pie, Cell, Legend,
  BarChart, Bar,
} from 'recharts';
import {
  type DateRange, DATE_RANGE_LABELS, DONE_STATUSES, ACTIVE_STATUSES, DONUT_COLORS,
  rangeStart, prevRangeStart, prevRangeEnd, growthPct,
  buildTimeSeriesData, buildEntityDonutData, buildTopEntitiesData,
} from '../lib/dashboardAnalytics';

const STATUS_CONFIG: Record<string, { label: string; color: string; bg: string; border: string; icon: React.ReactNode }> = {
  pending:     { label: 'Pending',     color: 'text-amber-700',   bg: 'bg-amber-50',   border: 'border-amber-200',   icon: <ToothIcon className="w-4 h-4" variant="default" /> },
  accepted:    { label: 'Accepted',    color: 'text-blue-700',    bg: 'bg-blue-50',    border: 'border-blue-200',    icon: <ToothIcon className="w-4 h-4" variant="check" /> },
  in_progress: { label: 'In Progress', color: 'text-primary-700', bg: 'bg-primary-50', border: 'border-primary-200', icon: <ToothIcon className="w-4 h-4" variant="spin" /> },
  completed:   { label: 'Completed',   color: 'text-teal-700',    bg: 'bg-teal-50',    border: 'border-teal-200',    icon: <ToothIcon className="w-4 h-4" variant="sparkle" /> },
  try_in:      { label: 'Try In',      color: 'text-amber-700',   bg: 'bg-amber-50',    border: 'border-amber-300',    icon: <FlaskConical className="w-4 h-4" /> },
  delivering:  { label: 'Delivering',  color: 'text-cyan-700',    bg: 'bg-cyan-50',    border: 'border-cyan-200',    icon: <Truck className="w-4 h-4" /> },
  delivered:   { label: 'Delivered',   color: 'text-emerald-700', bg: 'bg-emerald-50', border: 'border-emerald-200', icon: <CheckCircle2 className="w-4 h-4" /> },
  rejected:    { label: 'Rejected',    color: 'text-red-700',     bg: 'bg-red-50',     border: 'border-red-200',     icon: <ToothIcon className="w-4 h-4" variant="x" /> },
  cancelled:   { label: 'Cancelled',   color: 'text-neutral-600', bg: 'bg-neutral-50', border: 'border-neutral-200', icon: <ToothIcon className="w-4 h-4" variant="slash" /> },
  redo:        { label: 'Redo',        color: 'text-orange-700',  bg: 'bg-orange-50',  border: 'border-orange-200',  icon: <ToothIcon className="w-4 h-4" variant="redo" /> },
  finished:    { label: 'Finished',    color: 'text-green-800',   bg: 'bg-green-50',   border: 'border-green-300',   icon: <BadgeCheck className="w-4 h-4" /> },
};
const FILTER_STATUSES = ['pending', 'accepted', 'in_progress', 'completed', 'try_in', 'delivered', 'rejected', 'cancelled', 'redo', 'finished'] as const;
type FilterValue = typeof FILTER_STATUSES[number] | 'all';
type CustomFilter =
  | { type: 'none' }
  | { type: 'kpi'; key: 'completed' | 'pending' | 'labs' }
  | { type: 'lab'; name: string };

const THIRTY_DAYS_MS = 30 * 24 * 60 * 60 * 1000;

interface Props { onNavigateDiscover: () => void; }

function ChartTooltip({ active, payload, label }: any) {
  if (!active || !payload?.length) return null;
  return (
    <div className="bg-white/95 backdrop-blur-md rounded-xl shadow-lg border border-neutral-200 px-4 py-2.5">
      <p className="text-xs font-semibold text-neutral-500 mb-0.5">{label}</p>
      {payload.map((p: any, i: number) => (
        <p key={i} className="text-sm font-bold" style={{ color: p.color ?? '#0ea5e9' }}>
          {p.value} {p.name ?? 'cases'}
        </p>
      ))}
    </div>
  );
}

function DonutTooltip({ active, payload }: any) {
  if (!active || !payload?.length) return null;
  return (
    <div className="bg-white/95 backdrop-blur-md rounded-xl shadow-lg border border-neutral-200 px-4 py-2.5">
      <p className="text-sm font-bold text-neutral-900">{payload[0].name}: {payload[0].value}</p>
    </div>
  );
}

export default function DoctorDashboard({ onNavigateDiscover }: Props) {
  const { profile } = useAuth();
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<FilterValue>('all');
  const [sourceFilter, setSourceFilter] = useState<string>('all');
  const [selected, setSelected] = useState<Order | null>(null);
  const [showLabPicker, setShowLabPicker] = useState(false);
  const [orderTarget, setOrderTarget] = useState<Profile | null>(null);
  const [orderServices, setOrderServices] = useState<Service[]>([]);
  const [orderCenterId, setOrderCenterId] = useState<string | undefined>(undefined);
  const [myCenters, setMyCenters] = useState<Profile[]>([]);
  const [dateRange, setDateRange] = useState<DateRange>('30d');
  const [showRangeMenu, setShowRangeMenu] = useState(false);
  const [customFilter, setCustomFilter] = useState<CustomFilter>({ type: 'none' });
  const ordersRef = useRef<HTMLDivElement>(null);

  const scrollToOrders = useCallback(() => {
    setTimeout(() => ordersRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' }), 80);
  }, []);

  const fetchOrders = useCallback(async () => {
    if (!profile) return;
    setLoading(true);
    const { data } = await supabase
      .from('orders')
      .select('*, from_profile:profiles!orders_from_id_fkey(*), lab_profile:profiles!orders_lab_id_fkey(*), service:services(*), attachments:order_attachments(*), order_services(*, service:services(*))')
      .or(`from_id.eq.${profile.id},doctor_id.eq.${profile.id}`)
      .order('created_at', { ascending: false });
    setOrders(data ?? []);
    setLoading(false);
  }, [profile]);

  useEffect(() => { fetchOrders(); }, [fetchOrders]);
  useRealtimeOrders(profile?.id, fetchOrders);

  useEffect(() => {
    if (!profile || profile.role !== 'doctor') return;
    supabase.from('center_members')
      .select('center_profile:profiles!center_members_center_id_fkey(*)')
      .eq('doctor_id', profile.id)
      .then(({ data }) => {
        setMyCenters((data ?? []).map(r => r.center_profile as Profile));
      });
  }, [profile]);

  const handleSelectLab = async (lab: Profile, centerId?: string) => {
    const { data: services } = await supabase.from('services').select('*').eq('lab_id', lab.id);
    setOrderServices(services ?? []);
    setOrderTarget(lab);
    setOrderCenterId(centerId ?? 'self');
    setShowLabPicker(false);
  };

  /* ── Analytics derived data ── */
  const start = useMemo(() => rangeStart(dateRange), [dateRange]);
  const prevStart = useMemo(() => prevRangeStart(dateRange), [dateRange]);
  const prevEnd = useMemo(() => prevRangeEnd(dateRange), [dateRange]);

  const rangedOrders = useMemo(() => orders.filter(o => new Date(o.created_at) >= start), [orders, start]);
  const prevOrders = useMemo(() => orders.filter(o => { const d = new Date(o.created_at); return d >= prevStart && d < prevEnd; }), [orders, prevStart, prevEnd]);

  const uniqueLabs = useMemo(() => new Set(rangedOrders.map(o => o.lab_id)).size, [rangedOrders]);
  const prevLabs = useMemo(() => new Set(prevOrders.map(o => o.lab_id)).size, [prevOrders]);
  const completedCount = useMemo(() => rangedOrders.filter(o => DONE_STATUSES.has(o.status)).length, [rangedOrders]);
  const prevCompleted = useMemo(() => prevOrders.filter(o => DONE_STATUSES.has(o.status)).length, [prevOrders]);
  const pendingCount = useMemo(() => rangedOrders.filter(o => ACTIVE_STATUSES.has(o.status)).length, [rangedOrders]);
  const prevPending = useMemo(() => prevOrders.filter(o => ACTIVE_STATUSES.has(o.status)).length, [prevOrders]);
  const completionRate = useMemo(() => rangedOrders.length === 0 ? 0 : Math.round((completedCount / rangedOrders.length) * 100), [completedCount, rangedOrders]);
  const prevRate = useMemo(() => prevOrders.length === 0 ? 0 : Math.round((prevCompleted / prevOrders.length) * 100), [prevCompleted, prevOrders]);

  const timeSeriesData = useMemo(() => buildTimeSeriesData(orders, dateRange), [orders, dateRange]);
  const labDonutData = useMemo(() => buildEntityDonutData(orders, 'lab_id'), [orders]);
  const topLabsData = useMemo(() => buildTopEntitiesData(rangedOrders, 'lab_id', 'lab_profile'), [rangedOrders]);

  /* ── Status counts (all orders) ── */
  const counts = orders.reduce((acc, o) => {
    if (o.status === 'delivered') {
      if (o.finished_at || (o.delivered_at && Date.now() - new Date(o.delivered_at).getTime() > THIRTY_DAYS_MS)) {
        acc['finished'] = (acc['finished'] ?? 0) + 1;
      } else {
        acc['delivered'] = (acc['delivered'] ?? 0) + 1;
      }
    } else {
      acc[o.status] = (acc[o.status] ?? 0) + 1;
    }
    return acc;
  }, {} as Record<string, number>);

  const cashCount = orders.filter(o => o.from_id === profile?.id).length;

  const centers = useMemo(() => {
    const map = new Map<string, { id: string; name: string }>();
    for (const o of orders) {
      if (o.from_id !== profile?.id && o.from_profile) {
        if (!map.has(o.from_profile.id)) map.set(o.from_profile.id, { id: o.from_profile.id, name: o.from_profile.name });
      }
    }
    return Array.from(map.values()).sort((a, b) => a.name.localeCompare(b.name));
  }, [orders, profile]);

  const centerCounts = useMemo(() => {
    const m: Record<string, number> = {};
    for (const o of orders) {
      if (o.from_id !== profile?.id && o.from_profile) m[o.from_profile.id] = (m[o.from_profile.id] ?? 0) + 1;
    }
    return m;
  }, [orders, profile]);

  /* ── Filtering ── */
  const statusFiltered = useMemo(() => {
    let list = orders;
    if (filter === 'finished') list = orders.filter(o => o.status === 'delivered' && (o.finished_at || (o.delivered_at && Date.now() - new Date(o.delivered_at).getTime() > THIRTY_DAYS_MS)));
    else if (filter === 'delivered') list = orders.filter(o => o.status === 'delivered' && !o.finished_at && !(o.delivered_at && Date.now() - new Date(o.delivered_at).getTime() > THIRTY_DAYS_MS));
    else if (filter !== 'all') list = orders.filter(o => o.status === filter);

    if (sourceFilter === 'cash') list = list.filter(o => o.from_id === profile?.id);
    else if (sourceFilter !== 'all') list = list.filter(o => o.from_id === sourceFilter);

    return list;
  }, [orders, filter, sourceFilter, profile]);

  const filtered = useMemo(() => {
    if (customFilter.type === 'none') return statusFiltered;
    if (customFilter.type === 'kpi') {
      if (customFilter.key === 'completed') return statusFiltered.filter(o => DONE_STATUSES.has(o.status));
      if (customFilter.key === 'pending') return statusFiltered.filter(o => ACTIVE_STATUSES.has(o.status));
      return statusFiltered;
    }
    if (customFilter.type === 'lab') return statusFiltered.filter(o => o.lab_profile?.name === customFilter.name);
    return statusFiltered;
  }, [statusFiltered, customFilter]);

  const activeFilterLabel = customFilter.type === 'lab' ? `Lab: ${customFilter.name}`
    : customFilter.type === 'kpi' ? `Showing: ${customFilter.key === 'completed' ? 'Completed' : customFilter.key === 'pending' ? 'Pending' : 'All Labs'}`
    : null;

  const clearCustomFilter = () => setCustomFilter({ type: 'none' });

  const applyCustomFilter = useCallback((cf: CustomFilter) => {
    setCustomFilter(prev => prev.type === cf.type && JSON.stringify(prev) === JSON.stringify(cf) ? { type: 'none' } : cf);
    scrollToOrders();
  }, [scrollToOrders]);

  return (
    <div className="p-4 sm:p-6 max-w-5xl mx-auto">
      {/* Header + date range + new order */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="font-display text-2xl font-bold text-neutral-900">My Dashboard</h1>
          <p className="text-neutral-500 text-sm mt-1">Welcome back, {profile?.name}</p>
        </div>
        <div className="flex items-center gap-2">
          <div className="relative">
            <button
              onClick={() => setShowRangeMenu(!showRangeMenu)}
              className="flex items-center gap-2 px-4 py-2 bg-white rounded-xl border border-neutral-200 shadow-card text-sm font-semibold text-neutral-700 hover:border-neutral-300 transition-colors"
            >
              <span className="hidden sm:inline">{DATE_RANGE_LABELS[dateRange]}</span>
              <span className="sm:hidden text-xs">{dateRange === 'year' ? 'Year' : dateRange}</span>
              <ChevronDown className="w-4 h-4 text-neutral-400" />
            </button>
            {showRangeMenu && (
              <>
                <div className="fixed inset-0 z-20" onClick={() => setShowRangeMenu(false)} />
                <div className="absolute right-0 top-full mt-1 bg-white rounded-xl border border-neutral-200 shadow-lg z-30 overflow-hidden min-w-[160px]">
                  {(['7d', '30d', 'year'] as DateRange[]).map(r => (
                    <button
                      key={r}
                      onClick={() => { setDateRange(r); setShowRangeMenu(false); }}
                      className={`w-full text-left px-4 py-2.5 text-sm font-medium transition-colors ${r === dateRange ? 'bg-blue-50 text-blue-700' : 'text-neutral-700 hover:bg-neutral-50'}`}
                    >
                      {DATE_RANGE_LABELS[r]}
                    </button>
                  ))}
                </div>
              </>
            )}
          </div>
          <button
            onClick={() => setShowLabPicker(true)}
            className="flex items-center gap-2 px-4 py-2.5 bg-primary-600 hover:bg-primary-700 text-white text-sm font-semibold rounded-xl transition-colors shadow-sm"
          >
            <Plus className="w-4 h-4" />
            <span className="hidden sm:inline">New Order</span>
          </button>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4 mb-6">
        <KpiCard icon={<Microscope className="w-5 h-5 text-blue-600" />} bg="bg-blue-50" value={uniqueLabs} label="Labs Used" growth={growthPct(uniqueLabs, prevLabs)} index={0} onClick={() => applyCustomFilter({ type: 'kpi', key: 'labs' })} active={customFilter.type === 'kpi' && customFilter.key === 'labs'} />
        <KpiCard icon={<CheckCircle2 className="w-5 h-5 text-teal-600" />} bg="bg-teal-50" value={completedCount} label="Completed" growth={growthPct(completedCount, prevCompleted)} index={1} onClick={() => applyCustomFilter({ type: 'kpi', key: 'completed' })} active={customFilter.type === 'kpi' && customFilter.key === 'completed'} />
        <KpiCard icon={<Clock className="w-5 h-5 text-amber-600" />} bg="bg-amber-50" value={pendingCount} label="Pending" growth={growthPct(pendingCount, prevPending)} index={2} onClick={() => applyCustomFilter({ type: 'kpi', key: 'pending' })} active={customFilter.type === 'kpi' && customFilter.key === 'pending'} />
        <KpiCard icon={<Percent className="w-5 h-5 text-primary-600" />} bg="bg-primary-50" value={completionRate} label="Completion %" growth={growthPct(completionRate, prevRate)} suffix="%" index={3} />
      </div>

      {/* Completed Cases Chart */}
      <div className="bg-white rounded-2xl shadow-card border border-neutral-200/60 p-5 mb-6 animate-rise-in" style={{ animationDelay: '200ms' }}>
        <div className="flex items-center gap-2 mb-4">
          <BarChart3 className="w-5 h-5 text-blue-600" />
          <h2 className="font-display font-bold text-neutral-900">Completed Cases</h2>
          <span className="text-xs text-neutral-400 ml-auto">{DATE_RANGE_LABELS[dateRange]}</span>
        </div>
        <div className="h-56 sm:h-64">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={timeSeriesData} margin={{ top: 4, right: 4, left: -20, bottom: 0 }}>
              <defs>
                <linearGradient id="drAreaGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#0ea5e9" stopOpacity={0.25} />
                  <stop offset="95%" stopColor="#0ea5e9" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
              <XAxis dataKey="name" tick={{ fontSize: 11, fill: '#94a3b8' }} axisLine={false} tickLine={false} />
              <YAxis allowDecimals={false} tick={{ fontSize: 11, fill: '#94a3b8' }} axisLine={false} tickLine={false} />
              <ReTooltip content={<ChartTooltip />} />
              <Area type="monotone" dataKey="cases" stroke="#0ea5e9" strokeWidth={2.5} fill="url(#drAreaGrad)" dot={false} activeDot={{ r: 5, fill: '#0ea5e9', stroke: '#fff', strokeWidth: 2 }} />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Lab Breakdown Row */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
        <div className="bg-white rounded-2xl shadow-card border border-neutral-200/60 p-5 animate-rise-in" style={{ animationDelay: '280ms' }}>
          <h2 className="font-display font-bold text-neutral-900 mb-3">Lab Status</h2>
          {labDonutData.length === 0 ? (
            <p className="text-sm text-neutral-400 text-center py-10">No lab data yet</p>
          ) : (
            <div className="h-52 flex items-center justify-center">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie data={labDonutData} cx="50%" cy="50%" innerRadius="55%" outerRadius="80%" paddingAngle={3} dataKey="value" stroke="none">
                    {labDonutData.map((_, i) => <Cell key={i} fill={DONUT_COLORS[i % DONUT_COLORS.length]} />)}
                  </Pie>
                  <ReTooltip content={<DonutTooltip />} />
                  <Legend verticalAlign="bottom" iconType="circle" formatter={(v: string) => <span className="text-xs font-medium text-neutral-600">{v}</span>} />
                </PieChart>
              </ResponsiveContainer>
            </div>
          )}
        </div>

        <div className="bg-white rounded-2xl shadow-card border border-neutral-200/60 p-5 animate-rise-in" style={{ animationDelay: '340ms' }}>
          <h2 className="font-display font-bold text-neutral-900 mb-3">Top Labs</h2>
          {topLabsData.length === 0 ? (
            <p className="text-sm text-neutral-400 text-center py-10">No completed cases yet</p>
          ) : (
            <div className="h-52">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={topLabsData} layout="vertical" margin={{ top: 0, right: 12, left: 0, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" horizontal={false} />
                  <XAxis type="number" allowDecimals={false} tick={{ fontSize: 11, fill: '#94a3b8' }} axisLine={false} tickLine={false} />
                  <YAxis dataKey="name" type="category" tick={{ fontSize: 11, fill: '#64748b', fontWeight: 600 }} width={90} axisLine={false} tickLine={false} />
                  <ReTooltip content={<ChartTooltip />} />
                  <Bar dataKey="count" name="cases" fill="#0ea5e9" radius={[0, 6, 6, 0]} barSize={20} cursor="pointer" onClick={(data: any) => { if (data?.name) applyCustomFilter({ type: 'lab', name: data.name }); }} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          )}
        </div>
      </div>

      {/* Source filter */}
      <div className="flex items-center gap-2 mb-4 flex-wrap">
        <button onClick={() => setSourceFilter('all')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm font-medium transition-all border ${sourceFilter === 'all' ? 'bg-neutral-900 text-white border-neutral-900' : 'bg-white text-neutral-600 border-neutral-200 hover:border-neutral-300'}`}
        >All <span className="text-xs opacity-70">{orders.length}</span></button>
        <button onClick={() => setSourceFilter('cash')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm font-medium transition-all border ${sourceFilter === 'cash' ? 'bg-emerald-600 text-white border-emerald-600' : 'bg-white text-neutral-600 border-neutral-200 hover:border-neutral-300'}`}
        ><Wallet className="w-3.5 h-3.5" /> Cash <span className="text-xs opacity-70">{cashCount}</span></button>
        {centers.map(c => (
          <button key={c.id} onClick={() => setSourceFilter(sourceFilter === c.id ? 'all' : c.id)}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm font-medium transition-all border ${sourceFilter === c.id ? 'bg-blue-600 text-white border-blue-600' : 'bg-white text-neutral-600 border-neutral-200 hover:border-neutral-300'}`}
          ><Building2 className="w-3.5 h-3.5" /> {c.name} <span className="text-xs opacity-70">{centerCounts[c.id] ?? 0}</span></button>
        ))}
      </div>

      {/* Status filter strip */}
      <div className="grid grid-cols-4 md:grid-cols-10 gap-2 mb-5">
        {FILTER_STATUSES.map((s, i) => {
          const cfg = STATUS_CONFIG[s];
          const active = filter === s;
          return (
            <button key={s} onClick={() => setFilter(active ? 'all' : s)} style={{ animationDelay: `${i * 40}ms` }}
              className={`px-2 py-2.5 rounded-xl text-center transition-all border animate-rise-in hover:-translate-y-0.5 active:scale-[0.97] ${active ? `${cfg.bg} ${cfg.color} ${cfg.border}` : 'bg-white border-neutral-200 text-neutral-500 hover:border-neutral-300'}`}
            >
              <div className={`w-7 h-7 rounded-lg flex items-center justify-center mx-auto mb-1 ${active ? 'bg-white/60' : cfg.bg} ${cfg.color}`}>
                {cfg.icon}
              </div>
              <p className="text-base font-bold leading-none"><CountUp value={counts[s] ?? 0} /></p>
              <p className="text-[10px] font-medium mt-0.5">{cfg.label}</p>
            </button>
          );
        })}
      </div>

      {/* Active filter banner */}
      {activeFilterLabel && (
        <div ref={ordersRef} className="flex items-center justify-between bg-blue-50 border border-blue-200 rounded-xl px-4 py-2.5 mb-4 animate-rise-in">
          <span className="text-sm font-semibold text-blue-800">{activeFilterLabel}</span>
          <button onClick={clearCustomFilter} className="text-xs font-bold text-blue-600 hover:text-blue-800 transition-colors px-2 py-1 rounded-lg hover:bg-blue-100">Clear</button>
        </div>
      )}

      {/* Orders list */}
      {!activeFilterLabel && <div ref={ordersRef} />}
      {loading ? (
        <div className="space-y-3">
          {[1, 2, 3].map(i => <div key={i} className="bg-white rounded-xl h-20 animate-pulse shadow-card" />)}
        </div>
      ) : filtered.length === 0 ? (
        <div className="text-center py-16 bg-white rounded-2xl shadow-card border border-neutral-200/60">
          {orders.length === 0 ? (
            <>
              <Microscope className="w-12 h-12 text-neutral-300 mx-auto mb-3" />
              <p className="text-neutral-500 font-medium">No orders yet</p>
              <p className="text-neutral-400 text-sm mt-1 mb-4">Place your first order with a dental lab</p>
              <div className="flex items-center justify-center gap-3">
                <button onClick={() => setShowLabPicker(true)} className="inline-flex items-center gap-2 px-4 py-2 bg-primary-600 hover:bg-primary-700 text-white text-sm font-semibold rounded-xl transition-colors">
                  <Plus className="w-4 h-4" /> New Order
                </button>
                <button onClick={onNavigateDiscover} className="inline-flex items-center gap-2 px-4 py-2 bg-white border border-neutral-200 bg-neutral-50 text-neutral-700 hover:bg-neutral-100 text-sm font-semibold rounded-xl transition-colors">
                  <Search className="w-4 h-4" /> Browse Labs
                </button>
              </div>
            </>
          ) : (
            <>
              <ClipboardList className="w-12 h-12 text-neutral-300 mx-auto mb-3" />
              <p className="text-neutral-500 font-medium">No {STATUS_CONFIG[filter]?.label ?? 'matching'} orders</p>
            </>
          )}
        </div>
      ) : (
        <div className="space-y-2">
          {filtered.map(order => {
            const cfg = STATUS_CONFIG[order.status];
            return (
              <button key={order.id} onClick={() => setSelected(order)}
                className="w-full bg-white rounded-xl p-4 shadow-card hover:shadow-card-hover transition-all text-left flex items-center gap-4 group border border-transparent hover:border-primary-100"
              >
                <div className={`w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 ${cfg.bg} ${cfg.color} border ${cfg.border}`}>
                  {cfg.icon}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-0.5 flex-wrap">
                    <span className="font-semibold text-neutral-900 text-sm">{order.order_number}</span>
                    <span className={`text-xs font-medium px-2 py-0.5 rounded-full border ${cfg.bg} ${cfg.color} ${cfg.border}`}>{cfg.label}</span>
                    {order.parent_order_id && (
                      <span className="flex items-center gap-1 text-[11px] font-semibold text-orange-700 bg-orange-50 border border-orange-200 px-2 py-0.5 rounded-full">
                        <RefreshCw className="w-2.5 h-2.5" /> Redo
                      </span>
                    )}
                  </div>
                  <p className="text-sm text-neutral-600 truncate">
                    To: <span className="font-medium">{order.lab_profile?.name ?? '—'}</span>
                    {' '}&bull; Patient: {order.patient_name}
                    {order.from_id !== profile?.id && order.from_profile && (
                      <span className="ml-1 text-xs text-primary-600 font-medium">(by {order.from_profile.name})</span>
                    )}
                  </p>
                  <p className="text-xs text-neutral-400 mt-0.5">File #{order.file_number}</p>
                </div>
                <div className="text-right flex-shrink-0">
                  <p className="text-xs text-neutral-400">{new Date(order.created_at).toLocaleDateString()}</p>
                  {order.due_date && (
                    <p className="text-xs text-amber-600 font-medium">Due {new Date(order.due_date).toLocaleDateString()}</p>
                  )}
                </div>
                <ChevronRight className="w-4 h-4 text-neutral-300 group-hover:text-primary-500 transition-colors ml-1" />
              </button>
            );
          })}
        </div>
      )}

      {selected && (
        <OrderDetailModal order={selected} isLab={false} onClose={() => setSelected(null)} onStatusChange={() => { fetchOrders(); setSelected(null); }} />
      )}

      {showLabPicker && (
        <FavouriteLabPickerModal onSelect={handleSelectLab} onClose={() => setShowLabPicker(false)} onBrowseAll={onNavigateDiscover} centers={myCenters} />
      )}

      {orderTarget && (
        <NewOrderModal lab={orderTarget} services={orderServices} prefilledCenterId={orderCenterId}
          onClose={() => { setOrderTarget(null); setOrderCenterId(undefined); }}
          onSuccess={() => { setOrderTarget(null); setOrderCenterId(undefined); fetchOrders(); }}
        />
      )}
    </div>
  );
}

/* ─── Favourite-first Lab Picker ───────────────────────────────────────────── */

function FavouriteLabPickerModal({
  onSelect, onClose, onBrowseAll, centers,
}: {
  onSelect: (lab: Profile, centerId?: string) => void;
  onClose: () => void;
  onBrowseAll: () => void;
  centers: Profile[];
}) {
  const { profile } = useAuth();
  const [search, setSearch] = useState('');
  const [labs, setLabs] = useState<Profile[]>([]);
  const [favouriteIds, setFavouriteIds] = useState<Set<string>>(new Set());
  const [loading, setLoading] = useState(true);
  const [selectedCenterId, setSelectedCenterId] = useState<string>('');
  const [formalLabIds, setFormalLabIds] = useState<Set<string> | null>(null);

  useEffect(() => {
    if (!profile) return;
    Promise.all([
      supabase.from('profiles').select('*').eq('role', 'lab').order('name'),
      supabase.from('favourite_labs').select('lab_id').eq('user_id', profile.id),
    ]).then(([{ data: labData }, { data: favData }]) => {
      setLabs(labData ?? []);
      setFavouriteIds(new Set((favData ?? []).map(f => f.lab_id)));
      setLoading(false);
    });
  }, [profile]);

  useEffect(() => {
    if (!selectedCenterId) { setFormalLabIds(null); return; }
    supabase.from('center_labs').select('lab_id').eq('center_id', selectedCenterId)
      .then(({ data }) => setFormalLabIds(new Set((data ?? []).map(r => r.lab_id))));
  }, [selectedCenterId]);

  const filtered = labs.filter(l =>
    (!search.trim() || l.name.toLowerCase().includes(search.toLowerCase()) || (l.city ?? '').toLowerCase().includes(search.toLowerCase())) &&
    (!selectedCenterId || (formalLabIds?.has(l.id) ?? false))
  );

  const sorted = [...filtered].sort((a, b) => {
    const af = favouriteIds.has(a.id) ? 0 : 1;
    const bf = favouriteIds.has(b.id) ? 0 : 1;
    return af - bf || a.name.localeCompare(b.name);
  });

  const favourites = sorted.filter(l => favouriteIds.has(l.id));
  const others = sorted.filter(l => !favouriteIds.has(l.id));
  const handleSelect = (lab: Profile) => onSelect(lab, selectedCenterId || undefined);

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm transform-gpu flex items-center justify-center z-50 p-4 pt-[env(safe-area-inset-top,16px)] pb-[env(safe-area-inset-bottom,16px)] px-[max(env(safe-area-inset-left,16px),16px)]">
      <div className="bg-white rounded-2xl shadow-modal w-full max-w-[90vw] sm:max-w-md max-h-[85vh] flex flex-col break-words">
        <div className="flex items-center justify-between p-5 border-b border-neutral-200">
          <div>
            <h2 className="font-display font-bold text-neutral-900">Select a Lab</h2>
            <p className="text-sm text-neutral-500">
              {selectedCenterId ? 'Formal labs for this center' : (favouriteIds.size > 0 ? 'Your favourites are shown first' : 'Choose the lab to place an order with')}
            </p>
          </div>
          <button onClick={onClose} className="w-8 h-8 flex items-center justify-center rounded-lg hover:bg-neutral-100"><X className="w-4 h-4" /></button>
        </div>

        {centers.length > 0 && (
          <div className="px-5 pt-4 pb-2">
            <div className="flex gap-1.5 flex-wrap">
              <button onClick={() => setSelectedCenterId('')}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium border transition-all ${selectedCenterId === '' ? 'bg-primary-50 border-primary-400 text-primary-700' : 'bg-white border-neutral-200 text-neutral-600 hover:border-neutral-300'}`}
              >My account</button>
              {centers.map(c => (
                <button key={c.id} onClick={() => setSelectedCenterId(c.id)}
                  className={`flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-medium border transition-all ${selectedCenterId === c.id ? 'bg-primary-50 border-primary-400 text-primary-700' : 'bg-white border-neutral-200 text-neutral-600 hover:border-neutral-300'}`}
                ><Building2 className="w-3 h-3" /> {c.name}</button>
              ))}
            </div>
            {selectedCenterId && formalLabIds && formalLabIds.size === 0 && (
              <p className="text-xs text-amber-600 mt-2">This center has no formal labs yet. Ask the center to accept a quotation from a lab first.</p>
            )}
          </div>
        )}

        <div className="px-5 pt-4 pb-2">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-neutral-400" />
            <input type="text" placeholder="Search by name or city..." value={search} onChange={e => setSearch(e.target.value)} autoFocus
              className="w-full pl-9 pr-4 py-2.5 rounded-xl border border-neutral-200 bg-neutral-50 text-sm focus:outline-none focus:ring-2 focus:ring-primary-400/40 focus:border-primary-400" />
          </div>
        </div>

        <div className="flex-1 overflow-y-auto px-5 pb-4">
          {loading || (selectedCenterId && formalLabIds === null) ? (
            <div className="space-y-2 pt-2">{[1, 2, 3].map(i => <div key={i} className="h-14 bg-neutral-100 rounded-xl animate-pulse" />)}</div>
          ) : sorted.length === 0 ? (
            <div className="text-center py-10">
              <FlaskConical className="w-10 h-10 text-neutral-300 mx-auto mb-2" />
              <p className="text-neutral-500 text-sm">No labs found</p>
            </div>
          ) : (
            <>
              {favourites.length > 0 && (
                <div className="pt-3">
                  <p className="text-[10px] font-semibold text-neutral-400 uppercase tracking-wider mb-2 flex items-center gap-1.5"><Heart className="w-3 h-3 fill-red-400 text-red-400" /> Favourites</p>
                  <div className="space-y-1">{favourites.map(lab => <LabRow key={lab.id} lab={lab} isFav onSelect={handleSelect} />)}</div>
                </div>
              )}
              {others.length > 0 && (
                <div className={favourites.length > 0 ? 'pt-4' : 'pt-3'}>
                  {favourites.length > 0 && <p className="text-[10px] font-semibold text-neutral-400 uppercase tracking-wider mb-2">All Labs</p>}
                  <div className="space-y-1">{others.map(lab => <LabRow key={lab.id} lab={lab} isFav={false} onSelect={handleSelect} />)}</div>
                </div>
              )}
            </>
          )}
        </div>

        <div className="px-5 pb-5 pt-2 border-t border-neutral-200/60">
          <button onClick={() => { onClose(); onBrowseAll(); }}
            className="w-full py-2.5 border border-neutral-200 bg-neutral-50 text-neutral-600 hover:bg-neutral-100 text-sm font-semibold rounded-xl transition-colors flex items-center justify-center gap-2"
          ><Search className="w-4 h-4" /> Browse all labs</button>
        </div>
      </div>
    </div>
  );
}

function LabRow({ lab, isFav, onSelect }: { lab: Profile; isFav: boolean; onSelect: (lab: Profile) => void }) {
  return (
    <button onClick={() => onSelect(lab)}
      className="w-full flex items-center gap-3 px-3 py-3 rounded-xl hover:bg-primary-50 hover:border-primary-200 border border-transparent transition-all text-left group"
    >
      {lab.logo_url ? (
        <img src={lab.logo_url} alt={lab.name} className="w-10 h-10 rounded-xl object-cover flex-shrink-0" />
      ) : (
        <div className="w-10 h-10 bg-primary-50 rounded-xl flex items-center justify-center flex-shrink-0 group-hover:bg-primary-100 transition-colors">
          <Microscope className="w-5 h-5 text-primary-600" />
        </div>
      )}
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-1.5">
          <p className="font-semibold text-neutral-900 text-sm">{lab.name}</p>
          {isFav && <Heart className="w-3 h-3 fill-red-400 text-red-400 flex-shrink-0" />}
        </div>
        {lab.city && <p className="text-xs text-neutral-500 flex items-center gap-1 mt-0.5"><MapPin className="w-3 h-3" />{lab.city}</p>}
      </div>
      <ChevronRight className="w-4 h-4 text-neutral-300 group-hover:text-primary-500 transition-colors flex-shrink-0" />
    </button>
  );
}

/* ─── KPI Card ──────────────────────────────────────────────────────────────── */

function KpiCard({ icon, bg, value, label, growth, suffix, index = 0, onClick, active }: {
  icon: React.ReactNode; bg: string; value: number; label: string; growth: number | null; suffix?: string; index?: number; onClick?: () => void; active?: boolean;
}) {
  return (
    <div onClick={onClick}
      className={`bg-white rounded-2xl p-4 sm:p-5 shadow-card animate-rise-in transition-all duration-200 hover:-translate-y-0.5 hover:shadow-lg border ${active ? 'border-blue-300 ring-2 ring-blue-200' : 'border-neutral-200/60'} ${onClick ? 'cursor-pointer' : ''}`}
      style={{ animationDelay: `${index * 70}ms` }}
    >
      <div className="flex items-start justify-between gap-2">
        <div className={`w-10 h-10 ${bg} rounded-xl flex items-center justify-center flex-shrink-0`}>{icon}</div>
        {growth !== null && (
          <span className={`flex items-center gap-0.5 text-xs font-bold px-2 py-0.5 rounded-full ${growth >= 0 ? 'bg-emerald-50 text-emerald-600' : 'bg-red-50 text-red-500'}`}>
            {growth >= 0 ? <TrendingUp className="w-3 h-3" /> : <TrendingDown className="w-3 h-3" />}
            {growth >= 0 ? '+' : ''}{growth}%
          </span>
        )}
      </div>
      <p className="text-2xl font-bold text-neutral-900 mt-3"><CountUp value={value} />{suffix}</p>
      <p className="text-sm text-neutral-500">{label}</p>
    </div>
  );
}
