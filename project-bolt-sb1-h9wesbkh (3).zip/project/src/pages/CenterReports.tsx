import { useEffect, useState, useMemo, useCallback } from 'react';
import { supabase, Order, Profile } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { CountUp } from '../lib/CountUp';
import { escapeHtml } from '../lib/escapeHtml';
import {
  BarChart3, Calendar, Microscope, Stethoscope, FileDown,
  Loader2, Filter, TrendingUp, ClipboardList, CheckCircle2, XCircle,
  ChevronDown, ChevronRight, RefreshCw,
} from 'lucide-react';
import OrderDetailModal from '../components/OrderDetailModal';

const STATUS_LABELS: Record<string, string> = {
  pending: 'Pending',
  accepted: 'Accepted',
  in_progress: 'In Progress',
  completed: 'Completed',
  delivering: 'Delivering',
  delivered: 'Delivered',
  rejected: 'Rejected',
  cancelled: 'Cancelled',
  redo: 'Redo',
};

const STATUS_BADGE: Record<string, string> = {
  pending: 'bg-amber-50 text-amber-700 border-amber-200',
  accepted: 'bg-blue-50 text-blue-700 border-blue-200',
  in_progress: 'bg-primary-50 text-primary-700 border-primary-200',
  completed: 'bg-teal-50 text-teal-700 border-teal-200',
  delivering: 'bg-cyan-50 text-cyan-700 border-cyan-200',
  delivered: 'bg-emerald-50 text-emerald-700 border-emerald-200',
  rejected: 'bg-red-50 text-red-700 border-red-200',
  cancelled: 'bg-neutral-100 text-neutral-600 border-neutral-200',
  redo: 'bg-orange-50 text-orange-700 border-orange-200',
};

function getDoctorName(order: Order, centerId: string): string {
  return order.from_id === centerId
    ? (order.dr_name ?? '')
    : (order.from_profile?.name ?? order.dr_name ?? '');
}

type DatePreset = '7d' | '30d' | '90d' | 'ytd' | 'all' | 'custom';

export default function CenterReports() {
  const { profile } = useAuth();
  const [orders, setOrders] = useState<Order[]>([]);
  const [labs, setLabs] = useState<Profile[]>([]);
  const [members, setMembers] = useState<Profile[]>([]);
  const [loading, setLoading] = useState(true);

  const [doctorFilter, setDoctorFilter] = useState<string>('all');
  const [labFilter, setLabFilter] = useState<string>('all');
  const [datePreset, setDatePreset] = useState<DatePreset>('30d');
  const [startDate, setStartDate] = useState<string>('');
  const [endDate, setEndDate] = useState<string>('');

  const [expanded, setExpanded] = useState<Set<string>>(new Set());
  const [selected, setSelected] = useState<Order | null>(null);

  const fetchData = useCallback(async () => {
    if (!profile) return;
    setLoading(true);

    const { data: memberRows } = await supabase
      .from('center_members')
      .select('doctor_id, doctor_profile:profiles!center_members_doctor_id_fkey(*)')
      .eq('center_id', profile.id);
    const doctorProfiles = (memberRows ?? [])
      .map((r: { doctor_id: string; doctor_profile: Profile }) => r.doctor_profile)
      .filter(Boolean);
    setMembers(doctorProfiles);

    const senderIds = [profile.id, ...(memberRows ?? []).map((r: { doctor_id: string }) => r.doctor_id)];

    const { data: orderData } = await supabase
      .from('orders')
      .select('*, from_profile:profiles!orders_from_id_fkey(*), lab_profile:profiles!orders_lab_id_fkey(*), service:services(*), attachments:order_attachments(*), order_services(*, service:services(*))')
      .in('from_id', senderIds)
      .order('created_at', { ascending: false });
    setOrders(orderData ?? []);

    const uniqueLabIds = Array.from(new Set((orderData ?? []).map(o => o.lab_id)));
    if (uniqueLabIds.length) {
      const { data: labData } = await supabase
        .from('profiles')
        .select('*')
        .in('id', uniqueLabIds)
        .order('name');
      setLabs(labData ?? []);
    }

    setLoading(false);
  }, [profile]);

  useEffect(() => { fetchData(); }, [fetchData]);

  const dateRange = useMemo(() => {
    if (datePreset === 'custom') {
      return {
        start: startDate ? new Date(startDate + 'T00:00:00') : null,
        end: endDate ? new Date(endDate + 'T23:59:59') : null,
      };
    }
    const now = new Date();
    const end = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 23, 59, 59);
    if (datePreset === 'all') return { start: null, end: null };
    if (datePreset === 'ytd') return { start: new Date(now.getFullYear(), 0, 1), end };
    const days = datePreset === '7d' ? 7 : datePreset === '30d' ? 30 : 90;
    const start = new Date(now);
    start.setDate(start.getDate() - days);
    start.setHours(0, 0, 0, 0);
    return { start, end };
  }, [datePreset, startDate, endDate]);

  const filteredOrders = useMemo(() => {
    return orders.filter(o => {
      if (doctorFilter !== 'all') {
        const name = getDoctorName(o, profile?.id ?? '');
        if (name !== doctorFilter) return false;
      }
      if (labFilter !== 'all' && o.lab_id !== labFilter) return false;
      const created = new Date(o.created_at);
      if (dateRange.start && created < dateRange.start) return false;
      if (dateRange.end && created > dateRange.end) return false;
      return true;
    });
  }, [orders, doctorFilter, labFilter, dateRange, profile?.id]);

  // Group orders by doctor
  const doctorGroups = useMemo(() => {
    const map = new Map<string, { doctor: string; orders: Order[] }>();
    for (const o of filteredOrders) {
      const name = getDoctorName(o, profile?.id ?? '') || 'Unknown';
      if (!map.has(name)) map.set(name, { doctor: name, orders: [] });
      map.get(name)!.orders.push(o);
    }
    return Array.from(map.values()).sort((a, b) => b.orders.length - a.orders.length);
  }, [filteredOrders, profile?.id]);

  const totals = useMemo(() => ({
    total: filteredOrders.length,
    completed: filteredOrders.filter(o => o.status === 'completed').length,
    pending: filteredOrders.filter(o => ['pending', 'accepted', 'in_progress'].includes(o.status)).length,
    rejected: filteredOrders.filter(o => o.status === 'rejected').length,
    redo: filteredOrders.filter(o => o.status === 'redo').length,
  }), [filteredOrders]);

  const toggleDoctor = (name: string) => {
    setExpanded(prev => {
      const next = new Set(prev);
      if (next.has(name)) next.delete(name);
      else next.add(name);
      return next;
    });
  };

  const handleExport = () => {
    const centerName = profile?.name ?? 'Center';
    const now = new Date().toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' });
    const dateLabel = datePreset === 'all'
      ? 'All time'
      : datePreset === 'custom'
        ? `${startDate || 'Start'} → ${endDate || 'End'}`
        : datePreset === 'ytd'
          ? 'Year to date'
          : `Last ${datePreset.replace('d', ' days')}`;

    // Sort by date ascending for the export
    const exportOrders = [...filteredOrders].sort(
      (a, b) => new Date(a.created_at).getTime() - new Date(b.created_at).getTime()
    );

    const orderRows = exportOrders.map(o => {
      const status = STATUS_LABELS[o.status] ?? o.status;
      const date = new Date(o.created_at).toLocaleDateString('en-GB');
      return `
        <tr>
          <td>${escapeHtml(o.file_number || '—')}</td>
          <td>${escapeHtml(o.patient_name)}</td>
          <td><span class="badge status-${escapeHtml(o.status)}">${escapeHtml(status)}</span></td>
          <td>${escapeHtml(date)}</td>
        </tr>`;
    }).join('');

    const printDiv = document.getElementById('print-report')!;
    printDiv.innerHTML = `
      <style>
        @page { margin: 16mm 14mm; size: A4; }
        body { font-family: Inter, system-ui, sans-serif; color: #111; }
        .ph { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 20px; border-bottom: 2px solid #0ea5e9; padding-bottom: 12px; }
        .ph-left h1 { font-size: 18px; font-weight: 700; margin: 0 0 2px; }
        .ph-left p { font-size: 11px; color: #64748b; margin: 0; }
        .ph-right { text-align: right; font-size: 11px; color: #64748b; }
        .ph-right strong { display: block; font-size: 14px; color: #111; }
        table { width: 100%; border-collapse: collapse; font-size: 11px; }
        th { background: #f1f5f9; text-align: left; padding: 8px 12px; font-weight: 600; color: #475569; border-bottom: 1px solid #e2e8f0; font-size: 10px; text-transform: uppercase; letter-spacing: .04em; }
        td { padding: 8px 12px; border-bottom: 1px solid #f1f5f9; color: #334155; vertical-align: middle; }
        tr:last-child td { border-bottom: none; }
        .badge { display: inline-block; padding: 2px 8px; border-radius: 99px; font-size: 10px; font-weight: 600; }
        .status-pending     { background:#fef3c7; color:#92400e; }
        .status-accepted    { background:#dbeafe; color:#1e40af; }
        .status-in_progress { background:#e0f2fe; color:#0c4a6e; }
        .status-completed   { background:#ccfbf1; color:#134e4a; }
        .status-delivering  { background:#cffafe; color:#155e75; }
        .status-delivered   { background:#d1fae5; color:#065f46; }
        .status-rejected    { background:#fee2e2; color:#991b1b; }
        .status-cancelled   { background:#f1f5f9; color:#475569; }
        .status-redo        { background:#ffedd5; color:#9a3412; }
        .footer { margin-top: 16px; font-size: 10px; color: #94a3b8; text-align: right; }
      </style>
      <div class="ph">
        <div class="ph-left">
          <h1>Orders Report</h1>
          <p>${escapeHtml(dateLabel)}</p>
        </div>
        <div class="ph-right">
          <strong>${escapeHtml(centerName)}</strong>
          Exported on ${now}
        </div>
      </div>
      <table>
        <thead>
          <tr>
            <th>File Number</th><th>Patient Name</th><th>Status</th><th>Date</th>
          </tr>
        </thead>
        <tbody>${orderRows || '<tr><td colspan="4" style="text-align:center;color:#94a3b8;padding:24px">No orders match the selected filters.</td></tr>'}</tbody>
      </table>
      <div class="footer">Bridge Dental Platform</div>
    `;
    window.print();
  };

  const allDoctorNames = useMemo(() => {
    const teamNames = members.map(m => m.name).filter(Boolean);
    const orderNames = orders
      .filter(o => o.from_id === profile?.id && o.dr_name)
      .map(o => o.dr_name as string);
    return Array.from(new Set([...teamNames, ...orderNames])).sort();
  }, [members, orders, profile?.id]);

  return (
    <div className="p-6 max-w-5xl mx-auto">
      <div id="print-report" className="hidden" />

      {/* Header */}
      <div className="flex items-center justify-between mb-6 flex-wrap gap-3">
        <div>
          <h1 className="font-display text-2xl font-bold text-neutral-900 flex items-center gap-2">
            <BarChart3 className="w-6 h-6 text-primary-600" />
            Reports
          </h1>
          <p className="text-neutral-500 text-sm mt-1">Per-doctor orders with date and lab filters</p>
        </div>
        <button
          onClick={handleExport}
          disabled={loading || doctorGroups.length === 0}
          className="flex items-center gap-1.5 px-4 py-2.5 bg-primary-600 hover:bg-primary-700 disabled:opacity-50 disabled:cursor-not-allowed text-white text-sm font-semibold rounded-xl transition-colors shadow-sm"
        >
          <FileDown className="w-4 h-4" />
          Export PDF
        </button>
      </div>

      {/* Filters */}
      <div className="bg-white rounded-2xl shadow-card border border-neutral-200/60 p-4 mb-6">
        <div className="flex items-center gap-2 mb-4 text-neutral-700">
          <Filter className="w-4 h-4" />
          <span className="text-sm font-semibold">Filters</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div>
            <label className="text-xs font-semibold text-neutral-500 mb-1.5 flex items-center gap-1">
              <Stethoscope className="w-3.5 h-3.5" /> Doctor
            </label>
            <select
              value={doctorFilter}
              onChange={e => setDoctorFilter(e.target.value)}
              className="w-full px-3 py-2 rounded-xl border border-neutral-200 text-sm focus:outline-none focus:ring-2 focus:ring-primary-500 bg-white"
            >
              <option value="all">All Doctors</option>
              {allDoctorNames.map(name => (
                <option key={name} value={name}>{name}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="text-xs font-semibold text-neutral-500 mb-1.5 flex items-center gap-1">
              <Microscope className="w-3.5 h-3.5" /> Lab
            </label>
            <select
              value={labFilter}
              onChange={e => setLabFilter(e.target.value)}
              className="w-full px-3 py-2 rounded-xl border border-neutral-200 text-sm focus:outline-none focus:ring-2 focus:ring-primary-500 bg-white"
            >
              <option value="all">All Labs</option>
              {labs.map(lab => (
                <option key={lab.id} value={lab.id}>{lab.name}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="text-xs font-semibold text-neutral-500 mb-1.5 flex items-center gap-1">
              <Calendar className="w-3.5 h-3.5" /> Date Range
            </label>
            <select
              value={datePreset}
              onChange={e => setDatePreset(e.target.value as DatePreset)}
              className="w-full px-3 py-2 rounded-xl border border-neutral-200 text-sm focus:outline-none focus:ring-2 focus:ring-primary-500 bg-white"
            >
              <option value="7d">Last 7 days</option>
              <option value="30d">Last 30 days</option>
              <option value="90d">Last 90 days</option>
              <option value="ytd">Year to date</option>
              <option value="all">All time</option>
              <option value="custom">Custom range</option>
            </select>
          </div>
        </div>

        {datePreset === 'custom' && (
          <div className="grid grid-cols-2 gap-4 mt-4">
            <div>
              <label className="text-xs font-semibold text-neutral-500 mb-1.5 block">From</label>
              <input
                type="date"
                value={startDate}
                onChange={e => setStartDate(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-neutral-200 text-sm focus:outline-none focus:ring-2 focus:ring-primary-500 bg-white"
              />
            </div>
            <div>
              <label className="text-xs font-semibold text-neutral-500 mb-1.5 block">To</label>
              <input
                type="date"
                value={endDate}
                onChange={e => setEndDate(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-neutral-200 text-sm focus:outline-none focus:ring-2 focus:ring-primary-500 bg-white"
              />
            </div>
          </div>
        )}
      </div>

      {/* Summary cards */}
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 mb-6">
        <SummaryCard icon={<ClipboardList className="w-4 h-4 text-primary-600" />} bg="bg-primary-50" value={totals.total} label="Total" index={0} />
        <SummaryCard icon={<TrendingUp className="w-4 h-4 text-blue-600" />} bg="bg-blue-50" value={totals.pending} label="Active" index={1} />
        <SummaryCard icon={<CheckCircle2 className="w-4 h-4 text-teal-600" />} bg="bg-teal-50" value={totals.completed} label="Completed" index={2} />
        <SummaryCard icon={<XCircle className="w-4 h-4 text-red-600" />} bg="bg-red-50" value={totals.rejected} label="Rejected" index={3} />
        <SummaryCard icon={<RefreshCw className="w-4 h-4 text-orange-600" />} bg="bg-orange-50" value={totals.redo} label="Redos" index={4} />
      </div>

      {/* Doctor groups with order details */}
      {loading ? (
        <div className="flex items-center justify-center py-20">
          <Loader2 className="w-6 h-6 text-primary-500 animate-spin" />
        </div>
      ) : doctorGroups.length === 0 ? (
        <div className="text-center py-16 bg-white rounded-2xl shadow-card border border-neutral-200/60">
          <BarChart3 className="w-12 h-12 text-neutral-300 mx-auto mb-3" />
          <p className="text-neutral-500 font-medium">No orders for the selected filters</p>
          <p className="text-neutral-400 text-sm mt-1">Try adjusting the date range, doctor, or lab filter</p>
        </div>
      ) : (
        <div className="space-y-3">
          {doctorGroups.map(g => {
            const isOpen = expanded.has(g.doctor);
            const completed = g.orders.filter(o => o.status === 'completed').length;
            const active = g.orders.filter(o => ['pending', 'accepted', 'in_progress'].includes(o.status)).length;
            const rejected = g.orders.filter(o => o.status === 'rejected').length;
            const redos = g.orders.filter(o => o.status === 'redo').length;

            return (
              <div key={g.doctor} className="bg-white rounded-2xl shadow-card border border-neutral-200/60 overflow-hidden">
                <button
                  onClick={() => toggleDoctor(g.doctor)}
                  className="w-full flex items-center gap-3 p-4 hover:bg-neutral-50 transition-colors text-left"
                >
                  <div className="w-10 h-10 rounded-xl bg-primary-50 flex items-center justify-center flex-shrink-0">
                    <Stethoscope className="w-5 h-5 text-primary-600" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-semibold text-neutral-900 text-sm">{g.doctor}</p>
                    <p className="text-xs text-neutral-500 mt-0.5">
                      {g.orders.length} orders · {completed} completed · {active} active · {rejected} rejected · {redos} redos
                    </p>
                  </div>
                  <ChevronDown className={`w-5 h-5 text-neutral-400 transition-transform ${isOpen ? 'rotate-180' : ''}`} />
                </button>

                {isOpen && (
                  <div className="border-t border-neutral-200/60 divide-y divide-neutral-50">
                    {g.orders.map(o => {
                      const badge = STATUS_BADGE[o.status] ?? STATUS_BADGE.pending;
                      return (
                        <button
                          key={o.id}
                          onClick={() => setSelected(o)}
                          className="w-full flex items-center gap-3 px-4 py-3 hover:bg-primary-50/50 transition-colors text-left group"
                        >
                          <div className={`w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0 border ${badge}`}>
                            <span className="text-[10px] font-bold">{(STATUS_LABELS[o.status] ?? '?').charAt(0)}</span>
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2 flex-wrap">
                              <span className="font-semibold text-neutral-900 text-sm">{o.order_number}</span>
                              <span className={`text-[11px] font-medium px-2 py-0.5 rounded-full border ${badge}`}>
                                {STATUS_LABELS[o.status] ?? o.status}
                              </span>
                              {o.parent_order_id && (
                                <span className="flex items-center gap-1 text-[11px] font-semibold text-orange-700 bg-orange-50 border border-orange-200 px-2 py-0.5 rounded-full">
                                  <RefreshCw className="w-2.5 h-2.5" />
                                  Redo
                                </span>
                              )}
                            </div>
                            <p className="text-xs text-neutral-500 mt-0.5 truncate">
                              {o.lab_profile?.name ?? '—'} · {o.patient_name} · {o.service?.name ?? '—'}
                            </p>
                          </div>
                          <div className="text-right flex-shrink-0">
                            <p className="text-xs text-neutral-400">{new Date(o.created_at).toLocaleDateString('en-GB')}</p>
                            {o.due_date && (
                              <p className="text-xs text-amber-600 font-medium">
                                Due {new Date(o.due_date).toLocaleDateString('en-GB')}
                              </p>
                            )}
                          </div>
                          <ChevronRight className="w-4 h-4 text-neutral-300 group-hover:text-primary-500 transition-colors ml-1" />
                        </button>
                      );
                    })}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      {selected && (
        <OrderDetailModal
          order={selected}
          isLab={false}
          onClose={() => setSelected(null)}
          onStatusChange={() => { fetchData(); setSelected(null); }}
        />
      )}
    </div>
  );
}

function SummaryCard({ icon, bg, value, label, index = 0 }: { icon: React.ReactNode; bg: string; value: number; label: string; index?: number }) {
  return (
    <div className="bg-white rounded-2xl p-4 shadow-card border border-neutral-200/60 animate-rise-in transition-transform duration-200 hover:-translate-y-0.5 hover:shadow-lg" style={{ animationDelay: `${index * 60}ms` }}>
      <div className={`w-9 h-9 ${bg} rounded-xl flex items-center justify-center flex-shrink-0 mb-2`}>
        {icon}
      </div>
      <p className="text-2xl font-bold text-neutral-900 leading-none"><CountUp value={value} /></p>
      <p className="text-xs text-neutral-500 mt-1">{label}</p>
    </div>
  );
}
