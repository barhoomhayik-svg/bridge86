import React, { useEffect, useState, useCallback, useRef } from 'react';
import { supabase, Order } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { Truck, MapPin, CheckCircle2, Navigation, Clock, Package, Search, CheckSquare, Loader2, Camera, Upload, X, Image as ImageIcon } from 'lucide-react';
import { useRealtimeDriverOrders } from '../lib/useRealtimeOrders';
import { CountUp } from '../lib/CountUp';

export default function DriverDashboard() {
  const { profile } = useAuth();
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState<string | null>(null);
  const [search, setSearch] = useState('');
  const [multiSelectMode, setMultiSelectMode] = useState(false);
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [bulkUpdating, setBulkUpdating] = useState(false);
  const [bulkError, setBulkError] = useState('');
  const [proofOrderId, setProofOrderId] = useState<string | null>(null);

  const fetchOrders = useCallback(async () => {
    if (!profile) return;
    setLoading(true);
    const { data: driverLink } = await supabase
      .from('lab_drivers')
      .select('lab_id')
      .eq('driver_id', profile.id)
      .maybeSingle();

    if (!driverLink) { setLoading(false); return; }

    const { data } = await supabase
      .from('orders')
      .select('*, from_profile:profiles!orders_from_id_fkey(*), lab_profile:profiles!orders_lab_id_fkey(*), service:services(*)')
      .eq('lab_id', driverLink.lab_id)
      .in('status', ['completed', 'try_in', 'delivered'])
      .order('created_at', { ascending: false });

    setOrders(data ?? []);
    setLoading(false);
  }, [profile]);

  useEffect(() => { fetchOrders(); }, [fetchOrders]);
  useRealtimeDriverOrders(profile?.id, fetchOrders);

  const markDelivered = async (orderId: string) => {
    if (!profile) return;
    setBusy(orderId);
    const { error } = await supabase
      .from('orders')
      .update({
        status: 'delivered',
        delivered_at: new Date().toISOString(),
        delivered_by: profile.id,
        updated_at: new Date().toISOString(),
      })
      .eq('id', orderId);
    setBusy(null);
    if (!error) fetchOrders();
  };

  const bulkMarkDelivered = async () => {
    if (selectedIds.size === 0 || !profile) return;
    setBulkUpdating(true);
    setBulkError('');
    const { error } = await supabase
      .from('orders')
      .update({
        status: 'delivered',
        delivered_at: new Date().toISOString(),
        delivered_by: profile.id,
        updated_at: new Date().toISOString(),
      })
      .in('id', Array.from(selectedIds));
    setBulkUpdating(false);
    if (error) { setBulkError('Could not mark the selected deliveries. Please refresh and try again.'); return; }
    setSelectedIds(new Set());
    setMultiSelectMode(false);
    fetchOrders();
  };

  const toggleSelect = (id: string) => {
    setSelectedIds(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id); else next.add(id);
      return next;
    });
  };

  const toggleSelectAll = (ids: string[]) => {
    const allSelected = ids.every(id => selectedIds.has(id));
    if (allSelected) {
      setSelectedIds(prev => {
        const next = new Set(prev);
        ids.forEach(id => next.delete(id));
        return next;
      });
    } else {
      setSelectedIds(prev => {
        const next = new Set(prev);
        ids.forEach(id => next.add(id));
        return next;
      });
    }
  };

  const q = search.trim().toLowerCase();
  const matches = (o: Order) => !q ||
    (o.order_number ?? '').toLowerCase().includes(q) ||
    (o.patient_name ?? '').toLowerCase().includes(q) ||
    (o.dr_name ?? '').toLowerCase().includes(q) ||
    (o.file_number ?? '').toLowerCase().includes(q) ||
    (o.from_profile?.name ?? '').toLowerCase().includes(q) ||
    (o.from_profile?.address ?? '').toLowerCase().includes(q) ||
    (o.from_profile?.city ?? '').toLowerCase().includes(q);

  const ready = orders.filter(o => (o.status === 'completed' || o.status === 'try_in') && matches(o));
  const delivered = orders.filter(o => o.status === 'delivered' && matches(o));

  const readyIds = ready.map(o => o.id);
  const selectedReady = readyIds.filter(id => selectedIds.has(id));

  if (loading) {
    return (
      <div className="p-6 max-w-3xl mx-auto">
        <div className="space-y-3">
          {[1,2,3].map(i => <div key={i} className="bg-white rounded-xl h-28 animate-pulse shadow-card" />)}
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 max-w-3xl mx-auto">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-amber-100 rounded-xl flex items-center justify-center">
            <Truck className="w-5 h-5 text-amber-600" />
          </div>
          <div>
            <h1 className="font-display text-2xl font-bold text-neutral-900">Deliveries</h1>
            <p className="text-neutral-500 text-sm">Cases ready for delivery</p>
          </div>
        </div>
        <button
          onClick={() => { setMultiSelectMode(v => !v); setSelectedIds(new Set()); setBulkError(''); }}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-semibold border transition-colors ${
            multiSelectMode ? 'bg-primary-600 text-white border-primary-600' : 'bg-white text-neutral-600 border-neutral-200 hover:border-primary-300 hover:text-primary-600'
          }`}
        >
          <CheckSquare className="w-4 h-4" />
          {multiSelectMode ? 'Done' : 'Select'}
        </button>
      </div>

      {/* Search */}
      <div className="relative mb-5">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-neutral-400" />
        <input
          type="text"
          placeholder="Search by order #, patient, doctor, file #, or delivery address..."
          value={search}
          onChange={e => setSearch(e.target.value)}
          className="w-full pl-9 pr-4 py-2.5 rounded-xl border border-neutral-200 bg-white text-sm focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-transparent"
        />
      </div>

      {/* Bulk action bar */}
      {multiSelectMode && selectedReady.length > 0 && (
        <div className="bg-white rounded-xl border border-primary-200 shadow-card p-3 mb-4 flex items-center gap-3 flex-wrap">
          <span className="text-sm text-neutral-600 font-medium">{selectedIds.size} selected</span>
          <button
            onClick={bulkMarkDelivered}
            disabled={bulkUpdating}
            className="flex items-center gap-1.5 px-4 py-2 text-sm font-semibold rounded-lg bg-emerald-600 text-white hover:bg-emerald-700 disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
          >
            {bulkUpdating ? <Loader2 className="w-4 h-4 animate-spin" /> : <CheckCircle2 className="w-4 h-4" />}
            Mark Delivered ({selectedReady.length})
          </button>
          {bulkError && <p className="text-red-600 text-sm w-full">{bulkError}</p>}
        </div>
      )}

      {/* Stats */}
      <div className="grid grid-cols-2 gap-3 mb-6">
        <div className="bg-white rounded-2xl p-4 shadow-card animate-rise-in transition-transform duration-200 hover:-translate-y-0.5 hover:shadow-lg" style={{ animationDelay: '0ms' }}>
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-amber-50 rounded-lg flex items-center justify-center">
              <Package className="w-4 h-4 text-amber-600" />
            </div>
            <div>
              <p className="text-lg font-bold text-neutral-900"><CountUp value={ready.length} /></p>
              <p className="text-[11px] text-neutral-500">Ready</p>
            </div>
          </div>
        </div>
        <div className="bg-white rounded-2xl p-4 shadow-card animate-rise-in transition-transform duration-200 hover:-translate-y-0.5 hover:shadow-lg" style={{ animationDelay: '70ms' }}>
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-emerald-50 rounded-lg flex items-center justify-center">
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            </div>
            <div>
              <p className="text-lg font-bold text-neutral-900"><CountUp value={delivered.length} /></p>
              <p className="text-[11px] text-neutral-500">Delivered</p>
            </div>
          </div>
        </div>
      </div>

      {orders.length === 0 ? (
        <div className="text-center py-16">
          <Truck className="w-12 h-12 text-neutral-300 mx-auto mb-3" />
          <p className="text-neutral-500 font-medium">No cases to deliver</p>
          <p className="text-neutral-400 text-sm">Completed cases will appear here for delivery</p>
        </div>
      ) : ready.length === 0 && delivered.length === 0 ? (
        <div className="text-center py-16">
          <Search className="w-12 h-12 text-neutral-300 mx-auto mb-3" />
          <p className="text-neutral-500 font-medium">No matching cases</p>
          <p className="text-neutral-400 text-sm">Try a different search term</p>
        </div>
      ) : (
        <div className="space-y-6">
          {ready.length > 0 && (
            <Section title="Ready for Delivery" selectable={multiSelectMode} ids={readyIds} selectedIds={selectedIds} onToggleAll={() => toggleSelectAll(readyIds)}>
              {ready.map(o => (
                <DeliveryCard key={o.id} order={o} busy={busy === o.id}
                  multiSelectMode={multiSelectMode}
                  isSelected={selectedIds.has(o.id)}
                  onToggleSelect={() => toggleSelect(o.id)}
                  primaryAction={{ label: 'Mark Delivered', icon: 'check', onClick: () => markDelivered(o.id) }}
                />
              ))}
            </Section>
          )}
          {delivered.length > 0 && (
            <Section title="Delivered">
              {delivered.map(o => (
                <DeliveryCard key={o.id} order={o} busy={false}
                  onAddProof={() => setProofOrderId(o.id)}
                />
              ))}
            </Section>
          )}
        </div>
      )}

      {/* Delivery Proof Upload Modal */}
      {proofOrderId && profile && (
        <DeliveryProofModal
          orderId={proofOrderId}
          driverId={profile.id}
          driverName={profile.name}
          onClose={() => setProofOrderId(null)}
        />
      )}
    </div>
  );
}

function Section({
  title, children, selectable, ids, selectedIds, onToggleAll,
}: {
  title: string;
  children: React.ReactNode;
  selectable?: boolean;
  ids?: string[];
  selectedIds?: Set<string>;
  onToggleAll?: () => void;
}) {
  const allSelected = selectable && ids && selectedIds && ids.length > 0 && ids.every(id => selectedIds.has(id));
  return (
    <div>
      <div className="flex items-center gap-2 mb-3">
        {selectable && onToggleAll && (
          <button onClick={onToggleAll} className="flex items-center gap-1.5 text-sm font-medium text-primary-600 hover:text-primary-700">
            <div className={`w-4 h-4 rounded border-2 flex items-center justify-center transition-colors ${allSelected ? 'bg-primary-600 border-primary-600' : 'border-neutral-300'}`}>
              {allSelected && <CheckCircle2 className="w-3 h-3 text-white" />}
            </div>
            <span className="text-sm font-semibold text-neutral-700 uppercase tracking-wide">{title}</span>
          </button>
        )}
        {!selectable && <h2 className="font-display text-sm font-semibold text-neutral-700 uppercase tracking-wide">{title}</h2>}
      </div>
      <div className="space-y-3">{children}</div>
    </div>
  );
}

function DeliveryCard({
  order, busy, primaryAction, multiSelectMode, isSelected, onToggleSelect, onAddProof,
}: {
  order: Order;
  busy: boolean;
  primaryAction?: { label: string; icon: 'play' | 'check'; onClick: () => void };
  multiSelectMode?: boolean;
  isSelected?: boolean;
  onToggleSelect?: () => void;
  onAddProof?: () => void;
}) {
  const fp = order.from_profile;
  const hasCoords = fp?.latitude != null && fp?.longitude != null;
  const addrLine = [fp?.address, fp?.city].filter(Boolean).join(', ');
  const isDelivered = order.status === 'delivered';
  const isTryIn = order.status === 'try_in';

  const accent = isDelivered ? 'emerald' : isTryIn ? 'amber' : 'cyan';

  return (
    <div className={`bg-white rounded-2xl shadow-card overflow-hidden border ${isSelected ? 'border-primary-300 bg-primary-50/30' : `border-${accent}-100`} ${multiSelectMode ? 'cursor-pointer' : ''}`}
      onClick={multiSelectMode ? onToggleSelect : undefined}
    >
      <div className={`h-1 bg-${accent}-500`} />
      <div className="p-4">
        <div className="flex items-start justify-between mb-3">
          <div className="flex items-start gap-2">
            {multiSelectMode && (
              <div className={`w-5 h-5 rounded-md border-2 flex items-center justify-center flex-shrink-0 mt-0.5 transition-colors ${
                isSelected ? 'bg-primary-600 border-primary-600' : 'border-neutral-300'
              }`}>
                {isSelected && <CheckCircle2 className="w-3.5 h-3.5 text-white" />}
              </div>
            )}
            <div>
              <div className="flex items-center gap-2 mb-1">
                <span className="font-bold text-neutral-900 text-sm">{order.order_number}</span>
                {isDelivered ? (
                  <span className="flex items-center gap-1 text-[11px] font-semibold text-emerald-700 bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded-full">
                    <CheckCircle2 className="w-3 h-3" /> Delivered
                  </span>
                ) : isTryIn ? (
                  <span className="flex items-center gap-1 text-[11px] font-semibold text-amber-700 bg-amber-50 border border-amber-300 px-2 py-0.5 rounded-full">
                    <Clock className="w-3 h-3" /> Try In
                  </span>
                ) : (
                  <span className="flex items-center gap-1 text-[11px] font-semibold text-amber-700 bg-amber-50 border border-amber-200 px-2 py-0.5 rounded-full">
                    <Clock className="w-3 h-3" /> Ready
                  </span>
                )}
              </div>
              <p className="text-sm text-neutral-600">
                Patient: <span className="font-medium">{order.patient_name}</span> · Dr. {order.dr_name}
              </p>
              <p className="text-xs text-neutral-400 mt-0.5">File #{order.file_number}</p>
            </div>
          </div>
        </div>

        {/* Delivery location */}
        <div className="bg-blue-50 rounded-xl p-3 border border-blue-100 mb-3">
          <div className="flex items-center gap-1.5 mb-1.5">
            <MapPin className="w-4 h-4 text-blue-600" />
            <span className="text-xs font-semibold text-blue-700 uppercase tracking-wide">Deliver To</span>
          </div>
          <p className="text-sm text-blue-900 font-medium">{fp?.name ?? '—'}</p>
          {addrLine && <p className="text-xs text-blue-700 mt-0.5">{addrLine}</p>}
          {hasCoords && (
            <a
              href={`https://www.google.com/maps/dir/?api=1&destination=${fp!.latitude},${fp!.longitude}`}
              target="_blank"
              rel="noreferrer"
              onClick={e => e.stopPropagation()}
              className="mt-2 inline-flex items-center gap-1.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 px-3 py-1.5 rounded-lg transition-colors"
            >
              <Navigation className="w-3.5 h-3.5" />
              Get directions
            </a>
          )}
        </div>

        {isDelivered ? (
          <div className="space-y-2">
            <div className="flex items-center gap-2 text-xs text-emerald-700 bg-emerald-50 rounded-lg px-3 py-2">
              <CheckCircle2 className="w-4 h-4" />
              Delivered {new Date(order.delivered_at!).toLocaleString('en-GB', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' })}
            </div>
            {onAddProof && (
              <button
                onClick={e => { e.stopPropagation(); onAddProof(); }}
                className="w-full flex items-center justify-center gap-2 py-2.5 text-sm font-semibold rounded-xl border border-primary-200 text-primary-700 bg-primary-50 hover:bg-primary-100 transition-colors"
              >
                <Camera className="w-4 h-4" />
                Add Delivery Proof
              </button>
            )}
          </div>
        ) : primaryAction && !multiSelectMode ? (
          <button
            onClick={primaryAction.onClick}
            disabled={busy}
            className="w-full flex items-center justify-center gap-2 py-2.5 text-white text-sm font-semibold rounded-xl transition-colors disabled:opacity-60 bg-emerald-600 hover:bg-emerald-700"
          >
            {busy ? (
              <><div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" /> Please wait...</>
            ) : (
              <><CheckCircle2 className="w-4 h-4" /> {primaryAction.label}</>
            )}
          </button>
        ) : null}
      </div>
    </div>
  );
}

function DeliveryProofModal({
  orderId, driverId, driverName, onClose,
}: {
  orderId: string;
  driverId: string;
  driverName: string;
  onClose: () => void;
}) {
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);
  const cameraRef = useRef<HTMLInputElement>(null);

  const handleFile = (f: File | null) => {
    if (!f) return;
    if (f.size > 10 * 1024 * 1024) { setError('File is too large (max 10 MB).'); return; }
    setFile(f);
    setError('');
    if (f.type.startsWith('image/')) {
      const reader = new FileReader();
      reader.onload = () => setPreview(reader.result as string);
      reader.readAsDataURL(f);
    } else {
      setPreview(null);
    }
  };

  const handleUpload = async () => {
    if (!file) return;
    setUploading(true);
    setError('');

    const ext = file.name.split('.').pop() || 'jpg';
    const path = `${orderId}/comments/${Date.now()}-proof.${ext}`;
    const { error: upErr } = await supabase.storage.from('order-attachments').upload(path, file);
    if (upErr) {
      setError('Could not upload the photo. Please try again.');
      setUploading(false);
      return;
    }

    const { data: { publicUrl } } = supabase.storage.from('order-attachments').getPublicUrl(path);

    const { error: insertErr } = await supabase.from('order_comments').insert({
      order_id: orderId,
      author_id: driverId,
      body: '\u{1F4F8} Delivery proof attached',
      attachment_url: publicUrl,
      attachment_name: file.name,
      attachment_size: file.size,
      attachment_mime: file.type,
    });

    setUploading(false);
    if (insertErr) {
      setError('Photo uploaded but could not post to conversation. Please try again.');
      return;
    }
    setSuccess(true);
    setTimeout(onClose, 1500);
  };

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm transform-gpu flex items-center justify-center z-[70] p-4 animate-modal-in">
      <div className="bg-white rounded-2xl shadow-modal w-full max-w-sm overflow-hidden">
        <div className="flex items-center justify-between p-4 border-b border-neutral-200">
          <div>
            <h2 className="font-display font-bold text-neutral-900">Delivery Proof</h2>
            <p className="text-xs text-neutral-500">Take a photo or upload a file</p>
          </div>
          <button onClick={onClose} className="w-8 h-8 flex items-center justify-center rounded-lg hover:bg-neutral-100 transition-colors">
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="p-5 space-y-4">
          {success ? (
            <div className="text-center py-6">
              <div className="w-14 h-14 bg-emerald-100 rounded-full flex items-center justify-center mx-auto mb-3">
                <CheckCircle2 className="w-7 h-7 text-emerald-600" />
              </div>
              <p className="font-semibold text-neutral-900">Proof uploaded!</p>
              <p className="text-sm text-neutral-500 mt-1">It will appear in the order conversation.</p>
            </div>
          ) : (
            <>
              {/* Preview area */}
              {preview ? (
                <div className="relative">
                  <img src={preview} alt="Preview" className="w-full h-48 object-cover rounded-xl border border-neutral-200" />
                  <button
                    onClick={() => { setFile(null); setPreview(null); }}
                    className="absolute top-2 right-2 w-7 h-7 bg-white/90 rounded-full flex items-center justify-center shadow-sm hover:bg-white transition-colors"
                  >
                    <X className="w-4 h-4 text-neutral-600" />
                  </button>
                </div>
              ) : file ? (
                <div className="flex items-center gap-3 p-3 bg-neutral-50 rounded-xl border border-neutral-200">
                  <ImageIcon className="w-5 h-5 text-neutral-400" />
                  <span className="text-sm text-neutral-700 font-medium truncate flex-1">{file.name}</span>
                  <button onClick={() => { setFile(null); setPreview(null); }} className="text-neutral-400 hover:text-neutral-600">
                    <X className="w-4 h-4" />
                  </button>
                </div>
              ) : (
                <div className="grid grid-cols-2 gap-3">
                  <button
                    onClick={() => cameraRef.current?.click()}
                    className="flex flex-col items-center justify-center gap-2 p-6 bg-primary-50 border-2 border-dashed border-primary-200 rounded-xl hover:bg-primary-100 hover:border-primary-300 transition-colors"
                  >
                    <Camera className="w-6 h-6 text-primary-600" />
                    <span className="text-xs font-semibold text-primary-700">Take Photo</span>
                  </button>
                  <button
                    onClick={() => fileRef.current?.click()}
                    className="flex flex-col items-center justify-center gap-2 p-6 bg-neutral-50 border-2 border-dashed border-neutral-200 rounded-xl hover:bg-neutral-100 hover:border-neutral-300 transition-colors"
                  >
                    <Upload className="w-6 h-6 text-neutral-500" />
                    <span className="text-xs font-semibold text-neutral-600">Upload File</span>
                  </button>
                </div>
              )}

              {error && <p className="text-sm text-red-600 bg-red-50 rounded-lg px-3 py-2">{error}</p>}

              <input ref={cameraRef} type="file" accept="image/*" capture="environment" className="hidden"
                onChange={e => { handleFile(e.target.files?.[0] ?? null); e.target.value = ''; }} />
              <input ref={fileRef} type="file" accept="image/*,.pdf" className="hidden"
                onChange={e => { handleFile(e.target.files?.[0] ?? null); e.target.value = ''; }} />

              {file && (
                <button
                  onClick={handleUpload}
                  disabled={uploading}
                  className="w-full flex items-center justify-center gap-2 py-3 text-sm font-semibold rounded-xl bg-primary-600 hover:bg-primary-700 text-white transition-colors disabled:opacity-60"
                >
                  {uploading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Upload className="w-4 h-4" />}
                  {uploading ? 'Uploading...' : 'Upload Delivery Proof'}
                </button>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
}
