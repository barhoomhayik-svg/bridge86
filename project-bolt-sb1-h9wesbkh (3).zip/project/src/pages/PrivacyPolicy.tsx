import React from 'react';
import { ArrowLeft } from 'lucide-react';

export default function PrivacyPolicy() {
  const goBack = () => {
    if (window.history.length > 1) window.history.back();
    else { window.location.href = '/'; }
  };

  return (
    <div className="min-h-dvh bg-[#F8F7F4]">
      <header className="sticky top-0 z-20 bg-white/80 backdrop-blur-lg border-b border-neutral-200 transform-gpu">
        <div className="max-w-3xl mx-auto px-6 h-14 flex items-center gap-3">
          <button
            onClick={goBack}
            className="p-2 -ml-2 rounded-lg text-neutral-500 hover:text-neutral-900 hover:bg-neutral-100 transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h1 className="font-display font-bold text-lg text-neutral-900">Privacy Policy</h1>
        </div>
      </header>

      <main className="max-w-3xl mx-auto px-6 py-10">
        <p className="text-sm text-neutral-400 mb-8">Last updated: August 21, 2026</p>

        <div className="prose prose-neutral prose-sm max-w-none space-y-8">
          <section>
            <h2 className="font-display text-lg font-semibold text-neutral-900 mb-3">1. Introduction</h2>
            <p className="text-neutral-600 leading-relaxed">
              Bridge 86 ("we", "our", or "us") operates the Bridge 86 dental lab ordering platform. This Privacy Policy explains how we collect, use, disclose, and safeguard your information when you use our web and mobile applications (the "Service"). By using Bridge 86, you consent to the practices described in this policy.
            </p>
          </section>

          <section>
            <h2 className="font-display text-lg font-semibold text-neutral-900 mb-3">2. Information We Collect</h2>
            <h3 className="text-sm font-semibold text-neutral-700 mt-4 mb-2">Account Information</h3>
            <p className="text-neutral-600 leading-relaxed">
              When you register, we collect your name, email address, phone number, role (doctor, dental center, lab, or driver), and optionally your clinic or lab name, address, and professional credentials.
            </p>
            <h3 className="text-sm font-semibold text-neutral-700 mt-4 mb-2">Case and Order Data</h3>
            <p className="text-neutral-600 leading-relaxed">
              We store information related to dental cases you create or receive, including patient file numbers, tooth selections, service details, shade specifications, attachments (photos, documents), comments, and delivery tracking data.
            </p>
            <h3 className="text-sm font-semibold text-neutral-700 mt-4 mb-2">Usage Data</h3>
            <p className="text-neutral-600 leading-relaxed">
              We automatically collect device type, browser, IP address, pages visited, and interaction timestamps to improve performance and troubleshoot issues.
            </p>
          </section>

          <section>
            <h2 className="font-display text-lg font-semibold text-neutral-900 mb-3">3. How We Use Your Information</h2>
            <ul className="list-disc pl-5 text-neutral-600 space-y-2 leading-relaxed">
              <li>To provide, operate, and maintain the Service</li>
              <li>To facilitate communication between dental professionals, labs, and drivers</li>
              <li>To process and track case orders and deliveries</li>
              <li>To send notifications about order status changes, comments, and quotations</li>
              <li>To improve and personalize the user experience</li>
              <li>To enforce our terms and protect against fraud or misuse</li>
            </ul>
          </section>

          <section>
            <h2 className="font-display text-lg font-semibold text-neutral-900 mb-3">4. Data Sharing</h2>
            <p className="text-neutral-600 leading-relaxed">
              We share case information only with the parties directly involved in a specific order: the sending clinic or doctor, the receiving lab, and any assigned driver. We do not sell your personal information to third parties. We may share data with service providers who help us operate the platform (hosting, analytics) under strict confidentiality agreements, or when required by law.
            </p>
          </section>

          <section>
            <h2 className="font-display text-lg font-semibold text-neutral-900 mb-3">5. Data Security</h2>
            <p className="text-neutral-600 leading-relaxed">
              We implement industry-standard security measures including encryption in transit (TLS), encrypted storage, row-level access controls ensuring users only access data they are authorized to see, and regular security audits. However, no method of electronic transmission or storage is completely secure.
            </p>
          </section>

          <section>
            <h2 className="font-display text-lg font-semibold text-neutral-900 mb-3">6. Data Retention</h2>
            <p className="text-neutral-600 leading-relaxed">
              We retain your account and order data for as long as your account is active or as needed to provide the Service. Archived cases are retained for professional record-keeping purposes. You may request deletion of your account data by contacting us.
            </p>
          </section>

          <section>
            <h2 className="font-display text-lg font-semibold text-neutral-900 mb-3">7. Your Rights</h2>
            <p className="text-neutral-600 leading-relaxed">
              Depending on your jurisdiction, you may have the right to access, correct, or delete your personal data; object to or restrict processing; and data portability. To exercise these rights, contact us using the information below.
            </p>
          </section>

          <section>
            <h2 className="font-display text-lg font-semibold text-neutral-900 mb-3">8. Cookies and Local Storage</h2>
            <p className="text-neutral-600 leading-relaxed">
              Bridge 86 uses local storage and session tokens to keep you signed in and remember your preferences. We do not use third-party advertising cookies.
            </p>
          </section>

          <section>
            <h2 className="font-display text-lg font-semibold text-neutral-900 mb-3">9. Children's Privacy</h2>
            <p className="text-neutral-600 leading-relaxed">
              Bridge 86 is designed for dental professionals and is not intended for use by individuals under 18 years of age. We do not knowingly collect information from minors.
            </p>
          </section>

          <section>
            <h2 className="font-display text-lg font-semibold text-neutral-900 mb-3">10. Changes to This Policy</h2>
            <p className="text-neutral-600 leading-relaxed">
              We may update this Privacy Policy from time to time. We will notify you of material changes by posting the new policy on this page and updating the "Last updated" date. Continued use of the Service after changes constitutes acceptance.
            </p>
          </section>

          <section>
            <h2 className="font-display text-lg font-semibold text-neutral-900 mb-3">11. Contact Us</h2>
            <p className="text-neutral-600 leading-relaxed">
              If you have questions about this Privacy Policy or wish to exercise your data rights, please contact us at{' '}
              <a href="mailto:info@bridge-86.com" className="text-primary-600 hover:underline">info@bridge-86.com</a>.
            </p>
          </section>

          <section className="border-t border-neutral-200 pt-6">
            <p className="text-neutral-500 text-sm">
              See also:{' '}
              <a href="/terms-of-service" className="text-primary-600 hover:underline font-medium">Terms of Service</a>
            </p>
          </section>
        </div>
      </main>
    </div>
  );
}
