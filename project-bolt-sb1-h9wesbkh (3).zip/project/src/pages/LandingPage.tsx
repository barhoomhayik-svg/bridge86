import React, { useState, useEffect, useRef } from 'react';
import AuthPage from './AuthPage';
import {
  Stethoscope, FlaskConical, Building2, Truck, ClipboardList,
  MessageSquare, Package, CheckCircle2, ArrowRight, Menu, X,
  Shield, Zap, Clock, Sparkles, Star, Quote,
} from 'lucide-react';

const HERO_IMG = 'https://images.pexels.com/photos/6627592/pexels-photo-6627592.jpeg?auto=compress&cs=tinysrgb&w=1280&h=640';
const SPLIT_IMG = 'https://images.pexels.com/photos/7788493/pexels-photo-7788493.jpeg?auto=compress&cs=tinysrgb&w=900&h=900';
const CARD_1 = 'https://images.pexels.com/photos/305567/pexels-photo-305567.jpeg?auto=compress&cs=tinysrgb&w=600&h=450';
const CARD_2 = 'https://images.pexels.com/photos/7788506/pexels-photo-7788506.jpeg?auto=compress&cs=tinysrgb&w=600&h=450';
const CARD_3 = 'https://images.pexels.com/photos/6812483/pexels-photo-6812483.jpeg?auto=compress&cs=tinysrgb&w=600&h=450';
const FEAT_1 = 'https://images.pexels.com/photos/12712256/pexels-photo-12712256.jpeg?auto=compress&cs=tinysrgb&w=500&h=500';
const FEAT_2 = 'https://images.pexels.com/photos/12551732/pexels-photo-12551732.jpeg?auto=compress&cs=tinysrgb&w=500&h=500';
const FEAT_3 = 'https://images.pexels.com/photos/33800637/pexels-photo-33800637.jpeg?auto=compress&cs=tinysrgb&w=500&h=600';

const NAV_LINKS = [
  { label: 'Features', target: 'features' },
  { label: 'How it works', target: 'how-it-works' },
  { label: 'Roles', target: 'roles' },
  { label: 'Stories', target: 'testimonials' },
];

const FEATURE_CARDS = [
  {
    icon: ClipboardList,
    title: 'Digital Case Orders',
    desc: 'Send cases to any lab in seconds. Select teeth on an interactive chart, add services, shades, and attachments — all from your phone.',
    img: CARD_1,
    accent: 'coral',
  },
  {
    icon: MessageSquare,
    title: 'Real-time Comments',
    desc: 'Chat directly on each case. Lab technicians and doctors stay aligned without phone calls, emails, or lost messages.',
    img: CARD_2,
    accent: 'primary',
  },
  {
    icon: Truck,
    title: 'Driver Delivery Tracking',
    desc: 'Assign pickups and deliveries to drivers. Track every case from the clinic to the lab and back with live status updates.',
    img: CARD_3,
    accent: 'amber',
  },
];

const HOW_STEPS = [
  { icon: Stethoscope, title: 'Doctor sends the case', desc: 'Pick a lab, select teeth, choose services, and submit the order in under a minute.' },
  { icon: FlaskConical, title: 'Lab receives & produces', desc: 'The lab sees the case instantly, confirms the shade, and starts production with all the details.' },
  { icon: Truck, title: 'Driver delivers', desc: 'A driver picks up the finished work and delivers it back to the clinic — tracked end to end.' },
  { icon: CheckCircle2, title: 'Case complete', desc: 'The doctor confirms delivery. Everything is archived for future reference and redos.' },
];

const STATS = [
  { value: '4 roles', label: 'Doctors, centers, labs & drivers' },
  { value: '< 60s', label: 'To place a full case' },
  { value: '100%', label: 'Digital, no paperwork' },
];

const TESTIMONIALS = [
  {
    quote: 'Bridge replaced our WhatsApp orders and printed tickets. Cases arrive complete every time — no more missing shades or tooth numbers.',
    name: 'Dr. Sarah Mansour',
    role: 'Prosthodontist, Smile Center',
  },
  {
    quote: 'As a lab, we used to chase doctors for case details. Now everything arrives structured and clear. Production is faster and errors dropped to near zero.',
    name: 'Karim Haddad',
    role: 'Owner, Precision Dental Lab',
  },
  {
    quote: 'Our drivers know exactly where to go and what to pick up. The tracking gives our centers confidence that the case is on its way.',
    name: 'Lina Okafor',
    role: 'Operations, City Dental Group',
  },
];

const ROLES = [
  {
    icon: Stethoscope,
    title: 'Doctors',
    desc: 'Place orders, track status, and manage all your cases across multiple labs and centers.',
    img: FEAT_1,
    tall: false,
    glyph: 'M19 14c1.5-1.5 3-3.5 3-6 0-3.5-2.5-6-6-6-2 0-3 1-4 2-1-1-2-2-4-2-3.5 0-6 2.5-6 6 0 2.5 1.5 4.5 3 6 1 1 2 2.5 2 4 0 1.5-1 3-2 3s-2-1.5-2-3c0-1 .5-2 .5-3 0-1-.5-2-1.5-2s-1.5 1-1.5 2c0 1 .5 2 .5 3 0 1.5-1 3-2 3s-2-1.5-2-3c0-1.5 1-3 2-4z',
  },
  {
    icon: Building2,
    title: 'Dental Centers',
    desc: 'Coordinate your team of doctors, send orders from the center, and get one invoiced bill.',
    img: FEAT_2,
    tall: false,
  },
  {
    icon: FlaskConical,
    title: 'Laboratories',
    desc: 'Receive structured orders, manage your client base, publish your service catalog, and track production.',
    img: FEAT_3,
    tall: true,
  },
];

const FAQ_ITEMS = [
  { q: 'How long does it take to get started?', a: 'Most teams are up and running in under 10 minutes. Create your account, find your lab or clinic, and send your first case right away.' },
  { q: 'Does Bridge work for multi-location practices?', a: 'Yes. Centers can coordinate doctors across multiple locations, and labs can serve unlimited clinics. Everything is organized in one place.' },
  { q: 'Is my case data secure?', a: 'Absolutely. All data is encrypted in transit and at rest. Only the people on a specific case can see its details — no one else.' },
  { q: 'Can I use Bridge on my phone?', a: 'Yes. Bridge is a mobile-first app that works in any browser. There is also a native iOS app for an even smoother experience.' },
];

const FOOTER_LINKS = [
  { label: 'Features', target: 'features' },
  { label: 'How it works', target: 'how-it-works' },
  { label: 'Roles', target: 'roles' },
  { label: 'Stories', target: 'testimonials' },
];

/* ── Scroll-triggered reveal ── */
function Reveal({ children, className = '', delay = 0 }: { children: React.ReactNode; className?: string; delay?: number }) {
  const ref = useRef<HTMLDivElement>(null);
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const obs = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting) { setVisible(true); obs.disconnect(); } },
      { threshold: 0.15 },
    );
    obs.observe(el);
    return () => obs.disconnect();
  }, []);

  return (
    <div
      ref={ref}
      className={`transition-all duration-700 ease-out ${visible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'} ${className}`}
      style={{ transitionDelay: `${delay}ms` }}
    >
      {children}
    </div>
  );
}

/* ── Candy button: glossy 3D-style button adapted from Flutter design ── */
function CandyButton({ children, onClick, variant = 'mint', className = '' }: {
  children: React.ReactNode;
  onClick?: () => void;
  variant?: 'mint' | 'sugar';
  className?: string;
}) {
  const styles = {
    mint: 'bg-gradient-to-b from-primary-400 to-primary-600 text-white shadow-[0_3px_0_0_#1B504B,0_6px_16px_rgba(47,122,115,0.3)] hover:shadow-[0_2px_0_0_#1B504B,0_4px_12px_rgba(47,122,115,0.25)] active:shadow-[0_1px_0_0_#1B504B,0_2px_6px_rgba(47,122,115,0.2)]',
    sugar: 'bg-gradient-to-b from-white to-neutral-100 text-neutral-800 border border-neutral-200 shadow-[0_3px_0_0_#DAD6CE,0_4px_12px_rgba(33,30,27,0.08)] hover:shadow-[0_2px_0_0_#DAD6CE,0_3px_8px_rgba(33,30,27,0.06)] active:shadow-[0_1px_0_0_#DAD6CE]',
  };
  return (
    <button
      onClick={onClick}
      className={`no-lift inline-flex items-center gap-2 px-7 py-3.5 font-bold rounded-xl text-base transition-all duration-200 hover:-translate-y-0.5 active:translate-y-0.5 active:scale-[0.98] ${styles[variant]} ${className}`}
    >
      {children}
    </button>
  );
}

/* ── FAQ accordion item ── */
function FaqItem({ item, index }: { item: { q: string; a: string }; index: number }) {
  const [open, setOpen] = useState(false);
  return (
    <Reveal delay={index * 60}>
      <div className="border-b border-neutral-200/60">
        <button
          onClick={() => setOpen(!open)}
          className="no-lift w-full flex items-center justify-between py-5 text-left group"
        >
          <span className="font-display text-base font-bold text-neutral-900 group-hover:text-primary-700 transition-colors">
            {item.q}
          </span>
          <span className={`flex-shrink-0 ml-4 w-7 h-7 rounded-full flex items-center justify-center transition-all duration-300 ${open ? 'bg-primary-500 text-white rotate-180' : 'bg-neutral-100 text-neutral-500'}`}>
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M19 9l-7 7-7-7" /></svg>
          </span>
        </button>
        <div className={`overflow-hidden transition-all duration-300 ease-out ${open ? 'max-h-40 opacity-100' : 'max-h-0 opacity-0'}`}>
          <p className="pb-5 text-sm text-neutral-500 leading-relaxed pr-12">{item.a}</p>
        </div>
      </div>
    </Reveal>
  );
}

export default function LandingPage() {
  const [showAuth, setShowAuth] = useState(false);
  const [mobileMenu, setMobileMenu] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  const scrollTo = (id: string) => {
    document.getElementById(id)?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    setMobileMenu(false);
  };

  if (showAuth) return <AuthPage onBack={() => setShowAuth(false)} />;

  return (
    <div className="min-h-dvh bg-[#F7F6F1]">
      {/* ── Header ── */}
      <header className={`sticky top-0 z-40 transition-all duration-300 transform-gpu ${scrolled ? 'bg-white/95 backdrop-blur-md shadow-sm border-b border-neutral-200/60' : 'bg-transparent border-b border-transparent'}`}>
        <div className="max-w-[1200px] mx-auto px-6 lg:px-8 h-16 flex items-center justify-between">
          <a href="#" onClick={(e) => { e.preventDefault(); window.scrollTo({ top: 0, behavior: 'smooth' }); }} className="flex items-center gap-2.5 no-lift">
            <img src="/logo_%20copy%208.png" alt="Bridge" className="h-8 sm:h-9 w-auto object-contain" />
          </a>

          <nav className="hidden md:flex items-center gap-8">
            {NAV_LINKS.map(l => (
              <button key={l.target} onClick={() => scrollTo(l.target)}
                className="no-lift text-sm font-medium text-neutral-500 hover:text-neutral-800 transition-colors">
                {l.label}
              </button>
            ))}
          </nav>

          <div className="hidden md:flex items-center gap-3">
            <button onClick={() => setShowAuth(true)}
              className="no-lift text-sm font-semibold text-neutral-600 hover:text-neutral-900 px-4 py-2 transition-colors">
              Sign In
            </button>
            <CandyButton variant="mint" onClick={() => setShowAuth(true)} className="text-sm px-5 py-2.5">
              Get Started
            </CandyButton>
          </div>

          <button onClick={() => setMobileMenu(!mobileMenu)}
            className="md:hidden p-2 rounded-lg text-neutral-600 hover:bg-neutral-100">
            {mobileMenu ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>

        {mobileMenu && (
          <div className="md:hidden border-t border-neutral-200/60 px-6 py-4 flex flex-col gap-3 bg-white shadow-lg animate-rise-in">
            {NAV_LINKS.map(l => (
              <button key={l.target} onClick={() => scrollTo(l.target)}
                className="no-lift text-left text-sm font-medium text-neutral-700 hover:text-neutral-900">
                {l.label}
              </button>
            ))}
            <div className="flex gap-3 pt-2 border-t border-neutral-200/60">
              <button onClick={() => setShowAuth(true)}
                className="flex-1 text-sm font-semibold text-neutral-700 border border-neutral-200 rounded-xl py-2.5">
                Sign In
              </button>
              <button onClick={() => setShowAuth(true)}
                className="flex-1 text-sm font-bold text-white bg-primary-600 rounded-xl py-2.5">
                Get Started
              </button>
            </div>
          </div>
        )}
      </header>

      {/* ── Hero ── */}
      <section className="max-w-[1200px] mx-auto px-6 lg:px-8 pt-10 lg:pt-20">
        <div className="max-w-3xl">
          <Reveal>
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-coral-50 border border-coral-200/40 text-coral-600 text-xs font-semibold mb-6">
              <Sparkles className="w-3.5 h-3.5" />
              The dental case ordering platform
            </div>
          </Reveal>
          <Reveal delay={60}>
            <h1 className="font-display text-4xl sm:text-5xl lg:text-6xl font-extrabold text-neutral-900 leading-[1.02] tracking-tight">
              From chair to lab,
              <br />
              <span className="font-serif italic text-primary-500 font-normal">and back again.</span>
            </h1>
          </Reveal>
          <Reveal delay={120}>
            <p className="mt-6 text-lg text-neutral-600 leading-relaxed max-w-2xl">
              Bridge connects doctors, dental centers, laboratories, and drivers in one simple app.
              Send cases, track production, coordinate deliveries — no phone calls, no paperwork, no lost details.
            </p>
          </Reveal>
          <Reveal delay={180}>
            <div className="mt-8 flex flex-wrap items-center gap-3">
              <CandyButton variant="mint" onClick={() => setShowAuth(true)}>
                Get Started Free
                <ArrowRight className="w-4 h-4" />
              </CandyButton>
              <CandyButton variant="sugar" onClick={() => scrollTo('how-it-works')}>
                See how it works
              </CandyButton>
            </div>
          </Reveal>
          <Reveal delay={240}>
            <div className="mt-10 flex flex-wrap items-center gap-x-8 gap-y-3">
              {STATS.map(s => (
                <div key={s.label} className="flex flex-col">
                  <span className="font-display text-xl font-bold text-neutral-900">{s.value}</span>
                  <span className="text-xs text-neutral-400">{s.label}</span>
                </div>
              ))}
            </div>
          </Reveal>
        </div>

        <Reveal delay={300}>
          <div className="mt-12 lg:mt-16 w-full aspect-[2/1] rounded-2xl overflow-hidden shadow-lift">
            <img src={HERO_IMG} alt="Dental technician crafting a restoration" className="w-full h-full object-cover" />
          </div>
        </Reveal>
      </section>

      {/* ── Features ── */}
      <section id="features" className="max-w-[1200px] mx-auto px-6 lg:px-8 pt-20 lg:pt-28 scroll-mt-20">
        <Reveal>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary-50 text-primary-600 text-xs font-semibold mb-3">
            Features
          </div>
          <h2 className="font-display text-2xl sm:text-3xl lg:text-4xl font-extrabold text-neutral-900 tracking-tight">
            Everything in <span className="font-serif italic text-primary-500 font-normal">one place</span>
          </h2>
          <p className="mt-3 text-neutral-600 text-base lg:text-lg max-w-2xl">
            Four roles, one workflow. Bridge handles the entire journey from the moment a doctor sends a case to the moment it's delivered back.
          </p>
        </Reveal>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8 mt-10 lg:mt-12">
          {FEATURE_CARDS.map((card, i) => {
            const Icon = card.icon;
            const accentBg = card.accent === 'coral' ? 'bg-coral-50' : card.accent === 'amber' ? 'bg-amber-50' : 'bg-primary-50';
            const accentText = card.accent === 'coral' ? 'text-coral-500' : card.accent === 'amber' ? 'text-amber-500' : 'text-primary-600';
            return (
              <Reveal key={card.title} delay={i * 100}>
                <div className="group h-full rounded-2xl overflow-hidden border border-neutral-200/60 bg-white shadow-card hover:shadow-card-hover transition-all duration-300 hover:-translate-y-1">
                  <div className="aspect-[4/3] overflow-hidden relative">
                    <img src={card.img} alt={card.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                    <div className="absolute top-3 right-3 w-9 h-9 rounded-xl bg-white/90 backdrop-blur-sm flex items-center justify-center shadow-sm">
                      <Icon className={`w-4.5 h-4.5 ${accentText}`} />
                    </div>
                  </div>
                  <div className="p-6">
                    <h3 className="font-display text-lg font-bold text-neutral-900 mb-2">{card.title}</h3>
                    <p className="text-sm text-neutral-500 leading-relaxed">{card.desc}</p>
                  </div>
                </div>
              </Reveal>
            );
          })}
        </div>
      </section>

      {/* ── How it works ── */}
      <section id="how-it-works" className="max-w-[1200px] mx-auto px-6 lg:px-8 pt-20 lg:pt-28 scroll-mt-20">
        <Reveal>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-coral-50 text-coral-600 text-xs font-semibold mb-3">
            Workflow
          </div>
          <h2 className="font-display text-2xl sm:text-3xl lg:text-4xl font-extrabold text-neutral-900 tracking-tight">
            How a case <span className="font-serif italic text-primary-500 font-normal">moves</span>
          </h2>
          <p className="mt-3 text-neutral-600 text-base lg:text-lg max-w-2xl">
            Every case follows the same simple path. Each person sees only what they need to do their part.
          </p>
        </Reveal>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-14 mt-10 lg:mt-12 items-center">
          <div className="space-y-3">
            {HOW_STEPS.map((step, i) => {
              const Icon = step.icon;
              return (
                <Reveal key={step.title} delay={i * 100}>
                  <div className="flex items-start gap-4 group">
                    <div className="relative flex-shrink-0">
                      <div className="w-12 h-12 rounded-2xl bg-gradient-to-b from-primary-400 to-primary-600 text-white flex items-center justify-center shadow-[0_3px_0_0_#1B504B] transition-all duration-200 group-hover:shadow-[0_2px_0_0_#1B504B] group-hover:-translate-y-0.5">
                        <Icon className="w-5 h-5" />
                      </div>
                      {i < HOW_STEPS.length - 1 && (
                        <div className="absolute left-1/2 -translate-x-1/2 top-12 w-px h-6 bg-gradient-to-b from-primary-300 to-transparent" />
                      )}
                    </div>
                    <div className="flex-1 pt-1">
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold text-primary-400 tabular-nums">0{i + 1}</span>
                        <h3 className="font-display text-base font-bold text-neutral-900">{step.title}</h3>
                      </div>
                      <p className="mt-1 text-sm text-neutral-500 leading-relaxed">{step.desc}</p>
                    </div>
                  </div>
                </Reveal>
              );
            })}
          </div>
          <Reveal delay={200}>
            <div className="aspect-square rounded-2xl overflow-hidden shadow-lift">
              <img src={SPLIT_IMG} alt="Dental technician working on a case" className="w-full h-full object-cover" />
            </div>
          </Reveal>
        </div>
      </section>

      {/* ── Roles ── */}
      <section id="roles" className="max-w-[1200px] mx-auto px-6 lg:px-8 pt-20 lg:pt-28 scroll-mt-20">
        <Reveal>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-50 text-amber-600 text-xs font-semibold mb-3">
            Roles
          </div>
          <h2 className="font-display text-2xl sm:text-3xl lg:text-4xl font-extrabold text-neutral-900 tracking-tight">
            Built for <span className="font-serif italic text-primary-500 font-normal">every role</span>
          </h2>
          <p className="mt-3 text-neutral-600 text-base lg:text-lg max-w-2xl">
            Each role gets a focused dashboard with exactly the tools they need — nothing more, nothing less.
          </p>
        </Reveal>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8 mt-10 lg:mt-12">
          {ROLES.map((role, i) => {
            const Icon = role.icon;
            return (
              <Reveal key={role.title} delay={i * 100}>
                <div className="group h-full rounded-2xl overflow-hidden border border-neutral-200/60 bg-white shadow-card hover:shadow-card-hover transition-all duration-300 hover:-translate-y-1">
                  <div className={role.tall ? 'aspect-[5/6]' : 'aspect-square'}>
                    <img src={role.img} alt={role.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                  </div>
                  <div className="p-6">
                    <div className="w-10 h-10 rounded-xl bg-primary-50 flex items-center justify-center mb-4">
                      <Icon className="w-5 h-5 text-primary-600" />
                    </div>
                    <h3 className="font-display text-lg font-bold text-neutral-900 mb-2">{role.title}</h3>
                    <p className="text-sm text-neutral-500 leading-relaxed">{role.desc}</p>
                  </div>
                </div>
              </Reveal>
            );
          })}
        </div>
      </section>

      {/* ── Trust badges ── */}
      <section className="max-w-[1200px] mx-auto px-6 lg:px-8 pt-20 lg:pt-28">
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-5">
          {[
            { icon: Shield, title: 'Secure & private', desc: 'Your case data is encrypted and access-controlled. Only the people on the case can see it.' },
            { icon: Zap, title: 'Instant notifications', desc: 'Real-time updates on every case — new orders, comments, status changes, and delivery alerts.' },
            { icon: Clock, title: 'Faster turnaround', desc: 'No more phone tag. Cases arrive complete, labs start sooner, and drivers know the plan.' },
          ].map((badge, i) => {
            const Icon = badge.icon;
            return (
              <Reveal key={badge.title} delay={i * 80}>
                <div className="flex items-start gap-3.5 p-5 rounded-2xl bg-white border border-neutral-200/60 shadow-card hover:shadow-card-hover transition-all duration-300">
                  <div className="flex-shrink-0 w-10 h-10 rounded-xl bg-primary-50 flex items-center justify-center">
                    <Icon className="w-4.5 h-4.5 text-primary-600" />
                  </div>
                  <div>
                    <h3 className="font-display text-sm font-bold text-neutral-900">{badge.title}</h3>
                    <p className="mt-1 text-xs text-neutral-500 leading-relaxed">{badge.desc}</p>
                  </div>
                </div>
              </Reveal>
            );
          })}
        </div>
      </section>

      {/* ── Testimonials ── */}
      <section id="testimonials" className="max-w-[1200px] mx-auto px-6 lg:px-8 pt-20 lg:pt-28 scroll-mt-20">
        <Reveal>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary-50 text-primary-600 text-xs font-semibold mb-3">
            Stories
          </div>
          <h2 className="font-display text-2xl sm:text-3xl lg:text-4xl font-extrabold text-neutral-900 tracking-tight">
            Trusted by <span className="font-serif italic text-primary-500 font-normal">dental teams</span>
          </h2>
          <p className="mt-3 text-neutral-600 text-base lg:text-lg max-w-2xl">
            Doctors, labs, and centers use Bridge every day to keep their cases moving.
          </p>
        </Reveal>
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 lg:gap-8 mt-10 lg:mt-12">
          {TESTIMONIALS.map((t, i) => (
            <Reveal key={t.name} delay={i * 100}>
              <div className="h-full p-6 rounded-2xl bg-white border border-neutral-200/60 shadow-card hover:shadow-card-hover transition-all duration-300 flex flex-col">
                <Quote className="w-8 h-8 text-coral-300 mb-3" />
                <p className="text-sm text-neutral-600 leading-relaxed mb-5 flex-1 font-serif italic">"{t.quote}"</p>
                <div className="flex items-center gap-1 mb-4">
                  {[0, 1, 2, 3, 4].map(s => (
                    <Star key={s} className="w-4 h-4 text-amber-400 fill-amber-400" />
                  ))}
                </div>
                <div className="flex items-center gap-3 pt-4 border-t border-neutral-200/60">
                  <div className="w-10 h-10 rounded-full bg-primary-100 flex items-center justify-center">
                    <span className="text-sm font-bold text-primary-700">{t.name.charAt(0)}</span>
                  </div>
                  <div>
                    <p className="text-sm font-bold text-neutral-900">{t.name}</p>
                    <p className="text-xs text-neutral-400">{t.role}</p>
                  </div>
                </div>
              </div>
            </Reveal>
          ))}
        </div>
      </section>

      {/* ── FAQ ── */}
      <section className="max-w-[1200px] mx-auto px-6 lg:px-8 pt-20 lg:pt-28">
        <Reveal>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-coral-50 text-coral-600 text-xs font-semibold mb-3">
            FAQ
          </div>
          <h2 className="font-display text-2xl sm:text-3xl lg:text-4xl font-extrabold text-neutral-900 tracking-tight">
            Common <span className="font-serif italic text-primary-500 font-normal">questions</span>
          </h2>
        </Reveal>
        <div className="mt-8 max-w-2xl">
          {FAQ_ITEMS.map((item, i) => (
            <FaqItem key={item.q} item={item} index={i} />
          ))}
        </div>
      </section>

      {/* ── CTA ── */}
      <section className="pt-20 lg:pt-28">
        <div className="max-w-[1200px] mx-auto px-6 lg:px-8">
          <Reveal>
            <div className="relative rounded-3xl bg-gradient-to-br from-[#0F4540] via-[#134E48] to-[#0B3B36] overflow-hidden px-8 py-14 lg:px-16 lg:py-20 text-center">
              <div className="absolute inset-0 opacity-[0.07]" style={{ backgroundImage: `url(${HERO_IMG})`, backgroundSize: 'cover', backgroundPosition: 'center' }} />
              <div className="absolute top-[-60px] right-[-40px] w-[200px] h-[200px] rounded-full bg-white/[0.04]" />
              <div className="absolute bottom-[-40px] left-[-30px] w-[160px] h-[160px] rounded-full bg-coral-400/[0.06]" />
              <div className="relative">
                <h2 className="font-display text-2xl sm:text-3xl lg:text-4xl font-extrabold text-white tracking-tight">
                  Start sending cases <span className="font-serif italic font-normal text-coral-300">in minutes</span>
                </h2>
                <p className="mt-4 text-primary-200/70 text-base lg:text-lg max-w-xl mx-auto">
                  Create your free account, find a lab, and send your first case today. No setup fees, no contracts.
                </p>
                <div className="mt-8 flex flex-wrap items-center justify-center gap-3">
                  <CandyButton variant="mint" onClick={() => setShowAuth(true)} className="bg-gradient-to-b from-white to-primary-50 text-primary-800 shadow-[0_3px_0_0_#1B504B,0_6px_16px_rgba(47,122,115,0.3)]">
                    Get Started Free
                    <ArrowRight className="w-4 h-4" />
                  </CandyButton>
                </div>
              </div>
            </div>
          </Reveal>
        </div>
      </section>

      {/* ── Footer ── */}
      <footer className="border-t border-neutral-200/60 mt-20 lg:mt-28">
        <div className="max-w-[1200px] mx-auto px-6 lg:px-8 py-10">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-6">
            <div className="flex items-center gap-2.5">
              <img src="/logo_%20copy%208.png" alt="Bridge" className="w-8 h-8 rounded-lg object-contain" />
              <div>
                <span className="font-display font-bold text-neutral-900">Bridge</span>
                <p className="text-xs text-neutral-400">Lab Ordering Platform</p>
              </div>
            </div>
            <nav className="flex flex-wrap items-center gap-6">
              {FOOTER_LINKS.map(l => (
                <button key={l.target} onClick={() => scrollTo(l.target)}
                  className="no-lift text-sm text-neutral-500 hover:text-neutral-800 transition-colors">
                  {l.label}
                </button>
              ))}
              <button onClick={() => setShowAuth(true)}
                className="no-lift text-sm font-semibold text-neutral-700 hover:text-neutral-900 transition-colors">
                Sign In
              </button>
            </nav>
          </div>
          <div className="mt-8 pt-6 border-t border-neutral-200/60 flex flex-col sm:flex-row items-center justify-between gap-3">
            <p className="text-xs text-neutral-400">&copy; 2026 Bridge 86. All rights reserved.</p>
            <div className="flex items-center gap-4 text-xs text-neutral-400">
              <a href="/privacy-policy" className="hover:text-neutral-600 transition-colors">Privacy Policy</a>
              <a href="/terms-of-service" className="hover:text-neutral-600 transition-colors">Terms of Service</a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
