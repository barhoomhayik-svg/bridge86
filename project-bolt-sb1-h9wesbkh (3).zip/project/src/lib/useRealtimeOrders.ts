import { useEffect, useRef } from 'react';
import { supabase } from './supabase';

/**
 * Subscribes to real-time changes on the orders table for the given user
 * and calls onRefresh whenever an order is inserted, updated, or deleted.
 */
export function useRealtimeOrders(
  userId: string | undefined,
  onRefresh: () => void,
) {
  const onRefreshRef = useRef(onRefresh);
  onRefreshRef.current = onRefresh;

  useEffect(() => {
    if (!userId) return;

    const channel = supabase
      .channel(`orders_realtime:${userId}`)
      .on('postgres_changes', {
        event: 'INSERT',
        schema: 'public',
        table: 'orders',
        filter: `from_id=eq.${userId}`,
      }, () => onRefreshRef.current())
      .on('postgres_changes', {
        event: 'UPDATE',
        schema: 'public',
        table: 'orders',
        filter: `from_id=eq.${userId}`,
      }, () => onRefreshRef.current())
      .on('postgres_changes', {
        event: 'DELETE',
        schema: 'public',
        table: 'orders',
        filter: `from_id=eq.${userId}`,
      }, () => onRefreshRef.current())
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [userId]);
}

/**
 * Subscribes to real-time changes on orders for a center and all its team doctors.
 * Accepts the center's own ID plus an array of doctor IDs; listens for changes
 * from any of those senders.
 */
export function useRealtimeCenterOrders(
  centerId: string | undefined,
  doctorIds: string[],
  onRefresh: () => void,
) {
  const onRefreshRef = useRef(onRefresh);
  onRefreshRef.current = onRefresh;

  useEffect(() => {
    if (!centerId) return;

    const allIds = [centerId, ...doctorIds];
    const channels: ReturnType<typeof supabase.channel>[] = [];

    for (const id of allIds) {
      const channel = supabase
        .channel(`center_orders_rt:${centerId}:${id}`)
        .on('postgres_changes', {
          event: 'INSERT',
          schema: 'public',
          table: 'orders',
          filter: `from_id=eq.${id}`,
        }, () => onRefreshRef.current())
        .on('postgres_changes', {
          event: 'UPDATE',
          schema: 'public',
          table: 'orders',
          filter: `from_id=eq.${id}`,
        }, () => onRefreshRef.current())
        .subscribe();
      channels.push(channel);
    }

    return () => {
      channels.forEach(ch => supabase.removeChannel(ch));
    };
  }, [centerId, doctorIds.join(',')]);
}

/**
 * Subscribes to real-time changes on the orders table for a lab
 * (orders where lab_id = the given labId) and calls onRefresh.
 */
export function useRealtimeLabOrders(
  labId: string | undefined,
  onRefresh: () => void,
) {
  const onRefreshRef = useRef(onRefresh);
  onRefreshRef.current = onRefresh;

  useEffect(() => {
    if (!labId) return;

    const channel = supabase
      .channel(`lab_orders_realtime:${labId}`)
      .on('postgres_changes', {
        event: 'INSERT',
        schema: 'public',
        table: 'orders',
        filter: `lab_id=eq.${labId}`,
      }, () => onRefreshRef.current())
      .on('postgres_changes', {
        event: 'UPDATE',
        schema: 'public',
        table: 'orders',
        filter: `lab_id=eq.${labId}`,
      }, () => onRefreshRef.current())
      .on('postgres_changes', {
        event: 'DELETE',
        schema: 'public',
        table: 'orders',
        filter: `lab_id=eq.${labId}`,
      }, () => onRefreshRef.current())
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [labId]);
}

/**
 * Subscribes to real-time changes on the orders table for a driver
 * (orders where delivered_by = the given driverId) and calls onRefresh.
 */
export function useRealtimeDriverOrders(
  driverId: string | undefined,
  onRefresh: () => void,
) {
  const onRefreshRef = useRef(onRefresh);
  onRefreshRef.current = onRefresh;

  useEffect(() => {
    if (!driverId) return;

    const channel = supabase
      .channel(`driver_orders_realtime:${driverId}`)
      .on('postgres_changes', {
        event: 'INSERT',
        schema: 'public',
        table: 'orders',
        filter: `delivered_by=eq.${driverId}`,
      }, () => onRefreshRef.current())
      .on('postgres_changes', {
        event: 'UPDATE',
        schema: 'public',
        table: 'orders',
        filter: `delivered_by=eq.${driverId}`,
      }, () => onRefreshRef.current())
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [driverId]);
}

/**
 * Subscribes to real-time changes on the quotations table and calls onRefresh.
 */
export function useRealtimeQuotations(
  userId: string | undefined,
  onRefresh: () => void,
) {
  const onRefreshRef = useRef(onRefresh);
  onRefreshRef.current = onRefresh;

  useEffect(() => {
    if (!userId) return;

    const channel = supabase
      .channel(`quotations_realtime:${userId}`)
      .on('postgres_changes', {
        event: 'INSERT',
        schema: 'public',
        table: 'quotations',
        filter: `from_id=eq.${userId}`,
      }, () => onRefreshRef.current())
      .on('postgres_changes', {
        event: 'UPDATE',
        schema: 'public',
        table: 'quotations',
        filter: `from_id=eq.${userId}`,
      }, () => onRefreshRef.current())
      .on('postgres_changes', {
        event: 'INSERT',
        schema: 'public',
        table: 'quotations',
        filter: `lab_id=eq.${userId}`,
      }, () => onRefreshRef.current())
      .on('postgres_changes', {
        event: 'UPDATE',
        schema: 'public',
        table: 'quotations',
        filter: `lab_id=eq.${userId}`,
      }, () => onRefreshRef.current())
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [userId]);
}
