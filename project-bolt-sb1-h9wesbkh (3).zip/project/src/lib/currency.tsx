import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';

export interface CurrencyInfo {
  code: string;
  symbol: string;
  locale: string;
}

const CURRENCIES: Record<string, CurrencyInfo> = {
  SAR: { code: 'SAR', symbol: 'ر.س', locale: 'ar-SA' },
  AED: { code: 'AED', symbol: 'د.إ', locale: 'ar-AE' },
  KWD: { code: 'KWD', symbol: 'د.ك', locale: 'ar-KW' },
  BHD: { code: 'BHD', symbol: 'د.ب', locale: 'ar-BH' },
  OMR: { code: 'OMR', symbol: 'ر.ع', locale: 'ar-OM' },
  QAR: { code: 'QAR', symbol: 'ر.ق', locale: 'ar-QA' },
  EGP: { code: 'EGP', symbol: 'ج.م', locale: 'ar-EG' },
  JOD: { code: 'JOD', symbol: 'د.ا', locale: 'ar-JO' },
  IQD: { code: 'IQD', symbol: 'د.ع', locale: 'ar-IQ' },
  LBP: { code: 'LBP', symbol: 'ل.ل', locale: 'ar-LB' },
  MAD: { code: 'MAD', symbol: 'د.م', locale: 'ar-MA' },
  TND: { code: 'TND', symbol: 'د.ت', locale: 'ar-TN' },
  USD: { code: 'USD', symbol: '$', locale: 'en-US' },
  EUR: { code: 'EUR', symbol: '€', locale: 'en-IE' },
  GBP: { code: 'GBP', symbol: '£', locale: 'en-GB' },
  TRY: { code: 'TRY', symbol: '₺', locale: 'tr-TR' },
  INR: { code: 'INR', symbol: '₹', locale: 'en-IN' },
};

export const CURRENCY_LIST = Object.values(CURRENCIES);

const TZ_TO_CURRENCY: Record<string, string> = {
  'Asia/Riyadh': 'SAR',
  'Asia/Dubai': 'AED',
  'Asia/Kuwait': 'KWD',
  'Asia/Bahrain': 'BHD',
  'Asia/Muscat': 'OMR',
  'Asia/Qatar': 'QAR',
  'Africa/Cairo': 'EGP',
  'Asia/Amman': 'JOD',
  'Asia/Baghdad': 'IQD',
  'Asia/Beirut': 'LBP',
  'Africa/Casablanca': 'MAD',
  'Africa/Tunis': 'TND',
  'America/New_York': 'USD',
  'America/Chicago': 'USD',
  'America/Denver': 'USD',
  'America/Los_Angeles': 'USD',
  'Europe/London': 'GBP',
  'Europe/Istanbul': 'TRY',
  'Asia/Kolkata': 'INR',
  'Asia/Calcutta': 'INR',
};

const LANG_TO_CURRENCY: Record<string, string> = {
  'ar-SA': 'SAR', 'ar-AE': 'AED', 'ar-KW': 'KWD', 'ar-BH': 'BHD',
  'ar-OM': 'OMR', 'ar-QA': 'QAR', 'ar-EG': 'EGP', 'ar-JO': 'JOD',
  'ar-IQ': 'IQD', 'ar-LB': 'LBP', 'ar-MA': 'MAD', 'ar-TN': 'TND',
  'en-US': 'USD', 'en-GB': 'GBP', 'tr-TR': 'TRY', 'hi-IN': 'INR',
  'en-IN': 'INR',
};

const STORAGE_KEY = 'bridge_currency';

function detectCurrency(): string {
  const saved = localStorage.getItem(STORAGE_KEY);
  if (saved && CURRENCIES[saved]) return saved;

  const lang = navigator.language;
  if (LANG_TO_CURRENCY[lang]) return LANG_TO_CURRENCY[lang];

  try {
    const tz = Intl.DateTimeFormat().resolvedOptions().timeZone;
    if (tz && TZ_TO_CURRENCY[tz]) return TZ_TO_CURRENCY[tz];
  } catch { /* ignore */ }

  if (lang.startsWith('ar')) return 'SAR';
  return 'USD';
}

interface CurrencyContextValue {
  currency: CurrencyInfo;
  setCurrencyCode: (code: string) => void;
  formatPrice: (amount: number | null | undefined) => string;
  formatRange: (from: number | null | undefined, to: number | null | undefined) => string;
}

const CurrencyContext = createContext<CurrencyContextValue | null>(null);

export function CurrencyProvider({ children }: { children: React.ReactNode }) {
  const [code, setCode] = useState(() => detectCurrency());
  const currency = CURRENCIES[code] ?? CURRENCIES.USD;

  useEffect(() => {
    // Try IP-based detection only when no saved preference exists
    if (localStorage.getItem(STORAGE_KEY)) return;
    let cancelled = false;
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 4000);
    fetch('https://ipapi.co/json/', { signal: controller.signal })
      .then(r => r.json())
      .then(data => {
        clearTimeout(timer);
        if (cancelled) return;
        const cc = data?.currency;
        if (cc && CURRENCIES[cc] && !localStorage.getItem(STORAGE_KEY)) {
          setCode(cc);
        }
      })
      .catch(() => { /* network fail is fine, we already have a fallback */ });
    return () => { cancelled = true; controller.abort(); clearTimeout(timer); };
  }, []);

  const setCurrencyCode = useCallback((c: string) => {
    if (CURRENCIES[c]) {
      setCode(c);
      localStorage.setItem(STORAGE_KEY, c);
    }
  }, []);

  const formatPrice = useCallback((amount: number | null | undefined): string => {
    if (amount == null) return '';
    try {
      return new Intl.NumberFormat(currency.locale, {
        style: 'currency',
        currency: currency.code,
        minimumFractionDigits: 0,
        maximumFractionDigits: 2,
      }).format(amount);
    } catch {
      return `${currency.symbol} ${amount}`;
    }
  }, [currency]);

  const formatRange = useCallback((from: number | null | undefined, to: number | null | undefined): string => {
    if (from && to) return `${formatPrice(from)} – ${formatPrice(to)}`;
    if (from) return formatPrice(from);
    if (to) return formatPrice(to);
    return '';
  }, [formatPrice]);

  return (
    <CurrencyContext.Provider value={{ currency, setCurrencyCode, formatPrice, formatRange }}>
      {children}
    </CurrencyContext.Provider>
  );
}

export function useCurrency() {
  const ctx = useContext(CurrencyContext);
  if (!ctx) throw new Error('useCurrency must be used within CurrencyProvider');
  return ctx;
}
