// Escapes a value before it is written into a raw HTML string (print/export
// documents). Order fields, profile names and service names are written by other
// accounts, so they must never be interpolated into markup unescaped.
export function escapeHtml(value: unknown): string {
  if (value === null || value === undefined) return '';
  return String(value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}
