import type { Order } from './supabase';

export const DONE_STATUSES = new Set<string>(['completed', 'delivered', 'delivering']);
export const ACTIVE_STATUSES = new Set<string>(['pending', 'accepted', 'in_progress', 'try_in', 'redo']);

export type DateRange = '7d' | '30d' | 'year';
export const DATE_RANGE_LABELS: Record<DateRange, string> = {
  '7d': 'Last 7 Days',
  '30d': 'Last 30 Days',
  'year': 'This Year',
};

export const DONUT_COLORS = ['#0ea5e9', '#22c55e', '#f59e0b', '#ef4444', '#8b5cf6', '#94a3b8'];

export function rangeStart(range: DateRange): Date {
  const now = new Date();
  if (range === '7d') return new Date(now.getTime() - 7 * 86400000);
  if (range === '30d') return new Date(now.getTime() - 30 * 86400000);
  return new Date(now.getFullYear(), 0, 1);
}

export function prevRangeStart(range: DateRange): Date {
  const now = new Date();
  if (range === '7d') return new Date(now.getTime() - 14 * 86400000);
  if (range === '30d') return new Date(now.getTime() - 60 * 86400000);
  return new Date(now.getFullYear() - 1, 0, 1);
}

export function prevRangeEnd(range: DateRange): Date {
  return rangeStart(range);
}

export function growthPct(curr: number, prev: number): number | null {
  if (prev === 0 && curr === 0) return null;
  if (prev === 0) return 100;
  return Math.round(((curr - prev) / prev) * 100);
}

export function buildTimeSeriesData(orders: Order[], range: DateRange) {
  const start = rangeStart(range);
  const now = new Date();
  const completedOrders = orders.filter(o => DONE_STATUSES.has(o.status) && new Date(o.created_at) >= start);

  if (range === 'year') {
    const months: Record<string, number> = {};
    for (let m = 0; m <= now.getMonth(); m++) {
      const key = new Date(now.getFullYear(), m, 1).toLocaleDateString('en', { month: 'short' });
      months[key] = 0;
    }
    completedOrders.forEach(o => {
      const d = new Date(o.created_at);
      const key = d.toLocaleDateString('en', { month: 'short' });
      if (key in months) months[key]++;
    });
    return Object.entries(months).map(([name, cases]) => ({ name, cases }));
  }

  const days = range === '7d' ? 7 : 30;
  const data: { name: string; cases: number }[] = [];
  for (let i = days - 1; i >= 0; i--) {
    const d = new Date(now.getTime() - i * 86400000);
    const label = d.toLocaleDateString('en', { month: 'short', day: 'numeric' });
    const dayStr = d.toISOString().slice(0, 10);
    const count = completedOrders.filter(o => o.created_at.slice(0, 10) === dayStr).length;
    data.push({ name: label, cases: count });
  }
  return data;
}

export function buildEntityDonutData(orders: Order[], entityKey: 'from_id' | 'lab_id') {
  const now = Date.now();
  const byEntity = new Map<string, Order[]>();
  orders.forEach(o => {
    const id = (o as any)[entityKey];
    if (!id) return;
    const arr = byEntity.get(id) ?? [];
    arr.push(o);
    byEntity.set(id, arr);
  });

  let active = 0, recent = 0, inactive = 0;
  byEntity.forEach(entityOrders => {
    const latest = Math.max(...entityOrders.map(o => new Date(o.created_at).getTime()));
    const earliest = Math.min(...entityOrders.map(o => new Date(o.created_at).getTime()));
    const daysSinceLatest = (now - latest) / 86400000;
    const daysSinceFirst = (now - earliest) / 86400000;
    if (daysSinceLatest <= 30) {
      if (daysSinceFirst <= 14) recent++;
      else active++;
    } else {
      inactive++;
    }
  });
  return [
    { name: 'Active', value: active },
    { name: 'New', value: recent },
    { name: 'Inactive', value: inactive },
  ].filter(d => d.value > 0);
}

export function buildTopEntitiesData(
  orders: Order[],
  entityKey: 'from_id' | 'lab_id',
  profileKey: 'from_profile' | 'lab_profile',
  limit = 5,
) {
  const map = new Map<string, { name: string; count: number; id: string }>();
  orders.filter(o => DONE_STATUSES.has(o.status)).forEach(o => {
    const id = (o as any)[entityKey];
    const profile = (o as any)[profileKey];
    if (!id) return;
    const entry = map.get(id) ?? { name: profile?.name ?? 'Unknown', count: 0, id };
    entry.count++;
    map.set(id, entry);
  });
  return [...map.values()].sort((a, b) => b.count - a.count).slice(0, limit);
}
