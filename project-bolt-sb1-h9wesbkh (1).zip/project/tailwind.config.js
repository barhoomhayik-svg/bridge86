/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      screens: {
        'xs': '375px',
      },
      colors: {
        // Primary — calming teal (relaxed, professional, easy on the eyes)
        primary: {
          50:  '#f0fdfa',
          100: '#ccfbf1',
          200: '#99f6e4',
          300: '#5eead4',
          400: '#2dd4bf',
          500: '#14b8a6',
          600: '#0d9488',
          700: '#0f766e',
          800: '#115e59',
          900: '#134e4a',
          950: '#042f2e',
        },
        // Secondary — soft sage green (complementary, serene)
        sage: {
          50:  '#f4f7f5',
          100: '#e8efea',
          200: '#cfe0d6',
          300: '#aecbb8',
          400: '#88b094',
          500: '#6b9579',
          600: '#547a61',
          700: '#42614d',
          800: '#374e3f',
          900: '#2d3f33',
          950: '#1a2620',
        },
        // Accent — warm sand (adds warmth without harshness)
        sand: {
          50:  '#fbf8f3',
          100: '#f5efe2',
          200: '#ebe0c7',
          300: '#ddca9e',
          400: '#ccae6f',
          500: '#bf9a52',
          600: '#a87f42',
          700: '#8a6539',
          800: '#715233',
          900: '#5e4530',
          950: '#34251b',
        },
        // Warm neutrals — stone tones instead of cold gray
        neutral: {
          50:  '#faf9f7',
          100: '#f4f2ee',
          200: '#e8e4dc',
          300: '#d6d0c4',
          400: '#a8a094',
          500: '#837b6e',
          600: '#6b6358',
          700: '#564f46',
          800: '#3f3a33',
          900: '#2a2622',
          950: '#1a1714',
        },
      },
      fontFamily: {
        sans: ['Inter', '-apple-system', 'BlinkMacSystemFont', 'system-ui', 'sans-serif'],
      },
      fontSize: {
        // Fluid typography via clamp() — scales smoothly from mobile to desktop
        'fluid-xs':  ['clamp(0.6875rem, 0.66rem + 0.13vw, 0.75rem)',   { lineHeight: '1.5' }],
        'fluid-sm':  ['clamp(0.8125rem, 0.78rem + 0.18vw, 0.875rem)',  { lineHeight: '1.5' }],
        'fluid-base':['clamp(0.9375rem, 0.9rem + 0.22vw, 1rem)',       { lineHeight: '1.6' }],
        'fluid-lg':  ['clamp(1.0625rem, 1.02rem + 0.25vw, 1.125rem)',  { lineHeight: '1.5' }],
        'fluid-xl':  ['clamp(1.1875rem, 1.12rem + 0.38vw, 1.375rem)',  { lineHeight: '1.4' }],
        'fluid-2xl': ['clamp(1.375rem, 1.28rem + 0.5vw, 1.75rem)',     { lineHeight: '1.3' }],
        'fluid-3xl': ['clamp(1.75rem, 1.6rem + 0.75vw, 2.25rem)',      { lineHeight: '1.2' }],
        'fluid-4xl': ['clamp(2.125rem, 1.9rem + 1.13vw, 3rem)',        { lineHeight: '1.1' }],
      },
      boxShadow: {
        'card': '0 1px 3px 0 rgba(42, 38, 34, 0.06), 0 1px 2px -1px rgba(42, 38, 34, 0.05)',
        'card-hover': '0 4px 16px 0 rgba(42, 38, 34, 0.10), 0 2px 4px -1px rgba(42, 38, 34, 0.06)',
        'modal': '0 20px 60px -10px rgba(42, 38, 34, 0.22)',
      },
      keyframes: {
        'rise-in': {
          '0%': { opacity: '0', transform: 'translateY(8px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
        'tooth-pop': {
          '0%':   { transform: 'scale(1)' },
          '40%':  { transform: 'scale(1.18)' },
          '70%':  { transform: 'scale(0.94)' },
          '100%': { transform: 'scale(1)' },
        },
        'tooth-bounce': {
          '0%, 100%': { transform: 'translateY(0) rotate(-4deg)' },
          '50%':      { transform: 'translateY(-3px) rotate(4deg)' },
        },
        'tooth-shine': {
          '0%':   { opacity: '0.35', transform: 'scale(0.8)' },
          '50%':  { opacity: '1',    transform: 'scale(1.15)' },
          '100%': { opacity: '0.35', transform: 'scale(0.8)' },
        },
        'float-slow': {
          '0%, 100%': { transform: 'translateY(0)' },
          '50%':      { transform: 'translateY(-14px)' },
        },
        'glass-shine': {
          '0%':   { transform: 'translateX(-40%)' },
          '100%': { transform: 'translateX(40%)' },
        },
      },
      animation: {
        'rise-in': 'rise-in 260ms cubic-bezier(0.16, 1, 0.3, 1) both',
        'tooth-pop': 'tooth-pop 380ms cubic-bezier(0.34, 1.56, 0.64, 1)',
        'tooth-bounce': 'tooth-bounce 2.4s ease-in-out infinite',
        'tooth-shine': 'tooth-shine 2s ease-in-out infinite',
        'float-slow': 'float-slow 7s ease-in-out infinite',
        'glass-shine': 'glass-shine 5s ease-in-out infinite',
      },
      spacing: {
        'safe-top': 'env(safe-area-inset-top)',
        'safe-bottom': 'env(safe-area-inset-bottom)',
        'safe-left': 'env(safe-area-inset-left)',
        'safe-right': 'env(safe-area-inset-right)',
      },
    },
  },
  plugins: [],
};
