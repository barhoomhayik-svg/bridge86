import React, { createContext, useContext, useEffect, useState } from 'react';
import { Session, User } from '@supabase/supabase-js';
import { supabase, Profile } from '../lib/supabase';

interface AuthContextValue {
  session: Session | null;
  user: User | null;
  profile: Profile | null;
  loading: boolean;
  signOut: () => Promise<void>;
  refreshProfile: () => Promise<void>;
}

const AuthContext = createContext<AuthContextValue | null>(null);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [session, setSession] = useState<Session | null>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [loading, setLoading] = useState(true);

  const fetchProfile = async (userId: string) => {
    const { data } = await supabase
      .from('profiles')
      .select('*')
      .eq('id', userId)
      .maybeSingle();
    setProfile(data);
  };

  const refreshProfile = async () => {
    if (session?.user?.id) await fetchProfile(session.user.id);
  };

  useEffect(() => {
    // Handle email confirmation redirect (PKCE flow)
    if (window.location.search.includes('code=')) {
      supabase.auth.exchangeCodeForSession(window.location.href).then(() => {
        window.history.replaceState({}, document.title, window.location.pathname);
      });
    }

    supabase.auth.getSession().then(async ({ data: { session } }) => {
      if (session && !session.user.email_confirmed_at) {
        await supabase.auth.signOut();
        setSession(null);
        setProfile(null);
        setLoading(false);
        return;
      }
      setSession(session);
      if (session?.user?.id) {
        fetchProfile(session.user.id).finally(() => setLoading(false));
      } else {
        setLoading(false);
      }
    });

    const { data: { subscription } } = supabase.auth.onAuthStateChange((event, session) => {
      (async () => {
        // Block access until the email has been verified via the confirmation link.
        if (session && !session.user.email_confirmed_at) {
          await supabase.auth.signOut();
          setSession(null);
          setProfile(null);
          setLoading(false);
          return;
        }
        setSession(session);
        if (event === 'USER_UPDATED' || event === 'SIGNED_IN') {
          if (session?.user?.id) {
            // Apply pending OAuth role if this is a fresh sign-in
            const pendingRole = localStorage.getItem('pending_oauth_role');
            if (pendingRole && (pendingRole === 'center' || pendingRole === 'doctor' || pendingRole === 'lab')) {
              localStorage.removeItem('pending_oauth_role');
              try { await supabase.rpc('assign_initial_role', { desired_role: pendingRole }); } catch (_) {}
            }
            await fetchProfile(session.user.id);
          } else {
            setProfile(null);
          }
        } else if (event === 'SIGNED_OUT') {
          setProfile(null);
        }
        setLoading(false);
      })();
    });

    return () => subscription.unsubscribe();
  }, []);

  const signOut = async () => {
    await supabase.auth.signOut();
    setProfile(null);
  };

  return (
    <AuthContext.Provider value={{ session, user: session?.user ?? null, profile, loading, signOut, refreshProfile }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used inside AuthProvider');
  return ctx;
}
