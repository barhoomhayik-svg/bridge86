import React, { useEffect, useState, useCallback } from 'react';
import { supabase, Profile, Service, CasePhoto } from '../lib/supabase';
import { MapPin, Clock, ChevronRight, Search, Phone, Building2, Microscope, FlaskConical, Heart, Navigation, ShoppingBag, FileText, Camera, Sparkles } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';

function haversineKm(lat1: number, lng1: number, lat2: number, lng2: number): number {
  const R = 6371;
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLng = (lng2 - lng1) * Math.PI / 180;
  const a = Math.sin(dLat / 2) ** 2 + Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) * Math.sin(dLng / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

function StarDisplay({ avg, count, size = 'sm' }: { avg: number | null; count: number; size?: 'sm' | 'lg' }) {
  if (avg === null) return null;
  const filled = Math.round(avg);
  return (
    <span className={`inline-flex items-center gap-1 ${size === 'lg' ? 'text-sm' : 'text-xs'}`}>
      <span className="flex">
        {[1,2,3,4,5].map(i => (
          <svg key={i} className={`${size === 'lg' ? 'w-4 h-4' : 'w-3 h-3'} ${i <= filled ? 'text-amber-400' : 'text-neutral-200'}`} fill="currentColor" viewBox="0 0 24 24">
            <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/>
          </svg>
        ))}
      </span>
      <span className={`font-semibold text-neutral-700`}>{avg.toFixed(1)}</span>
      {count > 0 && <span className="text-neutral-400">({count})</span>}
    </span>
  );
}

function formatDistance(km: number): string {
  if (km < 1) return `${Math.round(km * 1000)} m`;
  if (km < 10) return `${km.toFixed(1)} km`;
  return `${Math.round(km)} km`;
}

function getDistance(userLat: number | null, userLng: number | null, lab: { latitude: number | null; longitude: number | null }): number | null {
  if (userLat == null || userLng == null || lab.latitude == null || lab.longitude == null) return null;
  return haversineKm(userLat, userLng, lab.latitude, lab.longitude);
}

interface LabWithDetails extends Profile {
  services: Service[];
  case_photos: CasePhoto[];
  serviceCount: number;
  photoCount: number;
  ratingAvg: number | null;
  ratingCount: number;
}

interface Props {
  onSelectLab: (lab: Profile) => void;
  onRequestQuotation: (lab: Profile) => void;
}

export default function LabDiscovery({ onSelectLab, onRequestQuotation }: Props) {
  const { profile } = useAuth();
  const [labs, setLabs] = useState<LabWithDetails[]>([]);
  const [favouriteIds, setFavouriteIds] = useState<Set<string>>(new Set());
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [showFavourites, setShowFavourites] = useState(false);
  const [selectedLab, setSelectedLab] = useState<LabWithDetails | null>(null);

  const fetchFavourites = useCallback(async () => {
    if (!profile) return;
    const { data } = await supabase
      .from('favourite_labs')
      .select('lab_id')
      .eq('user_id', profile.id);
    setFavouriteIds(new Set((data ?? []).map(f => f.lab_id)));
  }, [profile]);

  const fetchLabs = useCallback(async () => {
    setLoading(true);
    const { data: profiles } = await supabase.from('profiles').select('*').eq('role', 'lab');
    if (!profiles) { setLoading(false); return; }
    const labsWithDetails = await Promise.all(
      profiles.map(async (lab) => {
        const [{ data: services }, { data: photos }] = await Promise.all([
          supabase.from('services').select('*').eq('lab_id', lab.id),
          supabase.from('case_photos').select('*').eq('lab_id', lab.id).limit(6),
        ]);
        const { data: reviews } = await supabase.from('lab_reviews').select('rating').eq('lab_id', lab.id);
        const ratings = (reviews ?? []).map((r: { rating: number }) => r.rating);
        const ratingAvg = ratings.length > 0 ? ratings.reduce((a: number, b: number) => a + b, 0) / ratings.length : null;
        return { ...lab, services: services ?? [], case_photos: photos ?? [], serviceCount: services?.length ?? 0, photoCount: photos?.length ?? 0, ratingAvg, ratingCount: ratings.length };
      })
    );
    setLabs(labsWithDetails);
    setLoading(false);
  }, []);

  useEffect(() => { fetchLabs(); fetchFavourites(); }, [fetchLabs, fetchFavourites]);

  const toggleFavourite = async (e: React.MouseEvent, labId: string) => {
    e.stopPropagation();
    if (!profile) return;
    if (favouriteIds.has(labId)) {
      await supabase.from('favourite_labs').delete().eq('user_id', profile.id).eq('lab_id', labId);
      setFavouriteIds(prev => { const s = new Set(prev); s.delete(labId); return s; });
    } else {
      await supabase.from('favourite_labs').insert({ user_id: profile.id, lab_id: labId });
      setFavouriteIds(prev => new Set([...prev, labId]));
    }
  };

  const userLat = profile?.latitude ?? null;
  const userLng = profile?.longitude ?? null;
  const hasCoords = userLat != null && userLng != null;

  let filtered = labs.filter(l =>
    l.name.toLowerCase().includes(search.toLowerCase()) ||
    (l.city ?? '').toLowerCase().includes(search.toLowerCase())
  );

  if (showFavourites) filtered = filtered.filter(l => favouriteIds.has(l.id));

  filtered = [...filtered].sort((a, b) => {
    if (hasCoords) {
      const da = getDistance(userLat, userLng, a) ?? Infinity;
      const db = getDistance(userLat, userLng, b) ?? Infinity;
      if (da !== db) return da - db;
    }
    const aFav = favouriteIds.has(a.id) ? 0 : 1;
    const bFav = favouriteIds.has(b.id) ? 0 : 1;
    return aFav - bFav;
  });

  if (selectedLab) {
    return (
      <LabDetail
        lab={selectedLab}
        isFavourite={favouriteIds.has(selectedLab.id)}
        onToggleFavourite={(e) => toggleFavourite(e, selectedLab.id)}
        onBack={() => setSelectedLab(null)}
        onOrder={() => onSelectLab(selectedLab)}
        onQuotation={() => onRequestQuotation(selectedLab)}
        canOrder={profile?.role !== 'center'}
        userLat={userLat}
        userLng={userLng}
      />
    );
  }

  return (
    <div className="p-6 max-w-5xl mx-auto">
      <div className="mb-5">
        <h1 className="text-2xl font-bold text-neutral-900">Find Dental Labs</h1>
        <p className="text-neutral-500 text-sm mt-1">Discover labs near you and place orders</p>
      </div>

      <div className="flex items-center gap-3 mb-5">
        <div className="relative flex-1">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-neutral-400" />
          <input
            type="text" placeholder="Search by lab name or city..."
            value={search} onChange={e => setSearch(e.target.value)}
            className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-neutral-200 bg-white text-sm focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-transparent shadow-card"
          />
        </div>
        <button
          onClick={() => setShowFavourites(!showFavourites)}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-semibold border transition-all ${
            showFavourites ? 'bg-red-50 border-red-200 text-red-600' : 'bg-white border-neutral-200 text-neutral-600 hover:border-neutral-300'
          }`}
        >
          <Heart className={`w-4 h-4 ${showFavourites ? 'fill-red-500 text-red-500' : ''}`} />
          Favourites {favouriteIds.size > 0 && <span className="bg-red-100 text-red-600 text-xs font-bold px-1.5 py-0.5 rounded-full">{favouriteIds.size}</span>}
        </button>
      </div>

      {loading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {[1,2,3].map(i => <div key={i} className="bg-white rounded-2xl p-5 shadow-card animate-pulse h-36" />)}
        </div>
      ) : filtered.length === 0 ? (
        <div className="text-center py-16">
          <FlaskConical className="w-12 h-12 text-neutral-300 mx-auto mb-3" />
          <p className="text-neutral-500 font-medium">{showFavourites ? 'No favourite labs yet' : 'No labs found'}</p>
          <p className="text-neutral-400 text-sm">{showFavourites ? 'Click the heart on any lab to save it' : 'Try adjusting your search'}</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filtered.map((lab, i) => {
            const isFav = favouriteIds.has(lab.id);
            return (
              <button
                key={lab.id}
                onClick={() => setSelectedLab(lab)}
                style={{ animationDelay: `${i * 40}ms` }}
                className="bg-white rounded-2xl p-5 shadow-card hover:shadow-card-hover transition-all text-left group border border-transparent hover:border-primary-100 relative animate-rise-in hover:-translate-y-0.5 active:scale-[0.99]"
              >
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center gap-2.5">
                    {lab.logo_url ? (
                      <img src={lab.logo_url} alt={lab.name} className="w-11 h-11 rounded-xl object-cover" />
                    ) : (
                      <div className="w-11 h-11 bg-primary-50 rounded-xl flex items-center justify-center">
                        <Microscope className="w-5 h-5 text-primary-600" />
                      </div>
                    )}
                  </div>
                  <div className="flex items-center gap-1">
                    <button
                      onClick={(e) => toggleFavourite(e, lab.id)}
                      className={`p-1.5 rounded-lg transition-all ${isFav ? 'text-red-500' : 'text-neutral-300 hover:text-red-400'}`}
                    >
                      <Heart className={`w-4 h-4 ${isFav ? 'fill-red-500' : ''}`} />
                    </button>
                    <ChevronRight className="w-4 h-4 text-neutral-300 group-hover:text-primary-500 transition-colors" />
                  </div>
                </div>
                <h3 className="font-semibold text-neutral-900 mb-1">{lab.name}</h3>
                {lab.city && (
                  <div className="flex items-center gap-1 text-neutral-500 text-xs mb-3">
                    <MapPin className="w-3 h-3" /> {lab.city}
                    {getDistance(userLat, userLng, lab) != null && (
                      <span className="ml-1 inline-flex items-center gap-0.5 text-primary-600 font-semibold">
                        <Navigation className="w-3 h-3" /> {formatDistance(getDistance(userLat, userLng, lab)!)}
                      </span>
                    )}
                  </div>
                )}
                <div className="flex items-center gap-3 text-xs text-neutral-500">
                  {lab.ratingAvg !== null
                    ? <StarDisplay avg={lab.ratingAvg} count={lab.ratingCount} />
                    : <span className="text-neutral-300 flex items-center gap-1"><svg className="w-3 h-3" fill="currentColor" viewBox="0 0 24 24"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg> No reviews yet</span>
                  }
                  <span className="flex items-center gap-1">
                    <Building2 className="w-3 h-3" />{lab.serviceCount} service{lab.serviceCount !== 1 ? 's' : ''}
                  </span>
                </div>
                {lab.services.slice(0, 2).map(s => (
                  <span key={s.id} className="inline-block mt-2 mr-1.5 px-2 py-0.5 bg-teal-50 text-teal-700 text-xs rounded-full">{s.name}</span>
                ))}
              </button>
            );
          })}
        </div>
      )}
    </div>
  );
}

function LabDetail({ lab, isFavourite, onToggleFavourite, onBack, onOrder, onQuotation, userLat, userLng, canOrder }: {
  lab: LabWithDetails; isFavourite: boolean;
  onToggleFavourite: (e: React.MouseEvent) => void;
  onBack: () => void; onOrder: () => void; onQuotation: () => void;
  userLat: number | null; userLng: number | null; canOrder: boolean;
}) {
  return (
    <div className="p-6 max-w-3xl mx-auto">
      <button onClick={onBack} className="flex items-center gap-1.5 text-sm text-neutral-500 hover:text-neutral-700 mb-5 transition-colors">
        <ChevronRight className="w-4 h-4 rotate-180" /> Back to labs
      </button>
      <div className="bg-white rounded-3xl shadow-card overflow-hidden mb-5 animate-rise-in border border-neutral-100">
        <div className="relative h-32 bg-gradient-to-br from-primary-600 via-primary-500 to-teal-500 overflow-hidden">
          {lab.cover_url ? (
            <>
              <img src={lab.cover_url} alt={`${lab.name} cover`} className="absolute inset-0 w-full h-full object-cover" />
              <div className="absolute inset-0 bg-gradient-to-t from-black/25 via-transparent to-transparent" />
            </>
          ) : (
            <div className="absolute inset-0 opacity-20" style={{ backgroundImage: 'radial-gradient(circle at 20% 30%, white 0%, transparent 40%), radial-gradient(circle at 80% 70%, white 0%, transparent 40%)' }} />
          )}
          <button onClick={onToggleFavourite}
            className={`absolute top-4 right-4 p-2.5 rounded-full backdrop-blur-md transition-all shadow-sm ${isFavourite ? 'bg-white/95 text-red-500' : 'bg-white/25 text-white hover:bg-white/40'}`}
            aria-label={isFavourite ? 'Remove favourite' : 'Add favourite'}
          >
            <Heart className={`w-5 h-5 ${isFavourite ? 'fill-red-500' : ''}`} />
          </button>
        </div>

        <div className="px-6 pb-6 -mt-10">
          <div className="flex items-end justify-between gap-4 flex-wrap">
            {lab.logo_url ? (
              <img src={lab.logo_url} alt={lab.name} className="relative z-10 w-20 h-20 rounded-2xl object-cover ring-4 ring-white shadow-lg" />
            ) : (
              <div className="relative z-10 w-20 h-20 bg-gradient-to-br from-primary-50 to-teal-50 rounded-2xl flex items-center justify-center ring-4 ring-white shadow-lg">
                <Microscope className="w-10 h-10 text-primary-600" />
              </div>
            )}
          </div>

          <div className="mt-4">
            <div className="flex items-center gap-2 flex-wrap">
              <h2 className="text-2xl font-bold text-neutral-900 tracking-tight">{lab.name}</h2>
              {lab.ratingAvg !== null && lab.ratingAvg >= 4.5 && (
                <span className="inline-flex items-center gap-1 text-[11px] font-semibold px-2 py-0.5 rounded-full bg-amber-50 text-amber-700 border border-amber-200">
                  <Sparkles className="w-3 h-3" /> Top rated
                </span>
              )}
            </div>
            {lab.city && (
              <p className="text-sm text-neutral-500 flex items-center gap-1.5 mt-1">
                <MapPin className="w-3.5 h-3.5" />{lab.city}
                {getDistance(userLat, userLng, lab) != null && (
                  <span className="ml-1 inline-flex items-center gap-0.5 text-primary-600 font-semibold">
                    <Navigation className="w-3.5 h-3.5" />{formatDistance(getDistance(userLat, userLng, lab)!)}
                  </span>
                )}
              </p>
            )}
            {lab.address && <p className="text-xs text-neutral-400 mt-1">{lab.address}</p>}
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 mt-5">
            <div className="rounded-2xl bg-neutral-50 border border-neutral-100 px-3 py-2.5">
              <div className="flex items-center gap-1.5 text-neutral-500 text-[11px] uppercase tracking-wide font-semibold"><Building2 className="w-3 h-3" />Services</div>
              <div className="text-lg font-bold text-neutral-900 mt-0.5">{lab.services.length}</div>
            </div>
            <div className="rounded-2xl bg-neutral-50 border border-neutral-100 px-3 py-2.5">
              <div className="flex items-center gap-1.5 text-neutral-500 text-[11px] uppercase tracking-wide font-semibold"><Camera className="w-3 h-3" />Cases</div>
              <div className="text-lg font-bold text-neutral-900 mt-0.5">{lab.case_photos.length}</div>
            </div>
            <div className="rounded-2xl bg-neutral-50 border border-neutral-100 px-3 py-2.5">
              <div className="flex items-center gap-1.5 text-neutral-500 text-[11px] uppercase tracking-wide font-semibold">Rating</div>
              <div className="text-lg font-bold text-neutral-900 mt-0.5 flex items-baseline gap-1">
                {lab.ratingAvg !== null ? (
                  <>
                    {lab.ratingAvg.toFixed(1)}
                    <span className="text-[11px] font-normal text-neutral-400">/ 5</span>
                  </>
                ) : (
                  <span className="text-sm font-normal text-neutral-400">—</span>
                )}
              </div>
            </div>
            <div className="rounded-2xl bg-neutral-50 border border-neutral-100 px-3 py-2.5">
              <div className="flex items-center gap-1.5 text-neutral-500 text-[11px] uppercase tracking-wide font-semibold"><Navigation className="w-3 h-3" />Distance</div>
              <div className="text-lg font-bold text-neutral-900 mt-0.5">
                {getDistance(userLat, userLng, lab) != null ? formatDistance(getDistance(userLat, userLng, lab)!) : <span className="text-sm font-normal text-neutral-400">—</span>}
              </div>
            </div>
          </div>

          {lab.phone && (
            <a href={`tel:${lab.phone}`} className="flex items-center gap-2 mt-4 text-sm text-neutral-600 hover:text-primary-600 transition-colors w-fit">
              <Phone className="w-4 h-4 text-neutral-400" />{lab.phone}
            </a>
          )}

          {lab.latitude && lab.longitude && (
            <div className="mt-4 rounded-2xl overflow-hidden border border-neutral-200 h-44">
              <iframe
                src={`https://www.openstreetmap.org/export/embed.html?bbox=${lab.longitude-0.01},${lab.latitude-0.01},${lab.longitude+0.01},${lab.latitude+0.01}&layer=mapnik&marker=${lab.latitude},${lab.longitude}`}
                className="w-full h-full border-0"
                title="Lab location"
                loading="lazy"
              />
            </div>
          )}

          <div className={`grid ${canOrder ? 'grid-cols-2' : 'grid-cols-1'} gap-2 mt-5`}>
            <button
              onClick={onQuotation}
              className="flex items-center justify-center gap-2 px-4 py-3 bg-teal-50 hover:bg-teal-100 active:scale-[0.98] text-teal-700 border border-teal-200 text-sm font-semibold rounded-2xl transition-all"
            >
              <FileText className="w-4 h-4" /> Request Quotation
            </button>
            {canOrder && (
              <button onClick={onOrder} className="flex items-center justify-center gap-2 px-4 py-3 bg-primary-600 hover:bg-primary-700 active:scale-[0.98] text-white text-sm font-semibold rounded-2xl transition-all shadow-sm hover:shadow-md">
                <ShoppingBag className="w-4 h-4" /> Place Order
              </button>
            )}
          </div>
        </div>
      </div>

      {lab.services.length > 0 && (
        <div className="mb-4">
          <h3 className="text-sm font-semibold text-neutral-700 uppercase tracking-wide mb-3">Services</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {lab.services.map(s => (
              <div key={s.id} className="bg-white rounded-xl p-4 shadow-card">
                <div className="flex items-start justify-between">
                  <div>
                    <p className="font-semibold text-neutral-900 text-sm">{s.name}</p>
                    {s.description && <p className="text-xs text-neutral-500 mt-0.5">{s.description}</p>}
                  </div>
                  {s.turnaround_days && (
                    <span className="flex items-center gap-1 text-xs text-teal-600 bg-teal-50 px-2 py-0.5 rounded-full ml-2 whitespace-nowrap">
                      <Clock className="w-3 h-3" />{s.turnaround_days}d
                    </span>
                  )}
                </div>
                {(s.price_from || s.price_to) && (
                  <p className="text-xs font-semibold text-primary-600 mt-2">
                    {s.price_from && s.price_to ? `$${s.price_from} – $${s.price_to}` : s.price_from ? `From $${s.price_from}` : `Up to $${s.price_to}`}
                  </p>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {lab.case_photos.length > 0 && (
        <div>
          <h3 className="text-sm font-semibold text-neutral-700 uppercase tracking-wide mb-3">Case Gallery</h3>
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
            {lab.case_photos.map(photo => (
              <div key={photo.id} className="aspect-square rounded-xl overflow-hidden bg-neutral-100">
                <img src={photo.photo_url} alt={photo.title} className="w-full h-full object-cover hover:scale-105 transition-transform" />
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
