import React, { useState } from 'react';
import AuthPage from './AuthPage';
import BridgeLogo from '../components/BridgeLogo';
import {
  Stethoscope, FlaskConical, Building2, Truck, ClipboardList,
  MessageSquare, Package, CheckCircle2, ArrowRight, Menu, X,
  Shield, Zap, Clock, Sparkles,
} from 'lucide-react';

const HERO_IMG = 'https://images.pexels.com/photos/6627592/pexels-photo-6627592.jpeg?auto=compress&cs=tinysrgb&w=1280&h=640';
const SPLIT_IMG = 'https://images.pexels.com/photos/7788493/pexels-photo-7788493.jpeg?auto=compress&cs=tinysrgb&w=900&h=900';
const CARD_1 = 'https://images.pexels.com/photos/305567/pexels-photo-305567.jpeg?auto=compress&cs=tinysrgb&w=600&h=450';
const CARD_2 = 'https://images.pexels.com/photos/7788506/pexels-photo-7788506.jpeg?auto=compress&cs=tinysrgb&w=600&h=450';
const CARD_3 = 'https://images.pexels.com/photos/6812483/pexels-photo-6812483.jpeg?auto=compress&cs=tinysrgb&w=600&h=450';
const FEAT_1 = 'https://images.pexels.com/photos/12712256/pexels-photo-12712256.jpeg?auto=compress&cs=tinysrgb&w=500&h=500';
const FEAT_2 = 'https://images.pexels.com/photos/12551732/pexels-photo-12551732.jpeg?auto=compress&cs=tinysrgb&w=500&h=500';
const FEAT_3 = 'https://images.pexels.com/photos/33800637/pexels-photo-33800637.jpeg?auto=compress&cs=tinysrgb&w=500&h=600';

const NAV_LINKS = [
  { label: 'Features', target: 'features' },
  { label: 'How it works', target: 'how-it-works' },
  { label: 'Testimonials', target: 'testimonials' },
];

const FEATURE_CARDS = [
  {
    icon: ClipboardList,
    title: 'Digital Case Orders',
    desc: 'Send cases to any lab in seconds. Select teeth on an interactive chart, add services, shades, and attachments — all from your phone.',
    img: CARD_1,
  },
  {
    icon: MessageSquare,
    title: 'Real-time Comments',
    desc: 'Chat directly on each case. Lab technicians and doctors stay aligned without phone calls, emails, or lost messages.',
    img: CARD_2,
  },
  {
    icon: Truck,
    title: 'Driver Delivery Tracking',
    desc: 'Assign pickups and deliveries to drivers. Track every case from the clinic to the lab and back with live status updates.',
    img: CARD_3,
  },
];

const HOW_STEPS = [
  { icon: Stethoscope, title: 'Doctor sends the case', desc: 'Pick a lab, select teeth, choose services, and submit the order in under a minute.' },
  { icon: FlaskConical, title: 'Lab receives & produces', desc: 'The lab sees the case instantly, confirms the shade, and starts production with all the details.' },
  { icon: Truck, title: 'Driver delivers', desc: 'A driver picks up the finished work and delivers it back to the clinic — tracked end to end.' },
  { icon: CheckCircle2, title: 'Case complete', desc: 'The doctor confirms delivery. Everything is archived for future reference and redos.' },
];

const STATS = [
  { value: '4 roles', label: 'Doctors, centers, labs & drivers' },
  { value: '< 60s', label: 'To place a full case' },
  { value: '100%', label: 'Digital, no paperwork' },
];

const TESTIMONIALS = [
  {
    quote: 'Bridge replaced our WhatsApp orders and printed tickets. Cases arrive complete every time — no more missing shades or tooth numbers.',
    name: 'Dr. Sarah Mansour',
    role: 'Prosthodontist, Smile Center',
  },
  {
    quote: 'As a lab, we used to chase doctors for case details. Now everything arrives structured and clear. Production is faster and errors dropped to near zero.',
    name: 'Karim Haddad',
    role: 'Owner, Precision Dental Lab',
  },
  {
    quote: 'Our drivers know exactly where to go and what to pick up. The tracking gives our centers confidence that the case is on its way.',
    name: 'Lina Okafor',
    role: 'Operations, City Dental Group',
  },
];

const FOOTER_LINKS = [
  { label: 'Features', target: 'features' },
  { label: 'How it works', target: 'how-it-works' },
  { label: 'Testimonials', target: 'testimonials' },
];

export default function LandingPage() {
  const [showAuth, setShowAuth] = useState(false);
  const [mobileMenu, setMobileMenu] = useState(false);

  const scrollTo = (id: string) => {
    document.getElementById(id)?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    setMobileMenu(false);
  };

  if (showAuth) return <AuthPage onBack={() => setShowAuth(false)} />;

  return (
    <div className="min-h-dvh bg-white">
      {/* ── Header ── */}
      <header className="sticky top-0 z-40 bg-white/85 backdrop-blur-lg border-b border-neutral-100 transform-gpu">
        <div className="max-w-[1280px] mx-auto px-6 lg:px-0 h-16 flex items-center justify-between">
          <a href="#" onClick={(e) => { e.preventDefault(); window.scrollTo({ top: 0, behavior: 'smooth' }); }} className="flex items-center">
            <img
              src="/logo_%20copy%208.png"
              alt="Bridge"
              className="h-8 sm:h-10 md:h-11 w-auto object-contain transition-transform duration-200 hover:scale-105"
            />
          </a>

          <nav className="hidden md:flex items-center gap-8">
            {NAV_LINKS.map(l => (
              <button key={l.target} onClick={() => scrollTo(l.target)}
                className="text-sm font-medium text-neutral-600 hover:text-neutral-900 transition-colors">
                {l.label}
              </button>
            ))}
          </nav>

          <div className="hidden md:flex items-center gap-3">
            <button onClick={() => setShowAuth(true)}
              className="text-sm font-semibold text-neutral-700 hover:text-neutral-900 px-4 py-2 transition-colors">
              Sign In
            </button>
            <button onClick={() => setShowAuth(true)}
              className="text-sm font-semibold text-white bg-neutral-900 hover:bg-neutral-800 px-5 py-2.5 rounded-lg transition-all shadow-sm hover:shadow-md hover:-translate-y-0.5">
              Get Started
            </button>
          </div>

          <button onClick={() => setMobileMenu(!mobileMenu)}
            className="md:hidden p-2 rounded-lg text-neutral-600 hover:bg-neutral-100">
            {mobileMenu ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>

        {mobileMenu && (
          <div className="md:hidden border-t border-neutral-100 px-6 py-4 flex flex-col gap-3 bg-white shadow-lg">
            {NAV_LINKS.map(l => (
              <button key={l.target} onClick={() => scrollTo(l.target)}
                className="text-left text-sm font-medium text-neutral-700 hover:text-neutral-900">
                {l.label}
              </button>
            ))}
            <div className="flex gap-3 pt-2 border-t border-neutral-100">
              <button onClick={() => setShowAuth(true)}
                className="flex-1 text-sm font-semibold text-neutral-700 border border-neutral-300 rounded-lg py-2.5">
                Sign In
              </button>
              <button onClick={() => setShowAuth(true)}
                className="flex-1 text-sm font-semibold text-white bg-neutral-900 rounded-lg py-2.5">
                Get Started
              </button>
            </div>
          </div>
        )}
      </header>

      {/* ── Hero ── */}
      <section className="max-w-[1280px] mx-auto px-6 lg:px-0 pt-8 lg:pt-16">
        <div className="max-w-3xl">
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-primary-50 border border-primary-100 text-primary-700 text-xs font-semibold mb-6 animate-rise-in">
            <Sparkles className="w-3.5 h-3.5" />
            The dental case ordering platform
          </div>
          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-neutral-900 leading-[1.1] tracking-tight animate-rise-in">
            From chair to lab,<br />and back again.
          </h1>
          <p className="mt-6 text-lg text-neutral-500 leading-relaxed max-w-2xl animate-rise-in" style={{ animationDelay: '60ms' }}>
            Bridge connects doctors, dental centers, laboratories, and drivers in one simple app.
            Send cases, track production, coordinate deliveries — no phone calls, no paperwork, no lost details.
          </p>
          <div className="mt-8 flex flex-wrap items-center gap-3 animate-rise-in" style={{ animationDelay: '120ms' }}>
            <button onClick={() => setShowAuth(true)}
              className="btn-shine inline-flex items-center gap-2 px-6 py-3 bg-neutral-900 hover:bg-neutral-800 text-white font-semibold rounded-xl text-base shadow-lg hover:shadow-xl transition-all">
              Get Started Free
              <ArrowRight className="w-4 h-4" />
            </button>
            <button onClick={() => scrollTo('how-it-works')}
              className="inline-flex items-center gap-2 px-6 py-3 border border-neutral-300 hover:border-neutral-400 text-neutral-700 font-semibold rounded-xl text-base transition-all hover:bg-neutral-50">
              See how it works
            </button>
          </div>
          <div className="mt-10 flex flex-wrap items-center gap-x-8 gap-y-3 animate-rise-in" style={{ animationDelay: '180ms' }}>
            {STATS.map(s => (
              <div key={s.label} className="flex flex-col">
                <span className="text-xl font-bold text-neutral-900">{s.value}</span>
                <span className="text-xs text-neutral-400">{s.label}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="mt-10 lg:mt-14 w-full aspect-[2/1] rounded-2xl overflow-hidden shadow-card-hover animate-rise-in" style={{ animationDelay: '240ms' }}>
          <img src={HERO_IMG} alt="Dental technician crafting a restoration" className="w-full h-full object-cover" />
        </div>
      </section>

      {/* ── Features (Image card grid) ── */}
      <section id="features" className="max-w-[1280px] mx-auto px-6 lg:px-0 pt-16 lg:pt-24 scroll-mt-20">
        <h2 className="text-2xl sm:text-3xl lg:text-4xl font-bold text-neutral-900 tracking-tight">Everything in one place</h2>
        <p className="mt-3 text-neutral-500 text-base lg:text-lg max-w-2xl">
          Four roles, one workflow. Bridge handles the entire journey from the moment a doctor sends a case to the moment it's delivered back.
        </p>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8 mt-8 lg:mt-10">
          {FEATURE_CARDS.map((card, i) => {
            const Icon = card.icon;
            return (
              <div key={card.title}
                className="group rounded-2xl overflow-hidden border border-neutral-200 bg-white shadow-card hover:shadow-card-hover transition-all duration-300 hover:-translate-y-1 animate-rise-in"
                style={{ animationDelay: `${i * 80}ms` }}>
                <div className="aspect-[4/3] overflow-hidden">
                  <img src={card.img} alt={card.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                </div>
                <div className="p-6">
                  <div className="w-10 h-10 rounded-xl bg-primary-50 flex items-center justify-center mb-4">
                    <Icon className="w-5 h-5 text-primary-600" />
                  </div>
                  <h3 className="text-lg font-bold text-neutral-900 mb-2">{card.title}</h3>
                  <p className="text-sm text-neutral-500 leading-relaxed">{card.desc}</p>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* ── How it works (Split feature) ── */}
      <section id="how-it-works" className="max-w-[1280px] mx-auto px-6 lg:px-0 pt-16 lg:pt-24 scroll-mt-20">
        <h2 className="text-2xl sm:text-3xl lg:text-4xl font-bold text-neutral-900 tracking-tight">How a case moves</h2>
        <p className="mt-3 text-neutral-500 text-base lg:text-lg max-w-2xl">
          Every case follows the same simple path. Each person sees only what they need to do their part.
        </p>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-12 mt-8 lg:mt-10 items-center">
          <div className="space-y-5">
            {HOW_STEPS.map((step, i) => {
              const Icon = step.icon;
              return (
                <div key={step.title} className="flex items-start gap-4 animate-rise-in" style={{ animationDelay: `${i * 80}ms` }}>
                  <div className="flex-shrink-0 w-11 h-11 rounded-xl bg-neutral-900 text-white flex items-center justify-center font-bold text-sm">
                    {i + 1}
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <Icon className="w-4 h-4 text-primary-600" />
                      <h3 className="text-base font-bold text-neutral-900">{step.title}</h3>
                    </div>
                    <p className="mt-1 text-sm text-neutral-500 leading-relaxed">{step.desc}</p>
                  </div>
                </div>
              );
            })}
          </div>
          <div className="aspect-square rounded-2xl overflow-hidden shadow-card-hover">
            <img src={SPLIT_IMG} alt="Dental technician working on a case" className="w-full h-full object-cover" />
          </div>
        </div>
      </section>

      {/* ── Featured cards (roles) ── */}
      <section className="max-w-[1280px] mx-auto px-6 lg:px-0 pt-16 lg:pt-24">
        <h2 className="text-2xl sm:text-3xl lg:text-4xl font-bold text-neutral-900 tracking-tight">Built for every role</h2>
        <p className="mt-3 text-neutral-500 text-base lg:text-lg max-w-2xl">
          Each role gets a focused dashboard with exactly the tools they need — nothing more, nothing less.
        </p>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8 mt-8 lg:mt-10">
          {[
            { icon: Stethoscope, title: 'Doctors', desc: 'Place orders, track status, and manage all your cases across multiple labs and centers.', img: FEAT_1, tall: false },
            { icon: Building2, title: 'Dental Centers', desc: 'Coordinate your team of doctors, send orders from the center, and get one invoiced bill.', img: FEAT_2, tall: false },
            { icon: FlaskConical, title: 'Laboratories', desc: 'Receive structured orders, manage your client base, publish your service catalog, and track production.', img: FEAT_3, tall: true },
          ].map((role, i) => {
            const Icon = role.icon;
            return (
              <div key={role.title}
                className="group rounded-2xl overflow-hidden border border-neutral-200 bg-white shadow-card hover:shadow-card-hover transition-all duration-300 hover:-translate-y-1 animate-rise-in"
                style={{ animationDelay: `${i * 80}ms` }}>
                <div className={role.tall ? 'aspect-[5/6]' : 'aspect-square'}>
                  <img src={role.img} alt={role.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                </div>
                <div className="p-6">
                  <div className="w-10 h-10 rounded-xl bg-primary-50 flex items-center justify-center mb-4">
                    <Icon className="w-5 h-5 text-primary-600" />
                  </div>
                  <h3 className="text-lg font-bold text-neutral-900 mb-2">{role.title}</h3>
                  <p className="text-sm text-neutral-500 leading-relaxed">{role.desc}</p>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* ── Trust badges ── */}
      <section className="max-w-[1280px] mx-auto px-6 lg:px-0 pt-16 lg:pt-24">
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
          {[
            { icon: Shield, title: 'Secure & private', desc: 'Your case data is encrypted and access-controlled. Only the people on the case can see it.' },
            { icon: Zap, title: 'Instant notifications', desc: 'Real-time updates on every case — new orders, comments, status changes, and delivery alerts.' },
            { icon: Clock, title: 'Faster turnaround', desc: 'No more phone tag. Cases arrive complete, labs start sooner, and drivers know the plan.' },
          ].map((badge, i) => {
            const Icon = badge.icon;
            return (
              <div key={badge.title} className="flex items-start gap-3 p-5 rounded-xl bg-neutral-50 border border-neutral-100 animate-rise-in" style={{ animationDelay: `${i * 60}ms` }}>
                <div className="flex-shrink-0 w-9 h-9 rounded-lg bg-white border border-neutral-200 flex items-center justify-center">
                  <Icon className="w-4 h-4 text-primary-600" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-neutral-900">{badge.title}</h3>
                  <p className="mt-1 text-xs text-neutral-500 leading-relaxed">{badge.desc}</p>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* ── Testimonials ── */}
      <section id="testimonials" className="max-w-[1280px] mx-auto px-6 lg:px-0 pt-16 lg:pt-24 scroll-mt-20">
        <h2 className="text-2xl sm:text-3xl lg:text-4xl font-bold text-neutral-900 tracking-tight">Trusted by dental teams</h2>
        <p className="mt-3 text-neutral-500 text-base lg:text-lg max-w-2xl">
          Doctors, labs, and centers use Bridge every day to keep their cases moving.
        </p>
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 lg:gap-8 mt-8 lg:mt-10">
          {TESTIMONIALS.map((t, i) => (
            <div key={t.name}
              className="p-6 rounded-2xl bg-white border border-neutral-200 shadow-card hover:shadow-card-hover transition-all duration-300 animate-rise-in"
              style={{ animationDelay: `${i * 80}ms` }}>
              <div className="flex items-center gap-1 mb-4">
                {[0, 1, 2, 3, 4].map(s => (
                  <svg key={s} className="w-4 h-4 text-amber-400" fill="currentColor" viewBox="0 0 20 20">
                    <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                  </svg>
                ))}
              </div>
              <p className="text-sm text-neutral-700 leading-relaxed mb-5">"{t.quote}"</p>
              <div className="flex items-center gap-3 pt-4 border-t border-neutral-100">
                <div className="w-10 h-10 rounded-full bg-primary-100 flex items-center justify-center">
                  <span className="text-sm font-bold text-primary-700">{t.name.charAt(0)}</span>
                </div>
                <div>
                  <p className="text-sm font-bold text-neutral-900">{t.name}</p>
                  <p className="text-xs text-neutral-400">{t.role}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* ── CTA ── */}
      <section className="pt-16 lg:pt-24">
        <div className="max-w-[1280px] mx-auto px-6 lg:px-0">
          <div className="relative rounded-3xl bg-neutral-900 overflow-hidden px-8 py-12 lg:px-16 lg:py-20 text-center">
            <div className="absolute inset-0 opacity-10" style={{ backgroundImage: `url(${HERO_IMG})`, backgroundSize: 'cover', backgroundPosition: 'center' }} />
            <div className="relative">
              <h2 className="text-2xl sm:text-3xl lg:text-4xl font-bold text-white tracking-tight">
                Start sending cases in minutes
              </h2>
              <p className="mt-4 text-neutral-300 text-base lg:text-lg max-w-xl mx-auto">
                Create your free account, find a lab, and send your first case today. No setup fees, no contracts.
              </p>
              <button onClick={() => setShowAuth(true)}
                className="btn-shine mt-8 inline-flex items-center gap-2 px-8 py-3.5 bg-white text-neutral-900 font-bold rounded-xl text-base shadow-lg hover:shadow-xl transition-all hover:-translate-y-0.5">
                Get Started Free
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* ── Footer ── */}
      <footer className="border-t border-neutral-200 mt-16 lg:mt-24">
        <div className="max-w-[1280px] mx-auto px-6 lg:px-0 py-10">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-6">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg overflow-hidden flex items-center justify-center bg-white">
                <img src="/logo_%20copy%208.png" alt="Bridge" className="w-full h-full object-contain" />
              </div>
              <div>
                <span className="font-bold text-neutral-900">Bridge</span>
                <p className="text-xs text-neutral-400">Lab Ordering Platform</p>
              </div>
            </div>
            <nav className="flex flex-wrap items-center gap-6">
              {FOOTER_LINKS.map(l => (
                <button key={l.target} onClick={() => scrollTo(l.target)}
                  className="text-sm text-neutral-500 hover:text-neutral-900 transition-colors">
                  {l.label}
                </button>
              ))}
              <button onClick={() => setShowAuth(true)}
                className="text-sm font-semibold text-neutral-700 hover:text-neutral-900 transition-colors">
                Sign In
              </button>
            </nav>
          </div>
          <div className="mt-8 pt-6 border-t border-neutral-100 flex flex-col sm:flex-row items-center justify-between gap-3">
            <p className="text-xs text-neutral-400">&copy; 2026 Bridge 86. All rights reserved.</p>
            <div className="flex items-center gap-4 text-xs text-neutral-400">
              <a href="/privacy-policy" className="hover:text-neutral-700 transition-colors">Privacy Policy</a>
              <a href="/terms-of-service" className="hover:text-neutral-700 transition-colors">Terms of Service</a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
