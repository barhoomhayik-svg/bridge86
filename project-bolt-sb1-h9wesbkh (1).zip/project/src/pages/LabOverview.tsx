import { useEffect, useState, useCallback } from 'react';
import { supabase, Order, OrderStatus, Service } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { CountUp } from '../lib/CountUp';
import {
  ClipboardList, Clock, CheckCircle2, XCircle, Loader2,
  ChevronRight, TrendingUp, Microscope, RefreshCw, Truck, FlaskConical, BadgeCheck,
} from 'lucide-react';
import OrderDetailModal from '../components/OrderDetailModal';
import { ToothIcon } from '../components/ToothIcon';
import { useRealtimeLabOrders } from '../lib/useRealtimeOrders';

const STATUS_CONFIG: Record<string, { label: string; color: string; bg: string; border: string; icon: React.ReactNode }> = {
  pending:     { label: 'Pending',     color: 'text-amber-700',   bg: 'bg-amber-50',   border: 'border-amber-200',   icon: <ToothIcon className="w-4 h-4" variant="default" /> },
  accepted:    { label: 'Accepted',    color: 'text-blue-700',    bg: 'bg-blue-50',    border: 'border-blue-200',    icon: <ToothIcon className="w-4 h-4" variant="check" /> },
  in_progress: { label: 'In Progress', color: 'text-primary-700', bg: 'bg-primary-50', border: 'border-primary-200', icon: <ToothIcon className="w-4 h-4" variant="spin" /> },
  completed:   { label: 'Completed',   color: 'text-teal-700',    bg: 'bg-teal-50',    border: 'border-teal-200',    icon: <ToothIcon className="w-4 h-4" variant="sparkle" /> },
  try_in:      { label: 'Try In',      color: 'text-amber-700',   bg: 'bg-amber-50',   border: 'border-amber-300',   icon: <FlaskConical className="w-4 h-4" /> },
  delivering:  { label: 'Delivering',  color: 'text-cyan-700',    bg: 'bg-cyan-50',    border: 'border-cyan-200',    icon: <Truck className="w-4 h-4" /> },
  delivered:   { label: 'Delivered',   color: 'text-emerald-700', bg: 'bg-emerald-50', border: 'border-emerald-200', icon: <CheckCircle2 className="w-4 h-4" /> },
  rejected:    { label: 'Rejected',    color: 'text-red-700',     bg: 'bg-red-50',     border: 'border-red-200',     icon: <ToothIcon className="w-4 h-4" variant="x" /> },
  cancelled:   { label: 'Cancelled',   color: 'text-neutral-600', bg: 'bg-neutral-50', border: 'border-neutral-200', icon: <ToothIcon className="w-4 h-4" variant="slash" /> },
  redo:        { label: 'Redo',        color: 'text-orange-700',  bg: 'bg-orange-50',  border: 'border-orange-200',  icon: <ToothIcon className="w-4 h-4" variant="redo" /> },
  finished:    { label: 'Finished',    color: 'text-green-800',   bg: 'bg-green-50',   border: 'border-green-300',   icon: <BadgeCheck className="w-4 h-4" /> },
};
const FILTER_STATUSES = ['pending', 'accepted', 'in_progress', 'completed', 'try_in', 'delivered', 'rejected', 'cancelled', 'redo', 'finished'] as const;
type FilterValue = typeof FILTER_STATUSES[number] | 'all';

const THIRTY_DAYS_MS = 30 * 24 * 60 * 60 * 1000;

interface Props {
  onNavigateOrders: () => void;
}

export default function LabOverview({ onNavigateOrders }: Props) {
  const { profile } = useAuth();
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<FilterValue>('all');
  const [selected, setSelected] = useState<Order | null>(null);

  const fetchOrders = useCallback(async () => {
    if (!profile) return;
    setLoading(true);
    const { data } = await supabase
      .from('orders')
      .select('*, from_profile:profiles!orders_from_id_fkey(*), service:services(*), attachments:order_attachments(*), order_services(*, service:services(*))')
      .eq('lab_id', profile.id)
      .order('created_at', { ascending: false });
    setOrders(data ?? []);
    setLoading(false);
  }, [profile]);

  useEffect(() => { fetchOrders(); }, [fetchOrders]);
  useRealtimeLabOrders(profile?.id, fetchOrders);

  const counts = orders.reduce((acc, o) => {
    if (o.status === 'delivered') {
      if (o.finished_at || Date.now() - new Date(o.updated_at ?? o.created_at).getTime() > THIRTY_DAYS_MS) {
        acc['finished'] = (acc['finished'] ?? 0) + 1;
      } else {
        acc['delivered'] = (acc['delivered'] ?? 0) + 1;
      }
    } else {
      acc[o.status] = (acc[o.status] ?? 0) + 1;
    }
    return acc;
  }, {} as Record<string, number>);

  const activeCount = (counts['pending'] ?? 0) + (counts['accepted'] ?? 0) + (counts['in_progress'] ?? 0);
  const filtered = filter === 'all' ? orders
    : filter === 'finished' ? orders.filter(o => o.status === 'delivered' && (o.finished_at || Date.now() - new Date(o.updated_at ?? o.created_at).getTime() > THIRTY_DAYS_MS))
    : filter === 'delivered' ? orders.filter(o => o.status === 'delivered' && !o.finished_at && Date.now() - new Date(o.updated_at ?? o.created_at).getTime() <= THIRTY_DAYS_MS)
    : orders.filter(o => o.status === filter);

  return (
    <div className="p-6 max-w-5xl mx-auto">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-neutral-900">Lab Dashboard</h1>
          <p className="text-neutral-500 text-sm mt-1">Welcome back, {profile?.name}</p>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-6">
        <StatCard icon={<ClipboardList className="w-5 h-5 text-primary-600" />} bg="bg-primary-50" value={orders.length} label="Total Orders" index={0} />
        <StatCard icon={<TrendingUp className="w-5 h-5 text-blue-600" />} bg="bg-blue-50" value={activeCount} label="Active" index={1} />
        <StatCard icon={<CheckCircle2 className="w-5 h-5 text-teal-600" />} bg="bg-teal-50" value={counts['completed'] ?? 0} label="Completed" index={2} />
        <StatCard icon={<XCircle className="w-5 h-5 text-red-400" />} bg="bg-red-50" value={(counts['rejected'] ?? 0) + (counts['cancelled'] ?? 0)} label="Closed" index={3} />
      </div>

      {/* Status filter strip */}
      <div className="grid grid-cols-4 md:grid-cols-10 gap-2 mb-5">
        {FILTER_STATUSES.map((s, i) => {
          const cfg = STATUS_CONFIG[s];
          const active = filter === s;
          return (
            <button
              key={s}
              onClick={() => setFilter(active ? 'all' : s)}
              style={{ animationDelay: `${i * 40}ms` }}
              className={`px-2 py-2.5 rounded-xl text-center transition-all border animate-rise-in hover:-translate-y-0.5 active:scale-[0.97] ${
                active
                  ? `${cfg.bg} ${cfg.color} ${cfg.border}`
                  : 'bg-white border-neutral-200 text-neutral-500 hover:border-neutral-300'
              }`}
            >
              <div className={`w-7 h-7 rounded-lg flex items-center justify-center mx-auto mb-1 ${active ? 'bg-white/60' : cfg.bg} ${cfg.color}`}>
                {cfg.icon}
              </div>
              <p className="text-base font-bold leading-none"><CountUp value={counts[s] ?? 0} /></p>
              <p className="text-[10px] font-medium mt-0.5">{cfg.label}</p>
            </button>
          );
        })}
      </div>

      {/* Orders list */}
      {loading ? (
        <div className="space-y-3">
          {[1, 2, 3].map(i => <div key={i} className="bg-white rounded-xl h-20 animate-pulse shadow-card" />)}
        </div>
      ) : filtered.length === 0 ? (
        <div className="text-center py-16 bg-white rounded-2xl shadow-card border border-neutral-100">
          {orders.length === 0 ? (
            <>
              <Microscope className="w-12 h-12 text-neutral-300 mx-auto mb-3" />
              <p className="text-neutral-500 font-medium">No orders yet</p>
              <p className="text-neutral-400 text-sm mt-1">Orders from doctors will appear here</p>
            </>
          ) : (
            <>
              <ClipboardList className="w-12 h-12 text-neutral-300 mx-auto mb-3" />
              <p className="text-neutral-500 font-medium">No {STATUS_CONFIG[filter]?.label ?? 'matching'} orders</p>
            </>
          )}
        </div>
      ) : (
        <div className="space-y-2">
          {filtered.map(order => {
            const cfg = STATUS_CONFIG[order.status];
            return (
              <button
                key={order.id}
                onClick={() => setSelected(order)}
                className="w-full bg-white rounded-xl p-4 shadow-card hover:shadow-card-hover transition-all text-left flex items-center gap-4 group border border-transparent hover:border-primary-100"
              >
                <div className={`w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 ${cfg.bg} ${cfg.color} border ${cfg.border}`}>
                  {cfg.icon}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-0.5 flex-wrap">
                    <span className="font-semibold text-neutral-900 text-sm">{order.order_number}</span>
                    <span className={`text-xs font-medium px-2 py-0.5 rounded-full border ${cfg.bg} ${cfg.color} ${cfg.border}`}>
                      {cfg.label}
                    </span>
                  </div>
                  <p className="text-sm text-neutral-600 truncate">
                    From: <span className="font-medium">{order.from_profile?.name ?? '—'}</span>
                    {' '}&bull; Patient: {order.patient_name}
                    {order.service && <span className="text-neutral-400"> · {order.service.name}</span>}
                  </p>
                  <p className="text-xs text-neutral-400 mt-0.5">File #{order.file_number}</p>
                </div>
                <div className="text-right flex-shrink-0">
                  <p className="text-xs text-neutral-400">{new Date(order.created_at).toLocaleDateString()}</p>
                  {order.due_date && (
                    <p className="text-xs text-amber-600 font-medium">Due {new Date(order.due_date).toLocaleDateString()}</p>
                  )}
                </div>
                <ChevronRight className="w-4 h-4 text-neutral-300 group-hover:text-primary-500 transition-colors ml-1" />
              </button>
            );
          })}
        </div>
      )}

      {selected && (
        <OrderDetailModal
          order={selected}
          isLab={true}
          onClose={() => setSelected(null)}
          onStatusChange={() => { fetchOrders(); setSelected(null); }}
        />
      )}
    </div>
  );
}

function StatCard({ icon, bg, value, label, index = 0 }: { icon: React.ReactNode; bg: string; value: number; label: string; index?: number }) {
  return (
    <div className="bg-white rounded-2xl p-5 shadow-card animate-rise-in transition-transform duration-200 hover:-translate-y-0.5 hover:shadow-lg" style={{ animationDelay: `${index * 70}ms` }}>
      <div className="flex items-center gap-3">
        <div className={`w-10 h-10 ${bg} rounded-xl flex items-center justify-center flex-shrink-0`}>
          {icon}
        </div>
        <div>
          <p className="text-2xl font-bold text-neutral-900"><CountUp value={value} /></p>
          <p className="text-sm text-neutral-500">{label}</p>
        </div>
      </div>
    </div>
  );
}
