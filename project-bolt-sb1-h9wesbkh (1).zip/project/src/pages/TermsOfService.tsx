import React from 'react';
import { ArrowLeft } from 'lucide-react';

export default function TermsOfService() {
  const goBack = () => {
    if (window.history.length > 1) window.history.back();
    else { window.location.href = '/'; }
  };

  return (
    <div className="min-h-dvh bg-neutral-50">
      <header className="sticky top-0 z-20 bg-white/80 backdrop-blur-lg border-b border-neutral-200 transform-gpu">
        <div className="max-w-3xl mx-auto px-6 h-14 flex items-center gap-3">
          <button
            onClick={goBack}
            className="p-2 -ml-2 rounded-lg text-neutral-500 hover:text-neutral-900 hover:bg-neutral-100 transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h1 className="font-bold text-lg text-neutral-900">Terms of Service</h1>
        </div>
      </header>

      <main className="max-w-3xl mx-auto px-6 py-10">
        <p className="text-sm text-neutral-400 mb-8">Last updated: August 21, 2026</p>

        <div className="prose prose-neutral prose-sm max-w-none space-y-8">
          <section>
            <h2 className="text-lg font-semibold text-neutral-900 mb-3">1. Acceptance of Terms</h2>
            <p className="text-neutral-600 leading-relaxed">
              By accessing or using Bridge 86 ("the Service"), you agree to be bound by these Terms of Service. If you do not agree, do not use the Service. These terms apply to all users, including dental professionals, dental centers, laboratories, and drivers.
            </p>
          </section>

          <section>
            <h2 className="text-lg font-semibold text-neutral-900 mb-3">2. Description of Service</h2>
            <p className="text-neutral-600 leading-relaxed">
              Bridge 86 is a digital platform that connects dental professionals, centers, laboratories, and delivery drivers to streamline the ordering, production, and delivery of dental lab work. The Service includes order management, real-time communication, quotation handling, delivery tracking, and related features.
            </p>
          </section>

          <section>
            <h2 className="text-lg font-semibold text-neutral-900 mb-3">3. Account Registration</h2>
            <ul className="list-disc pl-5 text-neutral-600 space-y-2 leading-relaxed">
              <li>You must provide accurate and complete information when creating an account.</li>
              <li>You are responsible for maintaining the confidentiality of your login credentials.</li>
              <li>You must notify us immediately of any unauthorized use of your account.</li>
              <li>One person or entity may maintain only one account. Creating multiple accounts to circumvent restrictions is prohibited.</li>
            </ul>
          </section>

          <section>
            <h2 className="text-lg font-semibold text-neutral-900 mb-3">4. Acceptable Use</h2>
            <p className="text-neutral-600 leading-relaxed mb-3">
              You agree not to:
            </p>
            <ul className="list-disc pl-5 text-neutral-600 space-y-2 leading-relaxed">
              <li>Use the Service for any unlawful purpose</li>
              <li>Upload malicious files, viruses, or harmful content</li>
              <li>Attempt to gain unauthorized access to other accounts or system resources</li>
              <li>Scrape, harvest, or collect user data without authorization</li>
              <li>Impersonate another person or misrepresent your professional role</li>
              <li>Interfere with or disrupt the Service or its infrastructure</li>
              <li>Use the Service to send unsolicited communications or spam</li>
            </ul>
          </section>

          <section>
            <h2 className="text-lg font-semibold text-neutral-900 mb-3">5. Case Data and Patient Information</h2>
            <p className="text-neutral-600 leading-relaxed">
              You are responsible for ensuring that any patient information you enter complies with applicable healthcare privacy laws in your jurisdiction. Bridge 86 provides secure storage and access controls, but you retain responsibility for your obligations as a healthcare provider regarding patient data. Do not upload information beyond what is necessary for case fulfillment.
            </p>
          </section>

          <section>
            <h2 className="text-lg font-semibold text-neutral-900 mb-3">6. Orders and Quotations</h2>
            <p className="text-neutral-600 leading-relaxed">
              Bridge 86 facilitates communication between parties but is not itself a party to any agreement between a clinic and a lab. Pricing, timelines, quality standards, and dispute resolution for dental work are between the ordering party and the laboratory. Bridge 86 does not guarantee the quality, accuracy, or timeliness of any lab work.
            </p>
          </section>

          <section>
            <h2 className="text-lg font-semibold text-neutral-900 mb-3">7. Intellectual Property</h2>
            <p className="text-neutral-600 leading-relaxed">
              The Service, including its design, code, logos, and documentation, is the intellectual property of Bridge 86. You retain ownership of any content you upload (photos, case notes, documents). By uploading content, you grant Bridge 86 a limited license to store, display, and transmit it solely for the purpose of providing the Service.
            </p>
          </section>

          <section>
            <h2 className="text-lg font-semibold text-neutral-900 mb-3">8. Limitation of Liability</h2>
            <p className="text-neutral-600 leading-relaxed">
              To the maximum extent permitted by law, Bridge 86 shall not be liable for any indirect, incidental, special, consequential, or punitive damages arising from your use of the Service. Bridge 86 is not liable for any clinical outcomes, patient harm, or loss resulting from dental work coordinated through the platform.
            </p>
          </section>

          <section>
            <h2 className="text-lg font-semibold text-neutral-900 mb-3">9. Disclaimer of Warranties</h2>
            <p className="text-neutral-600 leading-relaxed">
              The Service is provided "as is" and "as available" without warranties of any kind, whether express or implied, including but not limited to implied warranties of merchantability, fitness for a particular purpose, or non-infringement.
            </p>
          </section>

          <section>
            <h2 className="text-lg font-semibold text-neutral-900 mb-3">10. Termination</h2>
            <p className="text-neutral-600 leading-relaxed">
              We reserve the right to suspend or terminate your account at any time for violation of these terms or for any reason with reasonable notice. Upon termination, your right to use the Service ceases immediately. Data retention after termination is governed by our Privacy Policy.
            </p>
          </section>

          <section>
            <h2 className="text-lg font-semibold text-neutral-900 mb-3">11. Modifications</h2>
            <p className="text-neutral-600 leading-relaxed">
              We may modify these Terms at any time. Material changes will be communicated via the Service or email. Continued use after modifications constitutes acceptance of the updated terms.
            </p>
          </section>

          <section>
            <h2 className="text-lg font-semibold text-neutral-900 mb-3">12. Governing Law</h2>
            <p className="text-neutral-600 leading-relaxed">
              These Terms shall be governed by and construed in accordance with the laws of the jurisdiction in which Bridge 86 operates, without regard to conflict of law principles.
            </p>
          </section>

          <section>
            <h2 className="text-lg font-semibold text-neutral-900 mb-3">13. Contact</h2>
            <p className="text-neutral-600 leading-relaxed">
              For questions about these Terms, please contact us at{' '}
              <a href="mailto:info@bridge-86.com" className="text-primary-600 hover:underline">info@bridge-86.com</a>.
            </p>
          </section>

          <section className="border-t border-neutral-200 pt-6">
            <p className="text-neutral-500 text-sm">
              See also:{' '}
              <a href="/privacy-policy" className="text-primary-600 hover:underline font-medium">Privacy Policy</a>
            </p>
          </section>
        </div>
      </main>
    </div>
  );
}
