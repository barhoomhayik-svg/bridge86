import { useEffect, useState, useCallback, useRef } from 'react';
import { supabase, Order, OrderStatus, Profile, Service } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { CountUp } from '../lib/CountUp';
import { escapeHtml } from '../lib/escapeHtml';
import {
  ClipboardList, Clock, CheckCircle2, XCircle, Loader2,
  ChevronRight, Users, Stethoscope, TrendingUp, AlertCircle,
  Search, Microscope, X, ArrowUpDown, FileDown, ChevronDown, RefreshCw, Truck, FlaskConical, BadgeCheck,
} from 'lucide-react';
import OrderDetailModal from '../components/OrderDetailModal';
import { ToothIcon } from '../components/ToothIcon';
import { useRealtimeCenterOrders } from '../lib/useRealtimeOrders';

const STATUS_CONFIG: Record<string, { label: string; color: string; bg: string; border: string; icon: React.ReactNode }> = {
  pending:     { label: 'Pending',     color: 'text-amber-700',   bg: 'bg-amber-50',   border: 'border-amber-200',   icon: <ToothIcon className="w-4 h-4" variant="default" /> },
  accepted:    { label: 'Accepted',    color: 'text-blue-700',    bg: 'bg-blue-50',    border: 'border-blue-200',    icon: <ToothIcon className="w-4 h-4" variant="check" /> },
  in_progress: { label: 'In Progress', color: 'text-primary-700', bg: 'bg-primary-50', border: 'border-primary-200', icon: <ToothIcon className="w-4 h-4" variant="spin" /> },
  completed:   { label: 'Completed',   color: 'text-teal-700',    bg: 'bg-teal-50',    border: 'border-teal-200',    icon: <ToothIcon className="w-4 h-4" variant="sparkle" /> },
  try_in:      { label: 'Try In',      color: 'text-amber-700',   bg: 'bg-amber-50',   border: 'border-amber-300',   icon: <FlaskConical className="w-4 h-4" /> },
  delivering:  { label: 'Delivering',  color: 'text-cyan-700',    bg: 'bg-cyan-50',    border: 'border-cyan-200',    icon: <Truck className="w-4 h-4" /> },
  delivered:   { label: 'Delivered',   color: 'text-emerald-700', bg: 'bg-emerald-50', border: 'border-emerald-200', icon: <CheckCircle2 className="w-4 h-4" /> },
  rejected:    { label: 'Rejected',    color: 'text-red-700',     bg: 'bg-red-50',     border: 'border-red-200',     icon: <ToothIcon className="w-4 h-4" variant="x" /> },
  cancelled:   { label: 'Cancelled',   color: 'text-neutral-600', bg: 'bg-neutral-50', border: 'border-neutral-200', icon: <ToothIcon className="w-4 h-4" variant="slash" /> },
  redo:        { label: 'Redo',        color: 'text-orange-700',  bg: 'bg-orange-50',  border: 'border-orange-200',  icon: <ToothIcon className="w-4 h-4" variant="redo" /> },
  finished:    { label: 'Finished',    color: 'text-green-800',   bg: 'bg-green-50',   border: 'border-green-300',   icon: <BadgeCheck className="w-4 h-4" /> },
};
const FILTER_STATUSES = ['pending', 'accepted', 'in_progress', 'completed', 'try_in', 'delivered', 'rejected', 'cancelled', 'redo', 'finished'] as const;
type FilterValue = typeof FILTER_STATUSES[number] | 'all';

const THIRTY_DAYS_MS = 30 * 24 * 60 * 60 * 1000;

type SortKey = 'date_desc' | 'date_asc' | 'doctor_asc' | 'doctor_desc';
const SORT_LABELS: Record<SortKey, string> = {
  date_desc: 'Newest first',
  date_asc: 'Oldest first',
  doctor_asc: 'Doctor A → Z',
  doctor_desc: 'Doctor Z → A',
};

function getDoctorName(order: Order, centerId: string): string {
  return order.from_id === centerId
    ? (order.dr_name ?? '')
    : (order.from_profile?.name ?? order.dr_name ?? '');
}

export default function CenterDashboard() {
  const { profile } = useAuth();
  const [orders, setOrders] = useState<Order[]>([]);
  const [members, setMembers] = useState<Profile[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<FilterValue>('all');
  const [doctorFilter, setDoctorFilter] = useState<string>('all');
  const [sortKey, setSortKey] = useState<SortKey>('date_desc');
  const [sortOpen, setSortOpen] = useState(false);
  const [selected, setSelected] = useState<Order | null>(null);
  const sortRef = useRef<HTMLDivElement>(null);

  const fetchData = useCallback(async () => {
    if (!profile) return;
    setLoading(true);

    const { data: memberRows } = await supabase
      .from('center_members')
      .select('doctor_id, doctor_profile:profiles!center_members_doctor_id_fkey(*)')
      .eq('center_id', profile.id);

    const doctorProfiles = (memberRows ?? []).map((r: { doctor_id: string; doctor_profile: Profile }) => r.doctor_profile).filter(Boolean);
    setMembers(doctorProfiles);

    const senderIds = [profile.id, ...(memberRows ?? []).map((r: { doctor_id: string }) => r.doctor_id)];

    const { data: orderData } = await supabase
      .from('orders')
      .select('*, from_profile:profiles!orders_from_id_fkey(*), lab_profile:profiles!orders_lab_id_fkey(*), service:services(*), attachments:order_attachments(*), order_services(*, service:services(*))')
      .in('from_id', senderIds)
      .order('created_at', { ascending: false });

    setOrders(orderData ?? []);
    setLoading(false);
  }, [profile]);

  useEffect(() => { fetchData(); }, [fetchData]);

  const doctorIds = (members ?? []).map((m: Profile) => m.id);
  useRealtimeCenterOrders(profile?.id, doctorIds, fetchData);

  // Close sort dropdown on outside click
  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (sortRef.current && !sortRef.current.contains(e.target as Node)) setSortOpen(false);
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  const counts = orders.reduce((acc, o) => {
    if (o.status === 'delivered') {
      if (o.finished_at || Date.now() - new Date(o.updated_at ?? o.created_at).getTime() > THIRTY_DAYS_MS) {
        acc['finished'] = (acc['finished'] ?? 0) + 1;
      } else {
        acc['delivered'] = (acc['delivered'] ?? 0) + 1;
      }
    } else {
      acc[o.status] = (acc[o.status] ?? 0) + 1;
    }
    return acc;
  }, {} as Record<string, number>);

  const activeCount = (counts['pending'] ?? 0) + (counts['accepted'] ?? 0) + (counts['in_progress'] ?? 0);

  // All unique doctor names (from team members + dr_name on center-placed orders)
  const teamDoctorNames = members.map(m => m.name).filter(Boolean);
  const drNamesFromOrders = orders
    .filter(o => o.from_id === profile?.id && o.dr_name)
    .map(o => o.dr_name as string);
  const allDoctorNames = Array.from(new Set([...teamDoctorNames, ...drNamesFromOrders])).sort();

  const displayOrders = (() => {
    let list = filter === 'all' ? orders
      : filter === 'finished' ? orders.filter(o => o.status === 'delivered' && (o.finished_at || Date.now() - new Date(o.updated_at ?? o.created_at).getTime() > THIRTY_DAYS_MS))
      : filter === 'delivered' ? orders.filter(o => o.status === 'delivered' && !o.finished_at && Date.now() - new Date(o.updated_at ?? o.created_at).getTime() <= THIRTY_DAYS_MS)
      : filter === 'redo' ? orders.filter(o => o.status === 'redo')
      : orders.filter(o => o.status === filter);

    if (doctorFilter !== 'all') {
      list = list.filter(o => {
        const name = getDoctorName(o, profile?.id ?? '');
        return name === doctorFilter;
      });
    }

    return [...list].sort((a, b) => {
      if (sortKey === 'date_desc') return new Date(b.created_at).getTime() - new Date(a.created_at).getTime();
      if (sortKey === 'date_asc')  return new Date(a.created_at).getTime() - new Date(b.created_at).getTime();
      const da = getDoctorName(a, profile?.id ?? '').toLowerCase();
      const db = getDoctorName(b, profile?.id ?? '').toLowerCase();
      if (sortKey === 'doctor_asc')  return da.localeCompare(db);
      return db.localeCompare(da);
    });
  })();

  const handleExportPDF = () => {
    const centerId = profile?.id ?? '';
    const centerName = profile?.name ?? 'Center';
    const title = doctorFilter !== 'all' ? `Orders — ${doctorFilter}` : 'All Team Orders';
    const now = new Date().toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' });

    const rows = displayOrders.map(o => {
      const doctor = getDoctorName(o, centerId);
      const status = STATUS_CONFIG[o.status]?.label ?? o.status;
      const date = new Date(o.created_at).toLocaleDateString('en-GB');
      const due = o.due_date ? new Date(o.due_date).toLocaleDateString('en-GB') : '—';
      return `
        <tr>
          <td>${escapeHtml(o.order_number)}</td>
          <td>${escapeHtml(doctor || '—')}</td>
          <td>${escapeHtml(o.patient_name)}</td>
          <td>${escapeHtml(o.lab_profile?.name ?? '—')}</td>
          <td>${escapeHtml(o.service?.name ?? '—')}</td>
          <td><span class="badge status-${escapeHtml(o.status)}">${escapeHtml(status)}</span></td>
          <td>${escapeHtml(date)}</td>
          <td>${escapeHtml(due)}</td>
        </tr>`;
    }).join('');

    const printDiv = document.getElementById('print-orders')!;
    printDiv.innerHTML = `
      <style>
        @page { margin: 16mm 14mm; size: A4 landscape; }
        body { font-family: Inter, system-ui, sans-serif; color: #111; }
        #print-orders { padding: 0; }
        .ph { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 20px; border-bottom: 2px solid #0ea5e9; padding-bottom: 12px; }
        .ph-left h1 { font-size: 18px; font-weight: 700; margin: 0 0 2px; }
        .ph-left p { font-size: 11px; color: #64748b; margin: 0; }
        .ph-right { text-align: right; font-size: 11px; color: #64748b; }
        .ph-right strong { display: block; font-size: 13px; color: #111; }
        table { width: 100%; border-collapse: collapse; font-size: 11px; }
        th { background: #f1f5f9; text-align: left; padding: 7px 10px; font-weight: 600; color: #475569; border-bottom: 1px solid #e2e8f0; font-size: 10px; text-transform: uppercase; letter-spacing: .04em; }
        td { padding: 7px 10px; border-bottom: 1px solid #f1f5f9; color: #334155; vertical-align: middle; }
        tr:last-child td { border-bottom: none; }
        .badge { display: inline-block; padding: 2px 7px; border-radius: 99px; font-size: 10px; font-weight: 600; }
        .status-pending     { background:#fef3c7; color:#92400e; }
        .status-accepted    { background:#dbeafe; color:#1e40af; }
        .status-in_progress { background:#e0f2fe; color:#0c4a6e; }
        .status-completed   { background:#ccfbf1; color:#134e4a; }
        .status-try_in      { background:#fef3c7; color:#92400e; }
        .status-delivering  { background:#cffafe; color:#155e75; }
        .status-delivered   { background:#d1fae5; color:#065f46; }
        .status-rejected    { background:#fee2e2; color:#991b1b; }
        .status-cancelled   { background:#f1f5f9; color:#475569; }
        .footer { margin-top: 16px; font-size: 10px; color: #94a3b8; text-align: right; }
      </style>
      <div class="ph">
        <div class="ph-left">
          <h1>${escapeHtml(title)}</h1>
          <p>Exported on ${now}</p>
        </div>
        <div class="ph-right">
          <strong>${escapeHtml(centerName)}</strong>
          ${displayOrders.length} order${displayOrders.length !== 1 ? 's' : ''}
        </div>
      </div>
      <table>
        <thead>
          <tr>
            <th>Order #</th><th>Doctor</th><th>Patient</th><th>Lab</th>
            <th>Service</th><th>Status</th><th>Date</th><th>Due</th>
          </tr>
        </thead>
        <tbody>${rows}</tbody>
      </table>
      <div class="footer">Bridge Dental Platform</div>
    `;
    window.print();
  };

  return (
    <div className="p-6 max-w-5xl mx-auto">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-neutral-900">Center Dashboard</h1>
          <p className="text-neutral-500 text-sm mt-1">All orders placed by your center and team doctors</p>
        </div>
      </div>

      {/* Summary stats */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-6">
        <StatCard icon={<ClipboardList className="w-5 h-5 text-primary-600" />} bg="bg-primary-50" value={orders.length} label="Total Orders" index={0} />
        <StatCard icon={<TrendingUp className="w-5 h-5 text-blue-600" />} bg="bg-blue-50" value={activeCount} label="Active" index={1} />
        <StatCard icon={<CheckCircle2 className="w-5 h-5 text-teal-600" />} bg="bg-teal-50" value={counts['completed'] ?? 0} label="Completed" index={2} />
        <StatCard icon={<Users className="w-5 h-5 text-violet-600" />} bg="bg-violet-50" value={members.length} label="Team Doctors" index={3} />
      </div>

      {/* Status filter strip */}
      <div className="grid grid-cols-4 md:grid-cols-10 gap-2 mb-4">
        {FILTER_STATUSES.map((s, i) => {
          const cfg = STATUS_CONFIG[s];
          const active = filter === s;
          return (
            <button
              key={s}
              onClick={() => setFilter(active ? 'all' : s)}
              style={{ animationDelay: `${i * 40}ms` }}
              className={`px-2 py-2.5 rounded-xl text-center transition-all border animate-rise-in hover:-translate-y-0.5 active:scale-[0.97] ${
                active
                  ? `${cfg.bg} ${cfg.color} ${cfg.border}`
                  : 'bg-white border-neutral-200 text-neutral-500 hover:border-neutral-300'
              }`}
            >
              <div className={`w-7 h-7 rounded-lg flex items-center justify-center mx-auto mb-1 ${active ? 'bg-white/60' : cfg.bg} ${cfg.color}`}>
                {cfg.icon}
              </div>
              <p className="text-base font-bold leading-none"><CountUp value={counts[s] ?? 0} /></p>
              <p className="text-[10px] font-medium mt-0.5">{cfg.label}</p>
            </button>
          );
        })}
      </div>

      {/* Sort + Doctor filter bar */}
      <div className="flex items-center gap-2 mb-5 flex-wrap">
        {/* Doctor filter tabs */}
        <div className="flex items-center gap-1.5 flex-wrap flex-1">
          <button
            onClick={() => setDoctorFilter('all')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all border ${
              doctorFilter === 'all'
                ? 'bg-primary-600 text-white border-primary-600'
                : 'bg-white text-neutral-500 border-neutral-200 hover:border-neutral-300'
            }`}
          >
            <Users className="w-3 h-3" /> All Doctors
          </button>
          {allDoctorNames.map(name => (
            <button
              key={name}
              onClick={() => setDoctorFilter(doctorFilter === name ? 'all' : name)}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all border ${
                doctorFilter === name
                  ? 'bg-blue-600 text-white border-blue-600'
                  : 'bg-white text-neutral-500 border-neutral-200 hover:border-neutral-300'
              }`}
            >
              <Stethoscope className="w-3 h-3" /> {name}
            </button>
          ))}
        </div>

        {/* Sort dropdown */}
        <div className="relative" ref={sortRef}>
          <button
            onClick={() => setSortOpen(o => !o)}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-white border border-neutral-200 hover:border-neutral-300 text-neutral-600 text-xs font-semibold rounded-lg transition-all"
          >
            <ArrowUpDown className="w-3.5 h-3.5" />
            {SORT_LABELS[sortKey]}
            <ChevronDown className={`w-3 h-3 transition-transform ${sortOpen ? 'rotate-180' : ''}`} />
          </button>
          {sortOpen && (
            <div className="absolute right-0 top-full mt-1.5 bg-white border border-neutral-200 rounded-xl shadow-lg z-20 py-1 min-w-[160px]">
              {(Object.keys(SORT_LABELS) as SortKey[]).map(k => (
                <button
                  key={k}
                  onClick={() => { setSortKey(k); setSortOpen(false); }}
                  className={`w-full text-left px-3.5 py-2 text-xs font-medium transition-colors ${
                    sortKey === k ? 'text-primary-600 bg-primary-50' : 'text-neutral-700 hover:bg-neutral-50'
                  }`}
                >
                  {SORT_LABELS[k]}
                </button>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Orders list */}
      {loading ? (
        <div className="space-y-3">
          {[1, 2, 3].map(i => <div key={i} className="bg-white rounded-xl h-20 animate-pulse shadow-card" />)}
        </div>
      ) : displayOrders.length === 0 ? (
        <div className="text-center py-16 bg-white rounded-2xl shadow-card border border-neutral-100">
          {orders.length === 0 ? (
            <>
              <AlertCircle className="w-12 h-12 text-neutral-300 mx-auto mb-3" />
              <p className="text-neutral-500 font-medium">No orders yet</p>
              <p className="text-neutral-400 text-sm mt-1">
                {members.length === 0
                  ? 'Add doctors to your team so they can place orders'
                  : 'Your team doctors have not placed any orders yet'}
              </p>
            </>
          ) : (
            <>
              <ClipboardList className="w-12 h-12 text-neutral-300 mx-auto mb-3" />
              <p className="text-neutral-500 font-medium">No orders match this filter</p>
            </>
          )}
        </div>
      ) : (
        <div className="space-y-2">
          {displayOrders.map(order => {
            const cfg = STATUS_CONFIG[order.status];
            const isFromCenter = order.from_id === profile?.id;
            const doctorName = getDoctorName(order, profile?.id ?? '');
            return (
              <button
                key={order.id}
                onClick={() => setSelected(order)}
                className="w-full bg-white rounded-xl p-4 shadow-card hover:shadow-card-hover transition-all text-left flex items-center gap-4 group border border-transparent hover:border-primary-100"
              >
                <div className={`w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 ${cfg.bg} ${cfg.color} border ${cfg.border}`}>
                  {cfg.icon}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-0.5 flex-wrap">
                    <span className="font-semibold text-neutral-900 text-sm">{order.order_number}</span>
                    <span className={`text-xs font-medium px-2 py-0.5 rounded-full border ${cfg.bg} ${cfg.color} ${cfg.border}`}>
                      {cfg.label}
                    </span>
                    {order.parent_order_id && (
                      <span className="flex items-center gap-1 text-[11px] font-semibold text-orange-700 bg-orange-50 border border-orange-200 px-2 py-0.5 rounded-full">
                        <RefreshCw className="w-2.5 h-2.5" />
                        Redo
                      </span>
                    )}
                    {doctorName && (
                      <span className={`flex items-center gap-1 text-xs px-2 py-0.5 rounded-full border ${
                        isFromCenter
                          ? 'text-violet-600 bg-violet-50 border-violet-200'
                          : 'text-blue-600 bg-blue-50 border-blue-200'
                      }`}>
                        <Stethoscope className="w-3 h-3" />
                        {doctorName}
                      </span>
                    )}
                  </div>
                  <p className="text-sm text-neutral-600 truncate">
                    To: <span className="font-medium">{order.lab_profile?.name ?? '—'}</span>
                    {' '}&bull; Patient: {order.patient_name}
                  </p>
                  <p className="text-xs text-neutral-400 mt-0.5">File #{order.file_number}</p>
                </div>
                <div className="text-right flex-shrink-0">
                  <p className="text-xs text-neutral-400">{new Date(order.created_at).toLocaleDateString()}</p>
                  {order.due_date && (
                    <p className="text-xs text-amber-600 font-medium">
                      Due {new Date(order.due_date).toLocaleDateString()}
                    </p>
                  )}
                </div>
                <ChevronRight className="w-4 h-4 text-neutral-300 group-hover:text-primary-500 transition-colors ml-1" />
              </button>
            );
          })}
        </div>
      )}

      {selected && (
        <OrderDetailModal
          order={selected}
          isLab={false}
          onClose={() => setSelected(null)}
          onStatusChange={() => { fetchData(); setSelected(null); }}
        />
      )}

    </div>
  );
}

function StatCard({ icon, bg, value, label, index = 0 }: { icon: React.ReactNode; bg: string; value: number; label: string; index?: number }) {
  return (
    <div
      className="bg-white rounded-2xl p-5 shadow-card animate-rise-in transition-transform duration-200 hover:-translate-y-0.5 hover:shadow-lg"
      style={{ animationDelay: `${index * 70}ms` }}
    >
      <div className="flex items-center gap-3">
        <div className={`w-10 h-10 ${bg} rounded-xl flex items-center justify-center flex-shrink-0`}>
          {icon}
        </div>
        <div>
          <p className="text-2xl font-bold text-neutral-900"><CountUp value={value} /></p>
          <p className="text-sm text-neutral-500">{label}</p>
        </div>
      </div>
    </div>
  );
}
