import React, { useEffect, useMemo, useRef, useState } from 'react';
import QRCode from 'qrcode';
import { Order } from '../lib/supabase';
import { X, Printer, Download } from 'lucide-react';
import { supabase } from '../lib/supabase';

interface Props {
  order: Order;
  onClose: () => void;
}

interface Row {
  label: string;
  value: string;
}

export default function OrderSticker({ order, onClose }: Props) {
  const [qrDataUrl, setQrDataUrl] = useState('');
  const [logoDataUrl, setLogoDataUrl] = useState('');
  const [services, setServices] = useState<any[]>([]);
  const mode = 'sticker' as const;
  const iframeRef = useRef<HTMLIFrameElement | null>(null);

  useEffect(() => {
    const base = import.meta.env.VITE_SUPABASE_URL as string;
    const payload = `${base}/functions/v1/order-view?id=${order.id}`;
    QRCode.toDataURL(payload, { margin: 0, width: 512, errorCorrectionLevel: 'M' })
      .then(setQrDataUrl)
      .catch(() => setQrDataUrl(''));
  }, [order.id]);

  useEffect(() => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => {
      const c = document.createElement('canvas');
      c.width = img.naturalWidth;
      c.height = img.naturalHeight;
      const cx = c.getContext('2d');
      if (cx) {
        cx.drawImage(img, 0, 0);
        setLogoDataUrl(c.toDataURL('image/png'));
      }
    };
    img.src = '/logo_ copy 8.png';
  }, []);

  useEffect(() => {
    supabase.from('order_services').select('*').eq('order_id', order.id).then(({ data }) => {
      if (data) setServices(data);
    });
  }, [order.id]);

  const rows: Row[] = useMemo(() => {
    const dash = '\u2014';
    return [
      { label: 'Dr', value: (order.dr_name || '').trim() || dash },
      { label: 'Pt', value: (order.patient_name || '').trim() || dash },
      { label: 'File', value: (order.file_number || '').trim() || dash },
    ];
  }, [order]);

  const fmtDate = (d: string | null | undefined) => {
    if (!d) return '\u2014';
    const dt = new Date(d);
    if (isNaN(dt.getTime())) return String(d);
    return dt.toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' });
  };

  const statusLabel = (s: string | null | undefined) => {
    if (!s) return '\u2014';
    return s.replace(/_/g, ' ').replace(/\b\w/g, c => c.toUpperCase());
  };

  // ========== FULL ORDER PRINT HTML ==========
  const buildFullOrderHtml = () => `<!doctype html><html><head><meta charset="utf-8" /><title>Order ${escapeHtml(order.order_number)}</title>
<style>
  @page { size: A4; margin: 16mm; }
  * { box-sizing: border-box; }
  html, body { margin: 0; padding: 0; font-family: -apple-system, "Segoe UI", Roboto, sans-serif; -webkit-print-color-adjust: exact; print-color-adjust: exact; color: #0f172a; font-size: 11px; line-height: 1.4; }
  .header { display: flex; align-items: center; justify-content: space-between; border-bottom: 2px solid #0d9488; padding-bottom: 12px; margin-bottom: 16px; }
  .brand { display: flex; align-items: center; gap: 10px; }
  .brand img { height: 36px; width: auto; }
  .brand-text h1 { margin: 0; font-size: 18px; color: #0f172a; }
  .brand-text p { margin: 0; font-size: 9px; color: #94a3b8; }
  .order-num { text-align: right; }
  .order-num h2 { margin: 0; font-size: 18px; color: #0f172a; }
  .status-badge { display: inline-block; background: #f0fdfa; border: 1px solid #0d9488; color: #0d9488; font-size: 9px; font-weight: 700; padding: 2px 10px; border-radius: 10px; margin-top: 4px; }
  .section-title { font-size: 12px; font-weight: 700; color: #0f172a; margin: 16px 0 8px; border-bottom: 1px solid #e2e8f0; padding-bottom: 4px; }
  .grid { display: grid; grid-template-columns: 1fr 1fr; gap: 6px; }
  .card { background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 6px; padding: 8px 10px; }
  .card .label { font-size: 7.5px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.04em; color: #94a3b8; margin-bottom: 2px; }
  .card .value { font-size: 11px; font-weight: 600; color: #0f172a; word-break: break-word; }
  .parties { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; margin-top: 8px; }
  .party-card { border: 1px solid #e2e8f0; border-radius: 6px; padding: 10px; border-top: 3px solid #0d9488; }
  .party-card .party-title { font-size: 8px; font-weight: 700; color: #0d9488; text-transform: uppercase; margin-bottom: 4px; }
  .party-card .party-name { font-size: 12px; font-weight: 700; color: #0f172a; }
  .party-card .party-detail { font-size: 9px; color: #475569; margin-top: 2px; }
  table { width: 100%; border-collapse: collapse; margin-top: 8px; font-size: 10px; }
  thead th { background: #f1f5f9; border: 1px solid #e2e8f0; padding: 6px 8px; text-align: left; font-size: 8px; font-weight: 700; text-transform: uppercase; color: #64748b; }
  tbody td { border: 1px solid #f1f5f9; padding: 6px 8px; vertical-align: top; }
  tbody tr:nth-child(even) { background: #f8fafc; }
  .notes-box { background: #fefce8; border: 1px solid #fde68a; border-radius: 6px; padding: 10px; margin-top: 8px; }
  .notes-box p { margin: 0; font-size: 10px; color: #713f12; white-space: pre-wrap; word-break: break-word; }
  .redo-badge { display: inline-block; background: #fef2f2; border: 1px solid #fca5a5; color: #991b1b; font-size: 9px; font-weight: 700; padding: 3px 10px; border-radius: 4px; margin-top: 8px; }
  .footer { margin-top: 24px; padding-top: 10px; border-top: 1px solid #e2e8f0; display: flex; justify-content: space-between; font-size: 8px; color: #94a3b8; }
  .qr-section { text-align: center; margin-top: 16px; }
  .qr-section img { width: 80px; height: 80px; }
  .qr-section p { font-size: 8px; color: #94a3b8; margin-top: 4px; }
</style></head><body>
<div class="header">
  <div class="brand">
    ${logoDataUrl ? `<img src="${logoDataUrl}" alt="Bridge" />` : ''}
    <div class="brand-text"><h1>Bridge</h1><p>Dental Lab Work Order</p></div>
  </div>
  <div class="order-num">
    <h2>#${escapeHtml(order.order_number)}</h2>
    <span class="status-badge">${escapeHtml(statusLabel(order.status))}</span>
  </div>
</div>

<div class="section-title">Order Information</div>
<div class="grid">
  <div class="card"><div class="label">Order #</div><div class="value">${escapeHtml(order.order_number)}</div></div>
  <div class="card"><div class="label">Status</div><div class="value">${escapeHtml(statusLabel(order.status))}</div></div>
  <div class="card"><div class="label">Doctor</div><div class="value">${escapeHtml(order.dr_name || '\u2014')}</div></div>
  <div class="card"><div class="label">Patient</div><div class="value">${escapeHtml(order.patient_name || '\u2014')}</div></div>
  <div class="card"><div class="label">File #</div><div class="value">${escapeHtml(order.file_number || '\u2014')}</div></div>
  <div class="card"><div class="label">Shade</div><div class="value">${escapeHtml(order.shade || '\u2014')}</div></div>
  <div class="card"><div class="label">Due Date</div><div class="value">${escapeHtml(fmtDate(order.due_date))}</div></div>
  <div class="card"><div class="label">Created</div><div class="value">${escapeHtml(fmtDate(order.created_at))}</div></div>
  <div class="card"><div class="label">Try-In</div><div class="value">${order.try_in ? 'Yes' : 'No'}</div></div>
  <div class="card"><div class="label">Final Delivery</div><div class="value">${order.is_final ? 'Yes' : 'No'}</div></div>
  <div class="card"><div class="label">Bill To</div><div class="value">${escapeHtml(order.bill_to || '\u2014')}</div></div>
  <div class="card"><div class="label">Delivered At</div><div class="value">${order.delivered_at ? escapeHtml(fmtDate(order.delivered_at)) : '\u2014'}</div></div>
</div>

<div class="section-title">Parties</div>
<div class="parties">
  <div class="party-card">
    <div class="party-title">From (Clinic / Center)</div>
    <div class="party-name">${escapeHtml((order as any).from_profile?.name || '\u2014')}</div>
    <div class="party-detail">${escapeHtml((order as any).from_profile?.phone || '')}</div>
    <div class="party-detail">${escapeHtml([(order as any).from_profile?.address, (order as any).from_profile?.city].filter(Boolean).join(', ') || '\u2014')}</div>
  </div>
  <div class="party-card">
    <div class="party-title">Lab</div>
    <div class="party-name">${escapeHtml((order as any).lab_profile?.name || '\u2014')}</div>
    <div class="party-detail">${escapeHtml((order as any).lab_profile?.phone || '')}</div>
    <div class="party-detail">${escapeHtml([(order as any).lab_profile?.address, (order as any).lab_profile?.city].filter(Boolean).join(', ') || '\u2014')}</div>
  </div>
</div>

<div class="section-title">Services</div>
${services.length === 0 ? '<p style="color:#94a3b8;font-style:italic;font-size:10px;">No services listed.</p>' : `
<table>
  <thead><tr><th>Service</th><th>Teeth</th><th>Bridge</th><th>Notes</th></tr></thead>
  <tbody>${services.map(s => `<tr><td>${escapeHtml(s.service_name || '\u2014')}</td><td>${escapeHtml(s.teeth_numbers || '\u2014')}</td><td>${s.is_bridge ? 'Yes' : '\u2014'}</td><td>${escapeHtml(s.notes || '\u2014')}</td></tr>`).join('')}</tbody>
</table>`}

${order.notes ? `<div class="section-title">Order Notes</div><div class="notes-box"><p>${escapeHtml(order.notes)}</p></div>` : ''}

${order.parent_order_id ? '<div class="redo-badge">REDO \u2014 This is a redo of a previous order</div>' : ''}

<div class="qr-section">
  ${qrDataUrl ? `<img src="${qrDataUrl}" alt="QR Code" />` : ''}
  <p>Scan to view digital order</p>
</div>

<div class="footer">
  <span>Generated by Bridge &middot; ${escapeHtml(fmtDate(new Date().toISOString()))}</span>
  <span>Order #${escapeHtml(order.order_number)}</span>
</div>
</body></html>`;

  // ========== STICKER HTML (compact label) ==========
  const buildStickerHtml = () => `<!doctype html><html><head><meta charset="utf-8" /><title>Sticker ${escapeHtml(order.order_number)}</title>
<style>
  @page { size: 80mm 50mm; margin: 0; }
  * { box-sizing: border-box; }
  html, body { margin: 0; padding: 0; font-family: -apple-system, "Segoe UI", Roboto, sans-serif; -webkit-print-color-adjust: exact; print-color-adjust: exact; }
  .card { width: 80mm; height: 50mm; padding: 3mm; display: flex; gap: 3mm; align-items: stretch; background: #ffffff; }
  .qr { width: 26mm; height: 26mm; flex-shrink: 0; align-self: center; }
  .qr img { width: 100%; height: 100%; display: block; }
  .info { flex: 1; min-width: 0; display: flex; flex-direction: column; justify-content: center; gap: 0.4mm; color: #0f172a; }
  .info .num { font-weight: 800; font-size: 11pt; letter-spacing: -0.02em; color: #0f172a; line-height: 1.05; margin-bottom: 0.6mm; }
  .info .row { font-size: 7pt; line-height: 1.2; color: #0f172a; word-wrap: break-word; overflow-wrap: anywhere; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
  .info .row .lbl { color: #64748b; font-size: 5.5pt; font-weight: 700; text-transform: uppercase; letter-spacing: 0.04em; margin-right: 1mm; }
  .info .row .val { font-weight: 600; }
  .brand { margin-top: 0.6mm; display: flex; align-items: center; }
  .brand img { height: 5mm; width: auto; display: block; }
</style></head><body>
<div class="card">
  <div class="qr"><img src="${qrDataUrl}" alt="QR" /></div>
  <div class="info">
    <div class="num">#${escapeHtml(order.order_number)}</div>
    ${rows.map(r => `<div class="row"><span class="lbl">${escapeHtml(r.label)}</span><span class="val">${escapeHtml(r.value)}</span></div>`).join('')}
    <div class="brand"><img src="${logoDataUrl}" alt="Bridge" /></div>
  </div>
</div>
</body></html>`;

  const handlePrint = () => {
    if (!qrDataUrl) return;
    const iframe = iframeRef.current;
    if (!iframe) return;
    const doc = iframe.contentDocument;
    const win = iframe.contentWindow;
    if (!doc || !win) return;

    doc.open();
    doc.write(mode === 'full' ? buildFullOrderHtml() : buildStickerHtml());
    doc.close();

    const runPrint = () => {
      try { win.focus(); win.print(); } catch { /* ignore */ }
    };

    const imgs = doc.querySelectorAll('img');
    let loaded = 0;
    const total = imgs.length;
    if (total === 0) { setTimeout(runPrint, 120); return; }
    const onLoad = () => { loaded++; if (loaded >= total) setTimeout(runPrint, 100); };
    imgs.forEach(img => {
      if (img.complete && img.naturalWidth > 0) onLoad();
      else { img.addEventListener('load', onLoad); img.addEventListener('error', onLoad); }
    });
  };

  const handleDownloadPdf = () => {
    const base = import.meta.env.VITE_SUPABASE_URL as string;
    const anonKey = import.meta.env.VITE_SUPABASE_ANON_KEY as string;
    const pdfUrl = `${base}/functions/v1/order-view?id=${order.id}`;
    
    supabase.auth.getSession().then(({ data }) => {
      const token = data.session?.access_token || anonKey;
      window.open(`${pdfUrl}`, '_blank');
    });
  };

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm transform-gpu flex items-center justify-center z-[70] p-4 pt-[env(safe-area-inset-top,16px)] pb-[env(safe-area-inset-bottom,16px)] px-[max(env(safe-area-inset-left,16px),16px)] animate-modal-in">
      <div className="bg-white rounded-2xl shadow-modal w-full max-w-[90vw] sm:max-w-lg max-h-[85vh] overflow-y-auto break-words">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-neutral-200">
          <div>
            <h2 className="font-bold text-neutral-900">Print Order</h2>
            <p className="text-xs text-neutral-500">Full work order or compact sticker label</p>
          </div>
          <button onClick={onClose} className="w-8 h-8 flex items-center justify-center rounded-lg hover:bg-neutral-100 transition-colors">
            <X className="w-4 h-4" />
          </button>
        </div>



        {/* Preview */}
        <div className="p-4">
          <div className="flex justify-center bg-neutral-50 rounded-xl border border-neutral-200 p-4">
            <div
              className="bg-white rounded-xl border border-neutral-200 shadow-sm p-3 flex items-center gap-3 w-full max-w-sm"
              style={{ aspectRatio: '80 / 50' }}
            >
              <div className="w-24 h-24 flex-shrink-0 flex items-center justify-center bg-white rounded-md border border-neutral-100">
                {qrDataUrl
                  ? <img src={qrDataUrl} alt="Order QR" className="w-full h-full" />
                  : <div className="w-full h-full animate-pulse bg-neutral-100" />
                }
              </div>
              <div className="flex-1 min-w-0 text-[10px] leading-tight text-neutral-800 space-y-[1px]">
                <p className="font-extrabold text-sm text-neutral-900 truncate mb-0.5">#{order.order_number}</p>
                {rows.map(r => (
                  <p key={r.label} className="truncate">
                    <span className="text-neutral-500 text-[8px] font-bold uppercase tracking-wider mr-1">{r.label}</span>
                    <span className="font-semibold">{r.value}</span>
                  </p>
                ))}
                {logoDataUrl && <img src={logoDataUrl} alt="Bridge" className="h-3 w-auto object-contain mt-1" />}
              </div>
            </div>
          </div>
        </div>

        {/* Actions */}
        <div className="p-4 border-t border-neutral-200 grid grid-cols-3 gap-2">
          <button onClick={onClose} className="py-2.5 border border-neutral-300 text-neutral-700 font-semibold rounded-xl text-sm hover:bg-neutral-50 active:scale-[0.98] transition-all duration-200">
            Close
          </button>
          <button onClick={handleDownloadPdf} disabled={!qrDataUrl}
            className="flex items-center justify-center gap-1.5 py-2.5 border border-teal-300 text-teal-700 font-semibold rounded-xl text-sm hover:bg-teal-50 disabled:opacity-50 active:scale-[0.98] transition-all duration-200">
            <Download className="w-3.5 h-3.5" /> PDF
          </button>
          <button onClick={handlePrint} disabled={!qrDataUrl}
            className="flex items-center justify-center gap-1.5 py-2.5 bg-teal-600 hover:bg-teal-700 disabled:bg-teal-400 text-white font-semibold rounded-xl text-sm active:scale-[0.98] transition-all duration-200">
            <Printer className="w-4 h-4" /> Print
          </button>
        </div>
      </div>

      <iframe
        ref={iframeRef}
        title="print-frame"
        style={{ position: 'fixed', right: 0, bottom: 0, width: 0, height: 0, border: 0, opacity: 0, pointerEvents: 'none' }}
      />
    </div>
  );
}

function escapeHtml(s: string | null | undefined): string {
  return (s ?? '').replace(/[&<>"']/g, ch => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[ch] as string));
}
