import React, { useState, useEffect, useRef } from 'react';
import { supabase, signedAttachmentUrl, Order, OrderStatus, OrderComment, LabReview } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { X, Paperclip, User, FileText, Palette, Grid3x3, Calendar, MessageSquare, CheckCircle2, Printer, Send, RefreshCw, AlertTriangle, Pencil, Receipt, Wallet, Building2, MapPin, Navigation, Hash, Package, Loader2, FlaskConical, Star, QrCode } from 'lucide-react';
import NewOrderModal from './NewOrderModal';
import OrderSticker from './OrderSticker';

/** Exchanges a stored attachment link for a short-lived signed link. */
function useSignedAttachment(url: string | null | undefined): string | null {
  const [signed, setSigned] = useState<string | null>(null);
  useEffect(() => {
    let alive = true;
    signedAttachmentUrl(url).then(u => { if (alive) setSigned(u); });
    return () => { alive = false; };
  }, [url]);
  return signed;
}

function AttachmentLink({ url, className, download, children }: {
  url: string | null | undefined;
  className?: string;
  download?: string;
  children: React.ReactNode;
}) {
  const href = useSignedAttachment(url);
  return (
    <a
      href={href ?? undefined}
      onClick={e => { if (!href) e.preventDefault(); }}
      target="_blank"
      rel="noreferrer"
      download={download}
      className={className}
    >
      {children}
    </a>
  );
}

function AttachmentImage({ url, alt, className }: { url: string | null | undefined; alt: string; className?: string }) {
  const src = useSignedAttachment(url);
  if (!src) return <div className={`${className ?? ''} bg-neutral-200 animate-pulse h-24`} />;
  return <img src={src} alt={alt} className={className} />;
}

const STATUS_TRANSITIONS: Record<OrderStatus, OrderStatus[]> = {
  pending:     ['accepted', 'rejected'],
  accepted:    ['in_progress', 'rejected'],
  in_progress: ['completed'],
  completed:   ['delivered'],
  delivering:  ['delivered'],
  delivered:   [],
  try_in:      ['delivered'],
  redo:        ['in_progress', 'rejected'],
  rejected:    [],
  cancelled:   [],
};

// For try-in cases, the lab sends the case directly to try-in from in_progress (skipping completed).
// The doctor approves the try-in, which returns the order to pending with is_final=true ("Final Case").
// The lab then completes and delivers normally.
const TRY_IN_TRANSITIONS: Record<OrderStatus, OrderStatus[]> = {
  ...STATUS_TRANSITIONS,
  in_progress: ['try_in'],
  try_in:     [],
};

// After doctor approves try-in, order is back in pending with is_final=true.
// Lab re-accepts and goes through the full normal flow (pending → accepted → in_progress → completed → delivering → delivered).
const FINAL_CASE_TRANSITIONS: Record<OrderStatus, OrderStatus[]> = {
  ...STATUS_TRANSITIONS,
};

const STATUS_LABELS: Record<OrderStatus, string> = {
  pending: 'Pending', accepted: 'Accepted', in_progress: 'In Progress',
  completed: 'Completed', try_in: 'Try In', delivering: 'Delivering', delivered: 'Delivered',
  rejected: 'Rejected', cancelled: 'Cancelled', redo: 'Redo',
};

const statusColor: Record<OrderStatus, string> = {
  pending:     'bg-amber-50 text-amber-700 border-amber-200',
  accepted:    'bg-blue-50 text-blue-700 border-blue-200',
  in_progress: 'bg-primary-50 text-primary-700 border-primary-200',
  completed:   'bg-teal-50 text-teal-700 border-teal-200',
  try_in:      'bg-amber-50 text-amber-700 border-amber-300',
  delivering:  'bg-cyan-50 text-cyan-700 border-cyan-200',
  delivered:   'bg-emerald-50 text-emerald-700 border-emerald-200',
  rejected:    'bg-red-50 text-red-700 border-red-200',
  cancelled:   'bg-neutral-100 text-neutral-600 border-neutral-200',
  redo:        'bg-orange-50 text-orange-700 border-orange-200',
};

// ─── Print HTML generator ───────────────────────────────────────────────────────

// Every value that reaches the printable document must be escaped: order fields,
// profile names and comment bodies are written by other accounts and would
// otherwise be able to inject markup into the print frame.
function esc(value: unknown): string {
  if (value === null || value === undefined) return '';
  return String(value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

// Only allow image sources we know are inert URLs.
function escUrl(value: unknown): string {
  const raw = String(value ?? '').trim();
  if (!/^(https?:\/\/|\/)/i.test(raw)) return '';
  return esc(raw);
}

function generatePrintHTML(order: Order, comments: OrderComment[], parentOrderNumber?: string | null): string {
  const fromProfile = order.from_profile;
  const labProfile  = order.lab_profile;
  const fromName    = esc(fromProfile?.name ?? '—');
  const labName     = esc(labProfile?.name  ?? '—');
  const fromCity    = esc(fromProfile?.city    ?? '');
  const labCity     = esc(labProfile?.city     ?? '');
  const fromPhone   = esc(fromProfile?.phone   ?? '');
  const labPhone    = esc(labProfile?.phone    ?? '');
  const fromLogo    = escUrl(fromProfile?.logo_url ?? '');
  const labLogo     = escUrl(labProfile?.logo_url  ?? '');
  const fromAddress = esc(fromProfile?.address ?? '');
  const labAddress  = esc(labProfile?.address  ?? '');
  const fromCode    = esc(fromProfile?.profile_code ?? '');
  const labCode     = esc(labProfile?.profile_code  ?? '');
  const fromRole    = (fromProfile?.role ?? 'doctor') as 'center' | 'doctor' | 'lab';
  const billToLabel = order.bill_to === 'center' ? 'Dental Center' : 'Doctor';
  const isRedo      = !!order.parent_order_id;

  // Cash order (bill_to = doctor): the ordering party is the doctor, not the center.
  // Use dr_name as the party name; center contact details don't apply to the doctor.
  const isCashOrder = order.bill_to === 'doctor' && fromRole === 'center';
  const fromRoleLabel = isCashOrder ? 'Doctor' : (fromRole === 'center' ? 'Dental Center' : 'Doctor');
  const partyName  = isCashOrder ? (esc(order.dr_name) || fromName) : fromName;
  const partyCode  = isCashOrder ? '' : fromCode;
  const partyAddr  = isCashOrder ? '' : fromAddress;
  const partyCityV = isCashOrder ? '' : fromCity;
  const partyPhone = isCashOrder ? '' : fromPhone;
  const partyLogo  = isCashOrder ? '' : fromLogo;

  const selected = new Set<number>(
    (order.teeth_numbers ?? '').split(/[,\s]+/)
      .map(t => parseInt(t.trim()))
      .filter(n => !isNaN(n))
  );

  const statusColors: Record<OrderStatus, { bg: string; text: string; border: string }> = {
    pending:     { bg: '#fffbeb', text: '#b45309', border: '#fcd34d' },
    accepted:    { bg: '#eff6ff', text: '#1d4ed8', border: '#93c5fd' },
    in_progress: { bg: '#eff6ff', text: '#1d4ed8', border: '#60a5fa' },
    completed:   { bg: '#f0fdf4', text: '#15803d', border: '#86efac' },
    try_in:      { bg: '#fffbeb', text: '#b45309', border: '#fcd34d' },
    delivering:  { bg: '#cffafe', text: '#155e75', border: '#67e8f9' },
    delivered:   { bg: '#d1fae5', text: '#065f46', border: '#6ee7b7' },
    rejected:    { bg: '#fef2f2', text: '#dc2626', border: '#fca5a5' },
    cancelled:   { bg: '#f5f5f5', text: '#525252', border: '#d4d4d4' },
    redo:        { bg: '#fff7ed', text: '#c2410c', border: '#fed7aa' },
  };
  const sc = statusColors[order.status] ?? statusColors.pending;

  const row3 = (a: string, av: string, b: string, bv: string, c: string, cv: string) =>
    `<tr><td class="lbl">${esc(a)}</td><td class="val">${esc(av)}</td><td class="lbl">${esc(b)}</td><td class="val">${esc(bv)}</td><td class="lbl">${esc(c)}</td><td class="val">${esc(cv)}</td></tr>`;

  const attachRows = order.attachments && order.attachments.length > 0
    ? order.attachments.map(a =>
        `<div class="att-item">
          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="#94a3b8" stroke-width="2" style="flex-shrink:0"><path d="M21.44 11.05l-9.19 9.19a6 6 0 0 1-8.49-8.49l9.19-9.19a4 4 0 0 1 5.66 5.66l-9.2 9.19a2 2 0 0 1-2.83-2.83l8.49-8.48"/></svg>
          <span style="flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${esc(a.file_name)}</span>
          ${a.file_size ? `<span style="color:#94a3b8;white-space:nowrap">${(a.file_size/1024).toFixed(1)} KB</span>` : ''}
        </div>`).join('')
    : '<p style="color:#94a3b8;font-size:11px;margin:0">No attachments</p>';

  const partyCard = (logo: string, label: string, name: string, address: string, city: string, phone: string, code: string) => `
    <div class="party-card">
      <div class="party-label">${label}</div>
      <div class="party-inner">
        ${logo ? `<img src="${logo}" class="party-logo" alt="logo"/>` : `<div class="party-avatar"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#0d9488" stroke-width="2"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9,22 9,12 15,12 15,22"/></svg></div>`}
        <div>
          <div class="party-name">${name}</div>
          ${code ? `<div class="party-sub" style="font-weight:600;color:#0d9488">Code: ${code}</div>` : ''}
          ${address ? `<div class="party-sub">${address}${city ? ', ' + city : ''}</div>` : city ? `<div class="party-sub">${city}</div>` : ''}
          ${phone ? `<div class="party-sub">${phone}</div>` : ''}
        </div>
      </div>
    </div>`;

  return `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Dental Lab Order — ${esc(order.order_number)}</title>
<style>
  @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap');
  *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

  @page { size: A4 portrait; margin: 1.8cm 1.8cm 1.8cm 1.8cm; }

  html { width: 210mm; }
  body {
    font-family: 'Inter', system-ui, -apple-system, sans-serif;
    font-size: 11px;
    color: #0f172a;
    background: #fff;
    width: 100%;
    -webkit-print-color-adjust: exact;
    print-color-adjust: exact;
  }

  /* ── Header ── */
  .header {
    display: flex; align-items: center; justify-content: space-between;
    padding-bottom: 14px; border-bottom: 2.5px solid #0d9488; margin-bottom: 18px;
  }
  .brand { display: flex; align-items: center; gap: 10px; }
  .brand-icon {
    width: 38px; height: 38px; background: #0d9488; border-radius: 10px;
    display: flex; align-items: center; justify-content: center;
  }
  .brand-name { font-size: 20px; font-weight: 800; color: #1e3a8a; letter-spacing: -0.5px; }
  .brand-tag  { font-size: 9px; color: #64748b; font-weight: 500; letter-spacing: 1px; text-transform: uppercase; }
  .header-right { text-align: right; }
  .order-num { font-size: 17px; font-weight: 800; color: #0f172a; letter-spacing: -0.3px; }
  .order-date { font-size: 10px; color: #64748b; margin-top: 2px; }
  .status-badge {
    display: inline-block; margin-top: 5px;
    padding: 3px 10px; border-radius: 20px; font-size: 10px; font-weight: 700;
    text-transform: uppercase; letter-spacing: 0.6px; border: 1px solid;
    background: ${sc.bg}; color: ${sc.text}; border-color: ${sc.border};
  }

  /* ── Parties ── */
  .parties { display: grid; grid-template-columns: 1fr 40px 1fr; gap: 10px; align-items: center; margin-bottom: 16px; }
  .party-card { background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 10px; padding: 12px; }
  .party-label { font-size: 8.5px; font-weight: 700; text-transform: uppercase; letter-spacing: 1px; color: #94a3b8; margin-bottom: 8px; }
  .party-inner { display: flex; align-items: center; gap: 10px; }
  .party-logo { width: 36px; height: 36px; border-radius: 8px; object-fit: cover; flex-shrink: 0; }
  .party-avatar { width: 36px; height: 36px; background: #eff6ff; border-radius: 8px; display: flex; align-items: center; justify-content: center; flex-shrink: 0; }
  .party-name { font-size: 13px; font-weight: 700; color: #0f172a; }
  .party-sub  { font-size: 10px; color: #64748b; margin-top: 1px; }
  .arrow-box { display: flex; justify-content: center; align-items: center; }

  /* ── Section title ── */
  .section { margin-bottom: 14px; }
  .section-title {
    font-size: 8.5px; font-weight: 700; text-transform: uppercase; letter-spacing: 1px;
    color: #94a3b8; margin-bottom: 8px; padding-bottom: 5px;
    border-bottom: 1px solid #f1f5f9;
  }

  /* ── Patient table ── */
  .patient-table { width: 100%; border-collapse: collapse; background: #f8fafc; border-radius: 10px; overflow: hidden; border: 1px solid #e2e8f0; }
  .patient-table tr:not(:last-child) { border-bottom: 1px solid #e2e8f0; }
  .patient-table td { padding: 8px 12px; }
  .patient-table td.lbl { font-size: 9px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.6px; color: #94a3b8; white-space: nowrap; width: 80px; }
  .patient-table td.val { font-size: 12px; font-weight: 600; color: #0f172a; }
  .patient-table td.lbl:nth-child(3), .patient-table td.lbl:nth-child(5) { border-left: 1px solid #e2e8f0; }

  /* ── Teeth badges ── */
  .chart-wrapper {
    border: 1px solid #e2e8f0; border-radius: 10px; overflow: hidden;
    background: #fff;
  }
  .chart-header {
    background: #f8fafc; border-bottom: 1px solid #e2e8f0;
    padding: 7px 14px; font-size: 8.5px; font-weight: 700;
    text-transform: uppercase; letter-spacing: 1px; color: #64748b;
    display: flex; justify-content: space-between; align-items: center;
  }
  .chart-body { padding: 10px 14px; }
  .teeth-rows { display: flex; flex-direction: column; gap: 6px; }
  .teeth-row { display: flex; align-items: center; gap: 4px; flex-wrap: wrap; }
  .teeth-row-label { font-size: 8px; font-weight: 700; color: #94a3b8; text-transform: uppercase; letter-spacing: 0.5px; width: 52px; flex-shrink: 0; }
  .teeth-divider { width: 10px; flex-shrink: 0; }
  .t { display: inline-flex; align-items: center; justify-content: center; width: 24px; height: 24px; border-radius: 6px; font-size: 10px; font-weight: 500; border: 1px solid #d1d5db; background: #f9fafb; color: #374151; }
  .t.sel { background: #0d9488; border-color: #1d4ed8; color: #fff; font-weight: 700; }

  /* ── Notes ── */
  .notes-box {
    background: #fffbeb; border: 1px solid #fde68a; border-radius: 10px; padding: 12px;
    font-size: 12px; color: #78350f; line-height: 1.6; word-break: break-word; white-space: pre-wrap;
  }

  /* ── Attachments ── */
  .att-list { display: flex; flex-direction: column; gap: 4px; }
  .att-item {
    display: flex; align-items: center; gap: 8px;
    background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 6px;
    padding: 6px 10px; font-size: 11px; color: #334155;
  }

  /* ── Multi-service list ── */
  .svc-list { display: flex; flex-direction: column; gap: 6px; }
  .svc-item { background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; padding: 8px 12px; page-break-inside: avoid; }
  .svc-item.custom { background: #fffbeb; border-color: #fde68a; }
  .svc-head { display: flex; align-items: center; gap: 8px; }
  .svc-num { width: 18px; height: 18px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 9px; font-weight: 700; background: #dbeafe; color: #1e40af; flex-shrink: 0; }
  .svc-num.custom { background: #fef3c7; color: #92400e; }
  .svc-name { font-size: 11px; font-weight: 700; color: #0f172a; }
  .svc-tag { font-size: 8px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.4px; background: #fff7ed; color: #b45309; border: 1px solid #fdba74; padding: 1px 5px; border-radius: 4px; }
  .svc-desc { font-size: 10px; color: #64748b; margin-top: 3px; margin-left: 26px; }
  .svc-meta { display: flex; gap: 14px; margin-top: 4px; margin-left: 26px; font-size: 10px; color: #475569; }
  .svc-meta span { display: flex; align-items: center; gap: 3px; }
  .svc-notes { font-size: 10px; color: #78350f; font-style: italic; margin-top: 4px; margin-left: 26px; }

  /* ── Page break helpers ── */
  .section { margin-bottom: 14px; page-break-inside: avoid; }
  .chart-wrapper { page-break-inside: avoid; }
  .parties { page-break-inside: avoid; }

  /* ── Footer / Signatures ── */
  .footer { margin-top: 20px; padding-top: 14px; border-top: 1px solid #e2e8f0; page-break-inside: avoid; }
  .sig-grid { display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 24px; margin-bottom: 12px; }
  .sig-box { }
  .sig-line { border-top: 1.5px solid #cbd5e1; padding-top: 5px; margin-top: 28px; }
  .sig-label { font-size: 9px; color: #94a3b8; font-weight: 600; text-transform: uppercase; letter-spacing: 0.5px; }
  .footer-meta { display: flex; justify-content: space-between; font-size: 9px; color: #94a3b8; }

  /* ── Print overrides ── */
  @media print {
    body { padding: 0; }
    .chart-wrapper, .patient-table, .party-card { -webkit-print-color-adjust: exact; print-color-adjust: exact; }
    svg { -webkit-print-color-adjust: exact; print-color-adjust: exact; }
  }

  /* ── Conversation ── */
  .conv-list { display: flex; flex-direction: column; gap: 8px; }
  .msg { border-radius: 10px; padding: 9px 12px; border: 1px solid; max-width: 100%; page-break-inside: avoid; }
  .msg-clinic { background: #f0f9ff; border-color: #bae6fd; }
  .msg-lab    { background: #f0fdf4; border-color: #bbf7d0; }
  .msg-header { display: flex; align-items: center; gap: 8px; margin-bottom: 5px; }
  .msg-avatar {
    width: 22px; height: 22px; border-radius: 50%;
    display: flex; align-items: center; justify-content: center;
    font-size: 9px; font-weight: 700; color: #fff; flex-shrink: 0;
  }
  .msg-avatar-clinic { background: #0d9488; }
  .msg-avatar-lab    { background: #16a34a; }
  .msg-sender { font-size: 10px; font-weight: 700; color: #374151; }
  .msg-role   { font-size: 9px; color: #94a3b8; font-weight: 500; }
  .msg-time   { margin-left: auto; font-size: 9px; color: #94a3b8; white-space: nowrap; }
  .msg-body   { font-size: 11px; color: #1e293b; line-height: 1.55; white-space: pre-wrap; word-break: break-word; }
  .conv-empty { color: #94a3b8; font-size: 11px; text-align: center; padding: 12px 0; font-style: italic; }
</style>
</head>
<body>

<!-- HEADER -->
<div class="header">
  <div class="brand">
    <img class="brand-icon" src="https://www.bridge-86.com/logo_%20copy%208.png" alt="Bridge logo" />
    <div>
      <div class="brand-name">Bridge</div>
      <div class="brand-tag">Lab Order Form</div>
    </div>
  </div>
  <div class="header-right">
    <div class="order-num">${esc(order.order_number)}</div>
    <div class="order-date">Issued: ${new Date(order.created_at).toLocaleDateString('en-GB', { day:'2-digit', month:'short', year:'numeric' })}</div>
    <div><span class="status-badge">${STATUS_LABELS[order.status]}</span></div>
  </div>
</div>

<!-- PARTIES -->
<div class="parties">
  ${partyCard(partyLogo, fromRoleLabel, partyName, partyAddr, partyCityV, partyPhone, partyCode)}
  <div class="arrow-box">
    <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#0d9488" stroke-width="2">
      <line x1="5" y1="12" x2="19" y2="12"/><polyline points="12,5 19,12 12,19"/>
    </svg>
  </div>
  ${partyCard(labLogo, 'Dental Laboratory', labName, labAddress, labCity, labPhone, labCode)}
</div>

<!-- PATIENT DETAILS -->
<div class="section">
  <div class="section-title">Patient &amp; Case Information</div>
  <table class="patient-table">
    <tbody>
      ${row3('File No.', order.file_number, 'Patient Name', order.patient_name, 'Doctor', order.dr_name)}
      ${row3('Shade', order.shade ?? '—', 'Service', order.service?.name ?? '—', 'Due Date', order.due_date ? new Date(order.due_date).toLocaleDateString('en-GB',{day:'2-digit',month:'short',year:'numeric'}) : '—')}
      ${row3(
        'Bill To',
        billToLabel,
        'Order Type',
        isRedo ? `Redo${parentOrderNumber ? ' of ' + parentOrderNumber : ''}` : 'New',
        'Teeth (FDI)',
        order.teeth_numbers ?? '—'
      )}
      ${order.try_in
        ? `<tr><td class="lbl">Try In</td><td class="val" colspan="5" style="color:#b45309">Yes — case needs try-in before final fit</td></tr>`
        : ''}
      ${(order.service?.price_from || order.service?.price_to || order.service?.turnaround_days)
        ? row3(
            'Price Range',
            order.service?.price_from || order.service?.price_to
              ? (order.service.price_from && order.service.price_to
                  ? `${order.service.price_from} – ${order.service.price_to}`
                  : order.service.price_from ? `From ${order.service.price_from}` : `Up to ${order.service.price_to}`)
              : '—',
            'Turnaround',
            order.service?.turnaround_days ? `${order.service.turnaround_days} days` : '—',
            'Last Updated',
            new Date(order.updated_at).toLocaleDateString('en-GB',{day:'2-digit',month:'short',year:'numeric'})
          )
        : ''}
      ${order.service?.description
        ? `<tr><td class="lbl">Service Desc.</td><td class="val" colspan="5">${esc(order.service.description)}</td></tr>`
        : ''}
      ${order.delivered_at
        ? `<tr><td class="lbl">Delivered</td><td class="val" colspan="5" style="color:#15803d">Yes — ${new Date(order.delivered_at).toLocaleString('en-GB',{day:'2-digit',month:'short',hour:'2-digit',minute:'2-digit'})}</td></tr>`
        : ''}
    </tbody>
  </table>
</div>

<!-- DENTAL CHART -->
<div class="section">
  <div class="section-title">Dental Chart</div>
  <div class="chart-wrapper">
    <div class="chart-header">
      <span>Teeth — FDI Notation</span>
      ${selected.size > 0
        ? `<span style="font-size:10px;color:#0d9488;font-weight:600">Selected: ${Array.from(selected).sort((a,b)=>a-b).join(', ')}</span>`
        : '<span style="font-size:10px;color:#94a3b8;font-weight:400">No specific teeth selected</span>'}
    </div>
    <div class="chart-body">
      <div class="teeth-rows">
        <div class="teeth-row">
          <span class="teeth-row-label">Upper R</span>
          ${[18,17,16,15,14,13,12,11].map(n=>`<span class="t${selected.has(n)?' sel':''}">${n}</span>`).join('')}
          <span class="teeth-divider"></span>
          ${[21,22,23,24,25,26,27,28].map(n=>`<span class="t${selected.has(n)?' sel':''}">${n}</span>`).join('')}
          <span class="teeth-row-label" style="text-align:right">Upper L</span>
        </div>
        <div class="teeth-row">
          <span class="teeth-row-label">Lower R</span>
          ${[48,47,46,45,44,43,42,41].map(n=>`<span class="t${selected.has(n)?' sel':''}">${n}</span>`).join('')}
          <span class="teeth-divider"></span>
          ${[31,32,33,34,35,36,37,38].map(n=>`<span class="t${selected.has(n)?' sel':''}">${n}</span>`).join('')}
          <span class="teeth-row-label" style="text-align:right">Lower L</span>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- MULTI-SERVICE BREAKDOWN -->
${order.order_services && order.order_services.length > 0 ? `
<div class="section">
  <div class="section-title">Services Breakdown (${order.order_services.length})</div>
  <div class="svc-list">
    ${order.order_services.map((s, i) => {
      const isCustom = !s.service_id;
      return `<div class="svc-item${isCustom ? ' custom' : ''}">
        <div class="svc-head">
          <span class="svc-num${isCustom ? ' custom' : ''}">${i + 1}</span>
          <span class="svc-name">${esc(s.service_name)}</span>
          ${isCustom ? '<span class="svc-tag">Custom</span>' : ''}
        </div>
        ${s.service?.description ? `<div class="svc-desc">${esc(s.service.description)}</div>` : ''}
        <div class="svc-meta">
          ${s.teeth_numbers ? `<span><strong>Teeth:</strong> ${esc(s.teeth_numbers)}</span>` : ''}
          ${s.service?.turnaround_days ? `<span><strong>Turnaround:</strong> ${s.service.turnaround_days} days</span>` : ''}
          ${(s.service?.price_from || s.service?.price_to)
            ? `<span><strong>Est. Price:</strong> ${
                s.service?.price_from && s.service?.price_to
                  ? `${s.service.price_from} – ${s.service.price_to}`
                  : s.service?.price_from ? `From ${s.service.price_from}` : `Up to ${s.service.price_to}`
              }</span>`
            : ''}
        </div>
        ${s.notes ? `<div class="svc-notes">"${esc(s.notes)}"</div>` : ''}
      </div>`;
    }).join('')}
  </div>
</div>` : ''}

<!-- NOTES -->
${order.notes ? `
<div class="section">
  <div class="section-title">Clinical Notes &amp; Instructions</div>
  <div class="notes-box">${esc(order.notes)}</div>
</div>` : ''}

<!-- ATTACHMENTS -->
<div class="section">
  <div class="section-title">Attachments (${order.attachments?.length ?? 0} file${(order.attachments?.length ?? 0) !== 1 ? 's' : ''})</div>
  <div class="att-list">${attachRows}</div>
</div>

<!-- CONVERSATION -->
<div class="section">
  <div class="section-title">Conversation (${comments.length} message${comments.length !== 1 ? 's' : ''})</div>
  ${comments.length === 0
    ? '<div class="conv-empty">No messages in this order conversation.</div>'
    : `<div class="conv-list">
        ${comments.map(c => {
          const isClinic = c.author_id === order.from_id;
          const cls      = isClinic ? 'msg-clinic' : 'msg-lab';
          const avCls    = isClinic ? 'msg-avatar-clinic' : 'msg-avatar-lab';
          const roleTag  = isClinic ? 'Clinic' : 'Lab';
          const initials = (c.author?.name ?? '?').charAt(0).toUpperCase();
          const dt = new Date(c.created_at);
          const dateStr  = dt.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' });
          const timeStr  = dt.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
          const isRtl    = /[\u0600-\u06FF]/.test(c.body);
          return `<div class="msg ${cls}">
            <div class="msg-header">
              <div class="msg-avatar ${avCls}">${esc(initials)}</div>
              <span class="msg-sender">${esc(c.author?.name ?? '—')}</span>
              <span class="msg-role">${esc(roleTag)}</span>
              <span class="msg-time">${dateStr} ${timeStr}</span>
            </div>
            <div class="msg-body" ${isRtl ? 'dir="rtl" style="text-align:right"' : ''}>${esc(c.body)}</div>
          </div>`;
        }).join('')}
       </div>`
  }
</div>

<!-- SIGNATURES / FOOTER -->
<div class="footer">
  <div class="sig-grid">
    <div class="sig-box">
      <div class="sig-line"><div class="sig-label">Authorized By (Clinic / Doctor)</div></div>
    </div>
    <div class="sig-box">
      <div class="sig-line"><div class="sig-label">Received By (Lab)</div></div>
    </div>
    <div class="sig-box">
      <div class="sig-line"><div class="sig-label">Delivery Date</div></div>
    </div>
  </div>
  <div class="footer-meta">
    <span>Generated: ${new Date().toLocaleString('en-GB', { day:'2-digit', month:'short', year:'numeric', hour:'2-digit', minute:'2-digit' })}</span>
    <span>Bridge — Lab Ordering Platform &nbsp;·&nbsp; ${esc(order.order_number)}</span>
  </div>
</div>

</body>
</html>`;
}

// ─── React component ────────────────────────────────────────────────────────────

interface Props {
  order: Order;
  isLab: boolean;
  onClose: () => void;
  onStatusChange: () => void;
  onRead?: (orderId: string) => void;
}

export default function OrderDetailModal({ order, isLab, onClose, onStatusChange, onRead }: Props) {
  const { profile } = useAuth();
  const [updating, setUpdating] = useState(false);
  const [error, setError] = useState('');
  const [comments, setComments] = useState<OrderComment[]>([]);
  const [newComment, setNewComment] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [pendingFile, setPendingFile] = useState<File | null>(null);
  const [uploading, setUploading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [showRedoDialog, setShowRedoDialog] = useState(false);
  const [redoReason, setRedoReason] = useState('');
  const [parentOrderNumber, setParentOrderNumber] = useState<string | null>(null);
  const commentsEndRef = useRef<HTMLDivElement>(null);
  const [existingReview, setExistingReview] = useState<LabReview | null>(null);
  const [reviewRating, setReviewRating] = useState(0);
  const [reviewHover, setReviewHover] = useState(0);
  const [reviewComment, setReviewComment] = useState('');
  const [submittingReview, setSubmittingReview] = useState(false);
  const [reviewError, setReviewError] = useState('');

  const canReview = !isLab && order.status === 'delivered' && profile?.role !== 'center';

  // Lab transitions come from STATUS_TRANSITIONS; non-lab can only cancel a pending order
  // For try-in cases, use the alternate flow: completed → try_in → delivering → delivered
  const transitions = isLab
    ? (order.is_final
        ? FINAL_CASE_TRANSITIONS[order.status]
        : order.try_in
          ? TRY_IN_TRANSITIONS[order.status]
          : STATUS_TRANSITIONS[order.status])
    : (order.status === 'pending'
        ? ['cancelled' as OrderStatus]
        : []);

  // Doctor can request redo on delivered or try_in orders, but only within 30 days of delivery.
  const REDO_WINDOW_DAYS = 30;
  const redoDeadline = order.delivered_at
    ? new Date(new Date(order.delivered_at).getTime() + REDO_WINDOW_DAYS * 24 * 60 * 60 * 1000)
    : null;
  const now = new Date();
  const redoWindowExpired = order.status === 'delivered' && !!redoDeadline && now > redoDeadline;
  const daysSinceDelivered = order.delivered_at
    ? Math.floor((now.getTime() - new Date(order.delivered_at).getTime()) / (24 * 60 * 60 * 1000))
    : null;
  const daysLeftForRedo = order.status === 'delivered' && redoDeadline
    ? Math.max(0, Math.ceil((redoDeadline.getTime() - now.getTime()) / (24 * 60 * 60 * 1000)))
    : null;
  const canRequestRedo =
    !isLab &&
    (order.status === 'try_in' || (order.status === 'delivered' && !redoWindowExpired)) &&
    profile?.role !== 'center';
  // Doctor can approve try-in and send to final delivery
  const canApproveTryIn = !isLab && order.status === 'try_in';
  // Doctor/center can edit their own pending orders
  const canEdit = !isLab && order.status === 'pending';
  const [showEdit, setShowEdit] = useState(false);
  const [showSticker, setShowSticker] = useState(false);

  // Fetch parent order number for redo cases
  useEffect(() => {
    if (!order.parent_order_id) return;
    supabase
      .from('orders')
      .select('order_number')
      .eq('id', order.parent_order_id)
      .maybeSingle()
      .then(({ data }) => { if (data) setParentOrderNumber(data.order_number); });
  }, [order.parent_order_id]);

  const markRead = async () => {
    if (!profile) return;
    await supabase
      .from('order_comment_reads')
      .upsert({ user_id: profile.id, order_id: order.id, last_read_at: new Date().toISOString() });
    onRead?.(order.id);
  };

  useEffect(() => {
    const fetchComments = async () => {
      const { data } = await supabase
        .from('order_comments')
        .select('*, author:profiles(id, name, role)')
        .eq('order_id', order.id)
        .order('created_at', { ascending: true });
      if (data) setComments(data as OrderComment[]);
    };

    fetchComments();
    markRead();

    const channel = supabase
      .channel(`order_comments:${order.id}`)
      .on('postgres_changes', {
        event: 'INSERT',
        schema: 'public',
        table: 'order_comments',
        filter: `order_id=eq.${order.id}`,
      }, async (payload) => {
        const incomingId = (payload.new as { id: string }).id;
        const { data } = await supabase
          .from('order_comments')
          .select('*, author:profiles(id, name, role)')
          .eq('id', incomingId)
          .maybeSingle();
        if (data) {
          setComments(prev => {
            const exists = prev.some(c => c.id === incomingId);
            if (exists) return prev.map(c => c.id === incomingId ? data as OrderComment : c);
            const withoutTemp = prev.filter(c => !(c.id.startsWith('temp-') && c.author_id === (data as OrderComment).author_id && c.body === (data as OrderComment).body && (!c.attachment_url || c.attachment_url === (data as OrderComment).attachment_url)));
            return [...withoutTemp, data as OrderComment];
          });
          markRead();
        }
      })
      .subscribe();

    return () => { supabase.removeChannel(channel); };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [order.id]);

  useEffect(() => {
    if (!canReview) return;
    const fetchReview = async () => {
      const { data } = await supabase
        .from('lab_reviews')
        .select('*')
        .eq('order_id', order.id)
        .maybeSingle();
      if (data) {
        setExistingReview(data as LabReview);
        setReviewRating((data as LabReview).rating);
        setReviewComment((data as LabReview).comment ?? '');
      }
    };
    fetchReview();
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [order.id, canReview]);

  const submitReview = async () => {
    if (!profile || reviewRating < 1) return;
    setSubmittingReview(true);
    setReviewError('');
    const payload = {
      order_id: order.id,
      lab_id: order.lab_id,
      reviewer_id: profile.id,
      rating: reviewRating,
      comment: reviewComment.trim() || null,
    };
    if (existingReview) {
      const { error } = await supabase.from('lab_reviews').update({ rating: reviewRating, comment: reviewComment.trim() || null, updated_at: new Date().toISOString() }).eq('id', existingReview.id);
      if (error) { setReviewError('Could not save your review. Please try again.'); setSubmittingReview(false); return; }
      setExistingReview({ ...existingReview, rating: reviewRating, comment: reviewComment.trim() || null });
    } else {
      const { data, error } = await supabase.from('lab_reviews').insert(payload).select().single();
      if (error) { setReviewError('Could not save your review. Please try again.'); setSubmittingReview(false); return; }
      setExistingReview(data as LabReview);
    }
    setSubmittingReview(false);
  };

  useEffect(() => {
    commentsEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [comments]);

  const uploadAttachment = async (file: File): Promise<{ url: string; name: string; size: number; mime: string } | null> => {
    const ext = file.name.split('.').pop();
    const path = `${order.id}/comments/${Date.now()}-${Math.random().toString(36).slice(2)}.${ext}`;
    const { error: uploadError } = await supabase.storage.from('order-attachments').upload(path, file);
    if (uploadError) { setError('Could not upload this file. Please check the file type and size, then try again.'); return null; }
    const { data: { publicUrl } } = supabase.storage.from('order-attachments').getPublicUrl(path);
    return { url: publicUrl, name: file.name, size: file.size, mime: file.type };
  };

  const submitComment = async () => {
    if ((!newComment.trim() && !pendingFile) || !profile || submitting) return;
    setSubmitting(true);
    const body = newComment.trim();
    const file = pendingFile;
    setNewComment('');
    setPendingFile(null);

    let attachment: { url: string; name: string; size: number; mime: string } | null = null;
    if (file) {
      setUploading(true);
      attachment = await uploadAttachment(file);
      setUploading(false);
      if (!attachment) { setSubmitting(false); return; }
    }

    const storedBody = body || 'Attachment';
    const tempId = `temp-${Date.now()}`;
    const optimisticComment: OrderComment = {
      id: tempId,
      order_id: order.id,
      author_id: profile.id,
      body: storedBody,
      created_at: new Date().toISOString(),
      author: { id: profile.id, name: profile.name, role: profile.role },
      attachment_url: attachment?.url ?? null,
      attachment_name: attachment?.name ?? null,
      attachment_size: attachment?.size ?? null,
      attachment_mime: attachment?.mime ?? null,
    };
    setComments(prev => [...prev, optimisticComment]);

    const { error: insertErr } = await supabase
      .from('order_comments')
      .insert({
        order_id: order.id,
        author_id: profile.id,
        body: storedBody,
        attachment_url: attachment?.url ?? null,
        attachment_name: attachment?.name ?? null,
        attachment_size: attachment?.size ?? null,
        attachment_mime: attachment?.mime ?? null,
      });

    if (insertErr) {
      setComments(prev => prev.filter(c => c.id !== tempId));
      setNewComment(body);
      if (file) setPendingFile(file);
      setError('Could not send your message. Please try again.');
    }
    setSubmitting(false);
  };

  const updateStatus = async (status: OrderStatus) => {
    setUpdating(true);
    setError('');
    const { error } = await supabase
      .from('orders')
      .update({ status, updated_at: new Date().toISOString() })
      .eq('id', order.id);
    setUpdating(false);
    if (error) { setError('Could not update this case. Please refresh and try again.'); return; }
    onStatusChange();
  };

  const approveTryIn = async () => {
    if (!profile) return;
    setUpdating(true);
    setError('');
    const updates: Record<string, unknown> = {
      status: 'pending',
      try_in: false,
      is_final: true,
      updated_at: new Date().toISOString(),
    };
    // If the doctor is approving a try-in on an order placed by their center,
    // transfer ownership so the continuing order lives on the doctor's account.
    const orderDoctorId = (order as unknown as { doctor_id?: string | null }).doctor_id ?? null;
    if (profile.role === 'doctor' && order.from_id !== profile.id && orderDoctorId === profile.id) {
      updates.from_id = profile.id;
      updates.doctor_id = null;
    }
    const { error } = await supabase
      .from('orders')
      .update(updates)
      .eq('id', order.id);
    setUpdating(false);
    if (error) { setError('Could not approve the try-in. Please refresh and try again.'); return; }
    onStatusChange();
  };

  const submitRedo = async () => {
    if (!redoReason.trim() || !profile) return;
    if (order.status === 'delivered' && redoWindowExpired) {
      setError('The 30-day redo window for this case has passed.');
      return;
    }
    setUpdating(true);
    setError('');
    const reason = redoReason.trim();

    const { error: updateErr } = await supabase
      .from('orders')
      .update({ status: 'redo', is_final: false })
      .eq('id', order.id);

    if (updateErr) {
      setError('Could not request a remake for this case. The remake window may have closed.');
      setUpdating(false);
      return;
    }

    await supabase.from('order_comments').insert({
      order_id: order.id,
      author_id: profile.id,
      body: `Redo reason: ${reason}`,
    });

    setUpdating(false);
    setShowRedoDialog(false);
    setRedoReason('');
    onStatusChange();
  };

  const handlePrint = () => {
    const iframe = document.createElement('iframe');
    iframe.style.cssText = 'position:fixed;top:0;left:0;width:0;height:0;border:none;opacity:0;pointer-events:none;';
    document.body.appendChild(iframe);
    const doc = iframe.contentDocument ?? iframe.contentWindow?.document;
    if (!doc) { document.body.removeChild(iframe); return; }
    doc.open();
    doc.write(generatePrintHTML(order, comments, parentOrderNumber));
    doc.close();
    iframe.contentWindow?.focus();
    setTimeout(() => {
      iframe.contentWindow?.print();
      setTimeout(() => document.body.removeChild(iframe), 1000);
    }, 600);
  };

  return (
    <>
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm transform-gpu flex items-center justify-center z-50 p-4 pt-[env(safe-area-inset-top,16px)] pb-[env(safe-area-inset-bottom,16px)] px-[max(env(safe-area-inset-left,16px),16px)]">
      <div className="bg-white rounded-2xl shadow-modal w-full max-w-[90vw] sm:max-w-3xl max-h-[85vh] overflow-hidden flex flex-col animate-modal-in break-words">

        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-neutral-200 flex-shrink-0">
          <div className="flex items-center gap-3">
            <div>
              <h2 className="font-bold text-neutral-900 text-base">{order.order_number}</h2>
              <div className="flex items-center gap-1.5 flex-wrap mt-0.5">
                {/* Try-in flow step indicator */}
                {order.is_final ? (
                  <div className="flex items-center gap-1">
                    {/* Step 1: Try In (done) */}
                    <span className="flex items-center gap-1 text-xs font-semibold px-2 py-0.5 rounded-full border bg-amber-50 text-amber-600 border-amber-200 opacity-60">
                      <FlaskConical className="w-2.5 h-2.5" />
                      Try In
                    </span>
                    <svg className="w-3 h-3 text-neutral-400 flex-shrink-0" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24"><path d="M9 18l6-6-6-6"/></svg>
                    {/* Step 2: current status */}
                    <span className={`text-xs font-semibold px-2 py-0.5 rounded-full border ${statusColor[order.status]}`}>
                      {STATUS_LABELS[order.status]}
                    </span>
                    <svg className="w-3 h-3 text-neutral-400 flex-shrink-0" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24"><path d="M9 18l6-6-6-6"/></svg>
                    {/* Step 3: Final Case */}
                    <span className="flex items-center gap-1 text-xs font-semibold px-2 py-0.5 rounded-full border bg-emerald-50 text-emerald-700 border-emerald-300">
                      <CheckCircle2 className="w-2.5 h-2.5" />
                      Final Case
                    </span>
                  </div>
                ) : (
                  <>
                    <span className={`text-xs font-semibold px-2 py-0.5 rounded-full border ${statusColor[order.status]}`}>
                      {STATUS_LABELS[order.status]}
                    </span>
                    {order.try_in && (
                      <span className="flex items-center gap-1 text-xs font-semibold px-2 py-0.5 rounded-full border bg-amber-50 text-amber-700 border-amber-300">
                        <FlaskConical className="w-2.5 h-2.5" />
                        Try In
                      </span>
                    )}
                  </>
                )}
                {order.parent_order_id && (
                  <span className="flex items-center gap-1 text-xs font-semibold px-2 py-0.5 rounded-full border bg-orange-50 text-orange-700 border-orange-200">
                    <RefreshCw className="w-2.5 h-2.5" />
                    Redo{parentOrderNumber ? ` of ${parentOrderNumber}` : ''}
                  </span>
                )}
              </div>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setShowSticker(true)}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-teal-50 hover:bg-teal-100 text-teal-700 border border-teal-200 text-xs font-semibold rounded-lg transition-colors"
              title="Print small sticker with QR code"
            >
              <QrCode className="w-3.5 h-3.5" /> Sticker
            </button>
            <button
              onClick={handlePrint}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-primary-50 hover:bg-primary-100 text-primary-700 border border-primary-200 text-xs font-semibold rounded-lg transition-colors"
            >
              <Printer className="w-3.5 h-3.5" /> Print / PDF
            </button>
            <button onClick={onClose} className="w-8 h-8 flex items-center justify-center rounded-lg hover:bg-neutral-100">
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Two-column body */}
        <div className="flex flex-1 overflow-hidden">

          {/* LEFT — order details */}
          <div className="w-[52%] border-r border-neutral-200 overflow-y-auto p-5 space-y-4 flex-shrink-0">

            <div className="grid grid-cols-2 gap-3">
              <div>
                <div className="bg-neutral-50 rounded-xl p-3 border border-neutral-200">
                  <div className="flex items-center gap-1.5 mb-1 text-neutral-400 text-xs"><User className="w-4 h-4" />From</div>
                  <p className="font-semibold text-neutral-900 text-sm">{order.from_profile?.name ?? '—'}</p>
                  {order.from_profile?.address && <p className="text-xs text-neutral-500">{order.from_profile.address}</p>}
                  {order.from_profile?.city && <p className="text-xs text-neutral-500">{order.from_profile.city}</p>}
                </div>
                {!isLab && order.from_profile && (
                  order.bill_to === 'doctor' && order.from_profile.role !== 'center'
                    ? <span className="mt-1.5 inline-flex items-center gap-1 text-[11px] font-medium text-emerald-700 bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded-full">
                        <Wallet className="w-3 h-3" /> Cash case
                      </span>
                    : order.from_profile.role === 'center'
                      ? <span className="mt-1.5 inline-flex items-center gap-1 text-[11px] font-medium text-blue-700 bg-blue-50 border border-blue-200 px-2 py-0.5 rounded-full">
                          <Building2 className="w-3 h-3" /> Sent from center
                        </span>
                      : null
                )}
              </div>
              <InfoCard icon={<User className="w-4 h-4" />} label="Lab"  value={order.lab_profile?.name  ?? '—'} sub={order.lab_profile?.city} />
            </div>

            {order.bill_to === 'center' && (
              <div className="flex items-center gap-2 px-3 py-2.5 rounded-xl bg-blue-50 border border-blue-200">
                <Receipt className="w-4 h-4 text-blue-600" />
                <span className="text-sm font-medium text-blue-700">
                  Invoice to the center, not the doctor directly.
                </span>
              </div>
            )}

            <div className="bg-neutral-50 rounded-xl p-4 border border-neutral-200">
              <h3 className="text-xs font-semibold text-neutral-500 uppercase tracking-wide mb-3">Patient Details</h3>
              <div className="grid grid-cols-2 gap-3">
                <Detail icon={<FileText    className="w-4 h-4" />} label="File No."      value={order.file_number} />
                <Detail icon={<User        className="w-4 h-4" />} label="Patient"       value={order.patient_name} />
                <Detail icon={<User        className="w-4 h-4" />} label="Doctor"        value={order.dr_name} />
                {order.shade         && <Detail icon={<Palette      className="w-4 h-4" />} label="Shade"        value={order.shade} />}
                {order.teeth_numbers && <Detail icon={<Grid3x3     className="w-4 h-4" />} label="Teeth"        value={order.teeth_numbers} />}
                {order.due_date      && <Detail icon={<Calendar     className="w-4 h-4" />} label="Due Date"     value={new Date(order.due_date).toLocaleDateString()} />}
                {order.service       && order.order_services?.length === 0 && <Detail icon={<CheckCircle2 className="w-4 h-4" />} label="Service"      value={order.service.name} />}
              </div>
            </div>

            {/* Multi-service list */}
            {order.order_services && order.order_services.length > 0 && (
              <div className="bg-neutral-50 rounded-xl p-4 border border-neutral-200">
                <h3 className="text-xs font-semibold text-neutral-500 uppercase tracking-wide mb-3 flex items-center gap-1.5">
                  <Package className="w-3.5 h-3.5" /> Services ({order.order_services.length})
                </h3>
                <div className="space-y-2">
                  {order.order_services.map((s, idx) => (
                    <div key={s.id} className={`rounded-xl border p-3 ${s.service_id ? 'bg-blue-50 border-blue-200' : 'bg-amber-50 border-amber-200'}`}>
                      <div className="flex items-start gap-2">
                        <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold flex-shrink-0 mt-0.5 ${s.service_id ? 'bg-blue-200 text-blue-800' : 'bg-amber-200 text-amber-800'}`}>{idx + 1}</span>
                        <div className="min-w-0 flex-1">
                          <div className="flex items-center gap-1.5 flex-wrap">
                            <p className={`font-semibold text-sm ${s.service_id ? 'text-blue-900' : 'text-amber-900'}`}>{s.service_name}</p>
                            {!s.service_id && <span className="text-[10px] font-bold text-amber-600 bg-amber-100 border border-amber-300 px-1.5 py-0.5 rounded">Custom</span>}
                          </div>
                          {s.service?.description && <p className="text-xs text-blue-700 mt-0.5">{s.service.description}</p>}
                          {s.teeth_numbers && (
                            <p className="text-xs text-neutral-500 flex items-center gap-1 mt-1"><Hash className="w-3 h-3" /> {s.teeth_numbers}</p>
                          )}
                          {s.notes && <p className="text-xs text-neutral-600 mt-1 italic">"{s.notes}"</p>}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Delivery location */}
            {(() => {
              const fp = order.from_profile;
              const hasAddr = fp?.address || fp?.city;
              const hasCoords = fp?.latitude != null && fp?.longitude != null;
              if (!hasAddr && !hasCoords) return null;
              const addrLine = [fp?.address, fp?.city].filter(Boolean).join(', ');
              return (
                <div className="bg-blue-50 rounded-xl p-4 border border-blue-200">
                  <div className="flex items-center gap-2 mb-2">
                    <MapPin className="w-4 h-4 text-blue-600" />
                    <span className="text-xs font-semibold text-blue-700 uppercase tracking-wide">Delivery Location</span>
                  </div>
                  {addrLine && <p className="text-sm text-blue-900 font-medium leading-relaxed">{addrLine}</p>}
                  {hasCoords && (
                    <a
                      href={`https://www.google.com/maps/dir/?api=1&destination=${fp!.latitude},${fp!.longitude}`}
                      target="_blank"
                      rel="noreferrer"
                      className="mt-2 inline-flex items-center gap-1.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 px-3 py-1.5 rounded-lg transition-colors"
                    >
                      <Navigation className="w-3.5 h-3.5" />
                      Get directions
                    </a>
                  )}
                </div>
              );
            })()}

            {order.delivered_at && (
              <div className="bg-teal-50 rounded-xl p-4 border border-teal-200">
                <div className="flex items-center gap-2 mb-1">
                  <CheckCircle2 className="w-4 h-4 text-teal-600" />
                  <span className="text-xs font-semibold text-teal-700 uppercase tracking-wide">Case Delivered</span>
                </div>
                <p className="text-sm text-teal-900 font-medium">
                  Delivered on {new Date(order.delivered_at).toLocaleString('en-GB', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' })}
                </p>
              </div>
            )}

            {order.notes && (
              <div className="bg-amber-50 rounded-xl p-4 border border-amber-200">
                <div className="flex items-center gap-2 mb-1.5">
                  <MessageSquare className="w-4 h-4 text-amber-600" />
                  <span className="text-xs font-semibold text-amber-700 uppercase tracking-wide">Notes</span>
                </div>
                <p className="text-sm text-amber-900 leading-relaxed">{order.notes}</p>
              </div>
            )}

            {order.attachments && order.attachments.length > 0 && (
              <div>
                <h3 className="text-xs font-semibold text-neutral-500 uppercase tracking-wide mb-2">Case Photos & Attachments</h3>
                <div className="space-y-2">
                  {order.attachments.map(att => {
                    const isImage = att.mime_type?.startsWith('image/');
                    return (
                      <AttachmentLink key={att.id} url={att.file_url}
                        className="block bg-neutral-50 rounded-xl border border-neutral-200 hover:border-primary-300 hover:bg-primary-50 transition-all overflow-hidden"
                      >
                        {isImage && (
                          <img src={att.file_url} alt={att.file_name} className="w-full h-40 object-cover" />
                        )}
                        <div className="flex items-center gap-3 px-3 py-2.5 text-sm">
                          <Paperclip className="w-4 h-4 text-neutral-400 flex-shrink-0" />
                          <div className="flex-1 min-w-0">
                            <span className="block truncate text-neutral-700 font-medium">{att.file_name}</span>
                            {att.description && <span className="block text-xs text-neutral-500 mt-0.5 line-clamp-2">{att.description}</span>}
                          </div>
                          {att.file_size && <span className="text-xs text-neutral-400 flex-shrink-0">{(att.file_size / 1024).toFixed(1)} KB</span>}
                        </div>
                      </AttachmentLink>
                    );
                  })}
                </div>
              </div>
            )}

            <div className="text-xs text-neutral-400 space-y-1 pt-1">
              <p>Created: {new Date(order.created_at).toLocaleString()}</p>
              <p>Updated: {new Date(order.updated_at).toLocaleString()}</p>
            </div>

            {error && <p className="text-red-600 text-sm">{error}</p>}

            {/* Lab transitions */}
            {transitions.length > 0 && (
              <div className="flex gap-2 flex-wrap pt-1">
                {transitions.map(status => {
                  const isPositive = ['accepted', 'in_progress', 'completed', 'try_in', 'delivered'].includes(status);
                  return (
                    <button key={status} onClick={() => updateStatus(status)} disabled={updating}
                      className={`flex-1 min-w-0 py-2.5 text-sm font-semibold rounded-xl transition-colors disabled:opacity-60 ${
                        isPositive
                          ? 'bg-primary-600 hover:bg-primary-700 text-white'
                          : 'bg-red-50 hover:bg-red-100 text-red-700 border border-red-200'
                      }`}
                    >
                      {updating ? '...' : STATUS_LABELS[status]}
                    </button>
                  );
                })}
              </div>
            )}

            {/* Doctor approve try-in → send back to lab for final completion */}
            {canApproveTryIn && (
              <button
                onClick={approveTryIn}
                disabled={updating}
                className="w-full flex items-center justify-center gap-2 py-2.5 text-sm font-semibold rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white transition-colors disabled:opacity-60"
              >
                <CheckCircle2 className="w-4 h-4" />
                {updating ? '...' : 'Approve Try In'}
              </button>
            )}

            {/* Doctor redo request (on delivered or try_in orders, within 30 days of delivery) */}
            {canRequestRedo && (
              <div>
                <button
                  onClick={() => setShowRedoDialog(true)}
                  disabled={updating}
                  className="w-full flex items-center justify-center gap-2 py-2.5 text-sm font-semibold rounded-xl border border-orange-300 bg-orange-50 text-orange-700 hover:bg-orange-100 transition-colors disabled:opacity-60"
                >
                  <RefreshCw className="w-4 h-4" />
                  Request Redo
                </button>
                {order.status === 'delivered' && daysLeftForRedo !== null && (
                  <p className="mt-1.5 text-xs text-neutral-500 text-center">
                    Redo window: {daysLeftForRedo} day{daysLeftForRedo === 1 ? '' : 's'} left
                  </p>
                )}
              </div>
            )}
            {!isLab && order.status === 'delivered' && redoWindowExpired && profile?.role !== 'center' && (
              <div className="flex items-start gap-2 text-xs bg-neutral-50 border border-neutral-200 text-neutral-600 rounded-xl px-3 py-2.5">
                <RefreshCw className="w-3.5 h-3.5 flex-shrink-0 mt-0.5 text-neutral-400" />
                <span>
                  Redo is no longer available for this case. The 30-day window closed
                  {daysSinceDelivered !== null ? ` ${daysSinceDelivered - REDO_WINDOW_DAYS} day${daysSinceDelivered - REDO_WINDOW_DAYS === 1 ? '' : 's'} ago` : ''}.
                </span>
              </div>
            )}

            {/* Doctor mark as finished */}
            {!isLab && order.status === 'delivered' && !order.finished_at && profile?.role !== 'center' && (
              <button
                onClick={async () => {
                  const { error: err } = await supabase.from('orders').update({ finished_at: new Date().toISOString() }).eq('id', order.id);
                  if (!err) onStatusChange();
                }}
                className="w-full flex items-center justify-center gap-2 py-2.5 text-sm font-semibold rounded-xl bg-green-600 hover:bg-green-700 text-white transition-colors"
              >
                <CheckCircle2 className="w-4 h-4" />
                Mark as Finished
              </button>
            )}

            {/* Doctor/Center edit (pending orders only) */}
            {canEdit && (
              <button
                onClick={() => setShowEdit(true)}
                className="w-full flex items-center justify-center gap-2 py-2.5 text-sm font-semibold rounded-xl border border-primary-300 bg-primary-50 text-primary-700 hover:bg-primary-100 transition-colors"
              >
                <Pencil className="w-4 h-4" />
                Edit Order
              </button>
            )}

            {/* Rate the case (delivered orders, doctor only) */}
            {canReview && (
              <div className="bg-amber-50/60 border border-amber-200 rounded-xl p-4 space-y-3">
                <div className="flex items-center gap-2">
                  <Star className="w-4 h-4 text-amber-500" />
                  <h4 className="text-sm font-bold text-neutral-900">
                    {existingReview ? 'Your Review' : 'Rate This Case'}
                  </h4>
                  {existingReview && (
                    <span className="ml-auto text-xs text-neutral-400">
                      {new Date(existingReview.updated_at).toLocaleDateString()}
                    </span>
                  )}
                </div>
                <div className="flex items-center gap-1">
                  {[1, 2, 3, 4, 5].map(i => (
                    <button
                      key={i}
                      type="button"
                      disabled={submittingReview}
                      onMouseEnter={() => setReviewHover(i)}
                      onMouseLeave={() => setReviewHover(0)}
                      onClick={() => setReviewRating(i)}
                      className="p-0.5 transition-transform hover:scale-110 disabled:opacity-50"
                    >
                      <svg
                        className={`w-7 h-7 ${(reviewHover || reviewRating) >= i ? 'text-amber-400' : 'text-neutral-300'}`}
                        fill="currentColor"
                        viewBox="0 0 24 24"
                      >
                        <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z" />
                      </svg>
                    </button>
                  ))}
                </div>
                <textarea
                  value={reviewComment}
                  onChange={e => setReviewComment(e.target.value)}
                  placeholder="Share your experience with this lab (optional)..."
                  rows={3}
                  dir={/[\u0600-\u06FF]/.test(reviewComment) ? 'rtl' : 'ltr'}
                  className="w-full resize-none text-sm border border-neutral-200 rounded-xl px-3 py-2.5 bg-white focus:outline-none focus:ring-2 focus:ring-amber-500 focus:border-transparent placeholder-neutral-400"
                />
                {reviewError && <p className="text-xs text-red-500">{reviewError}</p>}
                <button
                  onClick={submitReview}
                  disabled={reviewRating < 1 || submittingReview}
                  className="w-full flex items-center justify-center gap-2 py-2.5 text-sm font-semibold rounded-xl bg-amber-500 hover:bg-amber-600 text-white transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {submittingReview ? <Loader2 className="w-4 h-4 animate-spin" /> : <Star className="w-4 h-4" />}
                  {existingReview ? 'Update Review' : 'Submit Review'}
                </button>
              </div>
            )}
          </div>

          {/* RIGHT — conversation */}
          <div className="flex-1 flex flex-col overflow-hidden">
            {/* Chat header */}
            <div className="flex items-center gap-2 px-4 py-3 border-b border-neutral-200 bg-neutral-50 flex-shrink-0">
              <MessageSquare className="w-4 h-4 text-primary-600" />
              <span className="text-xs font-semibold text-neutral-600 uppercase tracking-wide">Conversation</span>
              {comments.length > 0 && (
                <span className="ml-auto bg-neutral-200 text-neutral-600 text-xs font-semibold px-2 py-0.5 rounded-full">
                  {comments.length}
                </span>
              )}
            </div>

            {/* Messages */}
            <div className="flex-1 overflow-y-auto p-4 space-y-3 bg-white">
              {comments.length === 0 ? (
                <div className="flex flex-col items-center justify-center h-full text-center py-8">
                  <div className="w-12 h-12 rounded-2xl bg-primary-50 flex items-center justify-center mb-3">
                    <MessageSquare className="w-6 h-6 text-primary-300" />
                  </div>
                  <p className="text-sm font-medium text-neutral-500">No messages yet</p>
                  <p className="text-xs text-neutral-400 mt-1">Start the conversation below</p>
                </div>
              ) : (
                comments.map(c => {
                  const isOwn = c.author_id === profile?.id;
                  const hasAttachment = !!c.attachment_url;
                  const isImage = hasAttachment && (c.attachment_mime?.startsWith('image/') || /\.(png|jpe?g|gif|webp|bmp)$/i.test(c.attachment_name ?? ''));
                  const isRtl = /[\u0600-\u06FF]/.test(c.body);
                  const time = new Date(c.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
                  const date = new Date(c.created_at).toLocaleDateString([], { month: 'short', day: 'numeric' });
                  return (
                    <div key={c.id} className={`flex gap-2 ${isOwn ? 'justify-end' : 'justify-start'}`}>
                      {!isOwn && (
                        <div className="w-7 h-7 rounded-full bg-primary-100 flex items-center justify-center flex-shrink-0 mt-1">
                          <User className="w-3.5 h-3.5 text-primary-600" />
                        </div>
                      )}
                      <div className={`max-w-[78%] flex flex-col ${isOwn ? 'items-end' : 'items-start'}`}>
                        <span className="text-[11px] text-neutral-400 mb-1 px-1">
                          {isOwn ? 'You' : (c.author?.name ?? '—')} · {date} {time}
                        </span>
                        <div
                          dir={isRtl ? 'rtl' : 'ltr'}
                          className={`px-3 py-2 rounded-2xl text-sm leading-relaxed break-words whitespace-pre-wrap ${
                            isRtl ? 'text-right' : 'text-left'
                          } ${
                            isOwn
                              ? 'bg-primary-600 text-white rounded-br-sm'
                              : 'bg-neutral-100 text-neutral-900 rounded-bl-sm'
                          }`}
                        >
                          {hasAttachment && (
                            <div className="mb-1.5">
                              {isImage ? (
                                <AttachmentLink url={c.attachment_url} className="block">
                                  <AttachmentImage
                                    url={c.attachment_url}
                                    alt={c.attachment_name ?? 'attachment'}
                                    className="max-w-full max-h-48 rounded-lg object-cover"
                                  />
                                </AttachmentLink>
                              ) : (
                                <AttachmentLink
                                  url={c.attachment_url}
                                  download={c.attachment_name ?? undefined}
                                  className={`flex items-center gap-2 px-3 py-2 rounded-lg border text-xs font-medium transition-colors ${
                                    isOwn
                                      ? 'bg-white/15 border-white/20 text-white hover:bg-white/25'
                                      : 'bg-white border-neutral-200 text-neutral-700 hover:bg-neutral-50'
                                  }`}
                                >
                                  <Paperclip className="w-3.5 h-3.5 flex-shrink-0" />
                                  <span className="truncate">{c.attachment_name ?? 'File'}</span>
                                  {c.attachment_size != null && (
                                    <span className="opacity-70 flex-shrink-0">{(c.attachment_size / 1024).toFixed(1)} KB</span>
                                  )}
                                </AttachmentLink>
                              )}
                            </div>
                          )}
                          {(!hasAttachment || c.body !== 'Attachment') && c.body}
                        </div>
                      </div>
                      {isOwn && (
                        <div className="w-7 h-7 rounded-full bg-primary-600 flex items-center justify-center flex-shrink-0 mt-1">
                          <User className="w-3.5 h-3.5 text-white" />
                        </div>
                      )}
                    </div>
                  );
                })
              )}
              <div ref={commentsEndRef} />
            </div>

            {/* Input */}
            <div className="border-t border-neutral-200 p-3 bg-neutral-50 flex-shrink-0">
              {pendingFile && (
                <div className="mb-2 flex items-center gap-2 px-3 py-2 bg-primary-50 border border-primary-200 rounded-xl">
                  <Paperclip className="w-3.5 h-3.5 text-primary-600 flex-shrink-0" />
                  <span className="text-xs text-primary-700 font-medium truncate flex-1">{pendingFile.name}</span>
                  <span className="text-[10px] text-primary-400 flex-shrink-0">{(pendingFile.size / 1024).toFixed(1)} KB</span>
                  <button
                    onClick={() => setPendingFile(null)}
                    className="w-5 h-5 flex items-center justify-center rounded hover:bg-primary-200 text-primary-600"
                  >
                    <X className="w-3 h-3" />
                  </button>
                </div>
              )}
              <div className="flex gap-2">
                <input
                  ref={fileInputRef}
                  type="file"
                  className="hidden"
                  onChange={e => {
                    if (e.target.files?.[0]) setPendingFile(e.target.files[0]);
                    e.target.value = '';
                  }}
                  accept="image/*,.pdf,.dcm,.stl,.ply"
                />
                <button
                  onClick={() => fileInputRef.current?.click()}
                  disabled={submitting || uploading}
                  className="self-end w-9 h-9 flex items-center justify-center bg-white border border-neutral-200 text-neutral-500 hover:text-primary-600 hover:border-primary-300 rounded-xl transition-colors disabled:opacity-40 flex-shrink-0"
                  title="Attach file"
                >
                  <Paperclip className="w-4 h-4" />
                </button>
                <textarea
                  value={newComment}
                  onChange={e => setNewComment(e.target.value)}
                  onKeyDown={e => {
                    if (e.key === 'Enter' && !e.shiftKey) {
                      e.preventDefault();
                      submitComment();
                    }
                  }}
                  dir={/[\u0600-\u06FF]/.test(newComment) ? 'rtl' : 'ltr'}
                  placeholder="Write a message... (Enter to send)"
                  rows={2}
                  className="flex-1 resize-none text-sm border border-neutral-200 rounded-xl px-3 py-2 bg-white focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-transparent placeholder-neutral-400"
                />
                <button
                  onClick={submitComment}
                  disabled={(!newComment.trim() && !pendingFile) || submitting}
                  className="self-end w-9 h-9 flex items-center justify-center bg-primary-600 hover:bg-primary-700 text-white rounded-xl transition-colors disabled:opacity-40 disabled:cursor-not-allowed flex-shrink-0"
                >
                  {uploading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
                </button>
              </div>
            </div>
          </div>

        </div>
      </div>
    </div>

    {/* Redo confirmation dialog */}
    {showRedoDialog && (
      <div className="fixed inset-0 bg-black/60 backdrop-blur-sm transform-gpu flex items-center justify-center z-[60] p-4 pt-[env(safe-area-inset-top,16px)] pb-[env(safe-area-inset-bottom,16px)] px-[max(env(safe-area-inset-left,16px),16px)]">
        <div className="bg-white rounded-2xl shadow-modal w-full max-w-[90vw] sm:max-w-sm max-h-[85vh] overflow-y-auto animate-modal-in break-words">
          <div className="p-5 border-b border-neutral-200 flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-orange-50 flex items-center justify-center flex-shrink-0">
              <AlertTriangle className="w-5 h-5 text-orange-600" />
            </div>
            <div>
              <h3 className="font-bold text-neutral-900">Request Redo</h3>
              <p className="text-sm text-neutral-500">Explain what needs to be corrected</p>
            </div>
          </div>
          <div className="p-5 space-y-4">
            <textarea
              value={redoReason}
              onChange={e => setRedoReason(e.target.value)}
              placeholder="Describe the issue with the completed work..."
              rows={4}
              autoFocus
              dir={/[\u0600-\u06FF]/.test(redoReason) ? 'rtl' : 'ltr'}
              className="w-full resize-none text-sm border border-neutral-200 rounded-xl px-3 py-2.5 bg-white focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent placeholder-neutral-400"
            />
            <div className="flex gap-2">
              <button
                onClick={() => { setShowRedoDialog(false); setRedoReason(''); }}
                className="flex-1 py-2.5 text-sm font-semibold rounded-xl border border-neutral-200 text-neutral-600 hover:bg-neutral-50 transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={submitRedo}
                disabled={!redoReason.trim() || updating}
                className="flex-1 flex items-center justify-center gap-2 py-2.5 text-sm font-semibold rounded-xl bg-orange-600 hover:bg-orange-700 text-white transition-colors disabled:opacity-50"
              >
                <RefreshCw className="w-4 h-4" />
                {updating ? 'Sending...' : 'Request Redo'}
              </button>
            </div>
          </div>
        </div>
      </div>
    )}

    {/* Edit order modal (pending orders only) — reuses the full new-order form */}
    {showEdit && order.lab_profile && (
      <NewOrderModal
        lab={order.lab_profile}
        existingOrder={order}
        onClose={() => setShowEdit(false)}
        onSuccess={() => { setShowEdit(false); onStatusChange(); }}
      />
    )}

    {showSticker && (
      <OrderSticker order={order} onClose={() => setShowSticker(false)} />
    )}

  </>
  );
}

function InfoCard({ icon, label, value, sub }: { icon: React.ReactNode; label: string; value: string; sub?: string | null }) {
  return (
    <div className="bg-neutral-50 rounded-xl p-3 border border-neutral-200">
      <div className="flex items-center gap-1.5 mb-1 text-neutral-400 text-xs">{icon}{label}</div>
      <p className="font-semibold text-neutral-900 text-sm">{value}</p>
      {sub && <p className="text-xs text-neutral-500">{sub}</p>}
    </div>
  );
}

function Detail({ icon, label, value }: { icon: React.ReactNode; label: string; value: string }) {
  return (
    <div>
      <div className="flex items-center gap-1 text-neutral-400 text-xs mb-0.5">{icon}{label}</div>
      <p className="text-sm font-medium text-neutral-900">{value}</p>
    </div>
  );
}
