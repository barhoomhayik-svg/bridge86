import React, { useState, useEffect } from 'react';
import { supabase, Profile, Service, Order, OrderService } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { X, Upload, AlertCircle, Building2, Wallet, Plus, Trash2, ChevronDown, DollarSign, Clock, Stethoscope, FileText, FlaskConical, Sparkles, Link2, Palette, Image as ImageIcon, File as FileIcon } from 'lucide-react';
import { ToothIcon } from './ToothIcon';

const SHADE_OPTIONS = ['A1','A2','A3','A3.5','A4','B1','B2','B3','B4','C1','C2','C3','C4','D2','D3','D4','BL1','BL2','BL3','BL4'];

interface Props {
  lab: Profile;
  services?: Service[];
  onClose: () => void;
  onSuccess: () => void;
  prefilledCenterId?: string;
  existingOrder?: Order;
}

interface ServiceLine {
  key: string;
  service: Service | null;
  customName: string;
  notes: string;
  // Zero or more bridge groups within this service line. Teeth in a group are
  // connected as one bridge; teeth in the line that don't appear in any group
  // are single crowns. A single line can carry multiple independent bridges.
  bridges: number[][];
  existingId?: string;
}

const UPPER_R = [18,17,16,15,14,13,12,11];
const UPPER_L = [21,22,23,24,25,26,27,28];
const LOWER_R = [48,47,46,45,44,43,42,41];
const LOWER_L = [31,32,33,34,35,36,37,38];

const PALETTE = [
  { label: 'Blue',    solid: '#3b82f6', ring: 'rgba(59,130,246,0.35)', soft: '#dbeafe' },
  { label: 'Green',   solid: '#10b981', ring: 'rgba(16,185,129,0.35)', soft: '#d1fae5' },
  { label: 'Amber',   solid: '#f59e0b', ring: 'rgba(245,158,11,0.35)', soft: '#fef3c7' },
  { label: 'Rose',    solid: '#f43f5e', ring: 'rgba(244,63,94,0.35)',  soft: '#ffe4e6' },
  { label: 'Cyan',    solid: '#06b6d4', ring: 'rgba(6,182,212,0.35)',  soft: '#cffafe' },
  { label: 'Orange',  solid: '#f97316', ring: 'rgba(249,115,22,0.35)', soft: '#ffedd5' },
  { label: 'Lime',    solid: '#84cc16', ring: 'rgba(132,204,22,0.35)', soft: '#ecfccb' },
  { label: 'Pink',    solid: '#ec4899', ring: 'rgba(236,72,153,0.35)', soft: '#fce7f3' },
];

function lineColor(idx: number) { return PALETTE[idx % PALETTE.length]; }

function newLine(): ServiceLine {
  return { key: crypto.randomUUID(), service: null, customName: '', notes: '', bridges: [] };
}

// Anatomical (FDI) tooth order across each jaw, right-to-left through the arch.
// Adjacent entries in this array are physically neighboring teeth in the mouth,
// including across the midline (11↔21 for upper, 41↔31 for lower).
const UPPER_ARCH = [18,17,16,15,14,13,12,11,21,22,23,24,25,26,27,28];
const LOWER_ARCH = [48,47,46,45,44,43,42,41,31,32,33,34,35,36,37,38];

function jawOf(n: number): 'upper' | 'lower' | null {
  const q = Math.floor(n / 10);
  if (q === 1 || q === 2) return 'upper';
  if (q === 3 || q === 4) return 'lower';
  return null;
}

// Format a set of teeth for a line: bridges use dashes to show connections
// between anatomically adjacent teeth (including across the midline).
// Each jaw is grouped independently, so a single case can carry one bridge
// in the upper jaw and another in the lower jaw.
function archOrder(n: number): number {
  const u = UPPER_ARCH.indexOf(n);
  if (u >= 0) return u;
  const l = LOWER_ARCH.indexOf(n);
  return l >= 0 ? 100 + l : 1000 + n;
}

// Format teeth for a line: each bridge group is shown as connected teeth
// (e.g. "13-14-15"); any teeth in the line that aren't part of a group are
// listed individually as single crowns.
function formatTeethForLine(teeth: number[], bridges: number[][]): string {
  const sorted = [...teeth].sort((a, b) => a - b);
  if (bridges.length === 0) return sorted.join(', ');
  const parts: string[] = [];
  const bridged = new Set<number>();
  for (const g of bridges) {
    const ordered = [...g].sort((a, b) => archOrder(a) - archOrder(b));
    parts.push(ordered.join('-'));
    for (const n of ordered) bridged.add(n);
  }
  const loose = sorted.filter(n => !bridged.has(n));
  if (loose.length) parts.push(loose.join(', '));
  return parts.join(', ');
}

interface ToothChartProps {
  toothOwner: Map<number, string>;
  colorFor: (lineKey: string) => { solid: string; ring: string; soft: string } | null;
  bridgeGroups: Map<string, number[][]>;
  onToggle: (n: number) => void;
  onClear: () => void;
  totalSelected: number;
  activeColor: { solid: string; ring: string; soft: string } | null;
}

function ToothChart({ toothOwner, colorFor, bridgeGroups, onToggle, onClear, totalSelected, activeColor }: ToothChartProps) {
  // Reverse lookup: tooth -> { ownerKey, groupIndex } for teeth that belong to
  // a bridge group. Used to draw connectors only between teeth in the same
  // group of the same service line.
  const toothGroup = new Map<number, { ownerKey: string; groupIdx: number }>();
  for (const [ownerKey, groups] of bridgeGroups) {
    groups.forEach((g, gi) => { for (const n of g) toothGroup.set(n, { ownerKey, groupIdx: gi }); });
  }
  const [justClicked, setJustClicked] = useState<number | null>(null);

  const handleClick = (n: number) => {
    onToggle(n);
    setJustClicked(n);
    window.setTimeout(() => setJustClicked(prev => (prev === n ? null : prev)), 400);
  };

  const Tooth = ({ n }: { n: number }) => {
    const ownerKey = toothOwner.get(n);
    const color = ownerKey ? colorFor(ownerKey) : null;
    const isOn = !!color;
    const isPop = justClicked === n;
    const hoverStyle = activeColor && !isOn ? { boxShadow: `inset 0 0 0 1.5px ${activeColor.ring}` } : undefined;
    const style: React.CSSProperties = isOn && color
      ? { backgroundColor: color.solid, color: '#fff', boxShadow: `0 4px 10px -2px ${color.ring}` }
      : hoverStyle ?? {};
    return (
      <button
        type="button"
        onClick={() => handleClick(n)}
        style={style}
        className={`relative group w-8 h-10 flex items-center justify-center rounded-md text-[10px] font-bold flex-shrink-0 transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-offset-1 focus:ring-primary-400/60 ${
          isOn
            ? 'scale-105'
            : 'bg-white text-neutral-500 hover:-translate-y-0.5 hover:shadow-sm border border-neutral-200'
        } ${isPop ? 'animate-tooth-pop' : ''}`}
        aria-pressed={isOn}
        aria-label={`Tooth ${n}`}
      >
        <ToothIcon
          className={`absolute inset-0 m-auto w-6 h-6 transition-opacity ${
            isOn ? 'opacity-30' : 'opacity-15 text-neutral-500 group-hover:opacity-35'
          }`}
        />
        <span className="relative z-10">{n}</span>
      </button>
    );
  };

  // Bridges are computed per row and per jaw. Each row can hold in-row segments;
  // a per-jaw midline connector is added when a bridge owner has both midline-
  // adjacent teeth (11+21 for upper, 41+31 for lower).
  const Row = ({ nums, align, position }: { nums: number[]; align: 'end' | 'start'; position: 'upper' | 'lower' }) => {
    const segments: Array<{ start: number; end: number; ownerKey: string }> = [];
    for (let i = 0; i < nums.length; i++) {
      const g = toothGroup.get(nums[i]);
      if (!g) continue;
      let j = i;
      while (j + 1 < nums.length) {
        const gNext = toothGroup.get(nums[j + 1]);
        if (!gNext || gNext.ownerKey !== g.ownerKey || gNext.groupIdx !== g.groupIdx) break;
        j++;
      }
      if (j > i) segments.push({ start: i, end: j, ownerKey: g.ownerKey });
      i = j;
    }

    const toothW = 32; // w-8
    const gap = 4;     // gap-1
    const H = 14;
    const R = 6;
    return (
      <div className={`relative flex gap-1 ${align === 'end' ? 'justify-end' : 'justify-start'} flex-wrap`}>
        {segments.filter(s => s.end > s.start).map((seg, idx) => {
          const color = colorFor(seg.ownerKey);
          if (!color) return null;
          const count = seg.end - seg.start + 1;
          const width = count * toothW + (seg.end - seg.start) * gap;
          const offset = (nums.length - 1 - seg.end) * (toothW + gap);
          const startOffset = seg.start * (toothW + gap);
          const unit = toothW + gap;
          const centerOffset = toothW / 2;
          let d = `M 0 0 L 0 ${H - R}`;
          for (let i = 0; i < count; i++) {
            const cx = centerOffset + i * unit;
            d += ` L ${cx - R} ${H - R} A ${R} ${R} 0 0 0 ${cx + R} ${H - R}`;
          }
          d += ` L ${width} ${H - R} L ${width} 0 Z`;
          const gradId = `bridge-grad-${position}-${idx}-${seg.start}`;
          const containerStyle: React.CSSProperties = {
            position: 'absolute',
            [align === 'end' ? 'right' : 'left']: align === 'end' ? offset : startOffset,
            [position === 'upper' ? 'bottom' : 'top']: -(H - 2),
            width,
            height: H,
            transform: position === 'lower' ? 'scaleY(-1)' : undefined,
            filter: `drop-shadow(0 3px 6px ${color.ring})`,
            zIndex: 1,
            pointerEvents: 'none',
          };
          return (
            <svg
              key={`seg-${idx}`}
              width={width}
              height={H}
              viewBox={`0 0 ${width} ${H}`}
              preserveAspectRatio="none"
              style={containerStyle}
              aria-hidden
            >
              <defs>
                <linearGradient id={gradId} x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor={color.solid} stopOpacity="1" />
                  <stop offset="70%" stopColor={color.solid} stopOpacity="0.85" />
                  <stop offset="100%" stopColor={color.solid} stopOpacity="0.55" />
                </linearGradient>
              </defs>
              <path d={d} fill={`url(#${gradId})`} stroke={color.ring} strokeOpacity="0.5" strokeWidth="0.6" />
              <path
                d={`M 4 1.2 L ${width - 4} 1.2`}
                stroke="rgba(255,255,255,0.55)"
                strokeWidth="1"
                strokeLinecap="round"
                fill="none"
              />
              <circle cx={centerOffset} cy={H - R} r="1.8" fill="rgba(255,255,255,0.7)" />
              <circle cx={width - centerOffset} cy={H - R} r="1.8" fill="rgba(255,255,255,0.7)" />
            </svg>
          );
        })}
        {nums.map(n => <Tooth key={n} n={n} />)}
      </div>
    );
  };

  // Midline connector: a small bar spanning the grid gap between the two rows,
  // rendered once per bridge owner that spans the midline in this jaw.
  const MidlineConnectors = ({ jaw, position }: { jaw: 'upper' | 'lower'; position: 'upper' | 'lower' }) => {
    const midPair: [number, number] = jaw === 'upper' ? [11, 21] : [41, 31];
    const spans: Array<{ ownerKey: string; groupIdx: number }> = [];
    const a = toothGroup.get(midPair[0]);
    const b = toothGroup.get(midPair[1]);
    if (a && b && a.ownerKey === b.ownerKey && a.groupIdx === b.groupIdx) {
      spans.push({ ownerKey: a.ownerKey, groupIdx: a.groupIdx });
    }
    if (spans.length === 0) return null;
    return (
      <>
        {spans.map(({ ownerKey, groupIdx }) => {
          const color = colorFor(ownerKey);
          if (!color) return null;
          const W = 28;
          const H = 14;
          const gradId = `bridge-mid-${jaw}-${groupIdx}-${ownerKey.replace(/[^a-z0-9]/gi, '')}`;
          const d = `M 0 0 L 0 ${H - 5} Q ${W / 2} ${H + 4} ${W} ${H - 5} L ${W} 0 Z`;
          const style: React.CSSProperties = {
            position: 'absolute',
            left: '50%',
            transform: `translateX(-50%)${position === 'lower' ? ' scaleY(-1)' : ''}`,
            [position === 'upper' ? 'bottom' : 'top']: -(H - 2),
            width: W,
            height: H,
            filter: `drop-shadow(0 3px 6px ${color.ring})`,
            zIndex: 2,
            pointerEvents: 'none',
          };
          return (
            <svg
              key={`mid-${ownerKey}-${groupIdx}`}
              width={W}
              height={H}
              viewBox={`0 0 ${W} ${H}`}
              preserveAspectRatio="none"
              style={style}
              aria-hidden
            >
              <defs>
                <linearGradient id={gradId} x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor={color.solid} stopOpacity="1" />
                  <stop offset="70%" stopColor={color.solid} stopOpacity="0.85" />
                  <stop offset="100%" stopColor={color.solid} stopOpacity="0.55" />
                </linearGradient>
              </defs>
              <path d={d} fill={`url(#${gradId})`} stroke={color.ring} strokeOpacity="0.5" strokeWidth="0.6" />
              <path
                d={`M 3 1.2 L ${W - 3} 1.2`}
                stroke="rgba(255,255,255,0.6)"
                strokeWidth="1"
                strokeLinecap="round"
                fill="none"
              />
            </svg>
          );
        })}
      </>
    );
  };

  return (
    <div className="relative rounded-2xl border border-primary-100 bg-gradient-to-b from-primary-50/40 via-white to-white p-3 sm:p-4 overflow-hidden">
      <div className="pointer-events-none absolute -top-6 -right-6 w-24 h-24 rounded-full bg-primary-200/30 blur-2xl" />
      <div className="pointer-events-none absolute -bottom-8 -left-6 w-24 h-24 rounded-full bg-sage-200/30 blur-2xl" />

      <div className="relative flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <span className="text-[10px] font-bold uppercase tracking-wider text-primary-700/70">Upper</span>
          <span className="text-[10px] text-neutral-400">Right ← → Left</span>
        </div>
        {totalSelected > 0 && (
          <button type="button" onClick={onClear}
            className="text-[10px] font-semibold text-neutral-400 hover:text-red-500 transition-colors">
            Clear all
          </button>
        )}
      </div>

      <div className="relative grid grid-cols-2 gap-1.5 pb-2">
        <Row nums={UPPER_R} align="end" position="upper" />
        <Row nums={UPPER_L} align="start" position="upper" />
        <MidlineConnectors jaw="upper" position="upper" />
      </div>

      <div className="relative my-3 flex items-center gap-2">
        <div className="flex-1 h-px bg-gradient-to-r from-transparent via-primary-200 to-transparent" />
        <ToothIcon className="w-4 h-4 text-primary-500 animate-tooth-bounce" />
        <div className="flex-1 h-px bg-gradient-to-r from-transparent via-primary-200 to-transparent" />
      </div>

      <div className="relative grid grid-cols-2 gap-1.5 pt-2">
        <Row nums={LOWER_R} align="end" position="lower" />
        <Row nums={LOWER_L} align="start" position="lower" />
        <MidlineConnectors jaw="lower" position="lower" />
      </div>

      <div className="relative flex items-center justify-between mt-3">
        <span className="text-[10px] font-bold uppercase tracking-wider text-primary-700/70">Lower</span>
        {totalSelected > 0 && (
          <span className="text-[11px] font-semibold text-neutral-700 bg-white border border-neutral-200 rounded-full px-2 py-0.5">
            {totalSelected} selected
          </span>
        )}
      </div>
    </div>
  );
}

function ServiceSelector({ services, line, onChange }: {
  services: Service[];
  line: ServiceLine;
  onChange: (patch: Partial<ServiceLine>) => void;
}) {
  const [open, setOpen] = useState(false);
  const isCustom = line.service === null;
  const displayName = isCustom ? (line.customName || 'Special / Custom case…') : line.service!.name;

  return (
    <div className="border border-neutral-200 rounded-xl overflow-visible bg-white">
      <div className="flex items-center gap-2 p-3 border-b border-neutral-100">
        <Stethoscope className="w-4 h-4 text-neutral-400 flex-shrink-0" />
        <div className="flex-1 relative">
          <button type="button" onClick={() => setOpen(v => !v)}
            className={`w-full flex items-center justify-between text-sm font-medium transition-colors ${line.service ? 'text-neutral-900' : 'text-neutral-400'}`}>
            <span className="truncate">{displayName}</span>
            <ChevronDown className={`w-3.5 h-3.5 transition-transform flex-shrink-0 ml-1 ${open ? 'rotate-180' : ''}`} />
          </button>
          {open && (
            <div className="absolute z-30 top-full left-0 mt-1 w-72 bg-white rounded-xl border border-neutral-200 shadow-modal overflow-auto max-h-60">
              {services.map(svc => (
                <button key={svc.id} type="button"
                  onClick={() => { onChange({ service: svc, customName: '' }); setOpen(false); }}
                  className={`w-full text-left px-3 py-2.5 hover:bg-primary-50 text-sm border-b border-neutral-100 last:border-0 ${line.service?.id === svc.id ? 'bg-primary-50' : ''}`}>
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <p className="font-semibold text-neutral-900">{svc.name}</p>
                      {svc.description && <p className="text-xs text-neutral-500 mt-0.5">{svc.description}</p>}
                    </div>
                    {(svc.price_from || svc.price_to) && (
                      <span className="text-xs font-semibold text-teal-700 flex-shrink-0 flex items-center gap-0.5">
                        <DollarSign className="w-3 h-3" />
                        {svc.price_from && svc.price_to ? `${svc.price_from}–${svc.price_to}` : svc.price_from ?? svc.price_to}
                      </span>
                    )}
                  </div>
                </button>
              ))}
              <button type="button"
                onClick={() => { onChange({ service: null }); setOpen(false); }}
                className="w-full text-left px-3 py-2.5 hover:bg-amber-50 text-sm text-amber-700 font-medium border-t border-neutral-100 flex items-center gap-2">
                <FileText className="w-3.5 h-3.5" /> Special / Custom case
              </button>
            </div>
          )}
        </div>
      </div>

      {isCustom && (
        <div className="px-3 pt-2.5 pb-0">
          <input type="text" value={line.customName} onChange={e => onChange({ customName: e.target.value })}
            placeholder="Describe the service or case…"
            className="w-full px-3 py-1.5 rounded-lg border border-amber-300 bg-amber-50 text-sm text-amber-900 placeholder-amber-400 focus:outline-none focus:ring-2 focus:ring-amber-400" />
        </div>
      )}

      {line.service && (line.service.price_from || line.service.turnaround_days) && (
        <div className="px-3 pt-2 pb-0 flex items-center gap-3 text-xs text-neutral-500">
          {(line.service.price_from || line.service.price_to) && (
            <span className="flex items-center gap-0.5 text-teal-700 font-medium">
              <DollarSign className="w-3 h-3" />
              {line.service.price_from && line.service.price_to ? `${line.service.price_from}–${line.service.price_to}` : line.service.price_from ?? line.service.price_to}
              <span className="text-neutral-400 font-normal ml-0.5">est.</span>
            </span>
          )}
          {line.service.turnaround_days && (
            <span className="flex items-center gap-0.5"><Clock className="w-3 h-3" /> {line.service.turnaround_days} days</span>
          )}
        </div>
      )}

      <div className="px-3 py-2.5">
        <textarea rows={2} value={line.notes} onChange={e => onChange({ notes: e.target.value })}
          placeholder="Notes for this service (material, instructions)…"
          className="w-full px-2.5 py-1.5 rounded-lg border border-neutral-200 text-xs text-neutral-700 placeholder-neutral-400 focus:outline-none focus:ring-1 focus:ring-primary-400 resize-none bg-neutral-50" />
      </div>
    </div>
  );
}

export default function NewOrderModal({ lab, services: servicesProp, onClose, onSuccess, prefilledCenterId, existingOrder }: Props) {
  const { profile } = useAuth();
  const isEdit = !!existingOrder;
  const accountPrefilled = prefilledCenterId === 'self' || (prefilledCenterId && prefilledCenterId !== '');
  const [fileNumber, setFileNumber] = useState(existingOrder?.file_number ?? '');
  const [patientName, setPatientName] = useState(existingOrder?.patient_name ?? '');
  const [drName, setDrName] = useState(existingOrder?.dr_name ?? (profile?.role === 'doctor' ? (profile.name ?? '') : ''));
  const [globalNotes, setGlobalNotes] = useState(existingOrder?.notes ?? '');
  const [dueDate, setDueDate] = useState(existingOrder?.due_date ? existingOrder.due_date.split('T')[0] : '');
  const [selectedDoctorId, setSelectedDoctorId] = useState('');
  const [billTo, setBillTo] = useState<'doctor' | 'center'>(existingOrder?.bill_to ?? (prefilledCenterId && prefilledCenterId !== 'self' ? 'center' : 'doctor'));
  const [shade, setShade] = useState(existingOrder?.shade ?? '');
  const [attachments, setAttachments] = useState<File[]>([]);
  const [attachmentDescs, setAttachmentDescs] = useState<Record<number, string>>({});
  const [teamDoctors, setTeamDoctors] = useState<Profile[]>([]);
  const [myCenters, setMyCenters] = useState<Profile[]>([]);
  const [sendFromId, setSendFromId] = useState<string>(prefilledCenterId && prefilledCenterId !== 'self' ? prefilledCenterId : '');
  const [tryIn, setTryIn] = useState(existingOrder?.try_in ?? false);
  const [services, setServices] = useState<Service[]>(servicesProp ?? []);
  const initialLine = newLine();
  const [lines, setLines] = useState<ServiceLine[]>([initialLine]);
  const [teethByLine, setTeethByLine] = useState<Record<string, Set<number>>>({});
  const [activeLineKey, setActiveLineKey] = useState<string>(initialLine.key);
  const [loading, setLoading] = useState(false);
  const [editLoading, setEditLoading] = useState(isEdit);
  const [error, setError] = useState('');

  useEffect(() => {
    if (!isEdit || !existingOrder) return;
    let cancelled = false;
    (async () => {
      let svcList = servicesProp ?? [];
      if (svcList.length === 0) {
        const { data } = await supabase.from('services').select('*').eq('lab_id', existingOrder.lab_id);
        svcList = data ?? [];
      }
      const { data: osData } = await supabase
        .from('order_services')
        .select('*, service:services(*)')
        .eq('order_id', existingOrder.id);
      if (cancelled) return;
      setServices(svcList);

      const newLines: ServiceLine[] = [];
      const newTeeth: Record<string, Set<number>> = {};
      for (const os of (osData ?? []) as OrderService[]) {
        const key = crypto.randomUUID();
        const raw = (os.teeth_numbers ?? '').trim();
        const bridges: number[][] = [];
        const teethSet = new Set<number>();
        if (raw) {
          for (const tok of raw.split(/,\s*/)) {
            if (tok.includes('-')) {
              const nums = tok.split('-').map(s => parseInt(s.trim())).filter(n => !isNaN(n));
              if (nums.length >= 2) { bridges.push(nums); nums.forEach(n => teethSet.add(n)); }
              else if (nums.length === 1) teethSet.add(nums[0]);
            } else {
              const n = parseInt(tok);
              if (!isNaN(n)) teethSet.add(n);
            }
          }
        }
        const matched = os.service ?? svcList.find(s => s.id === os.service_id) ?? null;
        newLines.push({
          key,
          service: matched,
          customName: matched ? '' : (os.service_name ?? ''),
          notes: os.notes ?? '',
          bridges,
          existingId: os.id,
        });
        if (teethSet.size > 0) newTeeth[key] = teethSet;
      }
      if (newLines.length > 0) {
        setLines(newLines);
        setTeethByLine(newTeeth);
        setActiveLineKey(newLines[0].key);
      }
      setEditLoading(false);
    })();
    return () => { cancelled = true; };
  }, [isEdit, existingOrder, servicesProp]);

  useEffect(() => {
    if (isEdit) return;
    if (profile?.role !== 'center') return;
    supabase.from('center_members')
      .select('doctor_profile:profiles!center_members_doctor_id_fkey(*)')
      .eq('center_id', profile.id)
      .then(({ data }) => {
        const docs = (data ?? []).map((m: { doctor_profile: Profile | Profile[] }) => Array.isArray(m.doctor_profile) ? m.doctor_profile[0] : m.doctor_profile).filter(Boolean) as Profile[];
        setTeamDoctors(docs);
      });
  }, [profile]);

  useEffect(() => {
    if (isEdit) return;
    if (profile?.role !== 'doctor') return;
    supabase.from('center_members')
      .select('center_profile:profiles!center_members_center_id_fkey(*)')
      .eq('doctor_id', profile.id)
      .then(({ data }) => {
        const centers = (data ?? []).map((m: { center_profile: Profile | Profile[] }) => Array.isArray(m.center_profile) ? m.center_profile[0] : m.center_profile).filter(Boolean) as Profile[];
        setMyCenters(centers);
      });
  }, [profile]);

  const updateLine = (key: string, patch: Partial<ServiceLine>) =>
    setLines(prev => prev.map(l => l.key === key ? { ...l, ...patch } : l));
  const removeLine = (key: string) => {
    setLines(prev => prev.filter(l => l.key !== key));
    setTeethByLine(prev => { const next = { ...prev }; delete next[key]; return next; });
    setActiveLineKey(prev => prev === key ? (lines.find(l => l.key !== key)?.key ?? '') : prev);
  };

  const toothOwner = new Map<number, string>();
  for (const [key, set] of Object.entries(teethByLine)) {
    for (const n of set) toothOwner.set(n, key);
  }
  const totalSelected = toothOwner.size;

  const colorFor = (lineKey: string) => {
    const idx = lines.findIndex(l => l.key === lineKey);
    return idx === -1 ? null : lineColor(idx);
  };

  const bridgeGroups = new Map<string, number[][]>(lines.map(l => [l.key, l.bridges]));

  const removeToothFromBridges = (lineKey: string, n: number) => {
    setLines(prev => prev.map(l => {
      if (l.key !== lineKey) return l;
      const nextBridges = l.bridges
        .map(g => g.filter(t => t !== n))
        .filter(g => g.length >= 2);
      return { ...l, bridges: nextBridges };
    }));
  };

  const toggleTooth = (n: number) => {
    if (!activeLineKey) return;
    const currentOwner = toothOwner.get(n);
    setTeethByLine(prev => {
      const next: Record<string, Set<number>> = {};
      for (const [k, v] of Object.entries(prev)) next[k] = new Set(v);
      if (currentOwner === activeLineKey) {
        next[activeLineKey].delete(n);
        if (next[activeLineKey].size === 0) delete next[activeLineKey];
      } else {
        if (currentOwner && next[currentOwner]) {
          next[currentOwner].delete(n);
          if (next[currentOwner].size === 0) delete next[currentOwner];
        }
        if (!next[activeLineKey]) next[activeLineKey] = new Set();
        next[activeLineKey].add(n);
      }
      return next;
    });
    if (currentOwner) removeToothFromBridges(currentOwner, n);
  };

  const handleFiles = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) setAttachments(prev => [...prev, ...Array.from(e.target.files!)]);
  };

  const removeAttachment = (index: number) => {
    setAttachments(prev => prev.filter((_, j) => j !== index));
    setAttachmentDescs(prev => {
      const next = { ...prev };
      delete next[index];
      const remapped: Record<number, string> = {};
      Object.keys(next).forEach(k => {
        const ki = Number(k);
        remapped[ki > index ? ki - 1 : ki] = next[ki];
      });
      return remapped;
    });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!profile) return;
    const validLines = lines.filter(l => l.service !== null || l.customName.trim());
    if (validLines.length === 0) { setError('Add at least one service or describe the case.'); return; }
    setError(''); setLoading(true);
    try {
      const firstLine = validLines[0];
      const firstService = firstLine.service;
      const allTeeth = new Set<number>();
      for (const set of Object.values(teethByLine)) for (const n of set) allTeeth.add(n);
      const teethSorted = Array.from(allTeeth).sort((a,b)=>a-b);

      const orderPayload = {
        file_number: fileNumber,
        patient_name: patientName,
        dr_name: drName,
        shade: shade || null,
        teeth_numbers: teethSorted.length ? teethSorted.join(', ') : null,
        service_id: firstService?.id ?? null,
        notes: globalNotes || null,
        due_date: dueDate || null,
        try_in: tryIn,
      };

      let orderId: string;

      if (isEdit && existingOrder) {
        const { error: updateError } = await supabase.from('orders')
          .update({ ...orderPayload, updated_at: new Date().toISOString() })
          .eq('id', existingOrder.id);
        if (updateError) throw updateError;
        orderId = existingOrder.id;

        const { data: existingRows } = await supabase.from('order_services').select('id').eq('order_id', orderId);
        const keptIds = new Set(validLines.filter(l => l.existingId).map(l => l.existingId!));
        const toDelete = (existingRows ?? []).map(r => r.id).filter(id => !keptIds.has(id));
        if (toDelete.length) await supabase.from('order_services').delete().in('id', toDelete);

        for (const l of validLines) {
          const lineTeeth = Array.from(teethByLine[l.key] ?? new Set<number>()).sort((a,b)=>a-b);
          const row = {
            order_id: orderId,
            service_id: l.service?.id ?? null,
            service_name: l.service?.name ?? l.customName.trim(),
            notes: l.notes || null,
            teeth_numbers: lineTeeth.length ? formatTeethForLine(lineTeeth, l.bridges) : null,
            is_bridge: l.bridges.length > 0,
          };
          if (l.existingId) await supabase.from('order_services').update(row).eq('id', l.existingId);
          else await supabase.from('order_services').insert(row);
        }
      } else {
        const fromId = sendFromId || profile.id;
        const { data: order, error: orderError } = await supabase.from('orders').insert({
          ...orderPayload,
          from_id: fromId,
          lab_id: lab.id,
          doctor_id: selectedDoctorId || (sendFromId ? profile.id : null),
          bill_to: billTo,
        }).select().single();
        if (orderError) throw orderError;
        orderId = order.id;

        const rows = validLines.map(l => {
          const lineTeeth = Array.from(teethByLine[l.key] ?? new Set<number>()).sort((a,b)=>a-b);
          return {
            order_id: orderId,
            service_id: l.service?.id ?? null,
            service_name: l.service?.name ?? l.customName.trim(),
            notes: l.notes || null,
            teeth_numbers: lineTeeth.length ? formatTeethForLine(lineTeeth, l.bridges) : null,
            is_bridge: l.bridges.length > 0,
          };
        });
        const { error: sErr } = await supabase.from('order_services').insert(rows);
        if (sErr) throw sErr;
      }

      if (attachments.length > 0) {
        for (const file of attachments) {
          const ext = file.name.split('.').pop();
          const path = `orders/${orderId}/${Date.now()}-${Math.random().toString(36).slice(2)}.${ext}`;
          const { data: uploaded, error: uploadError } = await supabase.storage.from('order-attachments').upload(path, file);
          if (!uploadError && uploaded) {
            const { data: { publicUrl } } = supabase.storage.from('order-attachments').getPublicUrl(path);
            await supabase.from('order_attachments').insert({
              order_id: orderId, file_name: file.name, file_url: publicUrl, file_size: file.size, mime_type: file.type,
              description: attachmentDescs[attachments.indexOf(file)]?.trim() || null,
            });
          }
        }
      }
      onSuccess();
    } catch (err: unknown) {
      setError(isEdit ? 'Failed to update this order. Please try again.' : 'Failed to create this order. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm transform-gpu flex items-center justify-center z-50 p-4 pt-[env(safe-area-inset-top,16px)] pb-[env(safe-area-inset-bottom,16px)] px-[max(env(safe-area-inset-left,16px),16px)] overflow-y-auto">
      <div className="bg-white rounded-2xl shadow-modal w-full max-w-[90vw] sm:max-w-5xl my-4 max-h-[85vh] overflow-hidden flex flex-col animate-modal-in break-words">
        <div className="flex items-center justify-between p-5 border-b border-neutral-200">
          <div>
            <h2 className="font-bold text-neutral-900">{isEdit ? 'Edit Order' : 'New Order'}</h2>
            <p className="text-sm text-neutral-500">
              {isEdit ? `#${existingOrder!.order_number} · ${lab.name}` : `To: ${lab.name}`}
            </p>
          </div>
          <button onClick={onClose} className="w-8 h-8 flex items-center justify-center rounded-lg hover:bg-neutral-100">
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="overflow-y-auto flex-1 p-5 space-y-4">
          <div className="grid grid-cols-2 gap-3">
            <Field label="File Number *">
              <input type="text" required value={fileNumber} onChange={e => setFileNumber(e.target.value)}
                placeholder="Patient file #" className={inputCls} />
            </Field>
            <Field label="Dr. Name *">
              {teamDoctors.length > 0 ? (
                <div className="space-y-1.5">
                  <select value={drName}
                    onChange={e => { const val = e.target.value; setDrName(val); const doc = teamDoctors.find(d => d.name === val); setSelectedDoctorId(doc?.id ?? ''); }}
                    className={inputCls + ' bg-white'}>
                    <option value="">Select doctor...</option>
                    {teamDoctors.map(d => <option key={d.id} value={d.name}>{d.name}</option>)}
                    <option value="__custom">Other (type name)</option>
                  </select>
                  {drName === '__custom' && (
                    <input type="text" placeholder="Enter doctor name"
                      onChange={e => { setDrName(e.target.value); setSelectedDoctorId(''); }} className={inputCls} />
                  )}
                </div>
              ) : profile?.role === 'doctor' ? (
                <input type="text" value={drName} readOnly
                  className={inputCls + ' bg-neutral-100 text-neutral-500 cursor-not-allowed'} />
              ) : (
                <input type="text" required value={drName} onChange={e => setDrName(e.target.value)}
                  placeholder="Treating doctor" className={inputCls} />
              )}
            </Field>
          </div>

          <Field label="Patient Name *">
            <input type="text" required value={patientName} onChange={e => setPatientName(e.target.value)}
              placeholder="Full patient name" className={inputCls} />
          </Field>

          {/* Order-level teeth chart with per-service colors */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="text-xs font-semibold text-neutral-600 uppercase tracking-wide flex items-center gap-1.5">
                <span className="relative inline-flex w-4 h-4">
                  <span className="absolute inset-0 bg-primary-300/50 rounded-full animate-tooth-shine" />
                  <ToothIcon className="relative w-4 h-4 text-primary-600" />
                </span>
                Teeth
              </label>
              <span className="text-xs text-neutral-400">Pick a service, then tap the teeth</span>
            </div>

            {lines.length > 0 && (
              <div className="flex flex-wrap gap-1.5 mb-2">
                {lines.map((l, idx) => {
                  const color = lineColor(idx);
                  const active = activeLineKey === l.key;
                  const displayName = l.service?.name || l.customName.trim() || `Item ${idx + 1}`;
                  const count = teethByLine[l.key]?.size ?? 0;
                  return (
                    <button
                      key={l.key}
                      type="button"
                      onClick={() => setActiveLineKey(l.key)}
                      style={active ? { backgroundColor: color.solid, borderColor: color.solid, color: '#fff', boxShadow: `0 4px 12px -2px ${color.ring}` } : { borderColor: color.solid, color: color.solid, backgroundColor: color.soft }}
                      className="flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold border transition-all duration-200 hover:-translate-y-0.5"
                    >
                      <span className="w-2 h-2 rounded-full" style={{ backgroundColor: active ? '#fff' : color.solid }} />
                      <span className="max-w-[140px] truncate">{displayName}</span>
                      {count > 0 && (
                        <span
                          className="text-[10px] font-bold rounded-full px-1.5 py-0.5"
                          style={active ? { backgroundColor: 'rgba(255,255,255,0.22)' } : { backgroundColor: '#fff', color: color.solid }}
                        >
                          {count}
                        </span>
                      )}
                      {l.bridges.length > 0 && (
                        <span className="flex items-center gap-0.5 text-[10px] font-bold" style={active ? undefined : { color: color.solid }}>
                          <Link2 className="w-3 h-3" />
                          {l.bridges.length > 1 ? `×${l.bridges.length}` : ''}
                        </span>
                      )}
                    </button>
                  );
                })}
              </div>
            )}

            <ToothChart
              toothOwner={toothOwner}
              colorFor={colorFor}
              bridgeGroups={bridgeGroups}
              onToggle={toggleTooth}
              onClear={() => setTeethByLine({})}
              totalSelected={totalSelected}
              activeColor={colorFor(activeLineKey)}
            />

            {/* Bridge grouping: within the active line, any teeth not yet in a
                bridge are "loose" (single crowns). The doctor can group those
                loose teeth into a new bridge, then keep selecting more teeth
                to build additional bridges in the same case. */}
            {activeLineKey && (() => {
              const activeLine = lines.find(l => l.key === activeLineKey);
              if (!activeLine) return null;
              const color = colorFor(activeLineKey);
              const lineTeeth = Array.from(teethByLine[activeLineKey] ?? new Set<number>());
              const bridged = new Set<number>();
              for (const g of activeLine.bridges) for (const n of g) bridged.add(n);
              const loose = lineTeeth.filter(n => !bridged.has(n)).sort((a, b) => archOrder(a) - archOrder(b));
              const canGroup = loose.length >= 2;
              return (
                <div className="mt-2 space-y-2">
                  {activeLine.bridges.length > 0 && (
                    <div className="flex flex-wrap gap-1.5">
                      {activeLine.bridges.map((g, gi) => {
                        const ordered = [...g].sort((a, b) => archOrder(a) - archOrder(b));
                        return (
                          <span
                            key={gi}
                            style={color ? { backgroundColor: color.solid, boxShadow: `0 3px 8px -2px ${color.ring}` } : undefined}
                            className="inline-flex items-center gap-1.5 pl-2.5 pr-1 py-1 rounded-full text-[11px] font-bold text-white"
                          >
                            <Link2 className="w-3 h-3" />
                            <span>Bridge {gi + 1}: {ordered.join('-')}</span>
                            <button
                              type="button"
                              onClick={() => updateLine(activeLineKey, { bridges: activeLine.bridges.filter((_, i) => i !== gi) })}
                              className="w-5 h-5 flex items-center justify-center rounded-full bg-white/20 hover:bg-white/30 transition-colors"
                              aria-label="Remove bridge"
                            >
                              <X className="w-3 h-3" />
                            </button>
                          </span>
                        );
                      })}
                    </div>
                  )}
                  <button
                    type="button"
                    disabled={!canGroup}
                    onClick={() => {
                      if (!canGroup) return;
                      updateLine(activeLineKey, { bridges: [...activeLine.bridges, loose] });
                    }}
                    style={canGroup && color ? { borderColor: color.solid, color: color.solid, backgroundColor: color.soft } : undefined}
                    className={`w-full flex items-center justify-center gap-2 px-3 py-2 rounded-xl border text-xs font-semibold transition-all ${canGroup ? 'hover:-translate-y-0.5' : 'opacity-50 cursor-not-allowed border-neutral-200 text-neutral-400 bg-neutral-50'}`}
                  >
                    <Link2 className="w-3.5 h-3.5" />
                    {canGroup
                      ? `Group ${loose.length} tooth${loose.length === 1 ? '' : (loose.length === 2 ? 'es' : 'es')} as a new bridge (${loose.join('-')})`
                      : (activeLine.bridges.length > 0
                          ? 'Pick more teeth to add another bridge'
                          : 'Pick 2+ adjacent teeth to group them as a bridge')}
                  </button>
                  {activeLine.bridges.length > 0 && loose.length > 0 && (
                    <p className="text-[11px] text-neutral-500 flex items-center gap-1.5">
                      <Sparkles className="w-3 h-3 text-primary-500" />
                      Loose teeth ({loose.join(', ')}) will be treated as single crowns unless you group them.
                    </p>
                  )}
                </div>
              );
            })()}
          </div>

          {/* Multi-service section */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="text-xs font-semibold text-neutral-600 uppercase tracking-wide">
                Services <span className="text-red-500">*</span>
              </label>
              <span className="text-xs text-neutral-400">Select lab services or describe custom cases</span>
            </div>
            {services.length === 0 && (
              <div className="flex items-center gap-2 text-sm text-amber-700 bg-amber-50 border border-amber-200 rounded-xl px-4 py-3 mb-2">
                <AlertCircle className="w-4 h-4 flex-shrink-0" />
                No services listed — use Special / Custom case for each item.
              </div>
            )}
            <div className="space-y-2.5">
              {lines.map((line, idx) => (
                <div key={line.key} className="relative">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-[10px] font-bold text-neutral-400 uppercase tracking-wider">Item {idx + 1}</span>
                    {lines.length > 1 && (
                      <button type="button" onClick={() => removeLine(line.key)}
                        className="text-red-400 hover:text-red-600 ml-auto" title="Remove">
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                  <ServiceSelector services={services} line={line} onChange={patch => updateLine(line.key, patch)} />
                </div>
              ))}
            </div>
            <button type="button" onClick={() => { const l = newLine(); setLines(prev => [...prev, l]); setActiveLineKey(l.key); }}
              className="mt-2 w-full flex items-center justify-center gap-2 py-2.5 rounded-xl border-2 border-dashed border-neutral-300 text-sm text-neutral-500 hover:border-primary-400 hover:text-primary-600 hover:bg-primary-50 transition-all">
              <Plus className="w-4 h-4" /> Add another service
            </button>
          </div>

          {/* Summary */}
          {lines.some(l => l.service || l.customName) && (
            <div className="bg-neutral-50 rounded-xl p-3 border border-neutral-200">
              <p className="text-xs font-semibold text-neutral-500 mb-2">
                Selected ({lines.filter(l=>l.service||l.customName).length})
              </p>
              <div className="space-y-1.5">
                {lines.filter(l => l.service || l.customName).map((l) => {
                  const idx = lines.findIndex(x => x.key === l.key);
                  const color = lineColor(idx);
                  const t = Array.from(teethByLine[l.key] ?? new Set<number>()).sort((a,b)=>a-b);
                  return (
                    <div key={l.key} className="flex items-start gap-2 text-xs">
                      <span className="w-2.5 h-2.5 rounded-full mt-1 flex-shrink-0" style={{ backgroundColor: color.solid }} />
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-1.5 flex-wrap">
                          <span className="font-semibold text-neutral-800">{l.service?.name ?? l.customName}</span>
                          {!l.service && <span className="text-amber-600 bg-amber-50 border border-amber-200 px-1.5 py-0.5 rounded text-[10px] font-semibold">Custom</span>}
                        </div>
                        {t.length > 0 ? (
                          <p className="mt-0.5 font-medium flex items-start gap-1.5" style={{ color: color.solid }}>
                            {l.bridges.length > 0 && <Link2 className="w-3 h-3 mt-0.5" />}
                            <span>
                              Teeth: {formatTeethForLine(t, l.bridges)}
                              {l.bridges.length > 0 && (
                                <span className="ml-1.5 text-[10px] font-semibold uppercase tracking-wide opacity-70">
                                  {l.bridges.length === 1 ? 'Bridge' : `${l.bridges.length} bridges`}
                                </span>
                              )}
                            </span>
                          </p>
                        ) : (
                          <p className="mt-0.5 text-neutral-400">No teeth assigned yet</p>
                        )}
                      </div>
                    </div>
                  );
                })}
                {totalSelected > 0 && (
                  <div className="flex items-center gap-2 text-xs pt-1.5 mt-1 border-t border-neutral-200">
                    <Sparkles className="w-3 h-3 text-primary-500" />
                    <span className="text-neutral-500">{totalSelected} tooth{totalSelected === 1 ? '' : 'ies'} across services</span>
                  </div>
                )}
              </div>
            </div>
          )}

          <div className="grid grid-cols-2 gap-3">
            <Field label="Shade">
              <div className="relative">
                <Palette className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-neutral-400 pointer-events-none" />
                <select value={shade} onChange={e => setShade(e.target.value)}
                  className={inputCls + ' bg-white pl-9'}>
                  <option value="">Select shade (optional)</option>
                  {SHADE_OPTIONS.map(s => <option key={s} value={s}>{s}</option>)}
                </select>
              </div>
            </Field>
            <Field label="Due Date">
              <input type="date" value={dueDate} onChange={e => setDueDate(e.target.value)} className={inputCls} />
            </Field>
          </div>

          <button
            type="button"
            onClick={() => setTryIn(v => !v)}
            className={`flex items-center gap-2.5 px-3 py-2.5 rounded-lg text-sm font-medium border transition-all ${
              tryIn ? 'bg-amber-50 border-amber-400 text-amber-700' : 'bg-white border-neutral-200 text-neutral-600 hover:border-neutral-300'
            }`}
          >
            <FlaskConical className={`w-4 h-4 ${tryIn ? 'text-amber-600' : 'text-neutral-400'}`} />
            <span>Try In</span>
            <span className="text-xs text-neutral-400 ml-auto">{tryIn ? 'Case needs try-in before final fit' : 'Toggle if this case needs a try-in'}</span>
          </button>

          {/* Send-from selector */}
          {!isEdit && profile?.role === 'doctor' && myCenters.length > 0 && (
            accountPrefilled ? (
              <div className="bg-primary-50 rounded-xl p-3 border border-primary-200 flex items-center gap-2.5">
                {sendFromId ? <Building2 className="w-4 h-4 text-primary-600" /> : <Wallet className="w-4 h-4 text-primary-600" />}
                <span className="text-sm font-medium text-primary-700">
                  {sendFromId
                    ? `Sending from ${myCenters.find(c => c.id === sendFromId)?.name ?? 'center'} (invoiced to center)`
                    : 'Sending from your account (cash case, invoiced to you)'}
                </span>
              </div>
            ) : (
            <div className="bg-neutral-50 rounded-xl p-3 border border-neutral-200">
              <label className="block text-xs font-semibold text-neutral-600 mb-2 uppercase tracking-wide">Send Order From</label>
              <div className="space-y-2">
                <button type="button" onClick={() => { setSendFromId(''); setBillTo('doctor'); }}
                  className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-lg text-sm font-medium border transition-all ${
                    sendFromId === '' ? 'bg-primary-50 border-primary-400 text-primary-700' : 'bg-white border-neutral-200 text-neutral-600 hover:border-neutral-300'
                  }`}>
                  <Wallet className="w-4 h-4" /><span>My account (cash case)</span>
                </button>
                {myCenters.map(c => (
                  <button key={c.id} type="button" onClick={() => { setSendFromId(c.id); setBillTo('center'); }}
                    className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-lg text-sm font-medium border transition-all ${
                      sendFromId === c.id ? 'bg-primary-50 border-primary-400 text-primary-700' : 'bg-white border-neutral-200 text-neutral-600 hover:border-neutral-300'
                    }`}>
                    <Building2 className="w-4 h-4" /><span>{c.name}</span>
                  </button>
                ))}
              </div>
              <p className="text-xs text-neutral-400 mt-2">
                {sendFromId === '' ? 'Order will be sent from your account and invoiced to you directly.' : 'Order will be sent from the selected center and invoiced to the center.'}
              </p>
            </div>
            )
          )}

          <Field label="Order Notes">
            <textarea rows={2} value={globalNotes} onChange={e => setGlobalNotes(e.target.value)}
              placeholder="Any general instructions for this order..." className={inputCls + ' resize-none'} />
          </Field>

          <div>
            <label className="block text-xs font-semibold text-neutral-600 mb-1.5 uppercase tracking-wide">Attachments</label>
            <label className="flex items-center gap-2 px-4 py-3 bg-neutral-50 border-2 border-dashed border-neutral-300 rounded-xl cursor-pointer hover:border-primary-400 hover:bg-primary-50/50 transition-all">
              <Upload className="w-4 h-4 text-neutral-400" />
              <span className="text-sm text-neutral-500">Click to upload files (X-rays, scans, PDFs, DICOM...)</span>
              <input type="file" multiple className="sr-only" onChange={handleFiles} accept="image/*,.pdf,.dcm,.stl,.ply,.obj,.zip" />
            </label>
            {attachments.length > 0 && (
              <div className="mt-2 space-y-1.5">
                {attachments.map((f, i) => {
                  const kind = fileKind(f.name, f.type);
                  return (
                    <div key={i} className="flex items-start gap-2.5 bg-neutral-50 px-3 py-2 rounded-lg text-sm border border-neutral-100">
                      <span className={`w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0 mt-0.5 ${kind.bg}`}>
                        <kind.Icon className={`w-4 h-4 ${kind.fg}`} />
                      </span>
                      <div className="flex-1 min-w-0">
                        <p className="text-neutral-800 text-sm truncate leading-tight">{f.name}</p>
                        <p className="text-[11px] text-neutral-400">{kind.label} · {formatSize(f.size)}</p>
                        <input
                          type="text"
                          placeholder="Add description (optional)"
                          value={attachmentDescs[i] ?? ''}
                          onChange={e => setAttachmentDescs(prev => ({ ...prev, [i]: e.target.value }))}
                          className="mt-1.5 w-full px-2 py-1 text-xs rounded border border-neutral-200 focus:outline-none focus:ring-1 focus:ring-primary-400 focus:border-primary-400 bg-white"
                        />
                      </div>
                      <button type="button" onClick={() => removeAttachment(i)} className="text-neutral-400 hover:text-red-500 flex-shrink-0 mt-0.5">
                        <X className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {error && (
            <div className="flex items-center gap-2 bg-red-50 border border-red-200 text-red-700 text-sm rounded-lg px-3.5 py-2.5">
              <AlertCircle className="w-4 h-4 flex-shrink-0" /> {error}
            </div>
          )}
        </form>

        <div className="p-5 border-t border-neutral-200 flex gap-3">
          <button type="button" onClick={onClose} className="flex-1 py-2.5 border border-neutral-300 text-neutral-700 font-semibold rounded-xl text-sm hover:bg-neutral-50 transition-colors">
            Cancel
          </button>
          <button type="submit" disabled={loading} onClick={handleSubmit as unknown as React.MouseEventHandler}
            className="flex-1 py-2.5 bg-primary-600 hover:bg-primary-700 disabled:bg-primary-400 text-white font-semibold rounded-xl text-sm transition-colors">
            {loading
              ? (isEdit ? 'Saving...' : 'Submitting...')
              : (isEdit
                  ? `Save Changes (${lines.filter(l=>l.service||l.customName).length} service${lines.filter(l=>l.service||l.customName).length !== 1 ? 's' : ''})`
                  : `Place Order (${lines.filter(l=>l.service||l.customName).length} service${lines.filter(l=>l.service||l.customName).length !== 1 ? 's' : ''})`)}
          </button>
        </div>
      </div>
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <label className="block text-xs font-semibold text-neutral-600 mb-1.5 uppercase tracking-wide">{label}</label>
      {children}
    </div>
  );
}

const inputCls = 'w-full px-3 py-2.5 rounded-lg border border-neutral-300 text-sm focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-transparent';

function fileKind(name: string, mime: string): { Icon: typeof FileIcon; label: string; bg: string; fg: string } {
  const ext = (name.split('.').pop() ?? '').toLowerCase();
  if (mime.startsWith('image/') || ['png','jpg','jpeg','gif','webp','heic','bmp','tiff'].includes(ext))
    return { Icon: ImageIcon, label: 'Image', bg: 'bg-blue-100', fg: 'text-blue-600' };
  if (mime === 'application/pdf' || ext === 'pdf')
    return { Icon: FileText, label: 'PDF', bg: 'bg-red-100', fg: 'text-red-600' };
  if (['dcm','dicom'].includes(ext))
    return { Icon: FileIcon, label: 'DICOM', bg: 'bg-purple-100', fg: 'text-purple-600' };
  if (['stl','ply','obj'].includes(ext))
    return { Icon: FileIcon, label: '3D Model', bg: 'bg-emerald-100', fg: 'text-emerald-600' };
  if (['zip','rar','7z'].includes(ext))
    return { Icon: FileIcon, label: 'Archive', bg: 'bg-amber-100', fg: 'text-amber-600' };
  return { Icon: FileIcon, label: ext.toUpperCase() || 'File', bg: 'bg-neutral-100', fg: 'text-neutral-600' };
}

function formatSize(bytes: number): string {
  if (bytes < 1024) return bytes + ' B';
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
  return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
}
